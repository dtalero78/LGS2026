import wixData from 'wix-data';
import { sendmessage } from 'backend/realtime.jsw';
import { panelAriel } from 'backend/ACADEMICA';
import { exportarClasesComoCsv } from 'backend/excel';
import wixLocation from 'wix-location';
import { session } from 'wix-storage';
import moment from 'moment-timezone';

let numeroId, idEstudiante, idEnPeople, idTitular;
let numeroIdGlobal, nivelGlobal;
let edad, estadoGlobal, vigenciaGlobal, idAcademicaGlobal;
let emailTrabajador;
let todosLosDatos = [];
let ultimoValorSlider = 0;
let transformedItemsGlobal = [];
let debounceTimer;
const debounceDelay = 500; // Tiempo en milisegundos
let selectedEventType = "SESSION";

// Función principal ejecutada al cargar la página
$w.onReady(async function () {

    // -----  BLOQUE DE RECONOCIMIENTO DE TOKEN LOGIN
    const tokenData = JSON.parse(session.getItem('accessToken'));
    if (tokenData) {
        const currentTime = new Date().getTime();
        // Convertir el tiempo de expiración a una fecha legible
        const expirationDate = new Date(tokenData.expiresAt);
        console.log(`El token expira el: ${expirationDate.toLocaleString()}`);
        if (currentTime > tokenData.expiresAt) {
            // Token ha expirado
            session.removeItem('accessToken');
            console.log("Token Acabado") // Eliminar el token expirado
            wixLocation.to(`/login`); // Redirigir a una página de error o login
        } else {
            // Token es válido
            // Aquí puedes continuar cargando el contenido de la página
        }
    } else {
        console.log("Token Expirado") // Eliminar el token expirado
        wixLocation.to(`/login`); // Redirigir a una página de error o login
    }
    //    

    // Buscar el nivel en ACADEMICA
    wixData.query("ACADEMICA")
        .eq("numeroId", numeroIdGlobal)
        .find()
        .then(async (result) => {
            if (result.items.length > 0) {
                nivelGlobal = result.items[0].nivel;
                console.log("Nivel cargado:", nivelGlobal);
            } else {
                console.warn("No se encontró nivel en ACADEMICA para:", numeroIdGlobal);
            }

            // Una vez ya tenemos todo, cargamos el resto de los datos
            await cargarDatosEstudianteYFinanciera();
            configurarEventosUI();
            configureTableColumns();
            queryBeneficiaries();

            emailTrabajador = session.getItem("emailTrabajador");
            console.log("📩 Email del trabajador en ficha-servicio-al-usuario:", emailTrabajador);
        })
        .catch((err) => {
            console.error("Error al buscar nivel:", err);
        });

    $w("#eventoDropdown").onChange(() => {
        const selectedDate = $w("#eventoDropdown").value;
        loadDateDropdown(selectedDate);
    });

    $w("#sesionButton").onClick(() => {
        selectedEventType = "SESSION";
        loadEventDropdown();
    });

    $w("#clubButton").onClick(() => {
        selectedEventType = "CLUB";
        loadEventDropdown();
    });

    $w('#agendarButton').onClick((event) => {
        $w('#asignarSessionBox').show()
    })

    $w('#guardar').onClick(guardarDatos);

});

$w("#search").onKeyPress((event) => {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => {
        realizarBusqueda($w("#search").value);
    }, debounceDelay);
});

// 2. INICIO QUERYS Y REPEATERS

// 2.1 INICIO BUSCADOR
function realizarBusqueda(query) {
    $w('#noExiste').hide();

    if (query.length < 3) {
        console.warn("La búsqueda requiere al menos 3 caracteres.");
        $w("#resultadoBusqueda").data = [];
        $w('#resultadoBusqueda').collapse();
        return;
    }

    $w('#loading').expand();

    // 🔍 Solo buscamos en la colección PEOPLE
    wixData.query("PEOPLE")
        .contains("numeroId", query)
        .or(wixData.query("PEOPLE").contains("primerNombre", query))
        .or(wixData.query("PEOPLE").contains("primerApellido", query))
        .or(wixData.query("PEOPLE").contains("contrato", query))
        .find()
        .then((result) => {
            if (result.items.length > 0) {
                const resultados = result.items.map(item => ({
                    _id: item._id,
                    primerNombre: item.primerNombre,
                    primerApellido: item.primerApellido,
                    segundoApellido: item.segundoApellido || "",
                    tipoUsuario: item.tipoUsuario || "N/A", // <-- NUEVO
                    numeroId: item.numeroId || "N/A"
                }));

                procesarResultados(resultados);
            } else {
                $w('#noExiste').show();
                $w('#resultadoBusqueda').collapse();
            }
        })
        .catch(err => {
            console.error("Error al realizar la búsqueda:", err);
            $w('#noExiste').show();
            $w('#resultadoBusqueda').collapse();
        })
        .finally(() => {
            $w('#loading').collapse();
        });
}

function procesarResultados(resultados) {
    $w("#resultadoBusqueda").data = resultados;
    $w("#resultadoBusqueda").expand();

    $w("#resultadoBusqueda").onItemReady(($item, itemData) => {
        const nombre = `${capitalizeFirstLetter(itemData.primerNombre)} ${capitalizeFirstLetter(itemData.primerApellido)} ${capitalizeFirstLetter(itemData.segundoApellido || "")}`;
        const tipoUsuario = itemData.tipoUsuario || "";
        const textoCompleto = `${nombre} - ${tipoUsuario}`;

        $item("#resultados").text = textoCompleto;

        $item("#resultados").onClick(() => {
            seleccionarResultado(itemData);
            console.log("Ojo info del item que se escoge", itemData._id)
            $w("#resultadoBusqueda").collapse();
            $w("#search").value = nombre;
        });
    });
}

async function seleccionarResultado(item) {
    // Logs de trazabilidad
    console.log("↳ seleccionarResultado: item.numeroId =", item.numeroId);
    console.log("↳ seleccionarResultado: item._id      =", item._id);

    // Asignamos directamente los valores que vienen del repeater
    idEnPeople = item._id;
    idEstudiante = item._id;
    numeroId = item.numeroId;
    numeroIdGlobal = item.numeroId;

    // *** Busca el registro correspondiente en ACADEMICA (relación con usuarioId = idEnPeople) ***
    const academicaResult = await wixData.query('ACADEMICA')
        .eq('usuarioId', idEnPeople)
        .find();

    if (!academicaResult.items.length) {
        console.error("No se encontró info académica para", idEnPeople);
        idAcademicaGlobal = null;
    } else {
        idAcademicaGlobal = academicaResult.items[0]._id;
        nivelGlobal = academicaResult.items[0].nivel;
        console.log("idAcademicaGlobal:", idAcademicaGlobal, "| nivelGlobal:", nivelGlobal);
    }

    // Cargamos toda la info y refrescamos la UI
    try {
        await cargarDatosEstudianteYFinanciera();
        configurarEventosUI();
        configureTableColumns();
        queryBeneficiaries();

        emailTrabajador = session.getItem("emailTrabajador");
        console.log("📩 Email del trabajador:", emailTrabajador);
    } catch (err) {
        console.error("Error en seleccionarResultado:", err);
    }
}


// Extiendo configurarEventosUI para incluir el resto de eventos
function configurarEventosUI() {
    $w('#comentarioTexto').onFocus(prepararCampoComentario);

    $w('#guardarComentarioButton').onClick(() => guardarDatos());

    // Configurar validación de fechas en tiempo real
    const inputIds = ["#fechaIngreso", "#fechaPago"];
    inputIds.forEach(inputId => {
        $w(inputId).onInput(validateDateRealTime);
    });

}

// Función asincrónica principal para cargar y manejar datos
async function cargarDatosEstudianteYFinanciera() {
    try {
        const userId = idEnPeople;

        // 1. Obtener datos del estudiante
        const studentData = await obtenerDatos('PEOPLE', '_id', userId);

        if (!studentData) {
            console.error("Estudiante no encontrado.");
            return;
        }
        // ——————————————+
        console.log("↳ cargarDatosEstudianteYFinanciera: studentData.numeroId =", studentData.numeroId);
        console.log("↳ cargarDatosEstudianteYFinanciera: studentData._id      =", studentData._id);
        // ——————————————+
        idTitular = studentData._id;
        numeroId = studentData.numeroId;
        edad = studentData.edad;
        estadoGlobal = studentData.estado;
        vigenciaGlobal = studentData.vigencia;

        // Datos básicos
        $w('#primerNombre').value = studentData.primerNombre;
        $w('#segundoNombre').value = studentData.segundoNombre;
        $w('#primerApellido').value = studentData.primerApellido;
        $w('#segundoApellido').value = studentData.segundoApellido;
        $w('#numeroId').value = studentData.numeroId;
        $w('#numeroIdText').text = studentData.numeroId;
        $w('#nombreTextBoxInfoBasica').text = `${capitalizeFirstLetter(studentData.primerNombre)} ${capitalizeFirstLetter(studentData.segundoNombre)} - ${capitalizeFirstLetter(studentData.tipoUsuario)}`;
        $w('#plataformaText').text = studentData.pais;
        $w('#celularText').text = studentData.celular;
        $w('#celularInfoBox').value = studentData.celular;
        $w('#statusText').text = studentData.estado;
        $w('#plataforma').value = studentData.plataforma;
        $w('#direccion').value = studentData.domicilio;
        $w('#email').value = studentData.email;
        $w('#numeroContrato').text = studentData.contrato;
        $w('#plan').value = studentData.plan;
        $w('#comentarioTexto').value = studentData.comentariosAdministrativo;
        $w('#fechaIngreso').value = ajustarFormatoFecha(studentData.inicioContrato);
        $w('#vigencia').value = studentData.vigencia;

        // Fechas contrato
        if (studentData.inicioContrato) {
            const fechaTexto = studentData.inicioContrato.toLocaleDateString('es-ES', { day: '2-digit', month: 'short', year: 'numeric' });
            $w('#fechaContratoText').text = fechaTexto;
            $w('#fechaContrato').value = fechaTexto;
        } else {
            $w('#fechaContratoText').text = "Sin fecha";
            $w('#fechaContrato').value = "";
        }

        // 2. Datos financieros
        const financieraData = await obtenerDatos('FINANCIERA', 'numeroId', studentData.numeroId);
        if (financieraData) {
            $w('#totalPlan').value = formatMiles(financieraData.totalPlan);
            $w('#fechaPago').value = ajustarFormatoFecha(financieraData.fechaPago);
            $w('#saldo').value = formatMiles(financieraData.saldo);
            $w('#valorCuota').value = formatMiles(financieraData.valorCuota);
            $w('#numeroCuotas').value = formatMiles(financieraData.numeroCuotas);
            $w('#inscripcionPagada').value = formatMiles(financieraData.inscripcionPagada);
            $w('#formaPago').value = financieraData.formaPago;
            $w('#plan').value = financieraData.plan;
        } else {
            console.log("Datos financieros no encontrados.");
        }

        // 3. Datos académicos
        const academicaData = await obtenerDatos('ACADEMICA', 'usuarioId', studentData._id);
        if (academicaData) {
            const nombreCompleto = `${studentData.primerNombre} ${studentData.primerApellido}`;
            const nivel = academicaData.nivel || "";
            $w('#nombres').text = `${nombreCompleto} - Nivel: ${nivel}`; // <-- aquí se incluye el nivel
            $w('#fotoPerfil').src = academicaData.foto;
            $w('#clave').value = academicaData.clave || "";
            $w('#usuario').value = academicaData.email || "";
        } else {
            console.log("Datos académicos no encontrados.");
        }

    } catch (err) {
        console.error("Error al cargar los datos:", err);
    }

    cargarComentarios();
}

function formatMiles(valor) {
    return valor ? valor.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".") : "";
}

async function cargarComentarios() {
    try {
        const studentData = await obtenerDatos('PEOPLE', 'numeroId', numeroId);
        if (!studentData || !studentData.comentarios) {
            console.error("No se encontraron comentarios o estudiante.");
            return;
        }

        todosLosDatos = studentData.comentarios.map((comment, index) => ({
            _id: `comment${index}`,
            fecha: new Date(comment.fecha).toLocaleDateString('es-ES') + ' ' + new Date(comment.fecha).toLocaleTimeString('es-ES'),
            texto: comment.comentario,
            fechaObj: new Date(comment.fecha) // Objeto Date para ordenamiento
        })).sort((a, b) => b.fechaObj - a.fechaObj); // Orden descendente

        configurarSlider();
        actualizarRepeater(0, 4); // Inicia mostrando los primeros dos elementos
    } catch (err) {
        console.error("Error al cargar y mostrar los comentarios", err);
    }
}

// SLIDER
function configurarSlider() {
    const itemsPorPagina = 4;
    $w('#slider1').max = Math.ceil(todosLosDatos.length / itemsPorPagina) - 1;
    $w('#slider1').value = 0;

    $w('#slider1').onChange((event) => {
        let paginaActual = parseInt(event.target.value, 10);
        if (paginaActual !== ultimoValorSlider) {
            actualizarRepeater(paginaActual, itemsPorPagina);
            setTimeout(() => {
                $w('#slider1').value = paginaActual;
                ultimoValorSlider = paginaActual;
            }, 100);
        }
    });
}

function actualizarRepeater(paginaActual, itemsPorPagina) {
    let startIndex = paginaActual * itemsPorPagina;
    let endIndex = startIndex + itemsPorPagina;
    let datosParaMostrar = todosLosDatos.slice(startIndex, endIndex);

    $w("#repeaterComentarios").data = datosParaMostrar;
    $w("#repeaterComentarios").forEachItem(($item, itemData, index) => {
        $item("#fechaRepeaterComentarios").text = itemData.fecha;
        $item("#comentarioRepeaterComentarios").text = itemData.texto;
    });
}

function validateDateRealTime(event) {
    const inputId = "#" + event.target.id; // Obtenemos el ID del campo de entrada que disparó el evento
    let inputDate = $w(inputId).value;
    const regexSimple = /^[0-9/]*$/;

    if (!regexSimple.test(inputDate)) {
        $w(inputId).value = inputDate.slice(0, -1);
        return; // Si el carácter introducido no es válido, salimos de la función
    }

    let parts = inputDate.split('/').filter(Boolean); // Divide la fecha en partes y elimina los elementos vacíos
    if (parts.length === 1 && parts[0].length === 2 && inputDate.endsWith('/') === false && inputDate.length < 6) {
        $w(inputId).value += '/';
    } else if (parts.length === 2 && parts[1].length === 2 && inputDate.endsWith('/') === false && inputDate.length === 5) {
        $w(inputId).value += '/';
    } else if (inputDate.length > 10) {
        $w(inputId).value = inputDate.slice(0, 10);
    }
    if (inputDate.length === 10) {
        // Actualización del regex para validar formato día/mes/año
        const regexComplete = /^(0[1-9]|[12][0-9]|3[01])\/(0[1-9]|1[0-2])\/\d{4}$/;
        if (!regexComplete.test(inputDate)) {
            console.warn("La fecha introducida en " + inputId + " no es válida");
        }
    }
}

function convertirCadenaAFecha(cadena) {
    if (!cadena) return undefined;

    // Verifica si la cadena ya está en el formato ISO 'YYYY-MM-DD'
    const regexISO = /^\d{4}-\d{2}-\d{2}$/;
    if (regexISO.test(cadena)) {
        // La cadena ya está en el formato correcto, retorna tal cual
        return cadena;
    }

    const partes = cadena.split('/');
    if (partes.length !== 3) {
        return undefined; // Retorna undefined si el formato no es correcto
    }

    const fechaFormatoISO = `${partes[2]}-${partes[1]}-${partes[0]}`;
    return fechaFormatoISO;
}

function ajustarFormatoFecha(cadena) {
    // Detecta si la entrada está en formato YYYY-MM-DD
    const regexISO = /^\d{4}-\d{2}-\d{2}$/;
    if (regexISO.test(cadena)) {
        // Convierte de YYYY-MM-DD a DD/MM/YYYY
        const [year, month, day] = cadena.split('-');
        return `${day}/${month}/${year}`;
    }
    // Si la entrada ya está en DD/MM/YYYY o cualquier otro caso, retorna sin cambios
    return cadena;
}

// Función para obtener datos de la base de datos
async function obtenerDatos(coleccion, campo, valor) {
    const result = await wixData.query(coleccion).eq(campo, valor).find();
    return result.items.length > 0 ? result.items[0] : null;
}

// Función para preparar el campo de comentario con la fecha actual
function prepararCampoComentario() {
    let comentarioActual = $w('#comentarioTexto').value;
    let fechaActual = new Date();
    let fechaTexto = `${fechaActual.toLocaleDateString('es-ES', { day: '2-digit', month: 'short', year: 'numeric' })} ${fechaActual.toLocaleTimeString('es-ES')}`;
    console.log("fecha comentario", fechaTexto)
    // Añadimos la fecha solo si el campo está vacío para evitar sobre escribir
    if (!comentarioActual.trim()) {
        $w('#comentarioTexto').value = `${fechaTexto}:\n` + " " + `${emailTrabajador}\n`;
    }
}

function parseFechaEspanolAFechaISO(fechaTexto) {
    const meses = {
        'ene': '01',
        'feb': '02',
        'mar': '03',
        'abr': '04',
        'may': '05',
        'jun': '06',
        'jul': '07',
        'ago': '08',
        'sep': '09',
        'oct': '10',
        'nov': '11',
        'dic': '12'
    };

    const partes = fechaTexto.split(' ');
    const dia = partes[0];
    const mes = meses[partes[1].toLowerCase()];
    const anio = partes[2];
    const hora = partes[3];

    const fechaISO = `${anio}-${mes}-${dia}T${hora}`;
    return new Date(fechaISO);
}

function capitalizeFirstLetter(string) {
    if (!string || typeof string !== 'string') return '';
    return string.charAt(0).toUpperCase() + string.slice(1).toLowerCase();
}

function configureTableColumns() {
    $w("#tablaBeneficiarios").columns = [
        { "id": "nombre", "dataPath": "nombreCompleto", "label": "Nombre", "width": 300, "visible": true, "type": "string" },
        { "id": "documento", "dataPath": "numeroId", "label": "Documento", "width": 200, "visible": true, "type": "string" },
        { "id": "tipoUsuario", "dataPath": "tipoUsuario", "label": "Tipo Usuario", "width": 200, "visible": true, "type": "string" }
    ];
}

async function queryBeneficiaries() {
    if (!idTitular) {
        console.error("idTitular is undefined");
        return;
    }

    // Primero, determinamos si el idTitular corresponde a un TITULAR o a un BENEFICIARIO
    const userData = await wixData.query('PEOPLE')
        .eq("_id", idTitular)
        .find();

    if (userData.items.length === 0) {
        console.error("Usuario no encontrado.");
        return;
    }

    const user = userData.items[0];

    // Si el usuario es BENEFICIARIO, buscamos y mostramos los datos del TITULAR (padre)
    if (user.tipoUsuario === "BENEFICIARIO") {
        const parentData = await wixData.query('PEOPLE')
            .eq("_id", user.titularId)
            .find();

        if (parentData.items.length > 0) {
            populateBeneficiaryTable($w('#tablaBeneficiarios'), parentData.items);
            $w('#tablaBeneficiarios').show()
        } else {
            console.error("Datos del titular (padre) no encontrados.");
        }
    }
    // Si el usuario es TITULAR, buscamos y mostramos todos los BENEFICIARIOS (hijos)
    else if (user.tipoUsuario === "TITULAR") {
        const childrenData = await wixData.query('PEOPLE')
            .eq("titularId", idTitular)
            .find();

        if (childrenData.items.length > 0) {
            populateBeneficiaryTable($w('#tablaBeneficiarios'), childrenData.items);
        } else {
            console.error("No se encontraron beneficiarios para este titular.");
        }
    }
}

function populateBeneficiaryTable($item, items) {
    const datosTabla = items.map(item => ({
        "nombreCompleto": [capitalizeFirstLetter(item.primerNombre), capitalizeFirstLetter(item.primerApellido), capitalizeFirstLetter(item.segundoApellido)].filter(Boolean).join(" "),
        "numeroId": item.numeroId,
        "tipoUsuario": item.tipoUsuario,
        "_id": item._id
    }));
    $w("#tablaBeneficiarios").rows = datosTabla;
    $w('#tablaBeneficiarios').show()
    $w('#loading').hide()
    $w('#tablaAsistencia').hide()

}

$w('#gestionNuevaButton').onClick((event) => {
    $w('#loading').show()
    $w('#tablaAsistencia').hide()
    $w('#exportarExcel').hide()
    $w('#grupoInformaciones').hide()
    $w('#boxOnHold').hide();
    $w('#grupoComentarios').hide()
    queryBeneficiaries();

})

$w('#registroClasesButton').onClick(async () => {
    $w('#loading').show();
    $w('#tablaBeneficiarios').hide();
    $w('#grupoInformaciones').hide();
    $w('#boxOnHold').hide();
    $w('#grupoComentarios').hide();

    // <<<<<< USA idAcademicaGlobal para buscar en CLASSES >>>>>>
    console.log("↳ registroClasesButton: idAcademicaGlobal =", idAcademicaGlobal);

    const clasesResult = await wixData.query("CLASSES")
        .eq("idEstudiante", idAcademicaGlobal) // <-- ESTE ES EL CAMBIO CLAVE
        .ne("step", "WELCOME")
        .find();

    if (!clasesResult.items.length) {
        console.warn("No hay clases para este estudiante:", idAcademicaGlobal);
        $w('#loading').hide();
        return;
    }
    try {
        // Panel Ariel también usa el idAcademicaGlobal y el nivelGlobal:
        const { formattedItems } = await panelAriel(idAcademicaGlobal, nivelGlobal);

        transformedItemsGlobal = formattedItems.map(item => ({
            fechaEvento: moment.utc(item.fechaEvento).local().format('D MMM YYYY, hh:mm A'),
            tipoEvento: item.tipoEvento,
            nivel: item.nivel,
            step: item.step,
            asistencia: item.asistencia,
            participacion: item.participacion,
            advisorName: item.advisorName,
            advisorId: item.advisorId,
            linkZoom: item.linkZoom
        }));

        $w("#tablaAsistencia").columns = [
            { id: "fechaEvento", dataPath: "fechaEvento", label: "Fecha", width: 200, visible: true, type: "string" },
            { id: "tipoEvento", dataPath: "tipoEvento", label: "Tipo", width: 120, visible: true, type: "string" },
            { id: "nivel", dataPath: "nivel", label: "Nivel", width: 90, visible: true, type: "string" },
            { id: "step", dataPath: "step", label: "Step", width: 210, visible: true, type: "string" },
            { id: "asistencia", dataPath: "asistencia", label: "Asistió", width: 100, visible: true, type: "string" },
            { id: "participacion", dataPath: "participacion", label: "Participó", width: 100, visible: true, type: "string" },
            { id: "advisorName", dataPath: "advisorName", label: "Asesor", width: 180, visible: true, type: "string" },
            { id: "linkZoom", dataPath: "linkZoom", label: "Zoom", width: 280, visible: true, type: "link" }
        ];

        $w("#tablaAsistencia").rows = transformedItemsGlobal;
        $w('#tablaAsistencia').show();
        $w('#exportarExcel').show();

    } catch (err) {
        console.error("❌ Error al obtener registros de clases:", err);
    } finally {
        $w('#loading').hide();
    }
});


$w('#exportarExcel').onClick(async () => {
    if (transformedItemsGlobal.length === 0) {
        console.warn("No hay datos para exportar.");
        return;
    }

    try {
        const fileUrl = await exportarClasesComoCsv(transformedItemsGlobal);
        console.log("✅ Archivo exportado:", fileUrl);
        wixLocation.to(fileUrl); // descarga directa
    } catch (error) {
        console.error("Error al exportar a Excel:", error);
    }
});

$w('#closeMaterial').onClick((event) => {
    $w('#boxOnHold').hide();
})

$w('#comentariosButton').onClick((event) => {
    $w('#grupoComentarios').show();
    $w('#boxOnHold').hide();
    $w('#tablaAsistencia').hide()
    $w('#exportarExcel').hide();
    $w('#grupoInformaciones').hide()
    $w('#tablaBeneficiarios').hide()

})

$w('#closeComentarios').onClick((event) => {
    $w('#grupoComentarios').hide();
    $w('#escribirComentarioBox').hide();
})

$w('#infoGralButton').onClick((event) => {
    $w('#grupoInformaciones').show();
    $w('#tablaAsistencia').hide()
    $w('#exportarExcel').hide()
    $w('#boxOnHold').hide();
    $w('#grupoComentarios').hide()
    $w('#tablaBeneficiarios').hide()
})

$w('#cerrarAsignarSesiones').onClick((event) => {
    $w('#asignarSessionBox').hide()
})

async function loadEventDropdown() {
    try {
        const today = new Date();
        const days = [];
        for (let i = 0; i < 5; i++) {
            const d = new Date();
            d.setDate(today.getDate() + i);
            days.push(d);
        }

        const options = days.map(d => {
            return {
                label: d.toLocaleDateString('es-ES', { weekday: 'long', day: 'numeric', month: 'short' }),
                value: d.toISOString().split('T')[0] // 'YYYY-MM-DD'
            };
        });

        $w("#eventoDropdown").options = options;
        $w("#diaDropdown").options = [];
    } catch (error) {
        console.error("Error al cargar eventoDropdown:", error);
    }
}

async function loadDateDropdown(selectedDay) {
    try {
        const academicaData = await obtenerDatos('ACADEMICA', 'usuarioId', idTitular);
        const nivel = academicaData?.nivel;
        console.log("Nivel extraído de ACADEMICA:", nivel);

        if (!nivel) {
            console.warn("Nivel no definido en ACADEMICA.");
            return;
        }

        if (!selectedEventType) {
            console.warn("Tipo de evento no definido.");
            return;
        }

        const zonaUsuario = Intl.DateTimeFormat().resolvedOptions().timeZone;
        const startOfDay = moment.tz(selectedDay, zonaUsuario).startOf('day').toDate();
        const endOfDay = moment.tz(selectedDay, zonaUsuario).endOf('day').toDate();

        const results = await wixData.query("CALENDARIO")
            .eq("tituloONivel", nivel)
            .eq("evento", selectedEventType)
            .ge("dia", startOfDay)
            .le("dia", endOfDay)
            .ascending("dia")
            .find();

        // Evaluamos si hay algún jump
        const jumps = [5, 10, 15, 20, 25, 30, 35, 40, 45];
        const eventosConJump = results.items.filter(item => {
            const match = item.nombreEvento?.toString().match(/(\d+)/);
            const stepNumber = match ? parseInt(match[1]) : null;
            return stepNumber && jumps.includes(stepNumber);
        });

        const eventosAUsar = (eventosConJump.length > 0) ? eventosConJump : results.items;

        const options = [];
        const detallesPorId = {};

        for (const item of eventosAUsar) {
            const hora = new Date(item.dia).toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' });

            let labelEvento = "";

            if (selectedEventType === "CLUB") {
                labelEvento = item.nombreEvento || "Club sin nombre";
            } else {
                const nombreEvento = item.nombreEvento || "Evento sin nombre";
                const stepLabel = getStepLabel(nombreEvento);
                labelEvento = stepLabel;
            }

            const zoom = item.linkZoom || "Sin Zoom";

            let nombreAdvisor = "Sin asesor";
            if (item.advisor) {
                const advisorData = await obtenerDatos("ADVISORS", "_id", item.advisor);
                if (advisorData) {
                    nombreAdvisor = `${capitalizeFirstLetter(advisorData.primerNombre)} ${capitalizeFirstLetter(advisorData.primerApellido)}`;
                }
            }

            const labelDropdown = `${hora} - ${labelEvento}`;
            const labelDetalles = `${hora} - ${labelEvento}\nAsesor: ${nombreAdvisor}\nZoom: ${zoom}`;

            options.push({
                label: labelDropdown,
                value: item._id
            });

            detallesPorId[item._id] = labelDetalles;
        }

        $w("#diaDropdown").options = options;

        $w("#diaDropdown").onChange(() => {
            const selected = $w("#diaDropdown").value;
            const detalles = detallesPorId[selected];
            if (detalles) {
                $w("#detallesEvento").text = detalles;
            }
        });

    } catch (error) {
        console.error("Error al cargar diaDropdown:", error);
    }
}

$w("#guardarEvento").onClick(async () => {
    try {
        const selectedDateId = $w("#diaDropdown").value;
        if (!selectedDateId) {
            console.warn("No se ha seleccionado una hora");
            return;
        }

        // 1. Obtener el evento seleccionado del calendario
        const calendarioData = await wixData.query("CALENDARIO")
            .eq("_id", selectedDateId)
            .find();

        if (calendarioData.items.length === 0) {
            console.warn("No se encontró el evento seleccionado");
            return;
        }

        const eventData = calendarioData.items[0];

        // 2. Obtener los datos del estudiante desde PEOPLE
        const studentData = await obtenerDatos("PEOPLE", "_id", idTitular) ||
            await obtenerDatos("PEOPLE", "_id", idEstudiante) ||
            await obtenerDatos("PEOPLE", "numeroId", numeroId);

        if (!studentData) {
            console.error("No se encontró información del estudiante.");
            return;
        }

        // 3. Obtener el usuarioId correcto desde ACADEMICA (referencia a PEOPLE)
        const academicaData = await obtenerDatos("ACADEMICA", "numeroId", studentData.numeroId);
        const idEstudianteFinal = academicaData?.usuarioId || studentData._id;

        // 4. Crear el nuevo registro para CLASSES
        const newClass = {
            fechaEvento: eventData.dia,
            idEstudiante: academicaData?._id || null,
            primerNombre: studentData.primerNombre,
            primerApellido: studentData.primerApellido,
            nivel: eventData.tituloONivel,
            numeroId: studentData._id,
            tipoEvento: eventData.evento,
            step: eventData.nombreEvento,
            idEvento: eventData._id,
            advisor: eventData.advisor,
            celular: studentData.celular,
        };

        // 5. Insertar en CLASSES y BOOKING
        await wixData.insert("CLASSES", newClass);
        await wixData.insert("BOOKING", newClass);

        console.log("✅ Evento agendado correctamente:", newClass);
        $w("#guardarEvento").label = "Agendado ✔";
        $w('#asignarSessionBox').hide();
        setTimeout(() => $w("#guardarEvento").label = "Guardar evento", 2000);
    } catch (error) {
        $w('#guardarEvento').label = "¡Error!";
        console.error("❌ Error al guardar evento:", error);
    }
});

function getStepLabel(nombreEvento) {
    const jumps = [5, 10, 15, 20, 25, 30, 35, 40, 45];

    if (!nombreEvento) return "Sin Step";

    const match = nombreEvento.toString().match(/(\d+)/);
    const stepNumber = match ? parseInt(match[1]) : null;

    if (stepNumber && jumps.includes(stepNumber)) {
        return `Jump (Step ${stepNumber})`;
    } else if (stepNumber) {
        return `Step ${stepNumber}`;
    } else {
        return nombreEvento;
    }
}

async function guardarDatos() {
    // Creamos un objeto donde almacenaremos solo los cambios
    let cambiosInfoBasica = {};

    // Asignar valores a cambiosInfoBasica
    cambiosInfoBasica.segundoNombre = $w('#segundoNombre').value ? $w('#segundoNombre').value : undefined;
    cambiosInfoBasica.segundoApellido = $w('#segundoApellido').value ? $w('#segundoApellido').value : undefined;
    cambiosInfoBasica.primerNombre = $w('#primerNombre').value ? $w('#primerNombre').value : undefined;
    cambiosInfoBasica.primerApellido = $w('#primerApellido').value ? $w('#primerApellido').value : undefined;
    cambiosInfoBasica.plataforma = $w('#plataforma').value ? $w('#plataforma').value : undefined;
    cambiosInfoBasica.numeroId = $w('#numeroId').value ? $w('#numeroId').value : undefined;
    cambiosInfoBasica.inicioContrato = $w('#fechaIngreso').value ? $w('#fechaIngreso').value : undefined;
    cambiosInfoBasica.email = $w('#email').value ? $w('#email').value : undefined;
    cambiosInfoBasica.elTraining = $w('#usuario').value ? $w('#usuario').value : undefined;
    cambiosInfoBasica.domicilio = $w('#direccion').value ? $w('#direccion').value : undefined;
    cambiosInfoBasica.celular = $w('#celularInfoBox').value ? $w('#celularInfoBox').value : undefined;
    // Verificar y asignar nueva vigencia
    const nuevaVigencia = $w('#vigencia').value;
    const vigenciaOriginal = vigenciaGlobal;

    if (nuevaVigencia) {
        cambiosInfoBasica.vigencia = nuevaVigencia;

        // Si cambió la vigencia, agregar " CON EXTENSIÓN" al estado
        if (nuevaVigencia !== vigenciaOriginal) {
            const estadoOriginal = estadoGlobal || "";
            if (!estadoOriginal.includes("CON EXTENSIÓN")) {
                cambiosInfoBasica.estado = estadoOriginal + " CON EXTENSIÓN";
            }
        }
    }

    // Log para depuración
    console.log("Cambios en info básica antes de eliminar indefinidos:", cambiosInfoBasica);

    // Eliminar propiedades indefinidas antes de proceder
    Object.keys(cambiosInfoBasica).forEach(key => cambiosInfoBasica[key] === undefined && delete cambiosInfoBasica[key]);

    // Verificar si hay cambios
    if (Object.keys(cambiosInfoBasica).length === 0) {
        console.log("No hay cambios para actualizar.");
        return;
    }

    console.log("Cambios en info básica después de eliminar indefinidos:", cambiosInfoBasica);

    // Convertir fechaIngreso a formato adecuado
    console.log("Antes de la conversión de fechaIngreso: ", $w('#fechaIngreso').value);
    cambiosInfoBasica.inicioContrato = convertirCadenaAFecha($w('#fechaIngreso').value);
    console.log(cambiosInfoBasica.plataforma);

    // Actualizar registro en la base de datos
    try {
        let resultados = await wixData.query('PEOPLE')
            .eq("_id", idTitular)
            .find();

        if (resultados.items.length > 0) {
            let datosActualizados = resultados.items[0];
            datosActualizados = { ...datosActualizados, ...cambiosInfoBasica };

            console.log("Datos actualizados antes de guardar:", datosActualizados);

            // Extraer la fecha y el comentario del campo de texto
            let valorCompleto = $w('#comentarioTexto').value;

            if (valorCompleto) {
                if (!valorCompleto.includes(':\n')) {
                    console.error('Formato de comentario incorrecto');
                } else {
                    let [fechaConEtiqueta, comentario] = valorCompleto.split(':\n');
                    let fechaTexto = fechaConEtiqueta.trim();
                    let fecha = parseFechaEspanolAFechaISO(fechaTexto);

                    let nuevoComentario = {
                        fecha: fecha,
                        comentario: comentario.trim()
                    };

                    // Añadir comentario
                    datosActualizados.comentarios = datosActualizados.comentarios || [];
                    datosActualizados.comentarios.push(nuevoComentario);
                }
            }

            // Actualizar el registro
            await wixData.update("PEOPLE", datosActualizados);
            console.log("Registro actualizado correctamente");

            // Publicar mensaje en el canal
            sendmessage({
                type: "update", // tipo de mensaje para controlar la lógica en el suscriptor
                message: "Datos actualizados"
            });
            cargarDatosEstudianteYFinanciera();
            // Limpiar el campo de comentario después de guardar
            $w('#comentarioTexto').value = "";
            $w('#guardar').label = "¡GUARDADO!"

            // Actualizar campo aprobación para todos los registros con el mismo numeroId, excepto el actual
            await actualizarAprobacionParaTodosLosRegistrosExceptoActual(idTitular, cambiosInfoBasica.aprobacion);

        } else {
            throw new Error("Registro no encontrado.");
        }

    } catch (err) {
        console.error("Error al actualizar el registro:", err);
    }

}

async function actualizarAprobacionParaTodosLosRegistrosExceptoActual(idTitularActual, nuevaAprobacion) {
    try {
        const numeroId = $w('#numeroId').value;

        // Obtener todos los registros con el mismo numeroId excepto el actual
        const resultados = await wixData.query('PEOPLE')
            .eq('numeroId', numeroId)
            .ne('_id', idTitularActual) // Excluir el registro actual
            .find();

        // Actualizar el campo aprobacion para cada registro sin eliminar otros datos
        const actualizaciones = resultados.items.map(async (registro) => {
            let datosActualizados = { ...registro, aprobacion: nuevaAprobacion };
            return wixData.update('PEOPLE', datosActualizados);
        });

        await Promise.all(actualizaciones);
        console.log(`Campo aprobación actualizado para todos los registros duplicados con numeroId ${numeroId}`);
    } catch (err) {
        console.error("Error al actualizar el campo aprobación para todos los registros duplicados:", err);
    }
}