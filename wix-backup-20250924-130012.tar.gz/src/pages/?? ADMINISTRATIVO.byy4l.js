import wixData from 'wix-data';
import wixRealtimeFrontend from 'wix-realtime-frontend';
import wixStorage from 'wix-storage';
import wixWindow from 'wix-window';
import { session } from 'wix-storage';
import wixLocation from 'wix-location';


let debounceTimer;
const debounceDelay = 500;
let pageSize = 100;
let currentStudentPage = 0;
let isOpen = false;

$w.onReady(function () {

// -----  BLOQUE DE RECONOCIMIENTO DE TOKEN LOGIN
    const tokenData = JSON.parse(session.getItem('accessToken'));
    if (tokenData) {
        const currentTime = new Date().getTime();
        // Convertir el tiempo de expiración a una fecha legible
        const expirationDate = new Date(tokenData.expiresAt);
        console.log(`El token expira el: ${expirationDate.toLocaleString()}`);
        if (currentTime > tokenData.expiresAt) {
            // Token ha expirado
            session.removeItem('accessToken');
            console.log("Token Acabado") // Eliminar el token expirado
            wixLocation.to(`/login`); // Redirigir a una página de error o login
        } else {
            // Token es válido
            // Aquí puedes continuar cargando el contenido de la página
        }
    } else {
        console.log("Token Expirado") // Eliminar el token expirado
        wixLocation.to(`/login`); // Redirigir a una página de error o login
    }
//


$w('#createStepButton').target = "_blank"

    initializePagination();
    configureTableColumns();
        suscribeToUpdates();

 // INICIO BUSCADOR
    $w("#search").onKeyPress((event) => {
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(() => {
            realizarBusqueda($w("#search").value);
        }, debounceDelay);
    });
    // FIN BUSCADOR
    
});


const suscribeToUpdates = () => {
    const channel = { "name": "updateChannel" };
    wixRealtimeFrontend.subscribe(channel, (message, channel) => {
        if (message.payload.type === "update") {
            queryStudents(currentStudentPage);
        }
    })
    .then((id) => {});
};


function realizarBusqueda(query) {
    $w('#todosLosRepeaters').collapse();
    $w('#noExiste').hide();


    // Si el input está vacío o contiene menos de 3 caracteres, resetea el estado sin buscar
    if (query.length < 3) {
        $w("#resultadoBusqueda").data = []; // Limpia los datos del repetidor
        $w('#resultadoBusqueda').collapse(); // Esconde el repetidor
        return; // Sale de la función para no ejecutar una búsqueda
    }

    // A partir de aquí, maneja el caso en que hay una búsqueda válida con 3 o más caracteres
    $w('#loading').expand();

    // Promesa para consultar la base de datos PROSPECTOS
    wixData.query("PEOPLE")
        .contains("primerNombre", query)
        .or(wixData.query("PEOPLE").contains("primerApellido", query))
        .or(wixData.query("PEOPLE").contains("celular", query))
        .find()
        .then(prospectosResults => {

            const combinedResults = [];

            // Procesar resultados de PROSPECTOS
            prospectosResults.items.forEach(item => {
    combinedResults.push({
        _id: item._id,
        primerNombre: item.primerNombre,
        primerApellido: item.primerApellido,
        segundoApellido: item.segundoApellido || "",
        tipoUsuario: item.tipoUsuario
    });
            });

            if (combinedResults.length > 0) {
                $w("#resultadoBusqueda").data = combinedResults;
                $w('#resultadoBusqueda').forEachItem(($item, itemData, index) => {
                    // Configuración del texto que muestra los resultados de búsqueda
                    $item("#resultados").text = `${capitalizeFirstLetter(itemData.primerNombre)} ${capitalizeFirstLetter(itemData.primerApellido)} ${itemData.segundoApellido ? capitalizeFirstLetter(itemData.segundoApellido) : ''} ${itemData.tipoUsuario}`;


   $item('#verFichaBuscador').link = "/ficha-administrativa/" + itemData._id
   $item('#verFichaBuscador').target = "_blank"

                });
                $w('#resultadoBusqueda').expand(); // Muestra el repetidor con los resultados
            } else {
                $w('#noExiste').show();
                $w('#resultadoBusqueda').collapse(); // Si no hay resultados, también esconde el repetidor
            }

            $w('#loading').collapse(); // Esconde el indicador de carga
        })
        .catch(err => {
            console.error("Error al realizar la búsqueda", err);
            $w('#loading').collapse();
            $w('#noExiste').show();
            $w("#resultadoBusqueda").data = [];
            $w('#resultadoBusqueda').collapse(); // Si hay un error, también esconde el repetidor
        });
}




function initializePagination() {
    queryStudents(currentStudentPage);
    $w("#backButtonRepeaterXGestionar").onClick(() => paginateStudents(-1));
    $w("#nextButtonRepeaterXGestionar").onClick(() => paginateStudents(1));
}

function paginateStudents(direction) {
    const newPage = currentStudentPage + direction;
    if (newPage >= 0) {
        currentStudentPage = newPage;
        queryStudents(currentStudentPage);
    }
}

function queryStudents(page) {
    wixData.query('PEOPLE')
        .eq("tipoUsuario", "TITULAR")
        .isEmpty("aprobacion")
        .limit(pageSize)
        .skip(page * pageSize)
        .find()
        .then(res => {
            setupRepeater(res.items);
            updatePaginationButtons('#backStudents', '#nextStudents', res.totalCount, currentStudentPage, pageSize);
        });
}

function setupRepeater(items) {
    $w('#repeaterPorGestionar').data = items;
    $w('#repeaterPorGestionar').forEachItem(($item, itemData) => {
        setupItem($item, itemData);
    });
}

function setupItem($item, itemData) {
    
    const fullName = [itemData.primerNombre, itemData.primerApellido, itemData.segundoApellido].filter(Boolean).join(" ");
    $item('#fechaRepeaterXGestionar').text = new Date(itemData._createdDate).toLocaleDateString();
    $item('#numeroIdRepeaterXGestionar').text = itemData.numeroId;
    $item('#nombreRepeaterXGestionar').text = fullName;
    $item('#paisRepeaterXGestionar').text = itemData.plataforma;

   $item('#irAFichaButton').link = "/ficha-administrativa/" + itemData._id
   $item('#irAFichaButton').target = "_blank"



    $item('#mostrarBeneficiariosButton').onClick(() => {
        if (isOpen) {
            $item('#tablaBeneficiarios').collapse();
            isOpen = false;
        } else {
            queryBeneficiaries($item, itemData._id);
            isOpen = true;
            $item("#tablaBeneficiarios").expand(); // Expande la tabla solo cuando se abre por primera vez
        }
    });
}

function configureTableColumns() {
    $w("#tablaBeneficiarios").columns = [
        { "id": "nombre", "dataPath": "nombreCompleto", "label": "Nombre", "width": 200, "visible": true, "type": "string" },
        { "id": "documento", "dataPath": "numeroId", "label": "Documento", "width": 120, "visible": true, "type": "string" },
        { "id": "tipoUsuario", "dataPath": "tipoUsuario", "label": "Tipo Usuario", "width": 120, "visible": true, "type": "string" }
    ];
}

function queryBeneficiaries($item, titularId) {
    wixData.query('PEOPLE')
        .eq("titularId", titularId)
        .find()
        .then((results) => populateBeneficiaryTable($item, results.items))
        .catch((err) => console.error(err));
}

function populateBeneficiaryTable($item, items) {
    const datosTabla = items.map(item => ({
         "nombreCompleto": [
        capitalizeFirstLetter(item.primerNombre || ""),
        capitalizeFirstLetter(item.segundoNombre || ""),
        capitalizeFirstLetter(item.primerApellido || ""),
        capitalizeFirstLetter(item.segundoApellido || "")
    ].filter(Boolean).join(" "), // Filtra valores vacíos o nulos
    "numeroId": item.numeroId || "N/A", // Maneja valores no definidos
    "tipoUsuario": item.tipoUsuario || "N/A", // Maneja valores no definidos
    "_id": item._id
    }));
    $item("#tablaBeneficiarios").rows = datosTabla;

    $w("#tablaBeneficiarios").onRowSelect((event) => {
        const selectedRowData = event.rowData;
        redirectUserProfile(selectedRowData._id, selectedRowData.numeroId);
    });



}

function redirectUserProfile(userId, numeroId) {
    wixStorage.local.setItem('userId', userId); // Guarda userId en el almacenamiento local
    wixStorage.local.setItem('numeroId', numeroId);
wixLocation.to("/ficha-administrativa/" + userId)
    // Guarda numeroId en el almacenamiento local
}


function updatePaginationButtons(backButtonId, nextButtonId, totalCount, currentPage, pageSize) {
    const maxPage = Math.ceil(totalCount / pageSize) - 1;

    // Habilitar o deshabilitar botones basándose en la página actual
    $w(backButtonId).enabled = currentPage > 0;
    $w(nextButtonId).enabled = currentPage < maxPage;

    // Mostrar u ocultar botones basándose en si hay más ítems de los que se pueden mostrar en una página
    const showPagination = totalCount > pageSize;
    $w(backButtonId).hidden = !showPagination;
    $w(nextButtonId).hidden = !showPagination;
}

function capitalizeFirstLetter(string) {
    if (!string) return ""; // Devuelve una cadena vacía si el valor es nulo o undefined
    return string.charAt(0).toUpperCase() + string.slice(1).toLowerCase();
}
