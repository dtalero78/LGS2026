import wixData from 'wix-data';
import { sendTextMessage } from 'backend/WHP';

let currentItemId; // Variable para guardar el ID del registro actual
let numeroId;
let celular;

$w.onReady(() => {
    // Evento del botón "buscarButton" para cargar los datos
    $w("#buscarButton").onClick(() => {
        const searchValue = $w("#buscar").value;

        if (!searchValue) {
            $w("#buscar").placeholder = "Por favor, ingresa un valor para buscar";
            return;
        }

        // Buscar el registro en la base de datos PEOPLE
        wixData.query("PEOPLE")
       
            .contains("numeroId", searchValue)
            .or(wixData.query("PEOPLE").contains("contrato", searchValue))
			     .eq("tipoUsuario", "BENEFICIARIO")
            .find()
            .then((results) => {
                if (results.items.length > 0) {
                    const item = results.items[0];
                    currentItemId = item._id; // Guardar el ID del registro encontrado
                    numeroId = item.numeroId;
                    celular = item.celular;
					console.log(results)

                    // Asignar los valores a los campos
                    $w("#primerNombre").value = item.primerNombre || "";
                    $w("#segundoNombre").value = item.segundoNombre || "";
                    $w("#primerApellido").value = item.primerApellido || "";
                    $w("#segundoApellido").value = item.segundoApellido || "";
                    $w("#plataforma").value = item.plataforma || "";
                    $w("#celular").value = item.celular || "";
                    $w("#email").value = item.email || "";
                    $w("#direccion").value = item.domicilio || "";
                    $w("#step").value = item.step || "";
					$w('#comentarios').value = item.comentariosEjecutivo || "";
                    const dropdownOptions = $w("#plataforma").options;

                    // Agregar la opción encontrada si no existe
                    if (!dropdownOptions.some(option => option.value === item.plataforma)) {
                        dropdownOptions.push({
                            label: item.plataforma,
                            value: item.plataforma
                        });
                        $w("#plataforma").options = dropdownOptions;
                    }

                    // Seleccionar el valor en el dropdown
                    $w("#plataforma").value = item.plataforma;
                } else {
                    $w("#buscar").value = "";
                    $w("#buscar").placeholder = "No se encontraron resultados";
                }

            })
            .catch((error) => console.error("Error en la búsqueda:", error));
    });

    // Evento del botón "guardarButton" para actualizar el registro y crear en ACADEMICA
    $w("#guardarButton").onClick(() => {
        if (!currentItemId) {
            console.log("No hay un registro cargado para actualizar.");
            return;
        }

        // Obtener el registro completo de PEOPLE antes de actualizar
        wixData.get("PEOPLE", currentItemId)
            .then((currentData) => {
                // Actualizar solo los campos modificados
                const updatedData = {
                    ...currentData, // Conservar todos los campos existentes
                    primerNombre: $w("#primerNombre").value || currentData.primerNombre,
                    segundoNombre: $w("#segundoNombre").value || currentData.segundoNombre,
                    primerApellido: $w("#primerApellido").value || currentData.primerApellido,
                    segundoApellido: $w("#segundoApellido").value || currentData.segundoApellido,
                    plataforma: $w("#plataforma").value || currentData.plataforma,
                    celular: $w("#celular").value || currentData.celular,
                    email: $w("#email").value || currentData.email,
                    domicilio: $w("#direccion").value || currentData.domicilio,
                    step: $w("#step").value || currentData.step,
					comentariosEjecutivo: $w('#comentarios').value || currentData.comentariosEjecutivo
					
                };

                // Actualizar el registro en PEOPLE
                return wixData.update("PEOPLE", updatedData);
            })
            .then(() => {
                console.log("Registro en PEOPLE actualizado exitosamente.");

                // Crear un nuevo registro en ACADEMICA
                const newAcademicaData = {
                    idEstudiante: currentItemId,
                    numeroId: numeroId,
                    primerNombre: $w("#primerNombre").value,
                    primerApellido: $w("#primerApellido").value,
                    step: $w("#step").value,
                    celular: $w("#celular").value
                };

                return wixData.insert("ACADEMICA", newAcademicaData);
            })
            .then((result) => {
                console.log("Nuevo registro creado en ACADEMICA:", result);

                // Enviar WhatsApp con el _id del nuevo registro
                envioWhp(result._id);

                setTimeout(() => $w("#guardarButton").label = "Guardar", 2000);
            })
            .catch((error) => {
                console.error("Error al actualizar o insertar datos:", error);
            });
    });
});

function envioWhp(newAcademicaId) {
    $w('#loading').show();
    let message = `Hola: 👋\n\n*¡Completa tu registro de la plataforma LetsGoSpeak!* 🎉\n\nSigue este enlace:\n\nhttps://www.lgsplataforma.com/nuevo-usuario/${newAcademicaId}`;
    enviarContrato(celular, message);
}

function enviarContrato(celular, message) {
    console.log("enviando a whp", celular, message);
    sendTextMessage(celular, message)
        .then(response => {
            $w('#guardarButton').label = "MENSAJE ENVIADO A WHATSAPP";
            $w('#loading').hide();
            console.log("Mensaje enviado con éxito", response);
        })
        .catch(err => {
            console.error("Error al enviar mensaje", err);
        });
}