import wixRealtimeFrontend from 'wix-realtime-frontend';
import wixData from 'wix-data';


$w.onReady(function () {
    // Llamar a la función para suscribirse a actualizaciones en tiempo real
    suscribeToUpdates();

    // Cargar conversaciones iniciales
    cargarConversaciones();
});

// Función para suscribirse al canal y manejar mensajes en tiempo real
const suscribeToUpdates = () => {
    const channel = { "name": "chatsWhp" }; // Nombre del canal
    wixRealtimeFrontend.subscribe(channel, (message) => {
            const payload = message.payload;
            console.log("Mensaje recibido:", message); // Verifica que el mensaje se recibe correctamente
            if (payload && payload.type === "updateComplete") {
                console.log("Ejecutando cargarConversaciones...");
                cargarConversaciones(); // Recargar conversaciones
            } else {
                console.log("Tipo de mensaje no coincide: ", payload?.type);
            }
        })
        .then((id) => {
            console.log("Suscripción a actualizaciones exitosa con ID:", id);
        })
        .catch(err => {
            console.error("Error en la suscripción a actualizaciones:", err);
        });
};

// Función para cargar y renderizar las conversaciones
const cargarConversaciones = () => {
    wixData.query("WHP")
        .find()
        .then((results) => {
            if (results.items.length > 0) {
                const conversations = results.items.map(conversation => {
                    const mensajes = Array.isArray(conversation.mensajes) ? conversation.mensajes : [];
                    const lastMessage = mensajes.length > 0 ?
                        mensajes[mensajes.length - 1].mensaje :
                        "Sin mensajes";

                    return {
                        _id: conversation._id,
                        nombre: conversation.nombre || "Usuario sin nombre",
                        userId: conversation.userId,
                        mensaje: lastMessage,
                        mensajesArray: mensajes,
                        stopBot: conversation.stopBot || false,
                        updatedDate: new Date(conversation._updatedDate)
                    };
                });

                conversations.sort((a, b) => {
                    const dateA = new Date(a.updatedDate).getTime();
                    const dateB = new Date(b.updatedDate).getTime();
                    return dateB - dateA;
                });

                $w("#chats").data = conversations;

                $w("#chats").onItemReady(($item, itemData) => {
    $item("#nombre").text = itemData.nombre;
    $item("#userId").text = itemData.userId;
    $item("#mensaje").text = itemData.mensaje;

    $item("#onOff").checked = !itemData.stopBot;

    $item("#onOff").onChange(() => {
        const newStopBot = !$item("#onOff").checked;
        console.log(`Actualizando stopBot de ${itemData._id} a:`, newStopBot);

        wixData.get("WHP", itemData._id)
            .then((currentItem) => {
                currentItem.stopBot = newStopBot;
                return wixData.update("WHP", currentItem);
            })
            .then(() => {
                console.log("stopBot actualizado con éxito.");
            })
            .catch((error) => {
                console.error("Error al actualizar stopBot:", error);
            });
    });

    $item("#mensaje").onClick(() => {
        ejecutarLogicaMensaje(itemData);
    });

    // Ejecutar automáticamente para el primer elemento
    if (itemData._id === results.items[0]._id) {
        ejecutarLogicaMensaje(itemData);
    }
});

// Función para ejecutar la lógica del clic en el mensaje
const ejecutarLogicaMensaje = (itemData) => {
    $w("#detalleConversacion").show();
    const mensajesOrdenados = itemData.mensajesArray.sort((a, b) => {
        const fechaA = new Date(a.timestamp).getTime();
        const fechaB = new Date(b.timestamp).getTime();
        return fechaB - fechaA;
    });

    const mensajesFormateados = mensajesOrdenados.map(mensajeObj => {
        const from = mensajeObj.from || "Desconocido";
        const mensaje = mensajeObj.mensaje || "Mensaje vacío";
        const timestamp = mensajeObj.timestamp ?
            new Date(mensajeObj.timestamp).toLocaleString("es-CO", { dateStyle: "short", timeStyle: "short" }) :
            "Fecha desconocida";

        return `<div style="font-size: 13px; line-height: 1.5; font-family: 'IBM Plex Sans Regular', sans-serif;">
            <b>[${from} - ${timestamp}]</b>:<br>
            ${mensaje}
        </div>`;
    }).join("<br><br>");

    $w("#detalleConversacion").expand();
    $w("#conversacion").html = mensajesFormateados || "Sin mensajes en esta conversación.";

    const nombre = itemData.nombre || "Nombre no disponible";
    const celular = itemData.userId || "Celular no disponible";
    $w("#datos").text = `${nombre} | ${celular}`;
};

            } else {
                console.log("No se encontraron conversaciones.");
                $w("#chats").data = [];
            }
        })
        .catch((error) => {
            console.error("Error al cargar las conversaciones:", error);
        });
};


$w.onReady(function () {
    const $inputTextoEnviar = $w("#textoEnviar");
    const $botonEnviar = $w("#botonEnviar");
    const $backButton = $w("#backButton");
    const $detalleConversacion = $w("#detalleConversacion");

    let celularActual = null; // Variable para almacenar el número de teléfono actual

    // Evento al hacer clic en el botón de enviar
    $botonEnviar.onClick(() => {
        const messageBody = $inputTextoEnviar.value;
        const datosTexto = $w("#datos").text;

        // Asignar el número de celular actual desde "datosTexto"
        const match = datosTexto.match(/\d+/g);
        celularActual = match ? match.join("") : null;

        console.log("Número destino:", celularActual);
        console.log("Mensaje:", messageBody);

        if (celularActual && messageBody) {
            sendTextMessage(celularActual, messageBody)
                .then(response => {
                    console.log("Mensaje enviado con éxito:", response);
                    $inputTextoEnviar.value = ""; // Limpiar el campo de texto después de enviar
                })
                .catch(error => console.error("Error al enviar el mensaje:", error));
        } else {
            console.error("Número o mensaje no válidos.");
        }


    });

    // Evento al hacer clic en el botón "backButton"
    $backButton.onClick(() => {
        $detalleConversacion.collapse();
        console.log("Caja oculta");
    });
});








export function sendTextMessage(toNumber, messageBody) {
    const url = "https://gate.whapi.cloud/messages/text";
    const headers = {
        "accept": "application/json",
        "authorization": "Bearer VSyDX4j7ooAJ7UGOhz8lGplUVDDs2EYj",
        "content-type": "application/json"
    };
    const postData = {
        "typing_time": 0,
        "to": toNumber,
        "body": messageBody
    };

    // Realizar la solicitud POST
    return fetch(url, {
            method: 'POST',
            headers: headers,
            body: JSON.stringify(postData)
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`Error en la solicitud: ${response.status} ${response.statusText}`);
            }
            return response.json();
        })
        .then(json => {
            console.log("Mensaje enviado con éxito:", json);

        });
}

$w('#enviar').onClick((event) => {
console.log("enviando")
	   const celular = $w("#celular").value; // Obtener el número ingresado en el campo de texto
        const mensaje = "Hola. Te escribimos de LGS"; // Mensaje predeterminado

        // Validar que el campo no esté vacío
        if (!celular || !/^\d+$/.test(celular)) {
            console.error("Por favor, ingresa un número de celular válido.");
            $w("#celular").value = ""; // Opcional: limpiar el campo
            return;
        }

        // Llamar a la función para enviar el mensaje
        sendTextMessage(celular, mensaje)
            .then(() => {
                console.log(`Mensaje enviado con éxito a ${celular}`);
                $w("#celular").value = ""; // Limpiar el campo de texto tras el envío exitoso
            })
            .catch(error => {
                console.error("Error al enviar el mensaje:", error);
            });
        
})