import wixData from 'wix-data';
import wixLocation from 'wix-location';
import { session } from 'wix-storage';
import { v4 as uuidv4 } from 'uuid';
import wixWindow from 'wix-window';
import { enviarClaveOlvidada } from 'backend/auth';

// Definiciones de tipos para mejor documentación del código
/**
 * @typedef {Object} AuthResult
 * @property {boolean} success - Indica si la autenticación fue exitosa
 * @property {Object|null} user - Datos del usuario autenticado
 * @property {string|null} database - Base de datos donde se encontró el usuario
 * @property {string|null} token - Token generado para la sesión
 */

/**
 * @typedef {Object} PersonStatus
 * @property {boolean} isValid - Indica si el estado de la persona es válido
 * @property {string} [message] - Mensaje de error si no es válido
 */

// Configuración de la aplicación
const CONFIG = {
    TOKEN_EXPIRATION_HOURS: 2,
    DATABASES: ["ACADEMICA", "ADVISORS", "PEOPLE", "COMERCIAL", "COBRANZA", "EQUIPOADMINISTRATIVO"],
    MESSAGES: {
        EMPTY_FIELDS: "Por favor, completa ambos campos.",
        INVALID_CREDENTIALS: "Usuario o clave incorrectos.",
        CONTRACT_FINISHED: "La vigencia de tu contrato ha finalizado",
        CONTRACT_ON_HOLD: "Tu contrato está congelado",
        NO_COBRANZA_PERMISSIONS: "No tienes permisos de cobranza.",
        UNKNOWN_ROLE: "Rol o base de datos no reconocido."
    }
};

// Clase para manejar la autenticación
class AuthManager {
    constructor() {
        this.setupEventListeners();
        this.initializeUI();
    }

    initializeUI() {
        // Para cuando haya anuncios
        //wixWindow.openLightbox("ANUNCIOS");
        
        this.setRightsText();
        this.hideElements();
    }

    setRightsText() {
        const currentYear = new Date().getFullYear();
        const rightsText = `${currentYear} LGS, All rights reserved. |`;
        $w("#derechos").text = rightsText;
    }

    hideElements() {
        $w("#errorText").hide();
        $w('#loading').hide();
    }

    setupEventListeners() {
        $w("#loginButton").onClick(() => this.handleLogin());
        $w("#olvidoClave").onClick(() => this.handleForgotPassword());
        $w("#inputUsuario, #inputClave").onKeyPress(event => {
            if (event.key === "Enter") {
                this.handleLogin();
            }
        });
    }

    async handleLogin() {
        const credentials = this.getCredentials();
        
        if (!this.validateCredentials(credentials)) {
            return;
        }

        this.showLoading();
        
        try {
            const authResult = await this.authenticateUser(credentials);
            
            if (authResult.success && authResult.user && authResult.database && authResult.token) {
                await this.processAuthResult(authResult);
            } else {
                this.showError(CONFIG.MESSAGES.INVALID_CREDENTIALS);
            }
        } catch (error) {
            console.error("Error durante el login:", error);
            this.showError("Ha ocurrido un error. Por favor, inténtalo de nuevo.");
        }
    }

    async handleForgotPassword() {
        const email = $w("#inputUsuario").value?.trim();
        
        if (!email) {
            this.showError("Por favor ingresa tu email en el campo de usuario.");
            return;
        }

        this.showLoading();
        
        try {
            const result = await enviarClaveOlvidada(email);
            
            if (result.success) {
                this.showSuccess(result.message);
            } else {
                this.showError(result.message);
            }
        } catch (error) {
            console.error("Error enviando email:", error);
            this.showError("Ha ocurrido un error. Por favor, inténtalo de nuevo.");
        }
    }

    getCredentials() {
        return {
            usuario: $w("#inputUsuario").value?.trim() || "",
            clave: $w("#inputClave").value?.trim() || ""
        };
    }

    validateCredentials({ usuario, clave }) {
        if (!usuario || !clave) {
            this.showError(CONFIG.MESSAGES.EMPTY_FIELDS);
            return false;
        }
        return true;
    }

    /**
     * Autentica un usuario en las bases de datos disponibles
     * @param {Object} credentials - Credenciales del usuario
     * @returns {Promise<AuthResult>} Resultado de la autenticación
     */
    async authenticateUser({ usuario, clave }) {
        for (const databaseName of CONFIG.DATABASES) {
            try {
                const result = await this.queryDatabase(databaseName, usuario, clave);
                
                if (result.length > 0) {
                    return {
                        success: true,
                        user: result[0],
                        database: databaseName,
                        token: this.generateToken()
                    };
                }
            } catch (error) {
                console.error(`Error consultando ${databaseName}:`, error);
            }
        }
        
        return { 
            success: false,
            user: null,
            database: null,
            token: null
        };
    }

    async queryDatabase(databaseName, usuario, clave) {
        const result = await wixData.query(databaseName)
            .eq("email", usuario)
            .eq("clave", clave)
            .find();
        
        return result.items;
    }

    generateToken() {
        const token = uuidv4();
        const expirationTime = new Date().getTime() + (CONFIG.TOKEN_EXPIRATION_HOURS * 60 * 60 * 1000);
        const tokenData = { token, expiresAt: expirationTime };
        
        session.setItem('accessToken', JSON.stringify(tokenData));
        return token;
    }

    async processAuthResult({ user, database, token }) {
        const usuario = $w("#inputUsuario").value.trim();
        const router = new RouteManager(user, database, token, usuario);
        
        await router.redirect();
    }

    showLoading() {
        $w('#loading').show();
        $w("#errorText").hide();
    }

    showError(message) {
        $w("#errorText").text = message;
        $w("#errorText").show();
        $w('#loading').hide();
    }

    showSuccess(message) {
        $w("#errorText").text = message;
        $w("#errorText").show();
        $w('#loading').hide();
    }
}

// Clase para manejar el enrutamiento según el rol y base de datos
class RouteManager {
    constructor(user, database, token, usuario) {
        this.user = user;
        this.database = database;
        this.token = token;
        this.usuario = usuario;
        this.authManager = new AuthManager();
    }

    async redirect() {
        const handler = this.getHandler();
        await handler();
    }

    getHandler() {
        const handlers = {
            'ACADEMICA': () => this.handleAcademica(),
            'ADVISORS': () => this.handleAdvisors(),
            'EQUIPOADMINISTRATIVO': () => this.handleEquipoAdministrativo(),
            'PEOPLE': () => this.handlePeople(),
            'COMERCIAL': () => this.handleComercial(),
            'COBRANZA': () => this.handleCobranza()
        };

        return handlers[this.database] || (() => {
            this.authManager.showError(CONFIG.MESSAGES.UNKNOWN_ROLE);
        });
    }

    async handleAcademica() {
        if (!this.user.usuarioId) {
            this.redirectTo(`/student/${this.user._id}`);
            return;
        }

        try {
            const personStatus = await this.checkPersonStatus(this.user.usuarioId);
            
            if (personStatus.isValid) {
                this.redirectTo(`/student/${this.user._id}`);
            } else {
                this.authManager.showError(personStatus.message);
            }
        } catch (error) {
            console.error("Error consultando PEOPLE:", error);
            this.redirectTo(`/student/${this.user._id}`);
        }
    }

    /**
     * Verifica el estado de una persona en la base de datos PEOPLE
     * @param {string} usuarioId - ID del usuario
     * @returns {Promise<PersonStatus>} Estado de la persona
     */
    async checkPersonStatus(usuarioId) {
        const result = await wixData.query("PEOPLE")
            .eq("_id", usuarioId)
            .find();

        if (result.items.length === 0) {
            return { isValid: true };
        }

        const persona = result.items[0];
        
        if (persona.estado === "FINALIZADA") {
            return { isValid: false, message: CONFIG.MESSAGES.CONTRACT_FINISHED };
        }
        
        if (persona.estado === "ON HOLD") {
            return { isValid: false, message: CONFIG.MESSAGES.CONTRACT_ON_HOLD };
        }

        return { isValid: true };
    }

    handleAdvisors() {
        const route = this.user.rol === "COORDINADOR" 
            ? "/dash-academico" 
            : "/dash-academico-advisor";
        
        this.redirectTo(route);
    }

    handleEquipoAdministrativo() {
        if (this.user.rol === "administrativo") {
            this.redirectTo("/dash-administrativo");
        } else {
            this.authManager.showError(CONFIG.MESSAGES.UNKNOWN_ROLE);
        }
    }

    handlePeople() {
        this.authManager.showError(`Login exitoso en PEOPLE. Token: ${this.token}`);
    }

    handleComercial() {
        const routes = {
            'ADMINISTRATIVO': '/administrativo',
            'Executive Training': '/dash-crm-asesor',
            'SERVICIO': '/dash-servicio'
        };

        const route = routes[this.user.rol] || '/dash-comercial';
        this.redirectTo(route);
        
        this.authManager.showError(`Login exitoso en COMERCIAL. Token: ${this.token}`);
    }

    handleCobranza() {
        if (this.user.rol === "COBRANZA") {
            this.redirectTo("/cobranza");
        } else {
            this.authManager.showError(CONFIG.MESSAGES.NO_COBRANZA_PERMISSIONS);
        }
    }

    redirectTo(path) {
        const url = `${path}?email=${encodeURIComponent(this.usuario)}&token=${this.token}`;
        wixLocation.to(url);
    }
}

// Inicialización de la aplicación
$w.onReady(() => {
    new AuthManager();
});