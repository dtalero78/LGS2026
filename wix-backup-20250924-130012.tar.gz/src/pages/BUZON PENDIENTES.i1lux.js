import wixData from 'wix-data';
import wixWindow from 'wix-window';
import wixLocation from 'wix-location';
import { getDownloadUrl } from 'backend/GETURLFILES';



let archivosSubidos = [];

$w.onReady(function () {
    // Configurar botones de subida
    $w('#uploadPdfButton').onChange(() => {
        const files = $w('#uploadPdfButton').value;
        if (files.length > 0) {
            archivosSubidos.push({
                uploadButtonId: '#uploadPdfButton',
                name: files[0].name,
                type: 'PDF'
            });
            actualizarRepetidor();
        }
    });

    $w('#uploadVideoButton').onChange(() => {
        const files = $w('#uploadVideoButton').value;
        if (files.length > 0) {
            archivosSubidos.push({
                uploadButtonId: '#uploadVideoButton',
                name: files[0].name,
                type: 'Video'
            });
            actualizarRepetidor();
        }
    });

    $w('#botonSubir').onClick(subirDatos);

    // Cargar solicitudes al iniciar
    cargarSolicitudes();
});

// 🟡 Actualizar vista de archivos subidos
function actualizarRepetidor() {
    $w('#archivos').data = archivosSubidos.map((file, index) => ({
        _id: String(index),
        nombreArchivo: file.name,
        tipoArchivo: file.type
    }));

    $w('#archivos').onItemReady(($item, itemData, index) => {
        $item('#nombre').text = `${itemData.nombreArchivo} (${itemData.tipoArchivo})`;
        $item('#caneca').onClick(() => eliminarArchivo(index));
    });
}

function eliminarArchivo(index) {
    archivosSubidos.splice(index, 1);
    actualizarRepetidor();
}

// 🟢 Subir archivos y guardar en base de datos
export async function subirDatos() {
    $w('#loading').show();

    const solicitante = $w('#dropdownSolicitante').value;
    const descripcion = $w('#descripcion').value;

    if (!solicitante || !descripcion) {
        console.warn("Por favor llena todos los campos obligatorios.");
        $w('#loading').hide();
        return;
    }

    let urlsFinales = [];

    try {
        // Si hay archivos, súbelos
        if (archivosSubidos.length > 0) {
            for (const archivo of archivosSubidos) {
                const uploadButton = $w(archivo.uploadButtonId);
                if (uploadButton.value.length > 0) {
                    const uploadedFiles = await uploadButton.uploadFiles();
                    uploadedFiles.forEach((uploadedFile) => {
                       if (uploadedFile.mediaId) {
    urlsFinales.push(uploadedFile.mediaId); // ✅ guardas el ID interno
}

                    });
                }
            }
        }

        // Crear objeto a guardar
        const nuevoRegistro = {
            solicitante,
            descripcion
        };

        if (urlsFinales.length > 0) {
            nuevoRegistro.adjuntos = urlsFinales;
        }

        await wixData.insert('SoporteTecnico', nuevoRegistro);
        console.log("✅ Datos guardados correctamente.");

        limpiarFormulario();
        cargarSolicitudes();

    } catch (error) {
        console.error("❌ Error al subir archivos o guardar el registro:", error);
    } finally {
        $w('#loading').hide();
    }
}


function limpiarFormulario() {
    $w('#dropdownSolicitante').value = undefined;
    $w('#descripcion').value = "";
    archivosSubidos = [];
    actualizarRepetidor();
    $w('#uploadPdfButton').reset();
    $w('#uploadVideoButton').reset();
}

// 🟣 Cargar solicitudes guardadas en el repetidor
async function cargarSolicitudes() {
    try {
        const results = await wixData.query('SoporteTecnico')
            .descending('_createdDate')
            .find();

        $w('#solicitudesRepeater').data = results.items.map(item => {
            console.log("🟢 Campo 'completado' del item:", item._id, "→", item.completada);

            return {
                _id: item._id,
                fecha: formatFecha(item._createdDate),
                solicitante: item.solicitante || '',
                descripcion: item.descripcion || '',
                respuesta: item.respuesta || '',
                adjuntos: item.adjuntos || [],
                completado: item.completada || false
            };
        });

        $w('#solicitudesRepeater').onItemReady(($item, itemData) => {

            $item('#fecha').text = itemData.fecha;
            $item('#solicitante').text = itemData.solicitante;
            $item('#descripcionList').text = itemData.descripcion;
            $item('#respuesta').text = itemData.respuesta;

            // Ocultar todos los campos por defecto
            for (let i = 1; i <= 5; i++) {
                $item(`#archivo${i}`).collapse();
            }

            // Mostrar hasta 5 archivos
            const maxAdjuntos = Math.min(itemData.adjuntos.length, 5);
            for (let i = 0; i < maxAdjuntos; i++) {
                const url = itemData.adjuntos[i];
                const nombre = decodeURIComponent(url.split('/').pop());
                const campoArchivo = $item(`#archivo${i + 1}`);
                campoArchivo.text = nombre;
                campoArchivo.style.cursor = 'pointer';
                campoArchivo.expand();

campoArchivo.onClick(async () => {
    try {
        const downloadUrl = await getDownloadUrl(url); // url = media reference como image://...
        wixLocation.to(downloadUrl);
        console.log("esta",downloadUrl)
    } catch (error) {
        console.error("❌ Error al obtener la URL de descarga:", error);
    }
});

            }

            if (itemData.completado) {
                $item('#completada').show();
            } else {
                $item('#completada').hide();
            }
        });

    } catch (error) {
        console.error("❌ Error al cargar solicitudes:", error);
    }
}


// 🔍 Funciones auxiliares
function esVideo(url) {
    return url.toLowerCase().endsWith('.mp4') || url.includes('/video/');
}

function formatFecha(dateObj) {
    const f = new Date(dateObj);
    return `${f.getDate().toString().padStart(2, '0')}/${(f.getMonth() + 1)
        .toString().padStart(2, '0')}/${f.getFullYear()}`;
}

$w('#crear').onClick((event) => {
    $w('#solicitud').show()
})

$w('#cerrar').onClick((event) => {
    $w('#solicitud').hide()
})