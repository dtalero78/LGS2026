
$w.onReady(function () {
let currentPage = 1; // Página inicial

	$w('#audioPlayer10').play()
    // Asegúrate de que sólo la primera página esté visible al cargar
    mostrarPagina(currentPage);

    // Evento para el botón "adelante"
    $w('#adelante').onClick(() => {
        if (currentPage < 4) {
            currentPage++;
            mostrarPagina(currentPage);
        }
    });

    // Evento para el botón "atras"
    $w('#atras').onClick(() => {
        if (currentPage > 1) {
            currentPage--;
            mostrarPagina(currentPage);
        }
    });
});

function mostrarPagina(pagina) {
    // Colapsar todas las páginas
    $w('#1').collapse();
    $w('#2').collapse();
    $w('#3').collapse();
    $w('#4').collapse();

    // Expandir la página actual
    switch (pagina) {
        case 1:
            $w('#1').expand();
            break;
        case 2:
            $w('#2').expand();
            break;
        case 3:
            $w('#3').expand();
            break;
        case 4:
            $w('#4').expand();
            break;
    }
    
    // Deshabilitar botones si es necesario
    $w('#adelante').enable();
    $w('#atras').enable();

    if (pagina === 1) {
        $w('#atras').disable(); // Deshabilita "atras" en la primera página
    } else if (pagina === 4) {
        $w('#adelante').disable(); // Deshabilita "adelante" en la última página
    }
}
