import wixData from 'wix-data';
import wixLocation from 'wix-location';

async function loadClasses(filterStartDate = null, filterEndDate = null, asistenciaFilter = [], advisorFilter = null) {
    try {
        let query = wixData.query("CLASSES");

        if (filterStartDate && filterEndDate) {
            query = query.between("fechaEvento", filterStartDate, filterEndDate);
        }

        if (advisorFilter) {
            query = query.eq("advisor", advisorFilter);
        }

        if (asistenciaFilter.length > 0) {
            if (!(asistenciaFilter.includes("Si") && asistenciaFilter.includes("No"))) {
                query = query.eq("asistencia", asistenciaFilter.includes("Si"));
            }
        }

        const result = await query.find();

        if (result.items.length > 0) {
            const advisorIds = [...new Set(result.items.map(item => item.advisor).filter(id => id))];
            const advisors = await getAdvisorNames(advisorIds);

            const clases = result.items.map(item => ({
                idEvento: item._id,
                fechaEvento: formatFecha(item.fechaEvento),
                tipoEvento: item.tipoEvento,
                nivel: item.nivel,
                step: item.step,
                nombreCompleto: `${item.primerNombre || ""} ${item.primerApellido || ""}`.trim(),
                advisorName: advisors[item.advisor] || "No asignado",
                asistencia: item.asistencia === true ? "Sí" : "No",
                participacion: item.participacion ? "Sí" : "No",
            }));

            clases.sort((a, b) => a.asistencia.localeCompare(b.asistencia));

            console.log("Clases filtradas:", clases);
            updateTable(clases);
        } else {
            console.warn("No se encontraron clases con los filtros aplicados.");
            updateTable([]);
        }
    } catch (error) {
        console.error("Error al cargar las CLASSES:", error);
    }
}






// Función para obtener los nombres de los advisors por sus IDs
async function getAdvisorNames(advisorIds) {
    if (advisorIds.length === 0) return {};

    try {
        const result = await wixData.query("ADVISORS")
            .hasSome("_id", advisorIds)
            .find();

        const advisorMap = {};
        result.items.forEach(advisor => {
            advisorMap[advisor._id] = `${advisor.primerNombre} ${advisor.primerApellido}`;
        });

        return advisorMap;
    } catch (error) {
        console.error("Error al obtener nombres de advisors:", error);
        return {};
    }
}

// ✅ Función para formatear la fecha
function formatFecha(fecha) {
    if (!fecha) return "";
    const date = new Date(fecha);
    return date.toLocaleString("es-CO", {
        month: "short",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
        hour12: true,
    }).replace(",", "");
}

// ✅ Evento para filtrar datos cuando se presiona el botón
function setupFilter() {
    $w("#filterButton").onClick(() => {
        const startDate = $w("#startDatePicker").value;
        const endDate = $w("#endDatePicker").value;
        const selectedAdvisor = $w("#advisorsDropdown").value;

        if (!startDate || !endDate) {
            console.warn("Debe seleccionar ambas fechas para filtrar.");
            return;
        }

        console.log(`Filtrando entre ${startDate} y ${endDate}, Advisor: ${selectedAdvisor}`);
        loadClasses(startDate, endDate, [], selectedAdvisor);
    });
}


// Llamar a la función al cargar la página
$w.onReady(() => {
    loadClasses(); // Cargar datos sin filtro inicialmente
    setupFilter();
    loadAdvisorsDropdown(); // Configurar evento del botón de filtro
});

// Función para actualizar la tabla en la interfaz
function updateTable(clases) {
    $w("#tabla").columns = [
        { "id": "idEvento", "dataPath": "idEvento", "label": "ID Evento", "width": 150, "visible": false, "type": "string" },
        { "id": "fechaEvento", "dataPath": "fechaEvento", "label": "Fecha", "width": 200, "visible": true, "type": "string" },
        { "id": "tipoEvento", "dataPath": "tipoEvento", "label": "Tipo", "width": 100, "visible": true, "type": "string" },
        { "id": "nivel", "dataPath": "nivel", "label": "Nivel", "width": 80, "visible": true, "type": "string" },
        { "id": "step", "dataPath": "step", "label": "Step", "width": 110, "visible": true, "type": "string" },
        { "id": "nombreCompleto", "dataPath": "nombreCompleto", "label": "Usuario", "width": 180, "visible": true, "type": "string" }, // ✅ Cambiado aquí
        { "id": "advisorName", "dataPath": "advisorName", "label": "Advisor", "width": 150, "visible": true, "type": "string" },
        { "id": "asistencia", "dataPath": "asistencia", "label": "Asistió", "width": 70, "visible": true, "type": "string" },
        { "id": "participacion", "dataPath": "participacion", "label": "Participó", "width": 70, "visible": true, "type": "string" },
    ];
    $w("#tabla").rows = clases;
}


$w('#button1').onClick((event) => {
       
        console.log("Exportando CSC.");
        wixLocation.to("https://www.lgsplataforma.com/_functions/exportCSV")
    });   


async function loadAdvisorsDropdown() {
    try {
        const result = await wixData.aggregate("CLASSES")
            .group("advisor")
            .run();

        // Obtener los IDs únicos de los advisors
        const advisorIds = result.items.map(item => item.advisor).filter(id => id);

        if (advisorIds.length === 0) {
            console.warn("No se encontraron advisors en las clases.");
            return;
        }

        // Obtener los nombres de los advisors
        const advisors = await getAdvisorNames(advisorIds);

        // Convertir a formato compatible con el dropdown
        const dropdownOptions = Object.keys(advisors).map(id => ({
            label: advisors[id], // Nombre del advisor
            value: id            // ID del advisor
        }));

        // Agregar una opción "Todos" al inicio
        dropdownOptions.unshift({ label: "Todos", value: "" });

        // Actualizar el dropdown en la interfaz
        $w("#advisorsDropdown").options = dropdownOptions;
    } catch (error) {
        console.error("Error al cargar los advisors en el dropdown:", error);
    }
}
