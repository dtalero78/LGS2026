import wixData from 'wix-data';
import wixWindow from 'wix-window';


// Se ejecuta cuando el documento estÃ¡ listo
$w.onReady(function () {
   initializePage();

});


let savedPersonId = null;
let fotoUrl; // ID de la persona guardada, se usa globalmente


// Prepara la pÃ¡gina para su uso
function initializePage() {
    hideAllGroupsExceptFirst();
    setupEventHandlers();
}


// Oculta todos los grupos excepto el primero
function hideAllGroupsExceptFirst() {
   ['2', '3'].forEach(group => hideElement(`#group${group}`));
}


function setupEventHandlers() {
   // Configura el evento de entrada para validar la fecha en tiempo real
   $w("#fechaNacimiento").onInput(validateDateRealTime);

 
   // BotÃ³n de acciÃ³n para pasar al siguiente grupo de formulario
   $w('#siguiente').onClick(handleNextButtonClick);

   // Manejadores de cambio para validar el formulario dinÃ¡micamente
   setupFieldChangeHandlers();
}


// Maneja el evento de clic en el botÃ³n "Siguiente"
async function handleNextButtonClick() {
    wixWindow.scrollTo(0, 0); // Asegura que la página se posicione arriba
    let currentGroup = getCurrentGroup();

    // Valida si hay más grupos para avanzar
    if (currentGroup < 4) {
        let validation = validateCurrentGroupFields(currentGroup);

        if (validation.isValid) {
            // Si es el grupo 3, ejecuta la lógica final
            if (currentGroup === 3) {
                $w('#loading').show(); // Verifica que '#loading' sea un ID válido

                // Subida de archivos
                if ($w("#uploadButton1").value.length > 0) {
                    await $w("#uploadButton1").uploadFiles()
                        .then((uploadedFiles) => {
                            uploadedFiles.forEach(uploadedFile => {
                                fotoUrl = uploadedFile.fileUrl;
                                console.log("Foto URL:", fotoUrl);
                            });
                            console.log("Upload exitoso.");
                            $w('#textoNuevoComercial').text = "Registro Creado";
                            $w('#Titulo').text = "Puedes cerrar"
                            $w('#loading').hide(); // Oculta correctamente
                            $w('#siguiente').hide();

                        }).catch(err => {
                            console.error("Error al cargar archivos:", err);
                        });
                } else {
                    console.log("Por favor selecciona un archivo.");
                }

                // Guarda el registro del titular
                await saveTitular();
            }

            // Cambiar de grupo
            toggleGroupVisibility(currentGroup, false); // Oculta el grupo actual
            currentGroup++; // Avanza al siguiente grupo
            toggleGroupVisibility(currentGroup, true); // Muestra el siguiente grupo

            
        } else {
            showElementWithText("#aviso", `Por favor complete los siguientes campos: ${validation.missingFields.join(", ")}`);
        }
    }
}







// Guarda informaciÃ³n del titular
async function saveTitular() {
   const person = createPersonObject("ADVISORS");
   try {
       const result = await wixData.insert("ADVISORS", person);
       savedPersonId = result._id; // Guarda el ID para uso futuro
       console.log("Titular guardado con Ã©xito:", result);
   } catch (err) {
       handleError(err);
   }
}


function setupFieldChangeHandlers() {
    const allFields = [
        "#primerNombre", "#segundoNombre", "#primerApellido", "#segundoApellido", "#numeroId",
        "#fechaNacimiento", "#pais", "#celular", "#email", "#clave",  "#zoom",
        
    ];
    allFields.forEach(fieldId => {
        try {
            $w(fieldId).onChange(() => {
                let currentGroup = getCurrentGroup();
                let validation = validateCurrentGroupFields(currentGroup);
                if (validation.isValid) {
                    hideElement("#aviso");
                }
            });
        } catch (err) {
            console.error(`Error setting up change handler for ${fieldId}:`, err);
        }
    });
}



// Crea el objeto de la persona con todos los campos necesarios
function createPersonObject(tipoUsuario) {
    return {
        primerNombre: $w("#primerNombre").value,
        segundoNombre: $w("#segundoNombre").value,
        primerApellido: $w("#primerApellido").value,
        segundoApellido: $w("#segundoApellido").value,
        numeroId: $w("#numeroId").value,
        fechaNacimiento: $w("#fechaNacimiento").value,
        pais: $w("#pais").value,
        celular: $w("#celular").value,
        email: $w("#email").value,
        clave: $w("#clave").value,
        zoom: $w("#zoom").value,
        foto: fotoUrl,
    };
}



// Muestra un elemento
function showElement(selector) {
   $w(selector).show();
}


// Oculta un elemento
function hideElement(selector) {
   $w(selector).hide();
}


// Muestra un elemento con texto especÃ­fico
function showElementWithText(selector, text) {
   const element = $w(selector);
   element.text = text;
   element.show();
}


// Maneja errores generales
function handleError(err) {
   console.error("Error: ", err);
   showElementWithText("#aviso", "Error al guardar la informaciÃ³n. Por favor, intente de nuevo.");
}


// Valida la fecha de nacimiento en tiempo real
function validateDateRealTime(event) {
   const inputId = "#" + event.target.id;
   let inputDate = $w(inputId).value;
   const regexSimple = /^[0-9/]*$/;


   if (!regexSimple.test(inputDate)) {
       $w(inputId).value = inputDate.slice(0, -1);
       return;
   }


   let parts = inputDate.split('/').filter(Boolean);
   if (parts.length === 1 && parts[0].length === 2 && inputDate.endsWith('/') === false && inputDate.length < 6) {
       $w(inputId).value += '/';
   } else if (parts.length === 2 && parts[1].length === 2 && inputDate.endsWith('/') === false && inputDate.length === 5) {
       $w(inputId).value += '/';
   } else if (inputDate.length > 10) {
       $w(inputId).value = inputDate.slice(0, 10);
   }
}


function validateCurrentGroupFields(groupNumber) {
  const groupFields = {
    1: ["#primerNombre", "#primerApellido", "#numeroId"],
    2: ["#fechaNacimiento", "#pais", "#celular", "#email", "#clave" ],
    3: ["#zoom"]
      
  };
  
  let isValid = true;
  let missingFields = [];

  groupFields[groupNumber].forEach(fieldId => {
      let fieldValue = $w(fieldId).value;

      // Verifica si el campo es un checkbox de múltiples selecciones
      if (Array.isArray(fieldValue)) {
          if (fieldValue.length === 0) {  // Chequea si el array está vacío, lo que significa que no se seleccionó ninguna opción
              missingFields.push($w(fieldId).placeholder || fieldId);
              isValid = false;
          }
      } else {
          // Para campos de texto normales, sigue usando trim para verificar campos vacíos
          if (fieldValue.trim() === "") {
              missingFields.push($w(fieldId).placeholder || fieldId);
              isValid = false;
          }
      }
  });

  return { isValid, missingFields };
}



// Cambia la visibilidad de un grupo de campos
function toggleGroupVisibility(groupNumber, show) {
   const groupId = `#group${groupNumber}`;
   if (show) {
       showElement(groupId);
   } else {
       hideElement(groupId);
   }
}


// Obtiene el grupo actual basado en la visibilidad de los grupos
function getCurrentGroup() {
   for (let i = 1; i <= 3; i++) {
       if (!$w(`#group${i}`).hidden) {
           return i;
       }
   }
   return 1; // Por defecto retorna el primer grupo si no se encuentra el actual
}
