import wixData from 'wix-data';
import { sendmessage } from 'backend/realTimeChat';

let personId;

$w.onReady(async function () {
    initializePage();
    personId = "9417ed9a-5c7b-455d-aea7-d76f0b8f1a24"//$w('#dynamicDataset').getCurrentItem()._id
    console.log(personId)

    await cargarDatosPersona();

    $w('#totalPlan').onInput(() => {
        aplicarFormatoNumero('#totalPlan');
        calcularSaldo();
    });
    $w('#pagoInscripcion').onInput(() => {
        aplicarFormatoNumero('#pagoInscripcion');
        calcularSaldo();
    });
    $w('#numeroCuotas').onInput(() => {
        calcularValorCuota();
    });
});

function initializePage() {
    setupEventHandlers();

    const prefijos = [
        { pais: "Argentina", prefijo: "+54" },
        { pais: "Bolivia", prefijo: "+591" },
        { pais: "Chile", prefijo: "+56" },
        { pais: "Colombia", prefijo: "+57" },
        { pais: "Costa Rica", prefijo: "+506" },
        { pais: "Cuba", prefijo: "+53" },
        { pais: "Ecuador", prefijo: "+593" },
        { pais: "El Salvador", prefijo: "+503" },
        { pais: "España", prefijo: "+34" },
        { pais: "Guatemala", prefijo: "+502" },
        { pais: "Honduras", prefijo: "+504" },
        { pais: "México", prefijo: "+52" },
        { pais: "Nicaragua", prefijo: "+505" },
        { pais: "Panamá", prefijo: "+507" },
        { pais: "Paraguay", prefijo: "+595" },
        { pais: "Perú", prefijo: "+51" },
        { pais: "Puerto Rico", prefijo: "+1 787" },
        { pais: "República Dominicana", prefijo: "+1 809" },
        { pais: "Uruguay", prefijo: "+598" },
        { pais: "Venezuela", prefijo: "+58" }
    ];

    // Asignar los valores al dropdown
    let options = prefijos.map(item => {
        return {
            label: `${item.pais} ${item.prefijo}`,
            value: item.prefijo
        };
    });

    $w('#prefijo').options = options;

}

function cargarDatosPersona(personId) {
    wixData.query("PEOPLE")
        .eq("_id", "9417ed9a-5c7b-455d-aea7-d76f0b8f1a24")
        .find()
        .then((result) => {
            if (result.items.length > 0) {
                let persona = result.items[0];

                $w("#primerNombre").value = capitalizeFirstLetter(persona.primerNombre || "");
                $w("#segundoNombre").value = capitalizeFirstLetter(persona.segundoNombre || "");
                $w("#primerApellido").value = capitalizeFirstLetter(persona.primerApellido || "");
                $w("#segundoApellido").value = capitalizeFirstLetter(persona.segundoApellido || "");
                $w("#numeroId").value = limpiarTexto(persona.numeroId || "");
                $w("#fechaNacimiento").value = persona.fechaNacimiento || "";
                $w("#pais").value = persona.plataforma || "";
                $w("#domicilio").value = persona.domicilio || "";
                $w("#ciudad").value = persona.ciudad || "";
                $w("#celular").value = limpiarTexto(persona.celular || "");
                $w("#ingresos").value = persona.ingresos || "";
                $w("#email").value = persona.email || "";
                $w("#empresa").value = persona.empresa || "";
                $w("#cargo").value = capitalizeFirstLetter(persona.cargo || "");
                $w("#genero").value = persona.genero || "";
                $w("#telefono").value = persona.telefono || "";
                $w("#referenciaUno").value = capitalizeFirstLetter(persona.referenciaUno || "");
                $w("#parentezcoRefUno").value = persona.parentezcoRefUno || "";
                $w("#telRefUno").value = persona.telefonoRefUno || "";
                $w("#referenciaDos").value = capitalizeFirstLetter(persona.referenciaDos || "");
                $w("#telRefDos").value = persona.telefonoRefDos || "";
                $w("#parentezcoRefDos").value = persona.parentezcoRefDos || "";
                $w("#vigencia").value = persona.vigencia || "";
            } else {
                console.log("No se encontró la persona con el ID especificado.");
            }
        })
        .catch((error) => {
            console.error("Error al cargar los datos de la persona:", error);
        });
}

function setupEventHandlers() {
    $w("#fechaNacimiento").onInput(validateDateRealTime);
    $w('#fechaPago').onInput(validateDateRealTime);
}

async function saveUsuario(isBeneficiario = false) {

}

async function saveTitular() {
    try {
        await saveUsuario(false);

        const totalPlan = parseFloat($w('#totalPlan').value.replace(/,/g, ''));
        const valorCuota = parseFloat($w('#valorCuota').value.replace(/,/g, ''));
        const pagoInscripcion = parseFloat($w('#pagoInscripcion').value.replace(/,/g, ''));
        const saldo = parseFloat($w('#saldo').value.replace(/,/g, ''));
        const numeroCuotas = parseInt($w('#numeroCuotas').value, 10);
        const vigencia = $w('#vigencia').value;

        let fechaPagoStr = $w('#fechaPago').value;
        let fechaPagoDate = new Date(fechaPagoStr.split('/').reverse().join('-'));
        let fechaPagoISO = fechaPagoDate.toISOString().split('T')[0];

        const financialRecord = {
            primerNombre: $w("#primerNombre").value,
            primerApellido: $w("#primerApellido").value,
            numeroId: $w("#numeroId").value,
            totalPlan: totalPlan,
            valorCuota: valorCuota,
            pagoInscripcion: pagoInscripcion,
            saldo: saldo,
            numeroCuotas: numeroCuotas,
            fechaPago: fechaPagoISO,
            vigencia: vigencia
        };

        const financialResult = await wixData.insert("FINANCIERA", financialRecord);

        sendmessage("gestionProspectos", { type: "updateComplete" })
            .then(response => {
                console.log("Mensaje enviado con éxito:", response);
            });

        console.log("Registro financiero creado con éxito:", financialResult);
    } catch (err) {
        console.error("Error al guardar la información del titular y financiera:", err);
    }
}

async function createPersonObject(tipoUsuario) {

    let fechaNacimientoStr = $w("#fechaNacimiento").value;
    let fechaNacimientoDate = new Date(fechaNacimientoStr.split('/').reverse().join('-'));
    let fechaNacimientoISO = fechaNacimientoDate.toISOString().split('T')[0];

    let edad = calculateAge(fechaNacimientoDate);

    // Obtener el prefijo seleccionado
    let prefijo = $w("#prefijo").value;
    // Concatenar el prefijo con el valor del celular
    let celularCompleto = prefijo + $w("#celular").value;

    return {
        primerNombre: capitalizeFirstLetter($w("#primerNombre").value),
        segundoNombre: capitalizeFirstLetter($w("#segundoNombre").value),
        primerApellido: capitalizeFirstLetter($w("#primerApellido").value),
        segundoApellido: capitalizeFirstLetter($w("#segundoApellido").value),
        numeroId: limpiarTexto($w("#numeroId").value),
        fechaNacimiento: fechaNacimientoISO,
        edad: edad.toString(),
        plataforma: $w("#pais").value,
        domicilio: $w("#domicilio").value,
        ciudad: $w("#ciudad").value,
        celular: limpiarTexto(celularCompleto), // Guardar el número completo con el prefijo
        ingresos: $w("#ingresos").value,
        email: $w("#email").value,
        empresa: $w("#empresa").value,
        cargo: capitalizeFirstLetter($w("#cargo").value),
        genero: $w("#genero").value,
        tipoUsuario: tipoUsuario,
        telefono: $w('#telefono').value,
        referenciaUno: capitalizeFirstLetter($w('#referenciaUno').value),
        parentezcoRefUno: $w('#parentezcoRefUno').value,
        telefonoRefUno: $w('#telRefUno').value,
        referenciaDos: capitalizeFirstLetter($w('#referenciaDos').value),
        telefonoRefDos: $w('#telRefDos').value,
        parentezcoRefDos: $w('#parentezcoRefDos').value,
        titularId: personId,
        vigencia: $w('#vigencia').value
    };
}

function calculateAge(fechaNacimiento) {
    let hoy = new Date();
    let edad = hoy.getFullYear() - fechaNacimiento.getFullYear();
    let mes = hoy.getMonth() - fechaNacimiento.getMonth();
    if (mes < 0 || (mes === 0 && hoy.getDate() < fechaNacimiento.getDate())) {
        edad--;
    }
    return edad;
}

function validateDateRealTime(event) {
    const inputId = "#" + event.target.id;
    let inputDate = $w(inputId).value;
    const regexSimple = /^[0-9/]*$/;

    if (!regexSimple.test(inputDate)) {
        $w(inputId).value = inputDate.slice(0, -1);
        return;
    }

    let parts = inputDate.split('/').filter(Boolean);
    if (parts.length === 1 && parts[0].length === 2 && inputDate.endsWith('/') === false && inputDate.length < 6) {
        $w(inputId).value += '/';
    } else if (parts.length === 2 && parts[1].length === 2 && inputDate.endsWith('/') === false && inputDate.length === 5) {
        $w(inputId).value += '/';
    } else if (inputDate.length > 10) {
        $w(inputId).value = inputDate.slice(0, 10);
    }
}

function setupGroupSixEventHandlers() {
    $w('#totalPlan').onInput(() => {
        console.log("Total Plan Input");
        aplicarFormatoNumero('#totalPlan');
        calcularSaldo();
    });
    $w('#pagoInscripcion').onInput(() => {
        console.log("Pago Inscripción Input");
        aplicarFormatoNumero('#pagoInscripcion');
        calcularSaldo();
    });
    $w('#numeroCuotas').onInput(() => {
        console.log("Número Cuotas Input");
        calcularValorCuota();
    });

    $w('#ingresos').onInput(() => {
        aplicarFormatoNumero('#ingresos');
    });
}

function getCurrentGroup() {
    for (let i = 1; i <= 7; i++) {
        if (!$w(`#group${i}`).hidden) {
            return i;
        }
    }
    return 1;
}

function calcularValoresFinancieros() {
    let totalPlan = parseFloat($w('#totalPlan').value.replace(/,/g, ''));
    let pagoInscripcion = parseFloat($w('#pagoInscripcion').value.replace(/,/g, ''));
    let numeroCuotas = parseInt($w('#numeroCuotas').value, 10);

    let saldo = totalPlan - pagoInscripcion;
    let valorCuota = saldo / numeroCuotas;

    $w('#saldo').value = saldo.toFixed(2).toString();
    $w('#valorCuota').value = valorCuota.toFixed(2).toString();

    return {
        totalPlan: totalPlan,
        valorCuota: valorCuota,
        pagoInscripcion: pagoInscripcion,
        saldo: saldo,
        numeroCuotas: numeroCuotas
    };
}

function aplicarFormatoNumero(selector) {
    let valor = $w(selector).value.replace(/,/g, '');
    valor = valor.replace(/\D/g, '');
    valor = valor.replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    $w(selector).value = valor;
}

function calcularSaldo() {
    let totalPlan = parseFloat($w('#totalPlan').value.replace(/,/g, ''));
    let pagoInscripcion = parseFloat($w('#pagoInscripcion').value.replace(/,/g, ''));

    if (!isNaN(totalPlan) && !isNaN(pagoInscripcion)) {
        let saldo = totalPlan - pagoInscripcion;
        $w('#saldo').value = saldo.toLocaleString();
        calcularValorCuota();
    }
}

function calcularValorCuota() {
    let saldo = parseFloat($w('#saldo').value.replace(/,/g, ''));
    let numeroCuotas = parseInt($w('#numeroCuotas').value, 10);

    if (!isNaN(saldo) && !isNaN(numeroCuotas) && numeroCuotas > 0) {
        let valorCuota = saldo / numeroCuotas;
        $w('#valorCuota').value = valorCuota.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    }
}

function capitalizeFirstLetter(string) {
    if (!string) return string;
    return string.charAt(0).toUpperCase() + string.slice(1).toLowerCase();
}

function limpiarTexto(texto) {
    return texto.replace(/[.\s-]|[^a-zA-Z0-9]/g, '');
}