import wixLocation from 'wix-location';

$w.onReady(function () {
    $w("#backBusqueda").onClick(() => {
        console.log("Exportando CSC.");
        wixLocation.to("https://www.lgsplataforma.com/_functions/exportCSV")
    });
});
