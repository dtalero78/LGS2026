import wixStorage from 'wix-storage';
import wixWindow from 'wix-window';
import wixData from 'wix-data';
import { sendmessage } from 'backend/realTimeChat'; // AsegÃºrate de que esta ruta es correcta

let prospectoOriginal;
let todosLosDatos = [];
let ultimoValorSlider = 0;


$w.onReady(async function () {

    const userId = wixStorage.local.getItem('userId');

    // 1. Comprueba si necesita mostrar primerContactoBox
    if (wixStorage.local.getItem('showPrimerContactoBox') === 'true') {
        $w('#primerContactoBox').show();
    }
    if (wixStorage.local.getItem('showSegundoContactoBox') === 'true') {
        $w('#segundoContactoBox').show();
    }
    wixStorage.local.removeItem('showPrimerContactoBox');

    // 2. Query de todo
    try {
        const results = await wixData.query("PROSPECTOS").eq("_id", userId).find();
        if (results.items.length > 0) {
            prospectoOriginal = results.items[0];
            todosLosDatos = prospectoOriginal.comentarios ? procesarComentarios(prospectoOriginal.comentarios) : [];
            mostrarDatosdeTodosLosBoxes(prospectoOriginal);
            configurarSlider();
        } else {
            console.warn("No se encontraron prospectos para el usuario actual.");
        }
    } catch (error) {
        console.error("Error al cargar los datos del prospecto:", error);
    }

    // 3. Eventos adicionales 
    agregarEventos();

    // 4. ConfiguraciÃ³n de los comentarios
    $w('#comentarios').onFocus(() => prepararCampoComentario('#comentarios'));
    $w('#comentarios2Contacto').onFocus(() => prepararCampoComentario('#comentarios2Contacto'));
});

// 2. BotÃ³n de guardar
$w('#guardar').onClick(async () => {
    if (validarDatosAntesDeGuardar()) {
        try {
            const prospectoModificado = datosModificadosParaGuardar(prospectoOriginal);
            await wixData.update("PROSPECTOS", prospectoModificado);

        } catch (error) {
            console.error("Error al actualizar datos:", error);
            wixWindow.lightbox.close({ "updated": false });
        }
    } else {
        console.error("Complete los campos requeridos.");
    }
});

function agregarEventos() {

    $w('#callToAction2Contacto').value = ""
    $w('#Motivo2Contacto').value = ""

    // 1. Ocultar el grupo Motivo DesistiÃ³ del grupo 1
    $w('#motivoDesistioGroup').hide();

    $w('#callToAction').onChange((event) => {
        const value = event.target.value;
        switch (value) {
        case "Cita":
        case "Llamar despuÃ©s":
            $w('#group2').show();
            $w('#motivoDesistioGroup').hide();
            break;
        case "No me interesa":
            $w('#motivoDesistioGroup').show();
            break;
        default:
            $w('#group2').show();
            $w('#motivoDesistioGroup').hide();
            break;
        }
    });

    // 2. BotÃ³n de guardar
    $w('#guardar').onClick(async () => {
        if (validarDatosAntesDeGuardar()) {
            try {
                const prospectoModificado = datosModificadosParaGuardar(prospectoOriginal);
                await wixData.update("PROSPECTOS", prospectoModificado);

                // Enviar mensaje y registrar el evento
                sendmessage("gestionProspectos", { type: "updateComplete" })
                .then(response => {
                    wixWindow.lightbox.close({ "updated": true });
                });
               

            } catch (error) {
                console.error("Error al actualizar datos:", error);
                wixWindow.lightbox.close({ "updated": false });
            }
        } else {
            console.error("Complete los campos requeridos.");
        }
    });

    //
    $w('#fechaProximaGestion2Contacto').onChange(validarHoraConFecha);

    // 

    $w('#callToAction2Contacto').onChange((event) => {
        if ($w('#callToAction2Contacto').value === "Cita Efectiva") {
            const nuevasOpciones = ["Crear Contrato", "Reprogramar", "No cuenta con dinero", "No cuenta con tiempo", "Indeciso"];
            actualizarOpciones(nuevasOpciones);
            $w('#group3').show()
        } else if ($w('#callToAction2Contacto').value === "Reprogramada") {
            const nuevasOpciones = ["No contesta", "Pidió reprogramar"];
            actualizarOpciones(nuevasOpciones);
            $w('#group3').show()

        }
    });

    function actualizarOpciones(nuevasOpciones) {
        $w('#Motivo2Contacto').options = [];
        $w('#Motivo2Contacto').options = nuevasOpciones.map(opcion => {
            return { label: opcion, value: opcion };
        });
    }

    $w('#Motivo2Contacto').onChange((event) => {
        if ($w('#Motivo2Contacto').value === "Crear Contrato") {
            $w('#crearContratoBox').show()
        }
    })

    $w('#vectorContrato').onClick((event) => {
$w('#vectorContrato').link = "/nuevo-titular";
        $w('#vectorContrato').target = "_blank";
        $w('#crearContratoBox').hide()
    });

    $w('#cerrarBoxContratoButton').onClick((event) => {
        $w('#crearContratoBox').hide()
    })

}

// 3. Verificar si el campo de hora2ProximaGestiÃ³n le asignaron hora porq si no no guarda
function validarDatosAntesDeGuardar() {
    let fecha = $w('#fechaProximaGestion2Contacto').value;
    let hora = $w('#horaProximaGestion2Contacto').value;

    return !(fecha && !hora); // Retorna falso si hay fecha pero no hora, bloqueando el guardado
}

// I. Funciones para populate repeaters y boxes
function actualizarRepeater(paginaActual, itemsPorPagina) {
    let startIndex = paginaActual * itemsPorPagina;
    let endIndex = startIndex + itemsPorPagina;
    let datosParaMostrar = todosLosDatos.slice(startIndex, endIndex);

    $w("#repeater1").data = datosParaMostrar;
    $w("#repeater1").forEachItem(($item, itemData, index) => {
        $item("#fecha").text = itemData.fecha;
        $item("#comentario").text = itemData.texto;
    });

}

// I.1 Populate en los dos boxes
function mostrarDatosdeTodosLosBoxes(prospecto) {
    var fechaHora = prospecto.fechaProximaGestion;
    var fechaFormateada = fechaHora.toLocaleDateString("es-CL");
    var horaFormateada = fechaHora.toLocaleTimeString("es-CL");
    var fechaHoraFormateada = fechaFormateada + ' ' + horaFormateada;

    // Asignar la fecha y hora formateadas al elemento en tu sitio web de Wix
    $w('#proximaGestionTitle').text = fechaHoraFormateada;
    $w('#primerNombre').value = prospecto.primerNombre;
    $w('#segundoNombre').value = prospecto.segundoNombre;
    $w('#primerApellido').value = prospecto.primerApellido;
    $w('#segundoApellido').value = prospecto.segundoApellido;
    $w('#pais').value = prospecto.pais;
    $w('#celular').value = prospecto.celular;
    $w('#email').value = prospecto.email;
    $w('#direccion').value = prospecto.direccion;
    $w('#callToAction').value = prospecto.callToAction;
    $w('#desistioMotivo').value = prospecto.desistioMotivo;

    // Dejar los campos de comentarios vacÃ­os para nuevos comentarios
    $w('#comentarios').value = "";
    $w('#comentarios2Contacto').value = "";

    // Elementos del Box 2 Contacto
    $w('#primerNombre2Contacto').value = prospecto.primerNombre;
    $w('#segundoNombre2Contacto').value = prospecto.segundoNombre;
    $w('#primerApellido2Contacto').value = prospecto.primerApellido;
    $w('#segundoApellido2Contacto').value = prospecto.segundoApellido;
    $w('#pais2Contacto').value = prospecto.pais;
    $w('#celularSegundo2Contacto').value = prospecto.celular;
    $w('#email2Contacto').value = prospecto.email;
    $w('#direccion2Contacto').value = prospecto.direccion;
    $w('#callToAction2Contacto').value = prospecto.callToAction;
    $w('#Motivo2Contacto').value = prospecto.desistioMotivo;

    // Separar comentarios para mostrarlos en el repeater
    let fullComments = prospecto.comentarios || "";
    let commentsArray = fullComments.split('Fecha:').slice(1);
    let commentVariables = []; // Arreglo para almacenar cada comentario

    commentsArray.forEach((comment, index) => {
        let parts = comment.split('\n').map(part => part.trim());
        let commentDate = new Date(parts[0]);
        let commentVariable = {
            _id: `comment${index}`,
            nombreCompleto: `${prospecto.primerNombre} ${prospecto.segundoApellido}`,
            fecha: parts[0],
            texto: parts.slice(1).join(' '),
            fechaObj: commentDate // Agregar fecha como objeto Date para ordenamiento
        };
        commentVariables.push(commentVariable);
    });

    // Ordenar los comentarios por fecha de creaciÃ³n descendente
    commentVariables.sort((a, b) => b.fechaObj - a.fechaObj);

    // Asignar los datos al repeater
    $w("#repeater1").data = commentVariables;
    $w("#repeater1").forEachItem(($item, itemData, index) => {
        $item("#fecha").text = itemData.fecha;
        $item("#comentario").text = itemData.texto;
    });

}

// I.2 reparar datos para guardar
function datosModificadosParaGuardar(prospectoOriginal) {
    let fechaInput, horaInput, fecha;

    // Verificar si los campos del segundo contacto tienen valores vÃ¡lidos
    if ($w("#fechaProximaGestion2Contacto").value && $w("#horaProximaGestion2Contacto").value) {
        fechaInput = $w("#fechaProximaGestion2Contacto").value;
        horaInput = $w("#horaProximaGestion2Contacto").value;
        fecha = new Date(fechaInput);
        let [horas, minutos] = horaInput.split(":").map(Number);
        fecha.setHours(horas, minutos);
    } else if ($w("#fechaProximaGestion").value && $w("#horaProximaGestion").value) {
        fechaInput = $w("#fechaProximaGestion").value;
        horaInput = $w("#horaProximaGestion").value;
        fecha = new Date(fechaInput);
        let [horas, minutos] = horaInput.split(":").map(Number);
        fecha.setHours(horas, minutos);
    } else {
        // Mantener la fecha original si no hay entradas vÃ¡lidas
        fecha = prospectoOriginal.fechaProximaGestion;
    }

    const comentariosActuales = prospectoOriginal.comentarios || "";
    const nuevosComentarios1 = $w('#comentarios').value.trim();
    const nuevosComentarios2 = $w('#comentarios2Contacto').value.trim();
    const comentarioFinal = prepararComentario(comentariosActuales, nuevosComentarios1, nuevosComentarios2);

    // Usar el operador spread para copiar todas las propiedades originales del prospecto
    const prospectoModificado = {
        ...prospectoOriginal,
        primerNombre: obtenerValorModificado($w('#primerNombre2Contacto').value, $w('#primerNombre').value, prospectoOriginal.primerNombre),
        segundoNombre: obtenerValorModificado($w('#segundoNombre2Contacto').value, $w('#segundoNombre').value, prospectoOriginal.segundoNombre),
        primerApellido: obtenerValorModificado($w('#primerApellido2Contacto').value, $w('#primerApellido').value, prospectoOriginal.primerApellido),
        segundoApellido: obtenerValorModificado($w('#segundoApellido2Contacto').value, $w('#segundoApellido').value, prospectoOriginal.segundoApellido),
        pais: obtenerValorModificado($w('#pais2Contacto').value, $w('#pais').value, prospectoOriginal.pais),
        celular: obtenerValorModificado($w('#celularSegundo2Contacto').value, $w('#celular').value, prospectoOriginal.celular),
        email: obtenerValorModificado($w('#email2Contacto').value, $w('#email').value, prospectoOriginal.email),
        direccion: obtenerValorModificado($w('#direccion2Contacto').value, $w('#direccion').value, prospectoOriginal.direccion),
        callToAction: obtenerValorModificado($w('#callToAction2Contacto').value, $w('#callToAction').value, prospectoOriginal.callToAction),
        desistioMotivo: obtenerValorModificado($w('#Motivo2Contacto').value, $w('#desistioMotivo').value, prospectoOriginal.desistioMotivo),
        fechaProximaGestion: fecha,
        comentarios: comentarioFinal
    };

    return prospectoModificado;
}

// I.3 Preparar datos para guardar
function obtenerValorModificado(valorContacto, valorPrincipal, valorOriginal) {
    // Chequear si alguno de los valores proporcionados es diferente del original y no estÃ¡ vacÃ­o
    if (valorContacto && valorContacto !== valorOriginal) {
        return valorContacto;
    } else if (valorPrincipal && valorPrincipal !== valorOriginal) {
        return valorPrincipal;
    }
    return valorOriginal;
}

// II. FUNCIONES DE COMENTARIO
// II.1 FunciÃ³n de comentario
function prepararComentario(comentariosActuales, nuevosComentarios1, nuevosComentarios2) {
    let comentarioFinal = comentariosActuales;
    if (nuevosComentarios1.trim()) {
        // AÃ±adir solo el comentario si ya hay una fecha desde onFocus
        comentarioFinal += `\n${nuevosComentarios1}`;
    }
    if (nuevosComentarios2.trim()) {
        comentarioFinal += `\n${nuevosComentarios2}`;
    }
    return comentarioFinal;
}
// II.2 FunciÃ³n de comentario
function prepararCampoComentario(elementId) {
    let comentarioActual = $w(elementId).value;
    // Agregar una fecha solo si el campo estÃ¡ completamente vacÃ­o
    if (!comentarioActual.trim()) {
        comentarioActual = `Fecha: ${obtenerFechaActualComoString()}\n`;
        $w(elementId).value = comentarioActual;
    }
}

// II.3 Obtener la fecha actual como string en formato DD/MM/AAAA
function obtenerFechaActualComoString() {
    const fecha = new Date();
    return fecha.toLocaleDateString('es-CL', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric'
    });
}

// II.4 FunciÃ³n para preparar el campo de comentario con la fecha actual
function validarHoraConFecha() {
    let fecha = $w('#fechaProximaGestion2Contacto').value;
    let hora = $w('#horaProximaGestion2Contacto').value;

    if (fecha && !hora) {
        $w('#horaProximaGestion2Contacto').focus(); // Enfoca el campo de hora
        $w('#errorHora').show(); // Muestra un mensaje de error
        $w('#errorHora').text = "Debe ingresar una hora si selecciona una fecha.";
    } else {
        $w('#errorHora').hide(); // Oculta el mensaje de error
    }
}

// II.5 ORDENAR LOS COMENTARIO
function procesarComentarios(comentarios) {
    let commentsArray = comentarios.split('Fecha:').slice(1);
    return commentsArray.map((comment, index) => {
        let parts = comment.split('\n').map(part => part.trim());
        let commentDate = new Date(parts[0]);
        return {
            _id: `comment${index}`,
            nombreCompleto: `${prospectoOriginal.primerNombre} ${prospectoOriginal.segundoApellido}`,
            fecha: parts[0],
            texto: parts.slice(1).join(' '),
            fechaObj: commentDate
        };
    }).sort((a, b) => b.fechaObj - a.fechaObj);
}

// SLIDER
function configurarSlider() {
    const itemsPorPagina = 5;
    $w('#slider1').max = Math.ceil(todosLosDatos.length / itemsPorPagina) - 1;
    $w('#slider1').value = 0;
    actualizarRepeater(0, itemsPorPagina);

    $w('#slider1').onChange((event) => {
        let paginaActual = parseInt(event.target.value, 10);

        if (paginaActual !== ultimoValorSlider) {
            actualizarRepeater(paginaActual, itemsPorPagina);
            setTimeout(() => {
                $w('#slider1').value = paginaActual; // Forzar la actualizaciÃ³n del valor del slider despuÃ©s de actualizar
                ultimoValorSlider = paginaActual;
            }, 100); // Un retardo para asegurar que el cambio se refleje visualmente
        }
    });
}