import wixData from 'wix-data';
import wixWindow from 'wix-window';
import wixStorage from 'wix-storage';
import wixLocation from 'wix-location';
import { session } from 'wix-storage';

let debounceTimer;
const debounceDelay = 500; // Tiempo en milisegundos
let idUsuario = ""
let cantidadBulk
let usuarioEmail;

$w.onReady(async function () {

    // -----  BLOQUE DE RECONOCIMIENTO DE TOKEN LOGIN

    const tokenData = JSON.parse(session.getItem('accessToken'));
    if (tokenData) {
        const currentTime = new Date().getTime();
        // Convertir el tiempo de expiración a una fecha legible
        const expirationDate = new Date(tokenData.expiresAt);
        console.log(`El token expira el: ${expirationDate.toLocaleString()}`);
        if (currentTime > tokenData.expiresAt) {
            // Token ha expirado
            session.removeItem('accessToken');
            console.log("Token Acabado") // Eliminar el token expirado
            wixLocation.to(`/login`); // Redirigir a una página de error o login
        } else {
            // Token es válido
            // Aquí puedes continuar cargando el contenido de la página
        }
    } else {
        console.log("Token Expirado") // Eliminar el token expirado
        wixLocation.to(`/login`); // Redirigir a una página de error o login
    }

    const query = wixLocation.query;
    if (!query.email) {
        console.error("No se encontró el email en la URL.");
    } else {
        usuarioEmail = decodeURIComponent(query.email);
        console.log("Email recibido:", usuarioEmail);
    }

    $w("#verAgenda").onClick(() => {
        const fechaHoy = new Date();

        setupTableColumns();
        cargarAgendaPorAdvisor(fechaHoy);
        $w('#agendaGroup').show()

    });

    configurarDiasDropdown();
    cargarAdvisorsDropdown()

});

function cargarAdvisorsDropdown() {
    // Primero limpiamos las opciones por defecto del dropdown
    $w("#advisorDropDown").options = [];
    
    wixData.query("ADVISORS")
        .limit(1000) // Aumentar el límite para obtener más registros
        .find()
        .then((results) => {
            if (results.items.length === 0) {
                console.log("No se encontraron advisors en la base de datos");
                $w("#advisorDropDown").options = [{ value: "", label: "No hay advisors disponibles" }];
                return;
            }
            
            console.log(`Se encontraron ${results.items.length} advisors`);
            
            let opciones = results.items.map(item => {
                // Validar y obtener valores seguros
                const primerNombre = item.primerNombre || 'Sin nombre';
                const primerApellido = item.primerApellido || 'Sin apellido';
                const pais = item.pais || 'Sin país';
                
                return { 
                    value: item._id, 
                    label: `${capitalizeFirstLetter(primerNombre)} ${capitalizeFirstLetter(primerApellido)} - ${capitalizeFirstLetter(pais)}` 
                };
            });

            // Ordenar las opciones alfabéticamente de A a Z
            opciones.sort((a, b) => {
                return a.label.localeCompare(b.label);
            });
            
            // Agregar opción por defecto al inicio
            opciones.unshift({ value: "", label: "Selecciona un advisor" });

            console.log(`Cargando ${opciones.length - 1} advisors en el dropdown`);
            $w("#advisorDropDown").options = opciones;
            $w("#advisorDropDown").value = ""; // Establecer el valor inicial
        })
        .catch((err) => {
            console.error("Error al cargar advisors:", err);
            $w("#advisorDropDown").options = [{ value: "", label: "Error al cargar advisors" }];
        });
}

function configurarDiasDropdown() {
    const hoy = new Date();

    // Fecha de inicio: 3 días antes de hoy
    const inicio = new Date(hoy);
    inicio.setDate(hoy.getDate() - 3);

    // Fecha de fin: el sábado de la semana actual
    // getDay() devuelve 0 para domingo, 1 para lunes, ... 6 para sábado.
    const finDeSemana = new Date(hoy);
    finDeSemana.setDate(finDeSemana.getDate() + (6 - finDeSemana.getDay()));

    const dias = [];

    // Iteramos desde la fecha de inicio hasta el sábado de la semana actual
    for (let dia = new Date(inicio); dia <= finDeSemana; dia.setDate(dia.getDate() + 1)) {
        const nombreDia = dia.toLocaleDateString('es-ES', { weekday: 'long' }); // Nombre del día en español
        const numeroDia = dia.getDate(); // Número del día
        const opcion = {
            "label": `${capitalizeFirstLetter(nombreDia)} ${numeroDia}`, // Ej: "Sábado 11"
            "value": dia.toISOString()
        };
        dias.push(opcion);
    }

    $w("#diasParaConsulta").options = dias;
    $w("#diasParaConsulta").onChange((event) => {
        $w('#advisorDropDown').value = "";
        cargarAgendaPorDia(event.target.value); // Cargar agenda para el día seleccionado
    });

    $w("#advisorDropDown").onChange((event) => {
        cargarAgendaPorAdvisor(event.target.value); // Cargar agenda según el advisor seleccionado
    });
}

function cargarEventosAdvisorPorDia(advisorId, fechaSeleccionada, advisorNombre) {
    const fechaInicio = new Date(fechaSeleccionada);
    fechaInicio.setHours(0, 0, 0, 0);
    const fechaFin = new Date(fechaSeleccionada);
    fechaFin.setHours(23, 59, 59, 999);
    
    console.log(`🔍 Buscando eventos del advisor ${advisorNombre} para el día ${fechaSeleccionada}`);
    
    wixData.query("CALENDARIO")
        .eq("advisor", advisorId)
        .between("dia", fechaInicio, fechaFin)
        .include("advisor")
        .limit(1000)
        .find()
        .then((results) => {
            const eventos = results.items;
            console.log(`📊 Eventos encontrados del advisor para el día: ${eventos.length}`);
            
            let repeaterItems = eventos.map(evento => {
                const hora = new Date(evento.dia).getHours();
                const eventoBase = `${evento.evento || ''} ${evento.tituloONivel || ''}`.trim();
                const stepLabel = getStepLabel(evento.nombreEvento);
                const eventoConTitulo = `${eventoBase} - ${stepLabel}`;
                
                return {
                    _id: evento._id,
                    advisor: advisorNombre,
                    tipoEvento: eventoConTitulo,
                    horaRepetidor: `${hora}:00`,
                    cantUsuarios: 0
                };
            });
            
            // Ordenar por hora
            repeaterItems.sort((a, b) => {
                const horaA = parseInt(a.horaRepetidor.split(':')[0]);
                const horaB = parseInt(b.horaRepetidor.split(':')[0]);
                return horaA - horaB;
            });
            
            console.log(`📋 Eventos procesados para mostrar: ${repeaterItems.length}`);
            repeaterItems.forEach(item => {
                console.log(`  - ${item.horaRepetidor}: ${item.tipoEvento}`);
            });
            
            $w("#misEventosRepeater").data = repeaterItems;
        })
        .catch((err) => {
            console.error("Error al cargar eventos del advisor por día:", err);
        });
}

function setupTableColumns() {
    const columns = [{
        "id": "nombreAdvisor",
        "dataPath": "nombreCompleto",
        "label": "Advisor",
        "width": 200,
        "visible": true,
        "type": "string"
    }]; // Columna para nombres de advisors

    // Añade columnas para cada hora desde las 7 AM hasta las 9 PM
    for (let hour = 7; hour <= 21; hour++) {
        columns.push({
            "id": `hora${hour}`,
            "dataPath": `hora${hour}`,
            "label": `${hour}-${hour + 1}`,
            "width": 200,
            "visible": true,
            "type": "string"
        });
    }

    $w("#mostrarAgenda").columns = columns; // Asegúrate de que 'mostrarAgenda' es el ID correcto del elemento de tabla
}

function cargarAgendaPorAdvisor(fechaSeleccionada) {
    const advisorId = $w('#advisorDropDown').value;
    const fechaDiaSeleccionado = $w('#diasParaConsulta').value;
    
    console.log(`🔍 cargarAgendaPorAdvisor - advisorId: ${advisorId}, fechaSeleccionada: ${fechaSeleccionada}, fechaDiaSeleccionado: ${fechaDiaSeleccionado}`);

    if (!advisorId) {
        console.warn("⚠️ No hay advisor seleccionado");
        return;
    }

    // Si hay un día específico seleccionado en el dropdown, usar esa fecha para filtrar
    const fechaParaFiltrar = fechaDiaSeleccionado || fechaSeleccionada;
    
    let query = wixData.query("CALENDARIO")
        .eq("advisor", advisorId)
        .include("advisor")
        .limit(1000);

    // Solo agregar filtro de fecha si se proporciona una fecha específica
    if (fechaParaFiltrar) {
        const fechaInicio = new Date(fechaParaFiltrar);
        fechaInicio.setHours(0, 0, 0, 0);
        const fechaFin = new Date(fechaParaFiltrar);
        fechaFin.setHours(23, 59, 59, 999);
        
        query = query.between("dia", fechaInicio, fechaFin);
        console.log(`📅 Filtrando por fecha: ${fechaParaFiltrar}`);
    } else {
        console.log(`📊 Mostrando todos los eventos del advisor (sin filtro de fecha)`);
    }

    query.find()
        .then((results) => {
            const bookings = results.items;
            console.log(`🔍 Consulta por advisor - Eventos encontrados: ${bookings.length}`);
            mostrarAgenda(bookings);
            $w('#agendaGroup').show()
        })
        .catch((err) => {
            console.error("Error al cargar las reservas para el día", err);
        });
}

function cargarAgendaPorDia(fechaSeleccionada) {
    const advisorId = $w('#advisorDropDown').value;
    const fechaInicio = new Date(fechaSeleccionada);
    fechaInicio.setHours(0, 0, 0, 0);
    const fechaFin = new Date(fechaSeleccionada);
    fechaFin.setHours(23, 59, 59, 999);

    console.log(`📅 cargarAgendaPorDia - fechaSeleccionada: ${fechaSeleccionada}, advisorId: ${advisorId}`);

    let query = wixData.query("CALENDARIO")
        .include("advisor")
        .between("dia", fechaInicio, fechaFin)
        .limit(1000);

    // Si hay un advisor específico seleccionado, filtrar también por advisor
    if (advisorId) {
        query = query.eq("advisor", advisorId);
        console.log(`👤 Filtrando también por advisor: ${advisorId}`);
    } else {
        console.log(`📊 Mostrando todos los advisors del día`);
    }

    query.find()
        .then((results) => {
            const bookings = results.items;
            console.log(`📅 Consulta por día - Eventos encontrados: ${bookings.length}`);
            mostrarAgenda(bookings);
            $w('#agendaGroup').show()

        })
        .catch((err) => {
            console.error("Error al cargar las reservas para el día", err);
        });
}

function mostrarAgenda(bookings) {
    const tableData = [];
    const advisorsMap = {};

    // Agrupar los bookings por advisor y hora.
    bookings.forEach(booking => {
    const advisor = booking.advisor;
    const advisorId = advisor._id;

    if (!advisorsMap[advisorId]) {
        advisorsMap[advisorId] = {
            nombreCompleto: advisor.primerNombre + " " + advisor.primerApellido
        };
    }

    const eventHour = new Date(booking.dia).getHours();

    const eventoBase = `${booking.evento || ''} ${booking.tituloONivel || ''}`.trim();
    const stepLabel = getStepLabel(booking.nombreEvento);
    const eventoConTitulo = `${eventoBase} - ${stepLabel}`;

    advisorsMap[advisorId][`hora${eventHour}`] = eventoConTitulo;
    advisorsMap[advisorId][`hora${eventHour}EventId`] = booking._id;
});


    for (let advisorId in advisorsMap) {
        const rowData = { id: advisorId, ...advisorsMap[advisorId] };
        tableData.push(rowData);
    }

    console.log(`📊 Total de bookings recibidos: ${bookings.length}`);
    console.log(`👥 Total de advisors únicos procesados: ${Object.keys(advisorsMap).length}`);
    console.log(`📋 Total de filas a mostrar en tabla: ${tableData.length}`);

    $w('#agendaButton').show();
    $w("#mostrarAgenda").rows = tableData;

    $w("#mostrarAgenda").onRowSelect((event) => {
        $w('#listaEstudiantes').show();
        const rowData = event.rowData;
        const advisorSeleccionado = rowData.nombreCompleto;
        const advisorId = rowData.id;
        
        console.log(`👤 Advisor seleccionado: ${advisorSeleccionado} (ID: ${advisorId})`);
        
        // Obtener la fecha seleccionada del dropdown de días
        const fechaSeleccionada = $w("#diasParaConsulta").value;
        console.log(`📅 Fecha seleccionada en dropdown: ${fechaSeleccionada}`);
        
        let repeaterItems = [];

        // Si hay una fecha específica seleccionada, filtrar los eventos del advisor para ese día
        if (fechaSeleccionada) {
            cargarEventosAdvisorPorDia(advisorId, fechaSeleccionada, advisorSeleccionado);
        } else {
            // Si no hay fecha específica, mostrar todos los eventos del advisor (comportamiento original)
            for (let hour = 7; hour <= 21; hour++) {
                const hourKey = `hora${hour}`;
                const hourKeyId = `hora${hour}EventId`;

                if (rowData[hourKey] && rowData[hourKey].trim() !== "") {
                    repeaterItems.push({
                        _id: rowData[hourKeyId],
                        advisor: rowData.nombreCompleto,
                        tipoEvento: rowData[hourKey],
                        horaRepetidor: `${hour}:00`,
                        cantUsuarios: 0
                    });
                }
            }
            console.log(`📋 Eventos del advisor (sin filtro de fecha): ${repeaterItems.length}`);
            $w("#misEventosRepeater").data = repeaterItems;
        }
    });

    $w("#misEventosRepeater").onItemReady(($item, itemData, index) => {
        console.log("🆔 ID de evento seleccionado:", itemData._id);

        
    const stepLabel = getStepLabel(itemData.tipoEvento);
$item("#tipoEventoText").text = itemData.tipoEvento;

    $item("#advisorText").text = itemData.advisor;
    $item("#horaRepetidor").text = itemData.horaRepetidor;

        wixData.query("BOOKING")
            .eq("idEvento", itemData._id)
            .isEmpty("cancelo")
            .count()
            .then((count) => {
                $item("#cantUsuariosText").text = count.toString();
            })
            .catch((err) => {
                console.error("Error al contar bookings:", err);
                $item("#cantUsuariosText").text = "error";
            });

        $item("#tablaUsuarios").columns = [{
            "id": "nombre",
            "dataPath": "nombre",
            "label": "Nombre",
            "width": 300,
            "visible": true,
            "type": "string"
        }];

        $item("#cantUsuariosText").onClick(() => {
            console.log("Evento click, _id del evento:", itemData._id);
            wixData.query("BOOKING")
                .eq("idEvento", itemData._id)
                .isEmpty("cancelo")
                .limit(1000)  // Por seguridad, aunque no debería haber tantos bookings por evento
                .find()
                .then((results) => {
                    if (results.items.length > 0) {
                        let usuariosItems = results.items.map(user => ({
                            _id: user._id,
                            idEstudiante: user.idEstudiante,
                            nombre: user.primerNombre + " " + user.primerApellido,
                            email: user.email || "No disponible",
                            fuente: user.fuente || "ACADEMICA"
                        }));
                        $item("#tablaUsuarios").rows = usuariosItems;
                        $item("#tablaUsuarios").expand();
                    } else {
                        console.log("No hay usuarios registrados para este evento.");
                        $item("#tablaUsuarios").hide();
                    }
                })
                .catch((err) => {
                    console.error("Error al cargar usuarios registrados:", err);
                });
        });

        $item("#tablaUsuarios").onRowSelect((event) => {
            const rowData = event.rowData;
            console.log("Fila seleccionada en tablaUsuarios:", rowData);
            redirectUserProfile(
                rowData._id,
                rowData.idEstudiante,
                null,
                false,
                true,
                rowData.fuente || "ACADEMICA",
                rowData.email || "No disponible",

            );
        });
    });
}


// INICIO BUSCADOR
$w("#search").onKeyPress((event) => {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => {
        realizarBusqueda($w("#search").value);
    }, debounceDelay);
});

// -- 1.5 Función para la mayúscula de los items
function capitalizeFirstLetter(string) {
    if (!string || typeof string !== 'string') return '';
    return string.charAt(0).toUpperCase() + string.slice(1).toLowerCase();
}

// 2. INICIO QUERYS Y REPEATERS

// 2.1 INICIO BUSCADOR
function realizarBusqueda(query) {
    $w('#noExiste').hide();

    console.log("Valor ingresado en search:", query); // Muestra lo que el usuario escribió en el campo
    console.log("ID de usuario actual (idUsuario):", idUsuario); // Verifica si idUsuario tiene un valor válido

    // Si el input está vacío o contiene menos de 3 caracteres, resetea el estado sin buscar
    if (query.length < 3) {
        console.warn("La búsqueda requiere al menos 3 caracteres.");
        $w("#resultadoBusqueda").data = []; // Limpia los datos del repetidor
        $w('#resultadoBusqueda').collapse(); // Esconde el repetidor
        return; // Sale de la función para no ejecutar una búsqueda
    }

    // Muestra el indicador de carga
    $w('#loading').expand();

    // Realizar búsquedas simultáneamente en ambas colecciones
    const academicaQuery = wixData.query("ACADEMICA")
        .contains("numeroId", query)
        .or(wixData.query("ACADEMICA").contains("primerNombre", query))
        .or(wixData.query("ACADEMICA").contains("primerApellido", query))
                .or(wixData.query("ACADEMICA").contains("contrato", query))

        .find();

    const advisorsQuery = wixData.query("ADVISORS")
        .contains("numeroId", query)
        .or(wixData.query("ADVISORS").contains("primerNombre", query))
        .or(wixData.query("ADVISORS").contains("primerApellido", query))
        .find();

    // Ejecutar ambas promesas en paralelo
    Promise.all([academicaQuery, advisorsQuery])
        .then(([academicaResults, advisorsResults]) => {
            const combinedResults = [];

            // Procesar resultados de ACADEMICA
            academicaResults.items.forEach(item => {
                combinedResults.push({
                    _id: item._id,
                    primerNombre: item.primerNombre,
                    primerApellido: item.primerApellido,
                    segundoApellido: item.segundoApellido || "",
                    fuente: "ACADEMICA", // Identificador de la fuente
                    numeroId: item.numeroId || "N/A"
                });
            });

            // Procesar resultados de ADVISORS
            advisorsResults.items.forEach(item => {
                combinedResults.push({
                    _id: item._id,
                    primerNombre: item.primerNombre,
                    primerApellido: item.primerApellido,
                    segundoApellido: "", // ADVISORS no tiene campo segundoApellido
                    fuente: "ADVISORS", // Identificador de la fuente
                    numeroId: item.numeroId || "N/A"
                });
            });

            if (combinedResults.length > 0) {
                // Mostrar los resultados combinados
                procesarResultados(combinedResults);
            } else {
                // Si no hay resultados en ninguna colección
                $w('#noExiste').show();
                $w('#resultadoBusqueda').collapse();
            }
        })
        .catch(err => {
            console.error("Error al realizar las búsquedas", err);
            $w('#noExiste').show();
            $w('#resultadoBusqueda').collapse();
        })
        .finally(() => {
            $w('#loading').collapse(); // Esconde el indicador de carga al final
        });
}

function procesarResultados(resultados) {
    $w("#resultadoBusqueda").data = resultados;
    $w('#resultadoBusqueda').expand(); // Muestra el repetidor con los resultados

    $w('#resultadoBusqueda').forEachItem(($item, itemData, index) => {
        const fuenteTexto = itemData.fuente === "ACADEMICA" ? "(ACADEMICA)" : "(ADVISORS)";

        $item("#resultados").text = `ID: ${itemData.numeroId}, ${capitalizeFirstLetter(itemData.primerNombre)} ${capitalizeFirstLetter(itemData.primerApellido)} ${itemData.segundoApellido ? capitalizeFirstLetter(itemData.segundoApellido) : ''} ${fuenteTexto}`;

        // Configuración del evento onClick para realizar la redirección
        $item("#resultados").onClick(() => {
            console.log("Datos del item seleccionado:", itemData);
            redirectUserProfile(itemData._id, itemData.numeroId, null, false, true, itemData.fuente, usuarioEmail);
        });
    });
}

function redirectUserProfile(_id, userId, eventId, showPrimerContactoBox, showSegundoContactoBox, fuente, email) {
    console.log("Redirigiendo con los siguientes datos:");
    console.log("userId:", userId, "eventId:", eventId, "fuente:", fuente, "email:", email);

    wixStorage.local.setItem('userId', userId);
    wixStorage.local.setItem('showPrimerContactoBox', showPrimerContactoBox.toString());
    wixStorage.local.setItem('showSegundoContactoBox', showSegundoContactoBox.toString());

    if (fuente === "ACADEMICA") {
        wixWindow.openLightbox("FICHA CLASE USER", { _id, userId, email }); // ✅ PASA _id AQUÍ
    } else if (fuente === "ADVISORS") {
        wixWindow.openLightbox("FICHA ADVISOR", { _id, userId, email }); // (Opcional si aplica para advisors también)
    } else {
        console.error("Fuente desconocida:", fuente);
    }
}


$w('#subirMaterialButton').onClick((event) => {
    wixWindow.openLightbox("SUBIR MATERIAL")
})

$w('#closeBoxEstudiantes').onClick((event) => {
    $w('#listaEstudiantes').hide()
})

function getStepLabel(nombreEvento) {
    const jumps = [5, 10, 15, 20, 25, 30, 35, 40, 45];
    if (!nombreEvento) return "";
    const match = nombreEvento.toString().match(/(\d+)/);
    const stepNumber = match ? parseInt(match[1]) : null;

    if (stepNumber && jumps.includes(stepNumber)) {
        return `Jump (Step ${stepNumber})`;
    } else if (stepNumber) {
        return `Step ${stepNumber}`;
    } else {
        return nombreEvento;
    }
}

