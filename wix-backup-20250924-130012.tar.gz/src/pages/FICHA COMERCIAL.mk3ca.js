import wixData from 'wix-data';
import wixLocation from 'wix-location';
import wixStorage from 'wix-storage';

// ====================== CONFIG & STATE ======================
const CONFIG = {
  COLLECTIONS: {
    COMERCIAL: 'COMERCIAL',
    FILIALES: 'FILIALES'
  },
  DROPS: {
    FILIAL: '#filial',
    LIDER: '#lider'
  },
  TABLES: ['#tabla1', '#tabla2', '#tabla3', '#tabla4', '#tabla5'],
  GROUPS: {
    INFO_BASICA: '#infoBasicaBox',
    TEAM: '#myTeamGroup',
    TOP_RECTANGLES: '#grupoRectangulosSuperiores'
  },
  WIDGETS: {
    LOADING: '#loading',
    SAVE_BTN: '#guardar',
    FOTO: '#foto',
    COMENTARIO: '#comentarioTexto',
    ROL_ACTUAL: '#rolActual',
    NOMBRES: '#nombres',
    TIPO_USUARIO: '#tipoUsuario',
    CELULAR_TEXT: '#celularText',
    STATUS_TEXT: '#statusText',
    FILIAL_TEXT: '#filialText',
    LIDER_TEXT: '#liderText',
    // Inputs
    PRIMER_NOMBRE: '#primerNombre',
    SEGUNDO_NOMBRE: '#segundoNombre',
    PRIMER_APELLIDO: '#primerApellido',
    SEGUNDO_APELLIDO: '#segundoApellido',
    NUMERO_ID: '#numeroId',
    PAIS: '#pais',
    CIUDAD: '#ciudad',
    DIRECCION: '#direccion',
    EMAIL: '#email',
    CELULAR: '#celular',
    TELEFONO: '#telefono',
    ROL: '#rol'
  },
  BUTTONS: {
    BASICA: '#basicaButton',
    FINANCIERA: '#financieraButton'
  }
};

const STATE = {
  idTitular: null,
  numeroId: null,
  nombreFilial: '',
  jerarquia: [],
  mapaFiliales: {}, // id -> nombre
  mapaLideres: {}   // id -> nombre
};

// ====================== UTILIDADES ======================
const $el = (id) => $w(id);

const capitalizeWords = (str = '') =>
  str.split(' ')
     .filter(Boolean)
     .map(w => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
     .join(' ');

const pad2 = (n) => ('0' + n).slice(-2);

const fechaDDMMYYYY = (d = new Date()) => `${pad2(d.getDate())}/${pad2(d.getMonth() + 1)}/${d.getFullYear()}`;

const hideAllTables = () => CONFIG.TABLES.forEach(t => $el(t).hide());

const setTableColumns = (tableId, label) => {
  $el(tableId).columns = [
    { id: 'nombreCompleto', dataPath: 'nombreCompleto', label, width: 100, visible: true, type: 'string' },
    { id: 'rol',            dataPath: 'rol',            label: '', width: 100, visible: true, type: 'string' }
  ];
};

const setDropdownOptions = (selector, options) => { $el(selector).options = options; };

const safeMerge = (target, patch) => {
  const out = { ...target };
  Object.entries(patch).forEach(([k, v]) => {
    if (v !== undefined) out[k] = v;
  });
  return out;
};

// ====================== CARGAS INICIALES ======================
async function cargarFiliales() {
  const res = await wixData.query(CONFIG.COLLECTIONS.FILIALES).limit(500).find();
  STATE.mapaFiliales = {};
  const options = res.items
    .sort((a, b) => a.filial.localeCompare(b.filial))
    .map(f => {
      STATE.mapaFiliales[f._id] = f.filial;
      return { label: f.filial, value: f._id };
    });
  setDropdownOptions(CONFIG.DROPS.FILIAL, options);
}

async function cargarLideres() {
  const res = await wixData.query(CONFIG.COLLECTIONS.COMERCIAL).limit(500).find();
  STATE.mapaLideres = {};
  const options = res.items
    .sort((a, b) => a.primerNombre.localeCompare(b.primerNombre))
    .map(i => {
      const nombre = `${capitalizeWords(i.primerNombre)} ${capitalizeWords(i.primerApellido)}`;
      STATE.mapaLideres[i._id] = nombre;
      return { label: nombre, value: i._id };
    });
  setDropdownOptions(CONFIG.DROPS.LIDER, options);
}

async function cargarDatosComercialActual() {
  const userId = wixStorage.local.getItem('userId');
  if (!userId) return;

  try {
    const comercialData = await wixData.get(CONFIG.COLLECTIONS.COMERCIAL, userId);
    if (!comercialData) return;

    STATE.idTitular = comercialData._id;
    STATE.numeroId = comercialData.numeroId;

    // Textos rápidos
    $el(CONFIG.WIDGETS.ROL_ACTUAL).text = comercialData.rol || '';
    $el(CONFIG.WIDGETS.NOMBRES).text = `${comercialData.primerNombre || ''} ${comercialData.primerApellido || ''}`.trim();
    $el(CONFIG.WIDGETS.TIPO_USUARIO).text = comercialData.tipoUsuario || '';
    $el(CONFIG.WIDGETS.CELULAR_TEXT).text = comercialData.celular || '';
    $el(CONFIG.WIDGETS.STATUS_TEXT).text = comercialData.aprobacion || '';
    $el(CONFIG.WIDGETS.FOTO).src = comercialData.foto || '';

    // Inputs
    $el(CONFIG.WIDGETS.PRIMER_NOMBRE).value   = comercialData.primerNombre || '';
    $el(CONFIG.WIDGETS.SEGUNDO_NOMBRE).value  = comercialData.segundoNombre || '';
    $el(CONFIG.WIDGETS.PRIMER_APELLIDO).value = comercialData.primerApellido || '';
    $el(CONFIG.WIDGETS.SEGUNDO_APELLIDO).value= comercialData.segundoApellido || '';
    $el(CONFIG.WIDGETS.NUMERO_ID).value       = comercialData.numeroId || '';
    $el(CONFIG.WIDGETS.PAIS).value            = comercialData.pais || '';
    $el(CONFIG.WIDGETS.CIUDAD).value          = comercialData.ciudad || '';
    $el(CONFIG.WIDGETS.DIRECCION).value       = comercialData.domicilio || '';
    $el(CONFIG.WIDGETS.EMAIL).value           = comercialData.email || '';
    $el(CONFIG.WIDGETS.CELULAR).value         = comercialData.celular || '';
    $el(CONFIG.WIDGETS.TELEFONO).value        = comercialData.telefono || '';
    $el(CONFIG.WIDGETS.ROL).value             = comercialData.rol || '';
    $el(CONFIG.WIDGETS.COMENTARIO).value      = comercialData.comentariosAdministrativo || '';

    // Filial
    if (comercialData.filial) {
      $el(CONFIG.DROPS.FILIAL).value = comercialData.filial;
      STATE.nombreFilial = STATE.mapaFiliales[comercialData.filial] || '';
      $el(CONFIG.WIDGETS.FILIAL_TEXT).text = STATE.nombreFilial || 'Nombre de filial no disponible';
    }

    // Líder
    if (comercialData.lider) {
      $el(CONFIG.DROPS.LIDER).value = comercialData.lider;
      const nombreLider = STATE.mapaLideres[comercialData.lider] || '';
      $el(CONFIG.WIDGETS.LIDER_TEXT).text = nombreLider || 'Nombre de líder no disponible';
    }
  } catch (err) {
    console.error('Error al cargar datos comerciales:', err);
  }
}

// ====================== UI / EVENTOS ======================
function prepararCampoComentario() {
  // Inserta una cabecera de fecha para el siguiente comentario
  let txt = $el(CONFIG.WIDGETS.COMENTARIO).value || '';
  if (txt.trim().length > 0) txt += '\n\n';
  txt += `Fecha: ${fechaDDMMYYYY()}\n`;
  $el(CONFIG.WIDGETS.COMENTARIO).value = txt;
}

function configurarBotones() {
  // Estado inicial
  hideAllTables();
  $el(CONFIG.WIDGETS.COMENTARIO).onFocus(prepararCampoComentario);

  // Financiera (muestra organigrama)
  $el(CONFIG.BUTTONS.FINANCIERA).onClick(() => {
    hideAllTables();
    $el(CONFIG.GROUPS.INFO_BASICA).hide();
    $el(CONFIG.GROUPS.TEAM).expand();
    $el(CONFIG.GROUPS.TOP_RECTANGLES).collapse();

    cargarOrganigramaInicial();
  });

  // Básica
  $el(CONFIG.BUTTONS.BASICA).onClick(() => {
    hideAllTables();
    $el(CONFIG.GROUPS.INFO_BASICA).show();
    $el(CONFIG.GROUPS.TEAM).collapse();
    $el(CONFIG.GROUPS.TOP_RECTANGLES).expand();
  });

  // Dropdowns
  $el(CONFIG.DROPS.LIDER).onChange(() => {
    const id = $el(CONFIG.DROPS.LIDER).value;
    console.log('ID del líder seleccionado:', id);
    $el(CONFIG.WIDGETS.LIDER_TEXT).text = STATE.mapaLideres[id] || '';
  });

  // Guardar
  $el(CONFIG.WIDGETS.SAVE_BTN).onClick(guardarDatos);
}

function configurarTablas() {
  setTableColumns('#tabla1', 'NIVEL 1');
  setTableColumns('#tabla2', 'NIVEL 2');
  setTableColumns('#tabla3', 'NIVEL 3');
  setTableColumns('#tabla4', 'NIVEL 4');
  setTableColumns('#tabla5', 'NIVEL 5');

  // Clicks encadenados
  $el('#tabla1').onRowSelect((e) => mostrarSubordinadosEnTabla(e.rowData._id, '#tabla2', ['#tabla3', '#tabla4', '#tabla5']));
  $el('#tabla2').onRowSelect((e) => mostrarSubordinadosEnTabla(e.rowData._id, '#tabla3', ['#tabla4', '#tabla5']));
  $el('#tabla3').onRowSelect((e) => mostrarSubordinadosEnTabla(e.rowData._id, '#tabla4', ['#tabla5']));
  $el('#tabla4').onRowSelect((e) => mostrarSubordinadosEnTabla(e.rowData._id, '#tabla5', []));
}

// ====================== GUARDADO ======================
async function guardarDatos() {
  $el(CONFIG.WIDGETS.LOADING).show();

  try {
    const id = STATE.idTitular;
    if (!id) throw new Error('Sin idTitular para actualizar');

    const original = await wixData.get(CONFIG.COLLECTIONS.COMERCIAL, id);

    const patch = {
      idUsuario: id, // mantengo tu campo si lo usas en otros procesos
      primerNombre: $el(CONFIG.WIDGETS.PRIMER_NOMBRE).value || undefined,
      segundoNombre: $el(CONFIG.WIDGETS.SEGUNDO_NOMBRE).value || undefined,
      primerApellido: $el(CONFIG.WIDGETS.PRIMER_APELLIDO).value || undefined,
      segundoApellido: $el(CONFIG.WIDGETS.SEGUNDO_APELLIDO).value || undefined,
      numeroId: $el(CONFIG.WIDGETS.NUMERO_ID).value || undefined,
      pais: $el(CONFIG.WIDGETS.PAIS).value || undefined,
      ciudad: $el(CONFIG.WIDGETS.CIUDAD).value || undefined,
      domicilio: $el(CONFIG.WIDGETS.DIRECCION).value || undefined,
      email: $el(CONFIG.WIDGETS.EMAIL).value || undefined,
      celular: $el(CONFIG.WIDGETS.CELULAR).value || undefined,
      telefono: $el(CONFIG.WIDGETS.TELEFONO).value || undefined,
      rol: $el(CONFIG.WIDGETS.ROL).value || undefined,
      filial: $el(CONFIG.DROPS.FILIAL).value || undefined,
      lider: $el(CONFIG.DROPS.LIDER).value || undefined,
      comentariosAdministrativo: $el(CONFIG.WIDGETS.COMENTARIO).value || undefined
    };

    // Limpia undefined
    Object.keys(patch).forEach(k => patch[k] === undefined && delete patch[k]);

    if (Object.keys(patch).length === 0) {
      console.log('No hay cambios para actualizar.');
      $el(CONFIG.WIDGETS.LOADING).hide();
      return;
    }

    const toUpdate = safeMerge(original, patch);
    const updated = await wixData.update(CONFIG.COLLECTIONS.COMERCIAL, toUpdate);

    // Feedback UI
    $el(CONFIG.WIDGETS.SAVE_BTN).label = 'GUARDADO √';
    setTimeout(() => { $el(CONFIG.WIDGETS.SAVE_BTN).label = 'Guardar'; }, 3000);
    console.log('Registro actualizado correctamente', updated);
  } catch (err) {
    console.error('Error al actualizar el registro:', err);
  } finally {
    $el(CONFIG.WIDGETS.LOADING).hide();
  }
}

// ====================== ORGANIGRAMA ======================
async function cargarOrganigramaInicial() {
  if (!STATE.idTitular) return;
  try {
    const res = await wixData.query(CONFIG.COLLECTIONS.COMERCIAL)
      .eq('_id', STATE.idTitular)
      .find();

    STATE.jerarquia = res.items || [];
    actualizarUIOrganigrama();
  } catch (e) {
    console.error('Error cargando organigrama:', e);
  }
}

function actualizarUIOrganigrama() {
  mostrarSubordinadosEnTabla(STATE.idTitular, '#tabla1');
  $el('#repeater1').data = STATE.jerarquia;
  $el('#repeater1').forEachItem(($item, itemData) => {
    const nombre = `${capitalizeWords(itemData.primerNombre)} ${capitalizeWords(itemData.primerApellido)}`.trim();
    $item('#text1').text = `Red: ${nombre}-${STATE.nombreFilial || ''}`;
  });
}

async function cargarSubordinados(managerId) {
  const res = await wixData.query(CONFIG.COLLECTIONS.COMERCIAL).eq('lider', managerId).find();
  return res.items || [];
}

async function mostrarSubordinadosEnTabla(managerId, tablaId, tablasAOcultar = []) {
  try {
    const subordinados = await cargarSubordinados(managerId);
    if (subordinados.length > 0) {
      const rows = subordinados.map(s => ({
        nombreCompleto: `${capitalizeWords(s.primerNombre)} ${capitalizeWords(s.primerApellido)}`.trim(),
        rol: s.rol || '',
        _id: s._id
      }));
      $el(tablaId).rows = rows;
      $el(tablaId).show();
      (tablasAOcultar || []).forEach(t => $el(t).hide());
    } else {
      (tablasAOcultar || []).forEach(t => $el(t).hide());
      $el(tablaId).rows = [];
      $el(tablaId).hide();
    }
  } catch (e) {
    console.error('Error mostrando subordinados:', e);
  }
}

// ====================== INIT ======================
$w.onReady(async function () {
  try {
    // Estado inicial UI
    hideAllTables();
    $el(CONFIG.GROUPS.INFO_BASICA).show();
    $el(CONFIG.GROUPS.TEAM).collapse();
    $el(CONFIG.GROUPS.TOP_RECTANGLES).expand();

    configurarTablas();
    configurarBotones();

    await Promise.all([cargarFiliales(), cargarLideres()]);
    await cargarDatosComercialActual(); // depende de mapas ya cargados
  } catch (e) {
    console.error('Error en inicialización:', e);
  }
});
