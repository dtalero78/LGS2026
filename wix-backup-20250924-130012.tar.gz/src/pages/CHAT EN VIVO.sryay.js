import wixRealtimeFrontend from 'wix-realtime-frontend';
import { sendmessage } from 'backend/realTimeChat'

let userName;

$w.onReady(function () {
    suscribeToChannel();
});

$w('#sendName').onClick(() => {
   userName = $w('#userName').value;
});

$w('#sendMessage').onClick(() => {
   const message = $w('#message').value;
   // Asumiendo que quieres enviar el nombre de usuario junto con el mensaje
   sendmessage({name: userName, message});
});

const suscribeToChannel = () => {
   const channel = { "name": "updateChannel" };
   wixRealtimeFrontend.subscribe(channel, (message, channel) => {
       let payload = message.payload;
$w('#messageText').text = payload.name

       updateRepeater([payload]); // Se pasa como un array para cumplir con la estructura esperada por el repetidor
   })
   .then((id) => {});
}

function updateRepeater(data) {
   // Genera _id único para cada ítem si aún no lo tiene
   const dataWithIds = data.map((item, index) => {
       // Verifica si el ítem ya tiene un _id, si no, asigna uno nuevo
       if (!item._id) {
           return { ...item, _id: String(index) }; // Aquí puedes generar un UUID o usar otra forma de generar IDs únicos
       }
       return item;
   });

   // Actualiza el repetidor con los nuevos datos que ahora incluyen un _id
   $w('#repeaterTitulares').data = dataWithIds;
   
   $w('#repeaterTitulares').forEachItem(($item, itemData, index) => {
       $item('#someTextElement').text = itemData.name; // Asigna el 'name' al elemento de texto dentro del repetidor
   });
}

