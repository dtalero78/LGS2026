import wixData from 'wix-data';
import { sendPoll } from 'backend/WHP';
import wixLocation from 'wix-location';
import { callOpenAI } from 'backend/OpenAI';
import { sendTextMessage } from 'backend/WHP';
import { sendmessage } from 'backend/realTimeChat';
import { session } from 'wix-storage';

import { actualizarNivelYStepDeUnEstudiante } from 'backend/clases.jsw';

// Declarar variables globales
let globalCelular = null;
let encuestasPreparadas = [];
let selectedStudentId = null;
let encuestaIndex = 0;
let advisorName = "";
let nivelEvento;
let prompt;
let stepEvento;
let advisorIdParaGuardar;
let globalNombre;
let comentarios;
let eventoId;

const textFieldMap = {
    preguntas: '#suggestions',
};

$w.onReady(function () {

    // -----  BLOQUE DE RECONOCIMIENTO DE TOKEN LOGIN

    const tokenData = JSON.parse(session.getItem('accessToken'));
    if (tokenData) {
        const currentTime = new Date().getTime();
        // Convertir el tiempo de expiración a una fecha legible
        const expirationDate = new Date(tokenData.expiresAt);
        console.log(`El token expira el: ${expirationDate.toLocaleString()}`);
        if (currentTime > tokenData.expiresAt) {
            // Token ha expirado
            session.removeItem('accessToken');
            console.log("Token Acabado") // Eliminar el token expirado
            wixLocation.to(`/login`); // Redirigir a una página de error o login
        } else {
            // Token es válido
            // Aquí puedes continuar cargando el contenido de la página
        }
    } else {
        console.log("Token Expirado") // Eliminar el token expirado
        wixLocation.to(`/login`); // Redirigir a una página de error o login
    }
    //

    const dataset = $w('#dynamicDataset');
    dataset.onReady(() => {
        const datosClase = dataset.getCurrentItem();
        nivelEvento = datosClase.tituloONivel;
        stepEvento = datosClase.nombreEvento;
        eventoId = datosClase._id;

        configurarEventos();
        cargarEstudiantes();

        $w('#suggestButton').disable();
        $w('#className').text = nivelEvento + " " + stepEvento

    });
});

function configurarEventos() {
    // Configurar el evento onClick para el botón materialButton
    $w('#materialButton').onClick(() => {
        $w('#materialBox').show();
        cargarMaterial();
    });

    configurarTabla();

    $w('#materialTable').onRowSelect((event) => {
        const selectedRowData = event.rowData;
        const url = selectedRowData.url; // Obtener la URL del archivo del campo "url"
        if (url) {
            // Redirigir al usuario a la URL del archivo para descargarlo
            wixLocation.to(url);
        }
    });

    $w('#closeMaterialBox').onClick(() => {
        $w('#materialBox').hide();
    });

    $w('#comentariosParaUsuario').onFocus(() => prepararCampoComentario('#comentariosParaUsuario'));
    $w('#advisorAnotaciones').onFocus(() => prepararCampoComentario('#advisorAnotaciones'));

    // Configurar evento onClick para el botón Guardar
    $w('#guardarComentariosParaUsuariosButton').onClick(() => {
        guardarComentariosYCalificacion();
    });

    $w('#guardarAnotacionesAdvisorButton').onClick(() => {
        guardarAnotacionesAdvisor();
    });

    $w('#saveSuggestionsButton').onClick(() => {
        guardarSugerencias();
    });

    $w('#advisorNotesButton').onClick(() => {
        if (!selectedStudentId) {
            // No hay alumno seleccionado
            $w('#advisorNotesButton').label = "ESCOGE UN USUARIO!";
        } else {
            // Ya hay alumno, mostramos el box y ponemos el label correcto
            $w('#advisorNotesButton').label = "Rate and LGS Comments";
            $w('#advisorNotes').show();
        }
    });

    $w('#rateStudentButton').onClick(() => {
        if (!selectedStudentId) {
            // No hay alumno seleccionado
            $w('#rateStudentButton').label = "ESCOGE UN USUARIO!";
        } else {
            // Ya hay alumno, mostramos el box y ponemos el label correcto
            $w('#rateStudentButton').label = "Comment to user";
            $w('#rateStudent').show();
        }

    });

    // Preparar la encuesta
    $w('#createPollButton').onClick((event) => {
        if (encuestaIndex < 3) {
            crearEncuesta();
        } else {
            console.warn("Se ha alcanzado el límite de 3 encuestas.");
        }
    });

    $w('#suggestButton').onClick(async () => {
        $w('#loading').show();
        $w('#whpBox').hide();
        $w('#sessionSuggestedBox').hide();
        await manejarClicBoton('suggestions2', true);
        $w('#userSuggestionsBox').show();
        $w('#loading').hide();
    });

    $w('#generateActivitieSession').onClick(() => manejarClicBoton('suggestedSessionActivities', false));

    $w('#whpExerciseButt').onClick(() => {
        $w('#whpBox').show();
        $w('#userSuggestionsBox').hide();
        $w('#sessionSuggestedBox').hide();
    });

    $w('#aISuggestedActivitiesButt').onClick(async () => {
        $w('#loading').show();
        $w('#whpBox').hide();
        $w('#userSuggestionsBox').hide();
        $w('#sessionSuggestedBox').show();
        $w('#loading').hide();
    });

}

function configurarTabla() {
    $w("#materialTable").columns = [
        { "id": "name", "dataPath": "name", "label": "File Name", "width": 300, "visible": true, "type": "string" }
    ];
}

function cargarMaterial() {
    console.log("Material del step:", stepEvento)
    wixData.query("NIVELES")
        .eq("step", stepEvento)
        .find()
        .then((results) => {
            if (results.items.length > 0) {
                const item = results.items[0]; // Suponiendo que step es único
                console.log(item);
                const materiales = item.material; // Obtener el campo "material"
                console.log(materiales);
                if (materiales && Array.isArray(materiales)) {
                    // Crear un arreglo de objetos para la tabla
                    const tableData = materiales.map((material, index) => {
                        return {
                            "index": index + 1,
                            "name": decodeURIComponent(extractFileName(material)), // Nombre del archivo
                            "url": material // URL del archivo
                        };
                    });

                    // Actualizar la tabla con los datos
                    $w('#materialTable').rows = tableData;
                } else if (typeof materiales === 'string') {
                    // Si 'material' es una cadena de texto
                    const tableData = [{
                        "index": 1,
                        "name": decodeURIComponent(extractFileName(materiales)), // Nombre del archivo
                        "url": materiales // URL del archivo
                    }];
                    console.log(tableData);

                    // Actualizar la tabla con los datos
                    $w('#materialTable').rows = tableData;
                } else {
                    console.warn("No se encontraron materiales en el campo 'material'.");
                    $w('#materialTable').rows = []; // Limpiar la tabla si no hay materiales
                }
            } else {
                console.warn("No se encontraron resultados para el step proporcionado.");
                $w('#materialTable').rows = []; // Limpiar la tabla si no se encuentran resultados
            }
        })
        .catch((error) => {
            console.error("Error al consultar la base de datos NIVELES:", error);
        });
}

function extractFileName(url) {
    const parts = url.split('/');
    return parts[parts.length - 1];
}

function cleanTextContent(textField, nombre) {
    const field = $w(`#${textField}`);
    let fieldValue = field.value || "";

    // Solo procede si hay contenido en el campo de texto
    if (fieldValue) {
        // Decodifica entidades HTML
        fieldValue = fieldValue.replace(/&quot;/g, '"');
        fieldValue = fieldValue.replace(/&amp;/g, '&');
        fieldValue = fieldValue.replace(/&lt;/g, '<');
        fieldValue = fieldValue.replace(/&gt;/g, '>');
        fieldValue = fieldValue.replace(/&nbsp;/g, ' ');

        // Elimina todas las etiquetas HTML
        fieldValue = fieldValue.replace(/<\/?[^>]+(>|$)/g, "");

        // Maneja los saltos de línea y otros caracteres especiales
        fieldValue = fieldValue.replace(/\\n/g, "\n");
        fieldValue = fieldValue.replace(/\\t/g, "\t");
        fieldValue = fieldValue.replace(/\\'/g, "'");
        fieldValue = fieldValue.replace(/\\"/g, '"');

        // Reemplaza cualquier \ que no esté seguido por "n" con un espacio
        fieldValue = fieldValue.replace(/\\(?!n)/g, " ");

        // Añade salto de línea después de cada punto y ajusta los espacios
        fieldValue = fieldValue.replace(/\.([^\n])/g, ".\n$1");
        fieldValue = fieldValue.replace(/\s\s+/g, " ");

        // Ajusta las listas numeradas y con viñetas
        fieldValue = fieldValue.replace(/(\d+)\.\s*/g, "\n$1. ");
        fieldValue = fieldValue.replace(/-\s/g, "\n- ");

        // Elimina puntos adicionales y ajusta los saltos de línea
        fieldValue = fieldValue.replace(/\.\.\.\s*/g, ".\n");

        // Elimina saltos de línea extra al principio
        fieldValue = fieldValue.replace(/^\s+/, '');

        // Solo añade "Hola [Nombre]" si nombre no está vacío
        if (nombre) {
            // Verifica si el saludo ya está presente y añádelo si no está
            if (!fieldValue.startsWith(`Hola ${nombre},\n\n`)) {
                fieldValue = `Hola ${nombre},\n\n` + fieldValue;
            }
        }

        // Actualiza el campo de texto con el texto corregido
        field.value = fieldValue;
    } else {
        console.warn(`El campo de texto ${textField} está vacío o indefinido`);
    }
}

function cargarEstudiantes() {
    const infoEvento = $w('#dynamicDataset').getCurrentItem();
    const advisorId = infoEvento.advisor;

    wixData.query("CLASSES")
        .eq("idEvento", infoEvento._id)
        .find()
        .then(async (results) => {
            const numEstudiantesInscritos = results.items.length;
            console.log("Número de estudiantes inscritos:", numEstudiantesInscritos);

            const studentsPromises = results.items.map(async (classItem) => {
                try {
                    const studentDetail = await wixData.get("ACADEMICA", classItem.idEstudiante);

                    if (!studentDetail || !studentDetail._id) {
                        console.warn("Estudiante inválido o sin _id:", classItem.idEstudiante);
                        return null;
                    }

                    return {
                        _id: studentDetail._id,
                        name: `${studentDetail.primerNombre} ${studentDetail.primerApellido}`,
                        platform: studentDetail.plataforma,
                        age: studentDetail.edad,
                        email: studentDetail.email,
                        celular: studentDetail.celular,
                        hobbies: studentDetail.hobbies,
                        foto: studentDetail.foto,
                        calificacion: classItem.calificacion || 'N/A'
                    };
                } catch (err) {
                    console.error("Error al obtener estudiante:", classItem.idEstudiante, err);
                    return null;
                }
            });

            const studentsDetails = await Promise.all(studentsPromises);
            const studentsData = studentsDetails.filter(item => item && item._id);
            console.log("Datos finales para el repetidor:", studentsData);

            $w('#repeaterStudents').data = studentsData;

            $w('#repeaterStudents').forEachItem(($item, itemData, index) => {
                $item('#nameRepeaterStudents').text = itemData.name || "Nombre no disponible";
                $item('#plataformRepeaterStudents').text = itemData.platform || "-";
                $item('#ageRepeaterStudents').text = itemData.age ? itemData.age.toString() : "-";

                const fotoValida = itemData.foto && itemData.foto.startsWith("http") ?
                    itemData.foto :
                    "https://static.wixstatic.com/media/default-avatar.jpg";

                $item('#photoRepeaterStudents').src = fotoValida;
                console.log("Foto del estudiante:", fotoValida);

                if (itemData.calificacion === 'N/A') {
                    $item('#calificacionRepeater').html = `<p style='font-size: 13px; font-family: Helvetica Neue; font-weight: 700; text-align: left; color: red;'>${itemData.calificacion}</p>`;
                } else {
                    $item('#calificacionRepeater').html = `<p style='font-size: 13px; font-family: Helvetica Neue; font-weight: 700; text-align: left; color: green;'>${itemData.calificacion}</p>`;
                }

                $item('#nameRepeaterStudents').onClick(() => {
                    $w('#guardarAnotacionesAdvisorButton').label = "Guardar";
                    $w('#guardarComentariosParaUsuariosButton').label = "Guardar";
                    $w('#studentNameBox').text = `${itemData.name}`;
                    $w('#plataformStudentBox').text = itemData.platform;
                    $w('#hobbiesText').text = itemData.hobbies;
                    $w('#photoStudentBox').src = fotoValida;

                    selectedStudentId = itemData._id;
                    // restablecemos el label del botón al seleccionar un alumno
                    $w('#advisorNotesButton').label = "Rate and LGS Comments";
                    $w('#rateStudentButton').label = "Comment to user";

                    wixData.query("CLASSES")
                        .eq("idEstudiante", selectedStudentId)
                        .eq("idEvento", eventoId)
                        .find()
                        .then((results) => {
                            if (results.items.length > 0) {
                                const classItem = results.items[0];
                                $w('#asistenciaCheckBox').checked = classItem.asistencia || false;
                                $w('#participacionCheckBox').checked = classItem.participacion || false;
                                $w('#advisorAnotaciones').value = classItem.advisorAnotaciones || '';
                                $w('#comentariosParaUsuario').value = classItem.comentarios || '';
                                $w('#calificacion').value = classItem.calificacion || '';

                                $w('#suggestButton').enable();
                            } else {
                                console.error("No se encontró ningún ítem en CLASSES con los criterios proporcionados.");
                            }
                        })
                        .catch((error) => {
                            console.error("Error al consultar CLASSES:", error);
                        });
                });
            });

            obtenerDetallesAdvisor(advisorId);
        })
        .catch((error) => {
            console.error("Error al cargar detalles de estudiantes:", error);
        });
}

function prepararCampoComentario(elementId) {
    let comentarioActual = $w(elementId).value;

    if (!comentarioActual.trim()) {
        comentarioActual = `Fecha: ${obtenerFechaActualComoString()}\nAdvisor: ${advisorName}\n`;
        $w(elementId).value = comentarioActual;
    }
}

function obtenerFechaActualComoString() {
    const fecha = new Date();
    return fecha.toLocaleDateString('es-CL', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric'
    });
}

function crearEncuesta() {
    $w('#repeaterEncuestas').show();
    let respuestas = [
        $w('#answerOne').value.trim(),
        $w('#answerTwo').value.trim(),
        $w('#answerThree').value.trim(),
        $w('#answerFour').value.trim(),
        $w('#answerFive').value.trim()
    ].filter(r => r); // Filtrar respuestas vacías

    let tituloEncuesta = $w('#pollTitle').value.trim();

    if (!tituloEncuesta) {
        console.error("El título de la encuesta está vacío.");
        return;
    }

    let encuesta = {
        _id: tituloEncuesta.replace(/\s/g, '-'),
        titulo: tituloEncuesta,
        respuestas: respuestas,
        cantidadRespuestas: 1 // Ajustar a 1
    };

    encuestasPreparadas.push(encuesta);
    encuestaIndex++;

    console.log("Encuesta preparada:", encuesta);

    limpiarCamposEncuesta();

    actualizarRepetidorEncuestas();
}

function limpiarCamposEncuesta() {
    $w('#pollTitle').value = '';
    $w('#answerOne').value = '';
    $w('#answerTwo').value = '';
    $w('#answerThree').value = '';
    $w('#answerFour').value = '';
    $w('#answerFive').value = '';
}

function actualizarRepetidorEncuestas() {

    console.log("actualizando encuesta", encuestasPreparadas);
    $w('#repeaterEncuestas').data = encuestasPreparadas;
    $w('#repeaterEncuestas').forEachItem(($item, itemData, index) => {
        console.log("Procesando encuesta:", itemData);

        // Verificar que itemData tenga la propiedad titulo
        if (itemData && itemData.titulo) {
            $item('#tituloEncuesta').text = itemData.titulo;
        } else {
            $item('#tituloEncuesta').text = 'Sin título';
        }

        console.log("Título de la encuesta en repetidor:", itemData.titulo);

        $item('#enviarEncuestaButton').onClick(() => {
            enviarEncuesta(itemData);
        });
    });
}

////////////////////////

async function guardarAnotacionesAdvisor() {
  $w('#loading1').show();

  if (!selectedStudentId) {
    console.error("No hay ningún estudiante seleccionado");
    $w('#loading1').hide();
    return;
  }

  try {
    console.log("Selected Student ID:", selectedStudentId);

    const advisorAnotaciones = $w('#advisorAnotaciones').value;
    const asistencia         = $w('#asistenciaCheckBox').checked;
    const participacion      = $w('#participacionCheckBox').checked;
    const calificacion       = $w('#calificacion').value;

    // 1) Obtener la clase (CLASSES) del evento para este estudiante
    const classesRes = await wixData.query("CLASSES")
      .eq("idEstudiante", selectedStudentId)
      .eq("idEvento", eventoId)
      .limit(1)
      .find();

    if (!classesRes.items.length) {
      throw new Error("No se encontró un ítem en CLASSES con idEstudiante: " + selectedStudentId);
    }

    const classItem = classesRes.items[0];

    // 2) Actualizar campos en CLASSES
    classItem.advisorAnotaciones = advisorAnotaciones;
    classItem.asistencia         = asistencia;
    classItem.participacion      = participacion;
    classItem.calificacion       = calificacion;

    // Reglas de promoción
    const sePromueve = participacion && (classItem.nivel === "WELCOME" || classItem.step === "WELCOME");
    if (sePromueve) {
      classItem.nivel = "BN1";
      classItem.step  = "Step 1";
      console.log("Usuario promovido de WELCOME a BN1 Step 1 (CLASSES)");
    }

    const updatedClass = await wixData.update("CLASSES", classItem);

    // 3) Actualizar BOOKING (asistencia)
    const bookingRes = await wixData.query("BOOKING")
      .eq("idEstudiante", selectedStudentId)
      .eq("idEvento", updatedClass.idEvento)
      .limit(1)
      .find();

    if (!bookingRes.items.length) {
      throw new Error("No se encontró un ítem en BOOKING con idEvento: " + updatedClass.idEvento);
    }

    const bookingItem = bookingRes.items[0];
    bookingItem.asistio = participacion;
    await wixData.update("BOOKING", bookingItem);

    // 4) Si hubo promoción, actualizar también ACADEMICA (estado vigente del estudiante)
    if (sePromueve) {
      const estudiante = await wixData.get("ACADEMICA", selectedStudentId); // selectedStudentId == _id en ACADEMICA
      estudiante.nivel = "BN1";
      estudiante.step  = "Step 1";
      await wixData.update("ACADEMICA", estudiante); // <-- Aquí se guarda el cambio en ACADEMICA
      console.log("Nivel y step actualizados en ACADEMICA");
    }

    // 5) (Opcional) backend para reglas adicionales/sincronización
    if (participacion && selectedStudentId) {
      try {
        const resultado = await actualizarNivelYStepDeUnEstudiante(selectedStudentId);
        console.log(`🔁 Nivel/step backend -> promovido:${resultado.promovido}, nivel:${resultado.nuevoNivel}, step:${resultado.nuevoStep}`);
        console.log(`🧩 Steps evaluados:`, resultado.stepsEvaluados);
        console.log(`✳️ Overrides aplicados:`, resultado.overrides);
      } catch (e) {
        console.error("❌ Error al actualizar nivel/step en backend:", e);
      }
    }

    // 6) Notificación realtime + UI
    await sendmessage("calificacionUsuario", { type: "updateComplete" });
    $w('#guardarAnotacionesAdvisorButton').label = "¡Guardada!";
    console.log("Anotaciones del advisor y asistencia actualizadas");
    cargarEstudiantes();

  } catch (error) {
    console.error("Error al guardar las anotaciones del advisor o la asistencia:", error);
  } finally {
    $w('#loading1').hide();
  }
}



function guardarSugerencias() {
    if (selectedStudentId) {
        // Obtener el nombre del estudiante de forma segura
        const nombreEstudiante = $w('#studentNameBox').text.trim() || "Estudiante";

        // Obtener el valor de suggestions2 y limpiar el texto
        cleanTextContent('suggestions2', nombreEstudiante);
        let actividadPropuesta = $w('#suggestions2').value;

        // Obtener el ítem del estudiante de la base de datos CLASSES usando idEstudiante
        wixData.query("CLASSES")
            .eq("idEstudiante", selectedStudentId)
            .find()
            .then((results) => {
                if (results.items.length > 0) {
                    let item = results.items[0]; // Suponiendo que idEstudiante es único

                    // Actualizar solo el campo actividadPropuesta
                    item.actividadPropuesta = actividadPropuesta;

                    // Actualizar el ítem en la base de datos CLASSES
                    wixData.update("CLASSES", item)
                        .then((updatedItem) => {
                            // Cambiar la etiqueta del botón para indicar éxito
                            $w('#saveSuggestionsButton').label = "¡Guardado!";
                            console.log("Sugerencias actualizadas", updatedItem);
                            $w('#suggestions2').value = "ACTIVIDAD ENVIADA!";
                            $w('#saveSuggestionsButton').label = "Guardar";

                            // Enviar la actividad al estudiante
                            enviarActividad(globalCelular, actividadPropuesta);
                            console.log("CELUCO ENVIO"), globalCelular
                        })
                        .catch((error) => {
                            // Registrar error si la actualización falla
                            console.error("Error al actualizar sugerencias", error);
                        });
                } else {
                    console.error("No se encontró un ítem en CLASSES con idEstudiante:", selectedStudentId);
                }
            })
            .catch((error) => {
                // Registrar error si la consulta falla
                console.error("Error al consultar CLASSES con idEstudiante:", selectedStudentId, error);
            });
    } else {
        // Registrar error si no hay ningún estudiante seleccionado
        console.error("No hay ningún estudiante seleccionado");
    }
}

function guardarComentariosYCalificacion() {
    $w('#loading2').show();
    if (selectedStudentId) {
        console.log("Estudiante ID:", selectedStudentId);
        console.log("Este evento id", eventoId);

        // Obtener los valores de los campos de entrada
        let comentarios = $w('#comentariosParaUsuario').value;
        let actividadPropuesta = $w('#suggestions2').value;

        // Obtener el ítem del estudiante de la base de datos CLASSES usando idEstudiante e idEvento
        wixData.query("CLASSES")
            .eq("idEstudiante", selectedStudentId)
            .eq("idEvento", eventoId) // Agregar la condición del idEvento
            .find()
            .then((results) => {
                if (results.items.length > 0) {
                    let item = results.items[0]; // Suponiendo que idEstudiante e idEvento son únicos
                    console.log("si corresponde al id de la clase", "Item obtenido de CLASSES:", item);

                    // Actualizar el ítem con los nuevos valores
                    item.comentarios = comentarios;

                    // Actualizar el ítem en la base de datos CLASSES
                    wixData.update("CLASSES", item)
                        .then((updatedItem) => {
                            // Cambiar la etiqueta del botón para indicar éxito
                            $w('#guardarComentariosParaUsuariosButton').label = "¡Guardada!";
                            $w('#loading2').hide();
                            console.log("Comentarios y calificación actualizados", updatedItem);
                            // ----------------------------------------------------------
                            // Enviar mensaje PARA ACTUALIZAR CANAL en este caso el comentarios para el usuario
                            sendmessage("comentariosAdvisor", { type: "updateComplete" })
                                .then(response => {
                                    console.log("Mensaje enviado con éxito:", response);
                                });
                            // ----------------------------------------------------------
                        })
                        .catch((error) => {
                            // Registrar error si la actualización falla
                            console.error("Error al actualizar comentarios y calificación", error);
                        });
                } else {
                    console.error("No se encontró un ítem en CLASSES con idEstudiante e idEvento:", selectedStudentId, eventoId);
                }
            })
            .catch((error) => {
                // Registrar error si la consulta falla
                console.error("Error al consultar CLASSES con idEstudiante e idEvento:", selectedStudentId, eventoId, error);
            });
    } else {
        // Registrar error si no hay ningún estudiante seleccionado
        console.error("No hay ningún estudiante seleccionado");
    }
}

function obtenerDetallesAdvisor(advisorId) {
    wixData.get("ADVISORS", advisorId)
        .then((advisorDetails) => {
            advisorName = `${advisorDetails.primerNombre} ${advisorDetails.primerApellido}`;
            advisorIdParaGuardar = advisorDetails._id;
            $w('#advisorName').text = advisorName
        })
        .catch((error) => {
            console.error("Error al obtener detalles del Advisor:", error);
        });
}

function enviarEncuesta(encuesta) {
    // Obtenemos todos los estudiantes del repetidor
    const estudiantes = $w('#repeaterStudents').data;

    // Iteramos sobre cada estudiante y enviamos la encuesta
    estudiantes.forEach(estudiante => {
        const celular = estudiante.celular;
        sendPoll(celular, encuesta.titulo, encuesta.respuestas, 1) // Asegurar que count sea 1
            .then(response => {
                console.log(`Encuesta enviada a ${celular}`, response);
            })
            .catch(err => {
                console.error(`Error al enviar encuesta a ${celular}`, err);
            });
    });
}

function enviarActividad(celular, actividad) {
    sendTextMessage(celular, actividad)
        .then(response => {
            console.log("Actividad enviada", response);
        })
        .catch(err => {
            console.error("Error al enviar actividad", err);
        });
}

function enviarCalificacion(celular, comentarios) {
    sendTextMessage(celular, comentarios)
        .then(response => {
            console.log("Actividad enviada", response);
        })
        .catch(err => {
            console.error("Error al enviar actividad", err);
        });
}

async function manejarClicBoton(targetElementId, fetchStudentData) {
    console.log('Target Element ID:', targetElementId); // Verificar el ID del elemento
    $w('#loading').show();
    try {
        let perfilEstudiante = '';

        if (fetchStudentData && selectedStudentId) {
            const studentDataQuery = await wixData.query("ACADEMICA")
                .eq("_id", selectedStudentId)
                .find();

            if (studentDataQuery.items.length > 0) {
                const studentData = studentDataQuery.items[0];
                const { edad, plataforma, hobbies, celular } = studentData;
                perfilEstudiante = `Edad: ${edad}, Plataforma: ${plataforma}, Hobbies: ${hobbies}`;
                globalCelular = celular
            } else {
                console.error('No se encontraron datos del estudiante.');
                $w('#loading').hide();
                return;
            }
        }

        const nivelesResult = await wixData.query("NIVELES").eq("code", nivelEvento).find();
        console.log("nivel Evento", nivelEvento)
        if (nivelesResult.items.length > 0) {
            const contenidoNivel = nivelesResult.items[0].contenido;
            const prompt = construirPrompt(perfilEstudiante, contenidoNivel, fetchStudentData);
            await actividadPersonal(prompt, targetElementId);
            console.log(prompt)
            console.log(contenidoNivel)

        }

        $w('#loading').hide();
    } catch (error) {
        console.error('Error fetching data:', error);
        $w('#loading').hide();
    }
}

function construirPrompt(perfilEstudiante, contenidoNivel, fetchStudentData) {
    if (fetchStudentData) {
        return `Sugiere una actividad muy corta EN INGLÉS para un estudiante que no sabe casi nada de inglés basada en el siguiente perfil y contenido. La respuesta debe ser directa sin introducciones o saludos, solo la actividad y Omite símbolos como asteriscos y comillas.:

Perfil del Estudiante:
${perfilEstudiante}

Contenido del Nivel:
${contenidoNivel}

Debe ser súper básico el nivel de ingés. Que las actividades hagan énfasis en la edad y el país. Incluye emoticons. Y QUE SEA EN INGLÉS`;
    } else {
        return `Sugiere dos actividades interesantes para una clase virtual de inglés. La respuesta debe ser directa sin introducciones o saludos, solo las actividades:

Contenido para enseñar:
${contenidoNivel}

Que las actividades hagan énfasis en la edad y el país. Incluye emoticons. Omite símbolos como asteriscos y comillas.`;
    }
}

async function actividadPersonal(prompt, targetElementId, intentos = 0) {
    console.log("disparando callopenai", prompt, targetElementId)

    try {
        const response = await callOpenAI(prompt);
        if (response.choices && response.choices.length > 0) {
            let message = response.choices[0].message.content;

            // Asegúrate de que no se añade un saludo aquí
            // Limpia el contenido antes de actualizar el campo de texto
            cleanTextContent(targetElementId, "");

            $w('#userSuggestionsBox').hide();
            $w(`#${targetElementId}`).value = message;
            cleanTextContent(targetElementId); // Llamar a cleanTextContent inmediatamente después de recibir la respuesta
            $w(`#${targetElementId}`).show();
        } else {
            $w('#userSuggestionsBox').show();
            $w(`#${targetElementId}`).value = "No hubo respuesta de OpenAI.";
            console.error("No hubo respuesta de OpenAI.");
        }
    } catch (error) {
        console.error("Error en actividadPersonal:", error);
        if (intentos < 3) {
            console.log("Reintentando actividadPersonal...");
            await actividadPersonal(prompt, targetElementId, intentos + 1);
        } else {
            $w(`#${targetElementId}`).value = "Error al comunicarse con OpenAI.";
        }
    }
}

$w('#closeComentariosInternos').onClick((event) => {
    $w('#advisorNotes').hide()
})

$w('#closeComentariosUsuario').onClick((event) => {
    $w('#rateStudent').hide()
})