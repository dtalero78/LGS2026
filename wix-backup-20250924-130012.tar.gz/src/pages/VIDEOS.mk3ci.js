import wixData from 'wix-data';
import { lightbox } from 'wix-window';

$w.onReady(function () {
    let receivedData = lightbox.getContext();

    let nivel = receivedData.nivel;
    let step = receivedData.step;

	console.log("nivel:", nivel, "step:", step)

    wixData.query("NIVELES")
        .eq("code", nivel)
        .eq("step", step)
        .find()
        .then((results) => {
            if (results.items.length > 0) {
                let videoUrl = results.items[0].video;
				$w('#tituloNivel').text = results.items[0].code + " " + results.items[0].step
				$w('#contenido').text = results.items[0].contenido
                $w("#videoBox1").src = videoUrl;
            } else {
                console.log("No se encontró el video para el nivel y step especificados.");
            }
        })
        .catch((err) => {
            console.error("Error al obtener el video:", err);
        });
});
