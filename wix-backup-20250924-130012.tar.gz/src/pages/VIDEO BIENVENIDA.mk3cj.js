import wixData from 'wix-data';
import wixWindow from 'wix-window';

$w.onReady(function () {
    let receivedData = wixWindow.lightbox.getContext();

    $w('#bienvenida').text = receivedData.nombres.primerNombre + ", te estábamos esperando!";
    console.log(receivedData);
});
