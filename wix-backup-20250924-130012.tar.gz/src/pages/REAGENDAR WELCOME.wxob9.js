import wixData from 'wix-data';
import moment from 'moment';
import wixLocation from 'wix-location';

$w.onReady(function () {
    verificarFaltasBienvenida();
    obtenerEventosWelcomeFuturos();
    cargarDatosEstudiante();
});

let datosEstudiante = {};

async function verificarFaltasBienvenida() {
    try {
        // Verificar si el estudiante tiene dos registros sin asistencia en la base de datos CLASSES
        datosEstudiante = $w("#dynamicDataset").getCurrentItem();
        const idEstudiante = datosEstudiante._id;

        const resultados = await wixData.query("CLASSES")
            .eq("idEstudiante", idEstudiante)
            .eq("step", "WELCOME")
            .isEmpty("asistencia")
            .find();

        if (resultados.items.length >= 2) {
            // Ocultar el dropdown y mostrar mensaje
            $w("#diaBooking").hide();
            $w('#confirmar').hide();
            $w('#whatsApp').show()
            $w("#anuncio").text = "Haz faltado a dos sesiones de bienvenida. Por favor comunícate con servicio al usuario";
        } else {
            $w("#diaBooking").show(); // Asegurarse de que el dropdown esté visible si no cumple la condición
            $w("#anuncio").text = "Te extrañamos en la sesión de bienvenida. Por favor, reagenda una nueva fecha. ¡Te esperamos!"; // Limpiar el mensaje en caso de que no aplique
        }
    } catch (error) {
        console.error("Error al verificar faltas en sesiones de bienvenida:", error);
    }
}

function cargarDatosEstudiante() {
    datosEstudiante = $w("#dynamicDataset").getCurrentItem();
    let nombres = "Hola" 
    + (datosEstudiante.primerNombre ? " " + datosEstudiante.primerNombre : "")
    + (datosEstudiante.segundoNombre ? " " + datosEstudiante.segundoNombre : "")
    
    $w('#nombrePerfil').text = nombres;
    const { _id, nivel, idEstudiante } = datosEstudiante || {};
    if (!datosEstudiante) {
        console.log("Datos del estudiante aún no están cargados.");
        return;
    }
}





export async function obtenerEventosWelcomeFuturos() {
    try {
        const ahora = new Date();
        const resultados = await wixData.query("CALENDARIO")
            .eq("nombreEvento", "WELCOME")
            .gt("dia", ahora)
            .find();

        const eventosFuturos = resultados.items;
        
        const opcionesDropdown = eventosFuturos.map(evento => {
            // Usa moment para formatear la fecha y hora
            const fechaFormateada = moment(evento.dia).locale('es').format("dddd DD, h:mm a"); // Ej: martes 29, 10:00 am
            
            return {
                label: fechaFormateada,
                value: evento._id // Usa el ID del evento como valor único
            };
        });

        // Asigna las opciones al dropdown
        $w("#diaBooking").options = opcionesDropdown;
    } catch (error) {
        console.error("Error al obtener eventos futuros WELCOME:", error);
        throw error;
    }
}


async function guardarEnBooking() {
    $w('#loading').show()
    try {
        const datosEstudiante = $w("#dynamicDataset").getCurrentItem();
        const eventoSeleccionado = $w("#diaBooking").value; // Suponiendo que seleccionas el evento desde un dropdown

        // Obtener detalles del evento seleccionado
        const eventoData = await wixData.get("CALENDARIO", eventoSeleccionado);

        // Asegurarse de que fechaEvento sea un objeto Date válido
        let fechaEvento = new Date(eventoData.dia);
        console.log("Datos del evento seleccionado:", eventoData);

        if (isNaN(fechaEvento.getTime())) {
            console.error("Fecha de evento no válida:", eventoData.dia);
            return;
        }

        let nuevoBooking = {
            "idEvento": eventoData._id,
            "idEstudiante": datosEstudiante._id,
            "primerNombre": datosEstudiante.primerNombre,
            "primerApellido": datosEstudiante.primerApellido,
            "numeroId": datosEstudiante.idEstudiante,
            "nivel": datosEstudiante.nivel,
            "fechaEvento": fechaEvento, // Guardar fecha como un objeto Date válido
            "tipoEvento": "WELCOME",
            "advisor": eventoData.advisor,
            "step": "WELCOME",
            "celular": datosEstudiante.celular
        };

        console.log("Intentando insertar en BOOKING:", nuevoBooking);

        const bookingResults = await wixData.insert("BOOKING", nuevoBooking);
        const classesResults = await wixData.insert("CLASSES", nuevoBooking);

        await wixLocation.to("https://letsgospeak.cl/")
        console.log("Registro insertado con éxito en BOOKING:", bookingResults);
                console.log("Registro insertado con éxito en BOOKING:", classesResults);

    } catch (err) {
        console.error("Error al insertar en BOOKING:", err);
    }
}

$w('#confirmar').onClick((event) => {
        guardarEnBooking();
})

const telefono = "+56957703724";
    const mensaje = "Hola. Necesito apoyo para agendar sesión de Bienvenida";
    const enlaceWhatsApp = `https://api.whatsapp.com/send?phone=${telefono}&text=${encodeURIComponent(mensaje)}`;
    $w('#whatsApp').link = enlaceWhatsApp;
    $w('#whatsApp').target = "_blank";
