import wixData from 'wix-data';
import wixStorage from 'wix-storage';
import { sendmessage } from 'backend/realtime.jsw';
import { sendTextMessage, sendTextMessageServicioUsuario } from 'backend/WHP';
import { triggeredEmails } from 'wix-crm-frontend';
import wixLocationFrontend from 'wix-location-frontend';

let idTitular;
let numeroId;
let nombreFilial;
let todosLosDatos = [];
let ultimoValorSlider = 0;
let edad;
let ultimoBeneficiarioCreado = null;

// NUEVO: Variable para rastrear a qué beneficiarios se les envió WhatsApp
let beneficiariosConWhatsAppEnviado = new Set();

// Función principal ejecutada al cargar la página
$w.onReady(function () {
    cargarDatosComercial()
        .then(() => {
            return cargarDatosEstudianteYFinanciera();
        })
        .then(() => {
            configurarEventosUI();
        })
        .catch((error) => {
            console.error("Error durante la inicialización:", error);
        });
});

function cargarDatosComercial() {
    return new Promise((resolve, reject) => {
        const userId = wixStorage.local.getItem('userId');

        // DEBUGGING CRÍTICO: Verificar el userId recibido
        console.log('=== LIGHTBOX DEBUG ===');
        console.log('userId recibido en lightbox:', userId);
        console.log('Tipo de userId:', typeof userId);
        console.log('======================');

        wixData.query('PEOPLE')
            .eq("_id", userId)
            .find()
            .then((result) => {
                if (result.items.length > 0) {
                    let datosPersona = result.items[0];

                    // DEBUGGING: Verificar datos de la persona encontrada
                    console.log('=== DATOS PERSONA ENCONTRADA ===');
                    console.log('_id:', datosPersona._id);
                    console.log('numeroId:', datosPersona.numeroId);
                    console.log('tipoUsuario:', datosPersona.tipoUsuario);
                    console.log('titularId:', datosPersona.titularId);
                    console.log('================================');

                    // CORRECCIÓN CRÍTICA: Verificar si es un titular o beneficiario
                    if (datosPersona.tipoUsuario === 'TITULAR') {
                        // Es un titular, usar su _id directamente
                        idTitular = datosPersona._id;
                        numeroId = datosPersona.numeroId;
                        console.log('Usuario es TITULAR, usando _id:', idTitular);
                    } else if (datosPersona.titularId) {
                        // Es un beneficiario, usar el titularId para encontrar al titular real
                        console.log('Usuario es BENEFICIARIO, buscando titular con _id:', datosPersona.titularId);

                        // Buscar al titular real
                        wixData.get('PEOPLE', datosPersona.titularId)
                            .then((titularReal) => {
                                if (titularReal && titularReal.tipoUsuario === 'TITULAR') {
                                    idTitular = titularReal._id;
                                    numeroId = titularReal.numeroId;
                                    console.log('Titular real encontrado:', idTitular);
                                    resolve();
                                } else {
                                    console.error('No se encontró titular válido para el beneficiario');
                                    reject("Titular no válido para el beneficiario.");
                                }
                            })
                            .catch((error) => {
                                console.error("Error al buscar titular real:", error);
                                reject(error);
                            });
                        return; // Salir aquí para evitar ejecutar resolve() abajo
                    } else {
                        // Caso problemático: no es titular y no tiene titularId
                        console.error('Registro problemático: no es titular y no tiene titularId válido');
                        reject("Registro sin titular válido.");
                        return;
                    }

                    resolve();
                } else {
                    reject("No se encontraron datos para el usuario.");
                }
            })
            .catch((error) => {
                console.error("Error al cargar datos comerciales:", error);
                reject(error);
            });
    });
}

// Función asincrónica principal para cargar y manejar datos
async function cargarDatosEstudianteYFinanciera() {
    try {
        console.log('=== CARGANDO DATOS ESTUDIANTE ===');
        console.log('idTitular a usar:', idTitular);
        console.log('numeroId a usar:', numeroId);
        console.log('================================');

        // Query 1. Obtener datos del estudiante usando el idTitular correcto
        const studentData = await obtenerDatos('PEOPLE', '_id', idTitular);
        if (!studentData) {
            console.error("Estudiante titular no encontrado.");
            return;
        }

        // VERIFICACIÓN: Asegurar que estamos trabajando con el titular correcto
        if (studentData.tipoUsuario !== 'TITULAR') {
            console.error('ERROR: El registro encontrado no es un TITULAR:', studentData);
            return;
        }

        console.log('Datos del titular cargados correctamente:', studentData.primerNombre, studentData.primerApellido);

        // Actualizar variables globales
        idTitular = studentData._id;
        numeroId = studentData.numeroId;
        edad = studentData.edad;

        // Query 2. Para imprimir el primer Nombre y segundo Nombre del Asesor Asignado
        const comercialData = await obtenerDatos('COMERCIAL', '_id', studentData.agenteAsignado);
        if (!comercialData) {
            console.error("Datos comerciales no encontrados para el campo 'agenteAsignado'.");
        } else {
            // Query 3. Para obtener el nombre de la Filial en el campo asesorAsignado
            const filialData = await obtenerDatos('FILIALES', '_id', comercialData.filial);
            if (!filialData) {
                console.error("Datos de filial no encontrados para el campo 'filial' en COMERCIAL.");
            } else {
                const textoComercial = `${capitalizeFirstLetter(comercialData.primerNombre)} ${capitalizeFirstLetter(comercialData.primerApellido)} - ${filialData.filial}`;
                $w('#elTraining').value = textoComercial;

                // Query 4. Para obtener el valor de "lider" en el campo "superior1"
                const liderData = await obtenerDatos('COMERCIAL', '_id', comercialData.lider);
                if (!liderData) {
                    console.error("Datos del líder no encontrados para el campo 'lider' en COMERCIAL.");
                } else {
                    const liderText = `${capitalizeFirstLetter(liderData.primerNombre)} ${capitalizeFirstLetter(liderData.primerApellido)} - ${filialData.filial}`;
                    $w('#superior1').value = liderText;

                    // Query 5. Para obtener el nombre completo del superior del líder (líder del líder) junto con el nombre de la filial
                    const superiorData = await obtenerDatos('COMERCIAL', '_id', liderData.lider);
                    if (!superiorData) {
                        console.error("Datos del superior del líder no encontrados para el campo 'lider' en COMERCIAL.");
                    } else {
                        const superiorText = `${capitalizeFirstLetter(superiorData.primerNombre)} ${capitalizeFirstLetter(superiorData.primerApellido)} - ${filialData.filial}`;
                        $w('#superior2').value = superiorText;

                        // Query 6. Para obtener el nombre completo del superior del superior del líder (superior del líder del líder) junto con el nombre de la filial
                        const superior2Data = await obtenerDatos('COMERCIAL', '_id', superiorData.lider);
                        if (!superior2Data) {
                            console.error("Datos del superior del superior del líder no encontrados para el campo 'lider' en COMERCIAL.");
                        } else {
                            const superior2Text = `${capitalizeFirstLetter(superior2Data.primerNombre)} ${capitalizeFirstLetter(superior2Data.primerApellido)} - ${filialData.filial}`;
                            $w('#superior3').value = superior2Text;
                        }
                    }
                }
            }
        }

        // Actualizar UI con datos del estudiante TITULAR
        $w('#primerNombre').value = studentData.primerNombre;
        $w('#segundoNombre').value = studentData.segundoNombre;
        $w('#primerApellido').value = studentData.primerApellido;
        $w('#segundoApellido').value = studentData.segundoApellido;
        $w('#numeroId').value = studentData.numeroId;
        $w('#numeroIdText').text = studentData.numeroId;
        $w('#nombres').text = studentData.primerNombre + " " + studentData.primerApellido + " " + "Estado: " + studentData.aprobacion;
        $w('#nombreTextBoxInfoBasica').text = capitalizeFirstLetter(studentData.primerNombre) + " " + capitalizeFirstLetter(studentData.segundoNombre) + " - " + capitalizeFirstLetter(studentData.tipoUsuario);
        $w('#plataformaText').text = studentData.pais;
        $w('#celularText').text = studentData.celular;
        $w('#celularInfoBox').value = studentData.celular;
        $w('#plataforma').value = studentData.plataforma;
        $w('#plataformaText').text = studentData.plataforma;
        $w('#direccion').value = studentData.domicilio;
        $w('#email').value = studentData.email;
        $w('#numeroContrato').text = studentData.numeroContrato;
        $w('#fechaContratoText').text = studentData._createdDate.toLocaleDateString('es-ES', { day: '2-digit', month: 'short', year: 'numeric' });
        $w('#fechaContrato').value = studentData._createdDate.toLocaleDateString('es-ES', { day: '2-digit', month: 'short', year: 'numeric' });
        $w('#plan').value = studentData.plan;
        $w('#plataformaCheckBox').checked = studentData.estadoPlataforma;
$w('#comentarioTexto').value = (studentData.observacionesContrato || '') + 
                               (studentData.comentariosAdministrativo ? '\n\n' + studentData.comentariosAdministrativo : '');

        $w('#fechaIngreso').value = ajustarFormatoFecha(studentData.fechaIngreso);
        $w('#aprobacion').value = studentData.aprobacion;
        $w('#vigencia').text = studentData.vigencia;

        // Obtener datos financieros del estudiante de la colección 'FINANCIERA'
        const financieraData = await obtenerDatos('FINANCIERA', 'numeroId', studentData.numeroId);
        if (!financieraData) {
            console.log("Datos financieros no encontrados.");
        } else {
            $w('#totalPlan').value = financieraData.totalPlan ? financieraData.totalPlan.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".") : "";
            $w('#fechaPago').value = ajustarFormatoFecha(financieraData.fechaPago);
            $w('#saldo').value = financieraData.saldo.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
            $w('#valorCuota').value = financieraData.valorCuota.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
            $w('#numeroCuotas').value = financieraData.numeroCuotas ? financieraData.numeroCuotas.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".") : "";
            $w('#inscripcionPagada').value = financieraData.inscripcionPagada ? financieraData.inscripcionPagada.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".") : "";
            $w('#formaPago').value = financieraData.formaPago;
            $w('#plan').value = financieraData.plan;
            $w('#confirmaJudithCheck').checked = financieraData.confirmaJudith;
            $w('#confirmaPrixusCheck').checked = financieraData.confirmaPrixus;
        }
    } catch (err) {
        console.error("Error al cargar los datos", err);
    }

    cargarComentarios();
    cargarBeneficiarios();
}

// Función para cargar beneficiarios en el repeater - CORREGIDA
async function cargarBeneficiarios() {
    try {
        console.log('=== CARGANDO BENEFICIARIOS ===');
        console.log('Buscando beneficiarios para titularId:', idTitular);

        // CORRECCIÓN: Buscar beneficiarios usando el idTitular correcto
        const resultados = await wixData.query('PEOPLE')
            .eq('titularId', idTitular)
            .find();

        console.log(`Beneficiarios encontrados: ${resultados.items.length}`);

        if (resultados.items.length > 0) {
            // Mapear los datos para el repeater y verificar si existe en ACADEMICA
            const datosBeneficiarios = await Promise.all(resultados.items.map(async (beneficiario) => {
                console.log('Procesando beneficiario:', beneficiario._id, beneficiario.primerNombre);

                // Verificar si ya existe un registro académico para este beneficiario
                const registroAcademico = await wixData.query('ACADEMICA')
                    .eq('idEstudiante', beneficiario._id)
                    .find();

                const yaExisteEnAcademica = registroAcademico.items.length > 0;
                
                // PROBLEMA 1 CORREGIDO: El código debe estar ANTES del return
                const aprobacion = beneficiario.aprobacion || 'Pendiente';
                const estaAprobado = aprobacion === "Aprobado";

                return {
                    _id: beneficiario._id,
                    nombreCompleto: `${beneficiario.primerNombre} ${beneficiario.primerApellido}`,
                    documento: beneficiario.numeroId,
                    celular: beneficiario.celular, // NUEVO: Incluir celular para comparación
                    aprobacion: aprobacion,
                    yaExisteEnAcademica: yaExisteEnAcademica,
                    estaAprobado: estaAprobado // NUEVO: Agregar flag para estado aprobado
                };
            }));

            // Asignar los datos al repeater
            $w("#beneficiariosRepeater").data = datosBeneficiarios;

            // Configurar cada item del repeater
            $w("#beneficiariosRepeater").forEachItem(($item, itemData, index) => {
                $item("#nombreBeneficiario").text = itemData.nombreCompleto;
                $item("#documentoBeneficiario").text = itemData.documento;

                // Configurar el dropdown de aprobación
                $item("#aprobacion").value = itemData.aprobacion;
                
                // Manejar el estado del ícono whpEnviado
                try {
                    if (beneficiariosConWhatsAppEnviado.has(itemData._id)) {
                        // Si ya se envió WhatsApp a este beneficiario, mostrar el ícono
                        $item("#whpEnviado").show();
                        console.log("Ícono whpEnviado restaurado para:", itemData.nombreCompleto);
                    } else {
                        // Si no se ha enviado WhatsApp, ocultar el ícono
                        $item("#whpEnviado").hide();
                    }
                } catch (e) {
                    console.log("Elemento whpEnviado no encontrado en el item");
                }

                // PROBLEMA 2 CORREGIDO: Lógica de enable/disable corregida
                if (itemData.yaExisteEnAcademica || itemData.estaAprobado) {
                    // Si ya existe en ACADEMICA o está aprobado, deshabilitar para evitar cambios
                    $item("#aprobacion").disable();
                    console.log(`Dropdown deshabilitado para ${itemData.nombreCompleto} - yaExisteEnAcademica: ${itemData.yaExisteEnAcademica}, estaAprobado: ${itemData.estaAprobado}`);
                } else {
                    // Si no existe en ACADEMICA y no está aprobado, permitir cambios
                    $item("#aprobacion").enable();
                    
                    // Configurar el evento onChange para el dropdown de aprobación
                    $item("#aprobacion").onChange((event) => {
                        // CAMBIO: Ahora también mostramos el box de confirmación para beneficiarios
                        handleAprobacionBeneficiarioChangeConConfirmacion(event, itemData._id, itemData.nombreCompleto);
                    });
                }
            });

            // Configurar estados de íconos WhatsApp después de configurar el repeater
            setTimeout(() => {
                configurarEstadosIconosWhatsApp();
            }, 200);

            console.log(`Se cargaron ${datosBeneficiarios.length} beneficiarios correctamente`);
        } else {
            console.log("No se encontraron beneficiarios para este titular");
            // Limpiar el repeater si no hay beneficiarios
            $w("#beneficiariosRepeater").data = [];
        }

        console.log('==============================');
    } catch (error) {
        console.error("Error al cargar beneficiarios:", error);
    }
}

// Resto del código permanece igual...
// 1. Agregar estas líneas en la función configurarEventosUI()
function configurarEventosUI() {
    $w('#comentarioTexto').onFocus(prepararCampoComentario);
    $w('#financieraButton').onClick(() => mostrarSeccion('financiera'));
    $w('#basicaButton').onClick(() => mostrarSeccion('basica'));
    //$w('#comentariosButton').onClick(() => mostrarSeccion('comentarios'));
    $w('#guardar').onClick(guardarDatos);
    $w('#plataforma').onChange(filtrarPlanPorPlataforma);
    $w('#plan').onChange(filtrarConvenioPorPlan);
    $w('#convenio').onChange(actualizarTotalPlan);
    $w('#totalPlan').onChange(calcularYFormatoValorCuota);
    $w('#inscripcionPagada').onChange(calcularYFormatoValorCuota);
    $w('#numeroCuotas').onChange(calcularYFormatoValorCuota);
    $w('#aprobacion').onChange(handleAprobacionChange);
    $w('#guardarComentarioButton').onClick(() => guardarSoloComentario()); // ← NUEVA FUNCIÓN
    $w('#beneficiariosButton').onClick(() => cargarBeneficiarios());
    
    // Configurar el botón de confirmación de aprobación
    $w('#confirmarAprobacionBtn').onClick(confirmarAprobacion);
    // Configurar el botón de cancelar aprobación (si existe)
    try {
        $w('#cancelarAprobacionBtn').onClick(cancelarAprobacion);
    } catch (e) {
        console.log("Botón cancelar no encontrado, continuando...");
    }
    // Ocultar el box de confirmación al inicio
    $w('#handleAprobacionChange').collapse();
    
    // Configurar el dropdown estadoTitular y sus botones de confirmación
    $w('#estadoTitular').onChange(handleEstadoTitularChange);
    $w('#confirmarEstado').onClick(confirmarEstadoTitular);
    $w('#cerrarBoxEstadoTitular').onClick(cancelarEstadoTitular);
    // Ocultar el box de confirmación de estado al inicio
    $w('#boxConfirmarEstado').collapse();

    $w('#cerrarBox').onClick(() => {
        $w('#nuevoBeneficiarioBox').hide();
    });

    // NUEVA LÓGICA CORREGIDA PARA nuevoBeneficiario
    $w("#nuevoBeneficiario").onClick(async () => {
        console.log("Iniciando creación de nuevo beneficiario...");

        try {
            // 1. Crear el nuevo beneficiario
            const nuevoBeneficiario = await crearNuevoBeneficiario();

            if (nuevoBeneficiario && nuevoBeneficiario._id) {
                console.log('Nuevo beneficiario creado con ID:', nuevoBeneficiario._id);

                // 2. Guardar el ID del último beneficiario creado
                ultimoBeneficiarioCreado = nuevoBeneficiario._id;

                // 3. Mostrar el box
                $w('#nuevoBeneficiarioBox').show();

                // 4. CONFIGURAR INMEDIATAMENTE el link y target de confirmarCreacion
                $w("#confirmarCreacion").link = `/new-beneficiario/${ultimoBeneficiarioCreado}`;
                $w("#confirmarCreacion").target = "_blank";

                console.log("Box mostrado y link configurado. Al hacer clic en confirmarCreacion se abrirá en nueva pestaña:", `/new-beneficiario/${ultimoBeneficiarioCreado}`);

            } else {
                console.error('Error: No se pudo crear el beneficiario');
            }
        } catch (error) {
            console.error('Error al crear nuevo beneficiario:', error);
        }
    });

    // Configurar confirmarCreacion con valores iniciales (se actualizarán cuando se cree un beneficiario)
    $w("#confirmarCreacion").link = "#"; // Link temporal
    $w("#confirmarCreacion").target = "_blank"; // Target fijo

    // Configurar validación de fechas en tiempo real
    const inputIds = ["#fechaIngreso", "#fechaPago"];
    inputIds.forEach(inputId => {
        $w(inputId).onInput(validateDateRealTime);
    });
}


async function crearNuevoBeneficiario() {
    try {
        console.log('Creando nuevo beneficiario con titularId:', idTitular);

        // Obtener datos del titular para algunos campos por defecto
        const datostTitular = await wixData.get('PEOPLE', idTitular);

        if (!datostTitular) {
            throw new Error('No se encontró el titular');
        }

        // Crear el objeto del nuevo beneficiario
        const nuevoBeneficiario = {
            titularId: idTitular, // El _id del titular actual
            tipoUsuario: 'BENEFICIARIO',
            aprobacion: 'Pendiente',

            // Campos por defecto basados en el titular (opcional)
            plataforma: datostTitular.plataforma,
            pais: datostTitular.pais,

            // Campos vacíos que se llenarán en el formulario
            primerNombre: '',
            segundoNombre: '',
            primerApellido: '',
            segundoApellido: '',
            numeroId: '',
            email: '',
            celular: '',
            edad: null,
            domicilio: '',

            // Campos específicos de beneficiario
            estadoPlataforma: false,
            observacionesContrato: ''
        };

        console.log('Datos del nuevo beneficiario a crear:', nuevoBeneficiario);

        // Insertar el nuevo beneficiario en la colección PEOPLE
        const resultado = await wixData.insert('PEOPLE', nuevoBeneficiario);

        console.log('Beneficiario creado exitosamente:', resultado);

        return resultado;

    } catch (error) {
        console.error('Error al crear nuevo beneficiario:', error);
        throw error;
    }
}

// ✅ FUNCIÓN cargarComentarios() CORREGIDA - Usar idTitular en lugar de numeroId
async function cargarComentarios() {
    try {
        console.log("=== CARGANDO COMENTARIOS ===");
        console.log("Buscando comentarios para idTitular:", idTitular);
        
        // ✅ CORREGIDO: Usar idTitular (_id) en lugar de numeroId
        const studentData = await obtenerDatos('PEOPLE', '_id', idTitular);
        
        console.log("Datos encontrados:", studentData ? "SÍ" : "NO");
        console.log("¿Tiene comentarios?", studentData && studentData.comentarios ? studentData.comentarios.length : "NO");
        
        if (!studentData || !studentData.comentarios) {
            console.error("No se encontraron comentarios o estudiante.");
            // ✅ LIMPIAR EL REPEATER si no hay comentarios
            todosLosDatos = [];
            $w("#repeaterComentarios").data = [];
            return;
        }

        console.log("Procesando", studentData.comentarios.length, "comentarios...");

        todosLosDatos = studentData.comentarios.map((comment, index) => ({
            _id: `comment${index}`,
            fecha: new Date(comment.fecha).toLocaleDateString('es-ES') + ' ' + new Date(comment.fecha).toLocaleTimeString('es-ES'),
            texto: comment.comentario,
            fechaObj: new Date(comment.fecha) // Objeto Date para ordenamiento
        })).sort((a, b) => b.fechaObj - a.fechaObj); // Orden descendente

        console.log("Comentarios procesados y ordenados:", todosLosDatos.length);

        configurarSlider();
        actualizarRepeater(0, 4); // Inicia mostrando los primeros elementos
        
        console.log("=== COMENTARIOS CARGADOS EXITOSAMENTE ===");
    } catch (err) {
        console.error("Error al cargar y mostrar los comentarios", err);
    }
}

async function guardarSoloComentario() {
    console.log("=== GUARDANDO COMENTARIO EN observacionesContrato ===");
    
    let valorCompleto = $w('#comentarioTexto').value;
    
    console.log("Valor completo del campo:", JSON.stringify(valorCompleto));
    console.log("ID del titular actual:", idTitular);
    
    if (!valorCompleto || !valorCompleto.trim()) {
        console.log("No hay comentario para guardar");
        $w('#guardarComentarioButton').label = "Campo vacío";
        setTimeout(() => {
            $w('#guardarComentarioButton').label = "Guardar Comentario";
        }, 2000);
        return;
    }
    
    try {
        // Obtener datos actuales
        console.log("Consultando base de datos para ID:", idTitular);
        let resultados = await wixData.query('PEOPLE')
            .eq("_id", idTitular)
            .find();

        console.log("Resultados de la consulta:", resultados.items.length);
        
        if (resultados.items.length > 0) {
            let datosActualizados = resultados.items[0];
            
            console.log("Registro encontrado. _id:", datosActualizados._id);
            
            let observacionesActuales = datosActualizados.observacionesContrato || '';
            console.log("observacionesContrato actual en BD:", JSON.stringify(observacionesActuales));
            console.log("Contenido actual del campo UI:", JSON.stringify(valorCompleto));
            
            // ✅ DETECTAR SOLO EL CONTENIDO NUEVO
            let comentarioNuevo;
            
            if (observacionesActuales && valorCompleto.includes(observacionesActuales)) {
                // El campo contiene las observaciones existentes + contenido nuevo
                comentarioNuevo = valorCompleto.replace(observacionesActuales, '').trim();
                console.log("Contenido nuevo detectado:", JSON.stringify(comentarioNuevo));
            } else {
                // El campo es completamente nuevo o diferente
                comentarioNuevo = valorCompleto.trim();
                console.log("Contenido completamente nuevo:", JSON.stringify(comentarioNuevo));
            }
            
            // ✅ EXTRAER SOLO EL COMENTARIO SIN FECHA (si tiene formato de fecha)
            let comentarioFinal;
            if (comentarioNuevo.includes(':\n')) {
                let [fechaConEtiqueta, ...restoComentario] = comentarioNuevo.split(':\n');
                comentarioFinal = restoComentario.join(':\n').trim();
                console.log("Comentario extraído después de fecha:", JSON.stringify(comentarioFinal));
            } else if (comentarioNuevo.includes(':')) {
                let [fechaConEtiqueta, ...restoComentario] = comentarioNuevo.split(':');
                comentarioFinal = restoComentario.join(':').trim();
                console.log("Comentario extraído (formato una línea):", JSON.stringify(comentarioFinal));
            } else {
                comentarioFinal = comentarioNuevo;
                console.log("Comentario sin formato de fecha:", JSON.stringify(comentarioFinal));
            }
            
            // Validar que hay comentario nuevo real
            if (!comentarioFinal || !comentarioFinal.trim()) {
                console.log("No hay comentario nuevo real para agregar");
                $w('#guardarComentarioButton').label = "Sin cambios";
                setTimeout(() => {
                    $w('#guardarComentarioButton').label = "Guardar Comentario";
                }, 2000);
                return;
            }
            
            // ✅ PREPARAR EL COMENTARIO CON FECHA PARA AGREGAR
            let fechaActual = new Date();
            let fechaTexto = `${fechaActual.toLocaleDateString('es-ES', { day: '2-digit', month: 'short', year: 'numeric' })} ${fechaActual.toLocaleTimeString('es-ES')}`;
            
            let comentarioConFecha = `${fechaTexto}: ${comentarioFinal}`;
            console.log("Comentario con fecha a agregar:", JSON.stringify(comentarioConFecha));
            
            // ✅ AGREGAR AL CAMPO observacionesContrato
            let nuevasObservaciones;
            
            if (observacionesActuales.trim()) {
                // Si ya hay contenido, agregar el nuevo comentario con salto de línea
                nuevasObservaciones = observacionesActuales + '\n' + comentarioConFecha;
            } else {
                // Si está vacío, usar solo el nuevo comentario
                nuevasObservaciones = comentarioConFecha;
            }
            
            console.log("Observaciones finales:", JSON.stringify(nuevasObservaciones));
            
            // ✅ ACTUALIZAR EL CAMPO observacionesContrato
            datosActualizados.observacionesContrato = nuevasObservaciones;
            
            console.log("Iniciando actualización en base de datos...");
            const resultadoUpdate = await wixData.update("PEOPLE", datosActualizados);
            
            console.log("✅ RESULTADO DE LA ACTUALIZACIÓN:", resultadoUpdate._id);
            console.log("✅ Comentario guardado en observacionesContrato");
            
            // ✅ VERIFICAR QUE SE GUARDÓ Y ACTUALIZAR UI
            const verificacion = await wixData.get("PEOPLE", idTitular);
            console.log("observacionesContrato después de guardar:", verificacion.observacionesContrato);
            
            // ✅ ACTUALIZAR EL CAMPO DE TEXTO EN LA UI CON EL CONTENIDO REAL DE LA BD
            $w('#comentarioTexto').value = verificacion.observacionesContrato;
            
            // Mostrar confirmación
            $w('#guardarComentarioButton').label = "¡GUARDADO!";
            
            // Restaurar label después de 2 segundos
            setTimeout(() => {
                $w('#guardarComentarioButton').label = "Guardar Comentario";
            }, 2000);
            
        } else {
            console.error("❌ NO SE ENCONTRÓ EL REGISTRO DEL TITULAR con ID:", idTitular);
        }
    } catch (error) {
        console.error("❌ ERROR CRÍTICO al guardar comentario:", error);
        $w('#guardarComentarioButton').label = "Error";
        setTimeout(() => {
            $w('#guardarComentarioButton').label = "Guardar Comentario";
        }, 2000);
    }
    
    console.log("=== FIN GUARDAR COMENTARIO ===");
}

// Variables para manejar la aprobación de beneficiarios pendiente
let beneficiarioAprobacionPendiente = null;
let dropdownBeneficiarioOriginal = null;

// Nueva función para manejar el cambio con confirmación
async function handleAprobacionBeneficiarioChangeConConfirmacion(event, beneficiarioId, nombreBeneficiario) {
    const nuevoEstado = event.target.value;
    console.log(`=== Cambio de aprobación para beneficiario: ${nombreBeneficiario} ===`);
    console.log("Nuevo estado:", nuevoEstado);
    
    // Manejar tanto "Aprobado" como "Eliminado"
    if (nuevoEstado === "Aprobado" || nuevoEstado === "Eliminado") {
        // Guardar los datos del beneficiario para procesarlo después de la confirmación
        beneficiarioAprobacionPendiente = {
            id: beneficiarioId,
            nombre: nombreBeneficiario,
            dropdown: event.target
        };
        
        // Obtener el valor original del beneficiario
        try {
            const beneficiario = await wixData.get("PEOPLE", beneficiarioId);
            dropdownBeneficiarioOriginal = beneficiario.aprobacion || "Pendiente";
        } catch (error) {
            dropdownBeneficiarioOriginal = "Pendiente";
        }
        
        console.log("Mostrando box de confirmación para beneficiario...");
        
        // Mostrar el box de confirmación
        try {
            $w('#handleAprobacionChange').expand();
            console.log("✓ Box de confirmación expandido para beneficiario");
        } catch (error) {
            console.error("Error al expandir el box:", error);
            try {
                $w('#handleAprobacionChange').show();
            } catch (error2) {
                console.error("Error con show():", error2);
            }
        }
        
        // Actualizar el texto del box si es posible según la acción
        try {
            // Si tienes un texto en el box, puedes actualizarlo aquí
            if (nuevoEstado === "Eliminado") {
                console.log("=== ADVERTENCIA: Se solicitó ELIMINAR el beneficiario ===");
                // $w('#textoConfirmacion').text = `¿Está seguro que desea ELIMINAR a ${nombreBeneficiario}?`;
            } else {
                // $w('#textoConfirmacion').text = `¿Confirmar aprobación de ${nombreBeneficiario}?`;
            }
        } catch (e) {
            // Ignorar si no existe el elemento de texto
        }
        
    } else {
        // Si cambia a otro estado, limpiar la aprobación pendiente
        beneficiarioAprobacionPendiente = null;
        dropdownBeneficiarioOriginal = null;
    }
}

// Función original que ahora será llamada después de la confirmación
async function procesarAprobacionBeneficiario(beneficiarioId, nombreBeneficiario, $dropdown) {
    console.log(`Procesando aprobación confirmada para beneficiario: ${nombreBeneficiario}`);
    
    try {
        $dropdown.value = "Un momento...";

        // 1. Obtener los datos del beneficiario
        const beneficiario = await wixData.get("PEOPLE", beneficiarioId);

        if (beneficiario) {
            // 2. Obtener el titular real (usando titularId si existe)
            let titularId = beneficiario.titularId || beneficiario._id;
            let titular = await wixData.get("PEOPLE", titularId);

            // 3. Obtener el número de contrato del titular
            let numeroContrato = titular && (titular.numeroContrato || titular.contrato || "");

            // 4. Actualizar el estado de aprobación del beneficiario Y el campo contrato
            const beneficiarioActualizado = {
                ...beneficiario,
                aprobacion: "Aprobado",
                contrato: numeroContrato
            };
            await wixData.update("PEOPLE", beneficiarioActualizado);

            // 5. Ejecutar lógica adicional (registro académico, mensaje, etc)
            await ejecutarProcesoAprobacion({ ...beneficiarioActualizado, contrato: numeroContrato });

            // 6. Si el titular es realmente TITULAR, actualizar también su campo de aprobación
            if (titular && titular.tipoUsuario === "TITULAR") {
                if (titular.aprobacion !== "Aprobado") {
                    titular.aprobacion = "Aprobado";
                    await wixData.update("PEOPLE", titular);
                    console.log(`Campo 'aprobacion' actualizado a 'Aprobado' para el titular con ID ${titularId}`);
                }
            }

            $dropdown.disable();

            // Recargar la lista de beneficiarios para refrescar el repeater
            await cargarBeneficiarios();

        } else {
            console.error("No se encontró el beneficiario con ID:", beneficiarioId);
            $dropdown.value = "Error";
        }
    } catch (error) {
        console.error("Error al aprobar beneficiario:", error);
        $dropdown.value = "Error";
    }
}



// Función auxiliar que contiene la lógica de handleAprobacionChange
async function ejecutarProcesoAprobacion(datosEstudiante) {
    console.log("Ejecutando proceso de aprobación para:", datosEstudiante.primerNombre);

    try {
        // Crear registro académico
        const idAcademico = await crearRegistroAcademicoParaBeneficiario(datosEstudiante);
        console.log("ID Académico generado para beneficiario:", idAcademico);

        // Enviar mensaje de texto de bienvenida
        const celular = datosEstudiante.celular ? datosEstudiante.celular.toString() : '';
        if (celular) {
            const message = `Hola 👋:\n\n*¡Eres parte de Lets Go Speak!* 🎉 \n\nPara terminar tu registro y crear tu usuario sigue este enlace:\n\nhttps://www.lgsplataforma.com/nuevo-usuario/${idAcademico}`;

            try {
                await enviarFormularioCreacionUsuario(celular, message);
                console.log("Formulario de creación de usuario enviado exitosamente al beneficiario.");
            } catch (error) {
                console.error("Error al enviar el formulario de creación de usuario al beneficiario:", error);
            }
        }

        // Enviar correo electrónico de bienvenida si tiene crmContactId
        if (datosEstudiante.crmContactId) {
            try {
                console.log("crmContactId obtenido para beneficiario:", datosEstudiante.crmContactId);
                // await triggeredEmails.emailContact('pruebaLGS', datosEstudiante.crmContactId);
                console.log("Correo electrónico enviado al beneficiario con ID:", datosEstudiante.crmContactId);
            } catch (err) {
                console.error("Error al enviar el correo electrónico al beneficiario:", err);
            }
        }
    } catch (error) {
        console.error("Error en el proceso de aprobación del beneficiario:", error);
    }
}

// Función para crear registro académico específico para beneficiario
async function crearRegistroAcademicoParaBeneficiario(datosEstudiante) {
    try {
        const primerNombre = datosEstudiante.primerNombre;
        const primerApellido = datosEstudiante.primerApellido;
        const email = datosEstudiante.email;
        const idEstudiante = datosEstudiante._id;
        const plataforma = datosEstudiante.plataforma;
        const celular = datosEstudiante.celular ? datosEstudiante.celular.toString() : '';
        const aprobacion = "Aprobado";
        const numeroIdBeneficiario = datosEstudiante.numeroId;
        const nivel = "WELCOME";
        const step = "WELCOME";
        const usuarioId = datosEstudiante._id;
        const edadBeneficiario = datosEstudiante.edad;

        console.log("Datos para el nuevo registro académico del beneficiario:", {
            primerNombre,
            primerApellido,
            email,
            idEstudiante,
            plataforma,
            edadBeneficiario,
            celular,
            aprobacion,
            numeroIdBeneficiario,
            usuarioId,
            step
        });

        // Crear el nuevo registro académico
        const nuevoRegistroAcademico = {
            primerNombre,
            primerApellido,
            email,
            idEstudiante,
            plataforma,
            edad: edadBeneficiario,
            celular,
            aprobacion,
            numeroId: numeroIdBeneficiario,
            nivel,
            step,
            usuarioId
        };

        const result = await wixData.insert("ACADEMICA", nuevoRegistroAcademico);
        console.log("Nuevo registro académico creado para beneficiario:", result);

        return result._id;
    } catch (err) {
        console.error("Error al crear el registro académico para beneficiario:", err);
        throw err;
    }
}

// Variables globales para manejar el estado de aprobación pendiente
let aprobacionPendiente = false;
let valorOriginalDropdown = null;

// Variables globales para manejar el cambio de estado del titular
let estadoTitularPendiente = false;
let valorOriginalEstadoTitular = null;

async function handleAprobacionChange(event) {
    console.log("=== handleAprobacionChange INICIADO ===");
    const estadoAprobacion = event.target.value;
    console.log("Nuevo estado de aprobación:", estadoAprobacion);
    console.log("Aprobación pendiente actual:", aprobacionPendiente);
    console.log("Valor original guardado:", valorOriginalDropdown);

    // Manejar tanto "Aprobado" como "Eliminado"
    if (estadoAprobacion === "Aprobado" || estadoAprobacion === "Eliminado") {
        console.log(`Estado cambiado a '${estadoAprobacion}', preparando confirmación...`);
        
        // Guardar el valor anterior antes de cambiar
        if (!aprobacionPendiente) {
            // Obtener el valor previo del registro desde la base de datos
            try {
                let resultados = await wixData.query('PEOPLE')
                    .eq("_id", idTitular)
                    .find();
                if (resultados.items.length > 0) {
                    valorOriginalDropdown = resultados.items[0].aprobacion || "Pendiente";
                    console.log("Valor original obtenido de BD:", valorOriginalDropdown);
                } else {
                    valorOriginalDropdown = "Pendiente";
                    console.log("No se encontró registro, usando 'Pendiente' como valor original");
                }
            } catch (error) {
                console.error("Error al obtener valor original:", error);
                valorOriginalDropdown = "Pendiente";
            }
        }
        
        // Mostrar el box de confirmación
        console.log("Intentando expandir el box de confirmación...");
        try {
            $w('#handleAprobacionChange').expand();
            console.log("✓ Box de confirmación expandido exitosamente");
        } catch (error) {
            console.error("✗ Error al expandir el box:", error);
            console.log("Intentando con show()...");
            try {
                $w('#handleAprobacionChange').show();
                console.log("✓ Box mostrado con show()");
            } catch (error2) {
                console.error("✗ Error con show() también:", error2);
            }
        }
        
        // Marcar que hay una aprobación pendiente
        aprobacionPendiente = true;
        
        if (estadoAprobacion === "Eliminado") {
            console.log("=== ADVERTENCIA: Se solicitó ELIMINAR el registro ===");
            console.log("Esperando confirmación del usuario para eliminar...");
            // Opcional: Cambiar el texto del box si es posible
            try {
                // Si tienes un elemento de texto en el box, puedes actualizarlo
                // $w('#textoConfirmacion').text = "¿Está seguro que desea ELIMINAR este registro?";
            } catch (e) {
                // Ignorar si no existe
            }
        } else {
            console.log("=== Box de confirmación debería estar visible ===");
            console.log("NO se envía ningún mensaje en este punto");
            console.log("Esperando confirmación del usuario...");
        }
        
    } else {
        console.log("Estado cambiado a:", estadoAprobacion);
        // Si el usuario cambia a otro estado, ocultar el box
        try {
            $w('#handleAprobacionChange').collapse();
        } catch (error) {
            try {
                $w('#handleAprobacionChange').hide();
            } catch (error2) {
                console.error("Error al ocultar el box:", error2);
            }
        }
        aprobacionPendiente = false;
        valorOriginalDropdown = null;
        console.log("Box ocultado y estado reseteado");
    }
    
    console.log("=== handleAprobacionChange FINALIZADO ===");
}

// Nueva función para confirmar la aprobación (maneja tanto titular como beneficiarios)
async function confirmarAprobacion() {
    console.log("=== CONFIRMACIÓN DE APROBACIÓN INICIADA ===");
    console.log("Esta función SOLO se ejecuta al hacer clic en el botón confirmar");
    $w('#loadingAprobar').show();
    // Obtener el valor actual del dropdown para determinar la acción
    const estadoActual = $w('#aprobacion').value;
    console.log("Estado actual del dropdown:", estadoActual);
    
    // Ocultar el box de confirmación
    try {
        $w('#handleAprobacionChange').collapse();
    } catch (error) {
        try {
            $w('#handleAprobacionChange').hide();
        } catch (error2) {
            console.error("Error al ocultar el box:", error2);
        }
    }
    
    // Determinar si es aprobación de titular o beneficiario
    if (beneficiarioAprobacionPendiente) {
        // Es una aprobación/eliminación de beneficiario
        const estadoBeneficiario = beneficiarioAprobacionPendiente.dropdown.value;
        console.log("Estado del beneficiario:", estadoBeneficiario);
        
        if (estadoBeneficiario === "Eliminado") {
            console.log("✓ Usuario confirmó la ELIMINACIÓN del beneficiario:", beneficiarioAprobacionPendiente.nombre);
            await eliminarBeneficiario(beneficiarioAprobacionPendiente.id, beneficiarioAprobacionPendiente.nombre);
        } else {
            console.log("✓ Usuario confirmó la aprobación del beneficiario:", beneficiarioAprobacionPendiente.nombre);
            await procesarAprobacionBeneficiario(
                beneficiarioAprobacionPendiente.id,
                beneficiarioAprobacionPendiente.nombre,
                beneficiarioAprobacionPendiente.dropdown
            );
        }
        
        // Resetear el estado de beneficiario pendiente
        beneficiarioAprobacionPendiente = null;
        dropdownBeneficiarioOriginal = null;
        
    } else {
        // Es una aprobación/eliminación del titular principal
        if (estadoActual === "Eliminado") {
            console.log("✓ Usuario confirmó la ELIMINACIÓN del titular");
            console.log("=== INICIANDO PROCESO DE ELIMINACIÓN ===");
            
            try {
                // Eliminar el registro del titular
                await wixData.remove("PEOPLE", idTitular);
                console.log("✅ Registro del titular eliminado exitosamente");
                console.log("ID eliminado:", idTitular);
                
                // Opcional: También eliminar registros relacionados
                try {
                    // Eliminar registro financiero si existe
                    const financieraResults = await wixData.query('FINANCIERA')
                        .eq("numeroId", numeroId)
                        .find();
                    
                    if (financieraResults.items.length > 0) {
                        await wixData.remove("FINANCIERA", financieraResults.items[0]._id);
                        console.log("✅ Registro financiero relacionado eliminado");
                    }
                    
                    // Eliminar registro académico si existe
                    const academicaResults = await wixData.query('ACADEMICA')
                        .eq("idEstudiante", idTitular)
                        .find();
                    
                    if (academicaResults.items.length > 0) {
                        await wixData.remove("ACADEMICA", academicaResults.items[0]._id);
                        console.log("✅ Registro académico relacionado eliminado");
                    }
                } catch (error) {
                    console.error("Error al eliminar registros relacionados:", error);
                }
                
                // Redirigir o mostrar mensaje de éxito
                setTimeout(() => {
                    console.log("Redirigiendo después de eliminación...");
                    // Opcional: Redirigir a otra página
                    // wixLocationFrontend.to('/lista-titulares');
                }, 2000);
                
            } catch (error) {
                console.error("❌ Error al eliminar el registro del titular:", error);
                // Restaurar el valor original si falla
                $w('#aprobacion').value = valorOriginalDropdown;
            }
            
        } else {
            // Es una aprobación normal del titular
            console.log("✓ Usuario confirmó la aprobación del titular");
            console.log("Iniciando proceso de aprobación del titular...");
            
            const idAcademico = await crearRegistroAcademico();
            console.log("ID Académico generado:", idAcademico);
            
            // Actualizar el texto en $w('#nombres') con el estado "Aprobado"
            try {
                const textoActual = $w('#nombres').text;
                let nombreBase = textoActual;
                
                if (textoActual.includes("Estado:")) {
                    nombreBase = textoActual.substring(0, textoActual.indexOf("Estado:")).trim();
                }
                
                $w('#nombres').text = nombreBase + " Estado: Aprobado";
                console.log("Texto actualizado en #nombres para aprobación:", $w('#nombres').text);
            } catch (error) {
                console.error("Error al actualizar el texto de #nombres:", error);
                try {
                    const primerNombre = $w('#primerNombre').value;
                    const primerApellido = $w('#primerApellido').value;
                    $w('#nombres').text = primerNombre + " " + primerApellido + " Estado: Aprobado";
                } catch (e) {
                    console.error("Error al reconstruir el texto:", e);
                }
            }
            
            // Enviar mensaje de texto de bienvenida
            const celular = $w('#celularInfoBox').value.toString();
            const message = `Hola 👋:\n\n*¡Eres parte de Lets Go Speak!* 🎉 \n\nPara terminar tu registro y crear tu usuario sigue este enlace:\n\nhttps://www.lgsplataforma.com/nuevo-usuario/${idAcademico}`;
            
            console.log("Preparando envío de mensaje WhatsApp...");

            try {
                await enviarFormularioCreacionUsuario(celular, message);
                console.log("Formulario de creación de usuario enviado exitosamente.");
                $w('#loadingAprobar').hide();
            } catch (error) {
                console.error("Error al enviar el formulario de creación de usuario:", error);
            }

            // Obtener crmContactId del estudiante
            try {
                let studentData = await wixData.get("PEOPLE", idTitular);
                let contactId = studentData.crmContactId;
                console.log("crmContactId obtenido:", contactId);

                // Enviar correo electrónico de bienvenida
                //await triggeredEmails.emailContact('pruebaLGS', contactId);
                console.log("Correo electrónico enviado al contacto con ID:", contactId);
            } catch (err) {
                console.error("Error al obtener crmContactId o enviar el correo electrónico:", err);
            }
        }
        
        // Resetear el estado de aprobación pendiente del titular
        aprobacionPendiente = false;
        valorOriginalDropdown = null;
    }
}

// Nueva función para eliminar un beneficiario
async function eliminarBeneficiario(beneficiarioId, nombreBeneficiario) {
    console.log(`=== ELIMINANDO BENEFICIARIO: ${nombreBeneficiario} ===`);
    
    try {
        // Eliminar el registro del beneficiario
        await wixData.remove("PEOPLE", beneficiarioId);
        console.log("✅ Beneficiario eliminado exitosamente");
        
        // Eliminar registro académico si existe
        try {
            const academicaResults = await wixData.query('ACADEMICA')
                .eq("idEstudiante", beneficiarioId)
                .find();
            
            if (academicaResults.items.length > 0) {
                await wixData.remove("ACADEMICA", academicaResults.items[0]._id);
                console.log("✅ Registro académico del beneficiario eliminado");
            }
        } catch (error) {
            console.error("Error al eliminar registro académico del beneficiario:", error);
        }
        
        // Recargar la lista de beneficiarios
        await cargarBeneficiarios();
        console.log("Lista de beneficiarios actualizada");
        
    } catch (error) {
        console.error("❌ Error al eliminar el beneficiario:", error);
    }
}

// Función para manejar el cambio de estado del titular
async function handleEstadoTitularChange(event) {
    console.log("=== handleEstadoTitularChange INICIADO ===");
    const nuevoEstado = event.target.value;
    console.log("Nuevo estado del titular:", nuevoEstado);
    console.log("Estado pendiente actual:", estadoTitularPendiente);
    
    // Guardar el valor anterior antes de cambiar
    if (!estadoTitularPendiente) {
        // Obtener el valor previo del registro desde la base de datos
        try {
            let resultados = await wixData.query('PEOPLE')
                .eq("_id", idTitular)
                .find();
            if (resultados.items.length > 0) {
                valorOriginalEstadoTitular = resultados.items[0].aprobacion || "Pendiente";
                console.log("Valor original del estado obtenido de BD:", valorOriginalEstadoTitular);
            } else {
                valorOriginalEstadoTitular = "Pendiente";
                console.log("No se encontró registro, usando 'Pendiente' como valor original");
            }
        } catch (error) {
            console.error("Error al obtener valor original del estado:", error);
            valorOriginalEstadoTitular = "Pendiente";
        }
    }
    
    // Mostrar el box de confirmación
    console.log("Mostrando box de confirmación de cambio de estado...");
    try {
        $w('#boxConfirmarEstado').expand();
        console.log("✓ Box de confirmación de estado expandido exitosamente");
    } catch (error) {
        console.error("✗ Error al expandir el box:", error);
        console.log("Intentando con show()...");
        try {
            $w('#boxConfirmarEstado').show();
            console.log("✓ Box mostrado con show()");
        } catch (error2) {
            console.error("✗ Error con show() también:", error2);
        }
    }
    
    // Marcar que hay un cambio de estado pendiente
    estadoTitularPendiente = true;
    
    console.log("=== Box de confirmación de estado debería estar visible ===");
    console.log("Esperando confirmación del usuario...");
    console.log("=== handleEstadoTitularChange FINALIZADO ===");
}

// Función para cancelar la aprobación (maneja tanto titular como beneficiarios)
function cancelarAprobacion() {
    console.log("=== CANCELANDO PROCESO DE APROBACIÓN ===");
    
    // Ocultar el box de confirmación
    try {
        $w('#handleAprobacionChange').collapse();
    } catch (error) {
        try {
            $w('#handleAprobacionChange').hide();
        } catch (error2) {
            console.error("Error al ocultar el box:", error2);
        }
    }
    
    // Determinar si es cancelación de titular o beneficiario
    if (beneficiarioAprobacionPendiente) {
        // Es una cancelación de aprobación de beneficiario
        console.log("Cancelando aprobación de beneficiario:", beneficiarioAprobacionPendiente.nombre);
        
        // Restaurar el valor original del dropdown del beneficiario
        if (beneficiarioAprobacionPendiente.dropdown) {
            beneficiarioAprobacionPendiente.dropdown.value = dropdownBeneficiarioOriginal || "Pendiente";
        }
        
        // Resetear el estado de beneficiario
        beneficiarioAprobacionPendiente = null;
        dropdownBeneficiarioOriginal = null;
        
    } else {
        // Es una cancelación de aprobación del titular
        console.log("Cancelando aprobación del titular");
        
        // Restaurar el valor original del dropdown del titular
        if (valorOriginalDropdown !== null) {
            $w('#aprobacion').value = valorOriginalDropdown;
        } else {
            $w('#aprobacion').value = "Pendiente";
        }
        
        // Resetear el estado del titular
        aprobacionPendiente = false;
        valorOriginalDropdown = null;
    }
    
    console.log("✓ Proceso de aprobación cancelado");
}

// Función para confirmar el cambio de estado del titular
async function confirmarEstadoTitular() {
    console.log("=== CONFIRMACIÓN DE CAMBIO DE ESTADO INICIADA ===");
    console.log("Esta función SOLO se ejecuta al hacer clic en el botón confirmarEstado");
    
    // Obtener el nuevo valor del dropdown
    const nuevoEstado = $w('#estadoTitular').value;
    console.log("Nuevo estado a aplicar:", nuevoEstado);
    
    // Ocultar el box de confirmación
    try {
        $w('#boxConfirmarEstado').collapse();
    } catch (error) {
        try {
            $w('#boxConfirmarEstado').hide();
        } catch (error2) {
            console.error("Error al ocultar el box:", error2);
        }
    }
    
    try {
        // Obtener el registro actual del titular
        let resultados = await wixData.query('PEOPLE')
            .eq("_id", idTitular)
            .find();
            
        if (resultados.items.length > 0) {
            let datosActualizados = resultados.items[0];
            
            // IMPORTANTE: Solo actualizar el campo 'aprobacion', preservar todo lo demás
            datosActualizados.aprobacion = nuevoEstado;
            
            console.log("Actualizando campo 'aprobacion' a:", nuevoEstado);
            console.log("ID del titular:", idTitular);
            
            // Actualizar el registro en la base de datos
            const resultadoUpdate = await wixData.update("PEOPLE", datosActualizados);
            
            console.log("✅ Estado del titular actualizado exitosamente");
            console.log("Registro actualizado:", resultadoUpdate._id);
            
            // Actualizar también el dropdown de aprobación para mantener sincronía
            $w('#aprobacion').value = nuevoEstado;
            
            // Actualizar el texto en $w('#nombres') con el nuevo estado
            try {
                // Obtener el nombre actual sin el estado
                const textoActual = $w('#nombres').text;
                let nombreBase = textoActual;
                
                // Si ya contiene "Estado:", quitar esa parte para obtener solo el nombre
                if (textoActual.includes("Estado:")) {
                    nombreBase = textoActual.substring(0, textoActual.indexOf("Estado:")).trim();
                }
                
                // Actualizar con el nuevo estado
                $w('#nombres').text = nombreBase + " Estado: " + nuevoEstado;
                console.log("Texto actualizado en #nombres:", $w('#nombres').text);
            } catch (error) {
                console.error("Error al actualizar el texto de #nombres:", error);
                // Alternativa: reconstruir desde los datos originales
                try {
                    const primerNombre = $w('#primerNombre').value;
                    const primerApellido = $w('#primerApellido').value;
                    $w('#nombres').text = primerNombre + " " + primerApellido + " Estado: " + nuevoEstado;
                } catch (e) {
                    console.error("Error al reconstruir el texto:", e);
                }
            }
            
            // Mostrar confirmación visual (opcional)
            try {
                $w('#estadoTitular').style.borderColor = "#00ff00";
                setTimeout(() => {
                    $w('#estadoTitular').style.borderColor = "#cccccc";
                }, 2000);
            } catch (e) {
                // Ignorar si no se puede cambiar el estilo
            }
            
        } else {
            console.error("❌ No se encontró el registro del titular con ID:", idTitular);
        }
        
    } catch (error) {
        console.error("❌ Error al actualizar el estado del titular:", error);
    }
    
    // Resetear el estado pendiente
    estadoTitularPendiente = false;
    valorOriginalEstadoTitular = null;
    
    console.log("=== CONFIRMACIÓN DE CAMBIO DE ESTADO FINALIZADA ===");
}

// Función para cancelar el cambio de estado del titular
function cancelarEstadoTitular() {
    console.log("=== CANCELANDO CAMBIO DE ESTADO DEL TITULAR ===");
    
    // Ocultar el box de confirmación
    try {
        $w('#boxConfirmarEstado').collapse();
    } catch (error) {
        try {
            $w('#boxConfirmarEstado').hide();
        } catch (error2) {
            console.error("Error al ocultar el box:", error2);
        }
    }
    
    // Restaurar el valor original del dropdown
    if (valorOriginalEstadoTitular !== null) {
        $w('#estadoTitular').value = valorOriginalEstadoTitular;
        console.log("Valor restaurado a:", valorOriginalEstadoTitular);
    }
    
    // Resetear el estado
    estadoTitularPendiente = false;
    valorOriginalEstadoTitular = null;
    
    console.log("✓ Cambio de estado cancelado");
}

function enviarFormularioCreacionUsuario(celular, message) {
    console.log("enviando link de registro")
    return sendTextMessageServicioUsuario(celular, message)
        .then(response => {
            console.log("Actividad enviada", response);
            
            // Mostrar ícono whpEnviado en el repeater para este celular
            mostrarIconoWhatsAppEnviado(celular);
            
            return response;
        })
        .catch(err => {
            console.error("Error al enviar actividad", err);
            throw err;
        });
}


// Función para mostrar el ícono whpEnviado en el item correspondiente del repeater
function mostrarIconoWhatsAppEnviado(celular) {
    try {
        console.log("Registrando WhatsApp enviado para celular:", celular);
        
        // Primero, encontrar el beneficiario por celular y registrarlo
        const data = $w("#beneficiariosRepeater").data;
        const beneficiario = data.find(item => item.celular && item.celular.toString() === celular.toString());
        
        if (beneficiario) {
            // Registrar que a este beneficiario se le envió WhatsApp
            beneficiariosConWhatsAppEnviado.add(beneficiario._id);
            console.log("Beneficiario registrado como WhatsApp enviado:", beneficiario._id, beneficiario.nombreCompleto);
            
            // Reconfigurar el repeater para actualizar el estado visual
            setTimeout(() => {
                configurarEstadosIconosWhatsApp();
            }, 100);
        } else {
            console.error("No se encontró beneficiario con celular:", celular);
        }
        
    } catch (error) {
        console.error("Error en mostrarIconoWhatsAppEnviado:", error);
    }
}

// Función auxiliar para configurar los estados de los íconos WhatsApp
function configurarEstadosIconosWhatsApp() {
    try {
        $w("#beneficiariosRepeater").forEachItem(($item, itemData, index) => {
            try {
                if (beneficiariosConWhatsAppEnviado.has(itemData._id)) {
                    $item("#whpEnviado").show();
                    console.log("Ícono whpEnviado mostrado para:", itemData.nombreCompleto);
                    $w('#loadingAprobar').hide();
                } else {
                    $item("#whpEnviado").hide();
                }
            } catch (e) {
                console.log("Elemento whpEnviado no encontrado en el item");
            }
        });
    } catch (error) {
        console.error("Error configurando estados de íconos WhatsApp:", error);
    }
}

async function crearRegistroAcademico() {
    $w('#loadingAprobar').show()
    try {
        const primerNombre = $w('#primerNombre').value;
        const primerApellido = $w('#primerApellido').value;
        const email = $w('#email').value;
        const idEstudiante = idTitular;
        const plataforma = $w('#plataforma').value;
        const celular = $w('#celularInfoBox').value.toString();
        const aprobacion = $w('#aprobacion').value;
        const numeroId = $w('#numeroId').value;
        const nivel = "WELCOME";
        const step = "WELCOME";
        const usuarioId = idTitular;

        console.log("Datos para el nuevo registro académico:", {
            primerNombre,
            primerApellido,
            email,
            idEstudiante,
            plataforma,
            edad,
            celular,
            aprobacion,
            numeroId,
            usuarioId,
            step
        });

        // Crear el nuevo registro académico
        const nuevoRegistroAcademico = {
            primerNombre,
            primerApellido,
            email,
            idEstudiante,
            plataforma,
            edad,
            celular,
            aprobacion,
            numeroId,
            nivel,
            step,
            usuarioId
        };

        const result = await wixData.insert("ACADEMICA", nuevoRegistroAcademico);
        console.log("Nuevo registro académico creado:", result);

        // Actualizar el campo 'aprobacion' en la colección PEOPLE
        let registroExistente = await wixData.get("PEOPLE", idEstudiante);

        if (registroExistente) {
            const registroActualizado = {
                ...registroExistente, // Preserva todos los campos existentes
                aprobacion: "Aprobado" // Sobrescribe solo el campo 'aprobacion'
            };

            await wixData.update("PEOPLE", registroActualizado);
            $w('#loadingAprobar').hide();
            console.log(`El campo 'aprobacion' del registro con ID ${idEstudiante} se ha actualizado a 'APROBADO'.`);
        } else {
            console.error("No se encontró el registro en la colección PEOPLE para actualizar 'aprobacion'.");
        }

        return result._id;
    } catch (err) {
        console.error("Error al crear el registro académico o actualizar 'aprobacion':", err);
    }
}

// RESTO DE FUNCIONES PERMANECEN IGUAL...
// (slider, validaciones, formateo, etc.)

// SLIDER
function configurarSlider() {
    const itemsPorPagina = 4;
    $w('#slider1').max = Math.ceil(todosLosDatos.length / itemsPorPagina) - 1;
    $w('#slider1').value = 0;

    $w('#slider1').onChange((event) => {
        let paginaActual = parseInt(event.target.value, 10);
        if (paginaActual !== ultimoValorSlider) {
            actualizarRepeater(paginaActual, itemsPorPagina);
            setTimeout(() => {
                $w('#slider1').value = paginaActual;
                ultimoValorSlider = paginaActual;
            }, 100);
        }
    });
}

function actualizarRepeater(paginaActual, itemsPorPagina) {
    let startIndex = paginaActual * itemsPorPagina;
    let endIndex = startIndex + itemsPorPagina;
    let datosParaMostrar = todosLosDatos.slice(startIndex, endIndex);

    $w("#repeaterComentarios").data = datosParaMostrar;
    $w("#repeaterComentarios").forEachItem(($item, itemData, index) => {
        $item("#fechaRepeaterComentarios").text = itemData.fecha;
        $item("#comentarioRepeaterComentarios").text = itemData.texto;
    });
}

function validateDateRealTime(event) {
    const inputId = "#" + event.target.id; // Obtenemos el ID del campo de entrada que disparó el evento
    let inputDate = $w(inputId).value;
    const regexSimple = /^[0-9/]*$/;

    if (!regexSimple.test(inputDate)) {
        $w(inputId).value = inputDate.slice(0, -1);
        return; // Si el carácter introducido no es válido, salimos de la función
    }

    let parts = inputDate.split('/').filter(Boolean); // Divide la fecha en partes y elimina los elementos vacíos
    if (parts.length === 1 && parts[0].length === 2 && inputDate.endsWith('/') === false && inputDate.length < 6) {
        $w(inputId).value += '/';
    } else if (parts.length === 2 && parts[1].length === 2 && inputDate.endsWith('/') === false && inputDate.length === 5) {
        $w(inputId).value += '/';
    } else if (inputDate.length > 10) {
        $w(inputId).value = inputDate.slice(0, 10);
    }
    if (inputDate.length === 10) {
        // Actualización del regex para validar formato día/mes/año
        const regexComplete = /^(0[1-9]|[12][0-9]|3[01])\/(0[1-9]|1[0-2])\/\d{4}$/;
        if (!regexComplete.test(inputDate)) {
            console.warn("La fecha introducida en " + inputId + " no es válida");
        }
    }
}

function convertirCadenaAFecha(cadena) {
    if (!cadena) return undefined;

    // Verifica si la cadena ya está en el formato ISO 'YYYY-MM-DD'
    const regexISO = /^\d{4}-\d{2}-\d{2}$/;
    if (regexISO.test(cadena)) {
        // La cadena ya está en el formato correcto, retorna tal cual
        return cadena;
    }

    const partes = cadena.split('/');
    if (partes.length !== 3) {
        return undefined; // Retorna undefined si el formato no es correcto
    }

    const fechaFormatoISO = `${partes[2]}-${partes[1]}-${partes[0]}`;
    return fechaFormatoISO;
}

function ajustarFormatoFecha(cadena) {
    // Detecta si la entrada está en formato YYYY-MM-DD
    const regexISO = /^\d{4}-\d{2}-\d{2}$/;
    if (regexISO.test(cadena)) {
        // Convierte de YYYY-MM-DD a DD/MM/YYYY
        const [year, month, day] = cadena.split('-');
        return `${day}/${month}/${year}`;
    }
    // Si la entrada ya está en DD/MM/YYYY o cualquier otro caso, retorna sin cambios
    return cadena;
}

function convertirTextoANumero(texto) {
    if (!texto || isNaN(parseFloat(texto.replace(/\./g, '')))) {
        return undefined; // Retorna undefined solo si el texto no es convertible a número
    }
    // Elimina los puntos de la cadena y luego convierte el resultado a un número flotante
    return parseFloat(texto.replace(/\./g, ''));
}

// Función para obtener datos de la base de datos
async function obtenerDatos(coleccion, campo, valor) {
    const result = await wixData.query(coleccion).eq(campo, valor).find();
    return result.items.length > 0 ? result.items[0] : null;
}

// Función para preparar el campo de comentario con la fecha actual
function prepararCampoComentario() {
    let comentarioActual = $w('#comentarioTexto').value;
    
    console.log("=== PREPARANDO CAMPO COMENTARIO (observacionesContrato) ===");
    console.log("Contenido actual:", JSON.stringify(comentarioActual));
    
    // Si el campo está vacío O solo contiene las observaciones existentes, preparar para nuevo comentario
    if (!comentarioActual || !comentarioActual.trim()) {
        let fechaActual = new Date();
        let fechaTexto = `${fechaActual.toLocaleDateString('es-ES', { day: '2-digit', month: 'short', year: 'numeric' })} ${fechaActual.toLocaleTimeString('es-ES')}`;
        
        let nuevoValor = `${fechaTexto}:\n`;
        $w('#comentarioTexto').value = nuevoValor;
        
        console.log("Campo preparado con:", JSON.stringify(nuevoValor));
    } else {
        // Si ya tiene contenido, agregar nueva línea al final para el nuevo comentario
        let fechaActual = new Date();
        let fechaTexto = `${fechaActual.toLocaleDateString('es-ES', { day: '2-digit', month: 'short', year: 'numeric' })} ${fechaActual.toLocaleTimeString('es-ES')}`;
        
        let nuevoValor = comentarioActual + '\n\n' + fechaTexto + ':\n';
        $w('#comentarioTexto').value = nuevoValor;
        
        console.log("Agregado nuevo comentario al final:", JSON.stringify(nuevoValor));
    }
    
    // Hacer focus en el campo
    setTimeout(() => {
        $w('#comentarioTexto').focus();
    }, 100);
    
    console.log("=== FIN PREPARAR CAMPO ===");
}

async function filtrarPlanPorPlataforma() {
    try {
        const plataformaSeleccionada = $w('#plataforma').value;
        const results = await wixData.query('TARIFAS').eq('pais', plataformaSeleccionada).find();
        const opcionesUnicas = [...new Set(results.items.map(item => item.plan))];

        $w('#plan').options = opcionesUnicas.map(plan => ({ label: plan, value: plan }));
    } catch (err) {
        console.error('Error al filtrar planes por plataforma', err);
    }
}

async function filtrarConvenioPorPlan() {
    try {
        const planSeleccionado = $w('#plan').value;
        const plataformaSeleccionada = $w('#plataforma').value;
        const results = await wixData.query('TARIFAS').eq('plan', planSeleccionado).eq('pais', plataformaSeleccionada).find();

        const opcionesUnicas = [...new Set(results.items.map(item => item.convenio))];
        $w('#convenio').options = opcionesUnicas.map(convenio => ({ label: convenio, value: convenio }));
    } catch (err) {
        console.error('Error al filtrar convenios por plan', err);
    }
}

async function actualizarTotalPlan() {
    try {
        const convenioSeleccionado = $w('#convenio').value;
        const planSeleccionado = $w('#plan').value;
        const plataformaSeleccionada = $w('#plataforma').value;
        const results = await wixData.query('TARIFAS').eq('convenio', convenioSeleccionado).eq('plan', planSeleccionado).eq('pais', plataformaSeleccionada).find();

        if (results.items.length > 0) {
            const tarifa = results.items[0].tarifa;
            $w('#totalPlan').value = tarifa.toString();
            // Asegurarse de convertir o manejar el valor del número de cuotas correctamente según la lógica de negocio
            $w('#numeroCuotas').value = $w('#plan').value; // Revisar esta línea para asegurar coherencia
        }
    } catch (err) {
        console.error('Error al actualizar el total del plan', err);
    }
}

function calcularYFormatoValorCuota() {
    // Parsear valores a números para realizar la operación
    let totalPlan = Math.round(parseFloat($w('#totalPlan').value.replace(/\./g, '').replace(/,/g, '.')) || 0);
    let inscripcionPagada = Math.round(parseFloat($w('#inscripcionPagada').value.replace(/\./g, '').replace(/,/g, '.')) || 0);
    let numeroCuotas = parseInt($w('#numeroCuotas').value, 10) || 1; // Asegura el manejo correcto como entero

    // Realizar la operación
    let valorCuota = Math.round((totalPlan - inscripcionPagada) / numeroCuotas);
    let saldo = Math.round(totalPlan - inscripcionPagada);

    // Asignar el resultado sin formato de decimales
    $w('#valorCuota').value = valorCuota.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
    $w('#saldo').value = saldo.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");

    // Formatear los valores de entrada para visualización
    $w('#totalPlan').value = totalPlan.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
    $w('#inscripcionPagada').value = inscripcionPagada.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
    $w('#numeroCuotas').value = numeroCuotas.toString();
}

// Manejar la interacción del usuario con la UI
function mostrarSeccion(seccion) {
    // Ocultar todas las secciones primero
    $w('#infoBasicaBox').hide();
    $w('#comentariosBox').hide();
    $w('#infoFinancieraBox').hide();
    // Agregar la sección de beneficiarios si tienes un contenedor específico
    // $w('#beneficiariosBox').hide();

    if (seccion === 'financiera') {
        $w('#infoFinancieraBox').show();
    } else if (seccion === 'basica') {
        $w('#infoBasicaBox').show();
    } else if (seccion === 'comentarios') {
        $w('#comentariosBox').show();
    } else if (seccion === 'beneficiarios') {
        // Mostrar la sección de beneficiarios si tienes un contenedor específico
        // $w('#beneficiariosBox').show();
        // Cargar los beneficiarios cuando se muestre la sección
        cargarBeneficiarios();
    }
}

// Asumiendo que 'idTitular' y 'numeroId' son globales y ya están establecidos
async function guardarDatos() {
    // Creamos un objeto donde almacenaremos solo los cambios
    let cambiosInfoBasica = {};
    let cambiosInfFinanciera = {};

    // Asignar valores a cambiosInfoBasica
    cambiosInfoBasica.segundoNombre = $w('#segundoNombre').value ? $w('#segundoNombre').value : undefined;
    cambiosInfoBasica.segundoApellido = $w('#segundoApellido').value ? $w('#segundoApellido').value : undefined;
    cambiosInfoBasica.primerNombre = $w('#primerNombre').value ? $w('#primerNombre').value : undefined;
    cambiosInfoBasica.primerApellido = $w('#primerApellido').value ? $w('#primerApellido').value : undefined;
    cambiosInfoBasica.plataforma = $w('#plataforma').value ? $w('#plataforma').value : undefined;
    cambiosInfoBasica.numeroId = $w('#numeroId').value ? $w('#numeroId').value : undefined;
    cambiosInfoBasica.fechaIngreso = $w('#fechaIngreso').value ? $w('#fechaIngreso').value : undefined;
    cambiosInfoBasica.email = $w('#email').value ? $w('#email').value : undefined;
    cambiosInfoBasica.elTraining = $w('#elTraining').value ? $w('#elTraining').value : undefined;
    cambiosInfoBasica.domicilio = $w('#direccion').value ? $w('#direccion').value : undefined;
    cambiosInfoBasica.celular = $w('#celularInfoBox').value ? $w('#celularInfoBox').value : undefined;
    
    // NO guardar el campo aprobación si hay una aprobación pendiente de confirmación
    if (!aprobacionPendiente) {
        cambiosInfoBasica.aprobacion = $w('#aprobacion').value ? $w('#aprobacion').value : undefined;
    } else {
        // Si hay aprobación pendiente, usar el valor original
        cambiosInfoBasica.aprobacion = valorOriginalDropdown;
        console.log("Aprobación pendiente detectada, no se guardará el valor 'Aprobado' hasta confirmación");
    }
    
    cambiosInfoBasica.estadoPlataforma = $w('#plataformaCheckBox').checked ? $w('#plataformaCheckBox').checked : undefined;

    // Log para depuración
    console.log("Cambios en info básica antes de eliminar indefinidos:", cambiosInfoBasica);

    // Eliminar propiedades indefinidas antes de proceder
    Object.keys(cambiosInfoBasica).forEach(key => cambiosInfoBasica[key] === undefined && delete cambiosInfoBasica[key]);

    // Verificar si hay cambios
    if (Object.keys(cambiosInfoBasica).length === 0) {
        console.log("No hay cambios para actualizar.");
        return;
    }

    console.log("Cambios en info básica después de eliminar indefinidos:", cambiosInfoBasica);

    // Convertir fechaIngreso a formato adecuado
    console.log("Antes de la conversión de fechaIngreso: ", $w('#fechaIngreso').value);
    cambiosInfoBasica.fechaIngreso = convertirCadenaAFecha($w('#fechaIngreso').value);
    console.log(cambiosInfoBasica.plataforma);

    // Actualizar registro en la base de datos
    try {
        let resultados = await wixData.query('PEOPLE')
            .eq("_id", idTitular)
            .find();

        if (resultados.items.length > 0) {
            let datosActualizados = resultados.items[0];
            datosActualizados = { ...datosActualizados, ...cambiosInfoBasica };

            console.log("Datos actualizados antes de guardar:", datosActualizados);

            // Extraer la fecha y el comentario del campo de texto
            let valorCompleto = $w('#comentarioTexto').value;

            if (valorCompleto) {
                if (!valorCompleto.includes(':\n')) {
                    console.error('Formato de comentario incorrecto');
                } else {
                    let [fechaConEtiqueta, comentario] = valorCompleto.split(':\n');
                    let fecha = fechaConEtiqueta.replace('Fecha: ', '').trim();

                    let nuevoComentario = {
                        fecha: new Date(fecha), // Convertimos la fecha a objeto Date
                        comentario: comentario.trim() // Aseguramos que no hay espacios innecesarios
                    };

                    // Añadir comentario
                    datosActualizados.comentarios = datosActualizados.comentarios || [];
                    datosActualizados.comentarios.push(nuevoComentario);
                }
            }

            // Actualizar el registro
            await wixData.update("PEOPLE", datosActualizados);
            console.log("Registro actualizado correctamente");

            // Publicar mensaje en el canal
            sendmessage({
                type: "update", // tipo de mensaje para controlar la lógica en el suscriptor
                message: "Datos actualizados"
            });

            // Limpiar el campo de comentario después de guardar
            $w('#comentarioTexto').value = "";
            $w('#guardar').label = "¡GUARDADO!"

            // Actualizar campo aprobación para todos los registros con el mismo numeroId, excepto el actual
            await actualizarAprobacionParaTodosLosRegistrosExceptoActual(idTitular, cambiosInfoBasica.aprobacion);

        } else {
            throw new Error("Registro no encontrado.");
        }

    } catch (err) {
        console.error("Error al actualizar el registro:", err);
    }

    // Asignar valores a cambiosInfFinanciera
    cambiosInfFinanciera.valorCuota = $w('#valorCuota').value ? $w('#valorCuota').value : undefined;
    cambiosInfFinanciera.totalPlan = $w('#totalPlan').value ? $w('#totalPlan').value : undefined;
    cambiosInfFinanciera.saldo = $w('#saldo').value ? $w('#saldo').value : undefined;
    cambiosInfFinanciera.primerNombre = $w('#primerNombre').value ? $w('#primerNombre').value : undefined;
    cambiosInfFinanciera.primerApellido = $w('#primerApellido').value ? $w('#primerApellido').value : undefined;
    cambiosInfFinanciera.plan = $w('#plan').value ? $w('#plan').value : undefined;
    cambiosInfFinanciera.numeroCuotas = $w('#numeroCuotas').value ? $w('#numeroCuotas').value : undefined;
    //cambiosInfFinanciera.numeroContrato = $w('#numeroContrato').value ? $w('#numeroContrato').value : undefined;
    cambiosInfFinanciera.inscripcionPagada = $w('#inscripcionPagada').value ? $w('#inscripcionPagada').value : undefined;
    cambiosInfFinanciera.idUsuario = idTitular;
    cambiosInfFinanciera.formaPago = $w('#formaPago').value ? $w('#formaPago').value : undefined;
    cambiosInfFinanciera.fechaPago = $w('#fechaPago').value ? $w('#fechaPago').value : undefined;
    //cambiosInfFinanciera.facturaNo = $w('#facturaNo').value ? $w('#facturaNo').value : undefined;
    cambiosInfFinanciera.confirmaPrixus = $w('#confirmaPrixusCheck').checked ? $w('#confirmaPrixusCheck').checked : undefined;
    cambiosInfFinanciera.confirmaJudith = $w('#confirmaJudithCheck').checked ? $w('#confirmaJudithCheck').checked : undefined;

    // Eliminar propiedades indefinidas antes de proceder
    Object.keys(cambiosInfFinanciera).forEach(key => cambiosInfFinanciera[key] === undefined && delete cambiosInfFinanciera[key]);

    if (Object.keys(cambiosInfFinanciera).length > 0) {
        try {
            let resultados = await wixData.query('FINANCIERA')
                .eq("numeroId", numeroId)
                .find();

            if (resultados.items.length > 0) {
                let financieraData = resultados.items[0];
                await wixData.update("FINANCIERA", { ...financieraData, ...cambiosInfFinanciera });
            } else {
                let nuevoRegistroFinanciera = { ...cambiosInfFinanciera, "numeroId": numeroId };
                await wixData.insert("FINANCIERA", nuevoRegistroFinanciera);
            }
            await cargarDatosEstudianteYFinanciera();
            console.log("Información financiera procesada correctamente");
        } catch (err) {
            console.error("Error al procesar la información financiera:", err);
        }
    } else {
        console.log("No hay cambios en la información financiera para procesar.");
    }
}

async function actualizarAprobacionParaTodosLosRegistrosExceptoActual(idTitularActual, nuevaAprobacion) {
    try {
        const numeroId = $w('#numeroId').value;

        // Obtener todos los registros con el mismo numeroId excepto el actual
        const resultados = await wixData.query('PEOPLE')
            .eq('numeroId', numeroId)
            .ne('_id', idTitularActual) // Excluir el registro actual
            .find();

        // Actualizar el campo aprobacion para cada registro sin eliminar otros datos
        const actualizaciones = resultados.items.map(async (registro) => {
            let datosActualizados = { ...registro, aprobacion: nuevaAprobacion };
            return wixData.update('PEOPLE', datosActualizados);
        });

        await Promise.all(actualizaciones);
        console.log(`Campo aprobación actualizado para todos los registros duplicados con numeroId ${numeroId}`);
    } catch (err) {
        console.error("Error al actualizar el campo aprobación para todos los registros duplicados:", err);
    }
}

function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1).toLowerCase();
}

/*
==================== RESUMEN DE CORRECCIONES APLICADAS ====================

1. **PROBLEMA IDENTIFICADO:**
   - Algunos registros tienen titularId que apunta a beneficiarios en lugar de titulares
   - Esto causaba que el lightbox recibiera el ID de un beneficiario y no encontrara al titular correcto

2. **SOLUCIÓN IMPLEMENTADA:**
   - En cargarDatosComercial(): Verificar si el usuario es TITULAR o BENEFICIARIO
   - Si es BENEFICIARIO: Buscar el titular real usando titularId
   - Si es TITULAR: Usar su _id directamente
   - Validaciones adicionales para asegurar consistencia

3. **DEBUGGING AGREGADO:**
   - Logs detallados en cada paso crítico
   - Verificación de tipos de usuario
   - Trazabilidad completa del flujo de datos

4. **VALIDACIONES:**
   - Verificar que el titular encontrado sea realmente un TITULAR
   - Manejar casos donde no hay titularId válido
   - Prevenir errores por datos inconsistentes

El problema era específicamente en los registros donde:
- Un beneficiario tenía como titularId el _id de otro beneficiario
- En lugar de tener el _id del titular real

Esta corrección asegura que siempre se trabaje con el titular correcto,
independientemente de si el _id inicial corresponde a un titular o beneficiario.
*/