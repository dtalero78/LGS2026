import wixData from 'wix-data';
import wixWindow from 'wix-window';
import wixLocation from 'wix-location';
import wixRealtimeFrontend from 'wix-realtime-frontend';
import { session } from 'wix-storage';
import moment from 'moment-timezone';

// Backend imports - VERIFICAR QUE ESTAS LÍNEAS ESTÉN CORRECTAS
import { 
    getFormattedClasses, 
    consolidadoNumericoAsistencia,
    panelAriel,
    tablaAsistenciaAriel,
    verificarNivelesCompletados
} from 'backend/ACADEMICA'; // ⚠️ VERIFICAR QUE SEA EL ARCHIVO CORRECTO
import { sendmessage } from 'backend/realTimeChat';

// ===== CONSTANTS =====
const CONSTANTS = {
    PHONE_NUMBERS: {
        SUPPORT: "56957208697",
        ACADEMIC: "56926209723", 
        BILLING_COL_ECU_PER: "573013894444",
        COMMERCIAL_CHILE: "56964077877"
    },
    
    JUMP_STEPS: [5, 10, 15, 20, 25, 30, 35, 40, 45],
    
    LEVEL_MATERIAL_MAPPING: {
        "F1": "/material-f1", "F1 JUMP": "/material-f1",
        "F2": "/material-f2", "F2 JUMP": "/material-f2", 
        "F3": "/material-f3", "F3 JUMP": "/material-f3",
        "P1": "/material-p1", "P1 JUMP": "/material-p1",
        "P2": "/material-p2", "P2 JUMP": "/material-p2",
        "P3": "/material-p3", "P3 JUMP": "/material-p3",
        "BN1": "/material-bn1", "BN1 JUMP": "/material-bn1",
        "BN2": "/material-bn2", "BN2 JUMP": "/material-bn2",
        "BN3": "/material-bn3", "BN3 JUMP": "/material-bn3"
    },

    TIME_LIMITS: {
        BOOKING_MIN_ADVANCE: 30,
        CANCEL_MIN_ADVANCE: 60,
        ZOOM_SHOW_BEFORE: 5,
        ZOOM_SHOW_AFTER: 10
    },

    BOOKING_LIMITS: {
        SESSIONS_PER_WEEK: 2,
        CLUBS_PER_WEEK: 3
    }
};

// ===== GLOBAL STATE =====
let eventosDisponibles = [];
let datosEstudiante = {};
let tipoEventoActual = "";
let nivelEstudiante = "";
let usuarioEstudiante = "";
let nombres = "";
let eventosConCapacidad = []; // Para almacenar info de capacidad

const zonaUsuario = Intl.DateTimeFormat().resolvedOptions().timeZone;

// ===== UTILITY FUNCTIONS =====

function validateToken() {
    const tokenData = JSON.parse(session.getItem('accessToken'));
    
    if (!tokenData) {
        wixLocation.to('/login');
        return false;
    }

    const currentTime = new Date().getTime();
    if (currentTime > tokenData.expiresAt) {
        session.removeItem('accessToken');
        wixLocation.to('/login');
        return false;
    }

    return true;
}

function setupWhatsAppLinks() {
    const links = [
        { elementId: '#whtps1', phone: CONSTANTS.PHONE_NUMBERS.SUPPORT },
        { elementId: '#soporteUsuario', phone: CONSTANTS.PHONE_NUMBERS.SUPPORT },
        { elementId: '#soporteAcademico', phone: CONSTANTS.PHONE_NUMBERS.ACADEMIC },
        { elementId: '#recaudosColEcuPer', phone: CONSTANTS.PHONE_NUMBERS.BILLING_COL_ECU_PER },
        { elementId: '#recaudosChile', phone: CONSTANTS.PHONE_NUMBERS.COMMERCIAL_CHILE }
    ];

    links.forEach(({ elementId, phone }) => {
        const mensaje = "Hola. Requiero soporte";
        const enlace = `https://api.whatsapp.com/send?phone=${phone}&text=${encodeURIComponent(mensaje)}`;
        
        $w(elementId).link = enlace;
        $w(elementId).target = "_blank";
    });
}

function setupMaterialLink() {
    const materialLink = CONSTANTS.LEVEL_MATERIAL_MAPPING[nivelEstudiante] || 
                        "https://www.lgsplataforma.com";
    
    $w('#verMaterial').link = materialLink;
    $w('#verMaterial').target = "_blank";
}

function setupDateOptions() {
    const hoy = new Date();
    const mañana = new Date(hoy);
    mañana.setDate(hoy.getDate() + 1);

    const opcionesDias = [
        { 
            label: `Hoy (${hoy.toLocaleString('es-ES', { month: 'short', day: 'numeric' })})`, 
            value: hoy.getDate().toString() 
        },
        { 
            label: `Mañana (${mañana.toLocaleString('es-ES', { month: 'short', day: 'numeric' })})`, 
            value: mañana.getDate().toString() 
        }
    ];

    $w("#diaBooking").options = opcionesDias;
}

function getSelectedDate(dayValue) {
    const hoy = new Date();
    const mesActual = hoy.getMonth();
    const añoActual = hoy.getFullYear();
    let mesSeleccionado = mesActual;

    if (parseInt(dayValue) < hoy.getDate()) {
        mesSeleccionado += 1;
    }

    return new Date(añoActual, mesSeleccionado, parseInt(dayValue));
}

function getTimeDifferenceInMinutes(eventTime, currentTime = new Date()) {
    return (eventTime - currentTime.getTime()) / (1000 * 60);
}

// ===== REAL-TIME SUBSCRIPTIONS =====

function suscribeToUpdates() {
    const channel = { name: "comentariosAdvisor" };
    
    wixRealtimeFrontend.subscribe(channel, (message) => {
        console.log("Mensaje comentarios recibido:", message);
        
        if (message.payload?.type === "updateComplete") {
            cargarComentariosAdvisor(datosEstudiante._id);
        }
    }).then(id => {
        console.log("Suscripción a comentarios exitosa:", id);
    });
}

function suscribeToUpdates2() {
    const channel = { name: "modificacionCalendario" };
    
    wixRealtimeFrontend.subscribe(channel, (message) => {
        console.log("Mensaje calendario recibido:", message);
        
        if (message.payload?.type === "updateComplete") {
            actualizarMisEventosRepeater(datosEstudiante._id);
            obtenerProximaClase(datosEstudiante._id);
        }
    }).then(id => {
        console.log("Suscripción a calendario exitosa:", id);
    }).catch(err => {
        console.error("Error en suscripción a calendario:", err);
    });
}

// ===== STUDENT DATA MANAGEMENT =====

function cargarDatosEstudiante() {
    datosEstudiante = $w("#dynamicDataset").getCurrentItem();
    nivelEstudiante = datosEstudiante.nivel;

    let nombres = "Hola" +
        (datosEstudiante.primerNombre ? " " + datosEstudiante.primerNombre : "") +
        (datosEstudiante.segundoNombre ? " " + datosEstudiante.segundoNombre : "");

    let foto = datosEstudiante.foto;
    $w('#nivelActual').text = "Nivel: " + nivelEstudiante;
    $w('#nombrePerfil').text = nombres;
    $w('#fotoPerfil').src = foto;

    const { _id, nivel, idEstudiante } = datosEstudiante || {};
    if (!datosEstudiante) {
        return;
    }

    obtenerProximaClase(_id);
    actualizarMisEventosRepeater(_id);
    cargarComentariosAdvisor(_id);

    // Consolidar asistencia
    consolidadoNumericoAsistencia(_id).then(({ countCancelados, countNoAsistidos, countAsistidos }) => {
        $w("#cancelaste").text = countCancelados.toString();
        $w("#noAsististe").text = countNoAsistidos.toString();
        $w("#asististe").text = countAsistidos.toString();

        // Caso especial para usuario específico
        if (idEstudiante === "59518aa1-1e10-4ad9-8561-026a207536eb") {
            $w('#noAsististe').text = "0";
        }
    });

    // Manejo del cambio en el selector de día
    $w("#diaBooking").onChange(event => {
        const diaSeleccionado = getSelectedDate(event.target.value);

        if (nivel) {
            filtrarHorasSession(diaSeleccionado, nivel, tipoEventoActual);
            actualizarConfirmacionEvento();
        }
    });
}

// ===== COMMENTS MANAGEMENT =====

function cargarComentariosAdvisor(idEstudiante) {
    console.log("Cargando comentarios para estudiante:", idEstudiante);

    $w('#comentariosTable').columns = [
        { 
            id: 'comentarios', 
            dataPath: 'comentarios', 
            label: 'Comentarios', 
            width: 500, 
            visible: true, 
            type: 'string' 
        }
    ];

    wixData.query("CLASSES")
        .eq("idEstudiante", idEstudiante)
        .find()
        .then((results) => {
            const comentariosData = results.items.map(item => ({
                comentarios: item.comentarios
            }));

            $w('#comentariosTable').rows = comentariosData;
        })
        .catch((err) => {
            console.error("Error cargando comentarios:", err);
        });
}

// ===== EVENT MANAGEMENT =====

async function actualizarMisEventosRepeater(idEstudiante) {
    if (!idEstudiante) {
        console.error("idEstudiante no definido");
        return;
    }

    try {
        const ahora = moment();
        const resultados = await wixData.query("BOOKING")
            .eq("idEstudiante", idEstudiante)
            .gt("fechaEvento", ahora.toDate())
            .ascending("cancelo")
            .descending("fechaEvento")
            .limit(4)
            .find();

        if (resultados.items.length > 0) {
            $w("#misEventosRepeater").data = resultados.items;
            setupEventRepeaterItems();
        } else {
            console.log("No se encontraron eventos futuros");
        }
    } catch (err) {
        console.error("Error actualizando eventos:", err);
    }
}

function setupEventRepeaterItems() {
    $w("#misEventosRepeater").onItemReady(async ($item, itemData) => {
        moment.locale("es");

        const fechaEventoUTC = moment.utc(itemData.fechaEvento);
        const adjustedFecha = fechaEventoUTC.local();
        
        $item("#fechaEvento").text = adjustedFecha.format('dddd D, hh:mm A');

        // Configurar advisor
        if (itemData.advisor) {
            try {
                const advisor = await wixData.get("ADVISORS", itemData.advisor);
                $item("#advisor").text = `${advisor.primerNombre} ${advisor.primerApellido}`;
            } catch (err) {
                console.error(`Error obteniendo advisor ${itemData.advisor}:`, err);
                $item("#advisor").text = "Sin asesor";
            }
        } else {
            $item("#advisor").text = "Sin asesor";
        }
        
        $item("#step").text = itemData.tipoEvento || "Sin step";

        // Configurar botón de cancelación
        const ahora = moment();
        const fechaEvento = adjustedFecha.valueOf();
        const diferencia = getTimeDifferenceInMinutes(fechaEvento, ahora.toDate());

        if (itemData.cancelo) {
            $item("#cancelarEventoMisEventos").label = "CANCELADO";
            $item("#cancelarEventoMisEventos").disable();
        } else if (diferencia < CONSTANTS.TIME_LIMITS.CANCEL_MIN_ADVANCE) {
            $item("#cancelarEventoMisEventos").label = "PROXIMAMENTE";
            $item("#cancelarEventoMisEventos").disable();
        } else {
            $item("#cancelarEventoMisEventos").enable();
            $item("#cancelarEventoMisEventos").label = "Cancelar";
            
            $item("#cancelarEventoMisEventos").onClick(async () => {
                try {
                    const itemCompleto = await wixData.get("BOOKING", itemData._id);
                    
                    itemCompleto.cancelo = true;
                    await wixData.update("BOOKING", itemCompleto);
                    await wixData.remove("CLASSES", itemData._id);

                    // Actualizar UI
                    const data = $w("#misEventosRepeater").data;
                    const updatedData = data.filter(event => event._id !== itemData._id);
                    $w("#misEventosRepeater").data = updatedData;

                    obtenerProximaClase(datosEstudiante._id);
                } catch (err) {
                    console.error("Error cancelando evento:", err);
                }
            });
        }
    });
}

function obtenerProximaClase(idEstudiante) {
    const diezMinutosAtras = new Date(Date.now() - 10 * 60 * 1000);

    wixData.query("BOOKING")
        .eq("idEstudiante", idEstudiante)
        .ne("cancelo", true)
        .gt("fechaEvento", diezMinutosAtras)
        .ascending("fechaEvento")
        .limit(10)
        .find()
        .then((results) => {
            if (results.items.length > 0) {
                actualizarRepetidor(results.items[0]);
            } else {
                mostrarEsqueletoNextClassRepeater();
                $w('#tituloNextSession').hide();
            }
        })
        .catch((err) => {
            console.error("Error obteniendo próxima clase:", err);
        });
}

async function actualizarRepetidor(clase) {
    moment.locale("es");

    const fechaEvento = moment.utc(clase.fechaEvento).local();
    const fechaEventoString = fechaEvento.format('dddd D, hh:mm A');

    try {
        const advisor = await wixData.get("ADVISORS", clase.advisor);
        const nombreAdvisor = `${advisor.primerNombre} ${advisor.primerApellido}`;
        const enlaceZoom = advisor.zoom || '';

        $w("#nextClassRepeater").data = [{
            "_id": clase._id,
            "nivelTextRepeater": clase.nivel,
            "advisorClassRepeater": nombreAdvisor,
            "fechaClassRepeater": fechaEventoString,
            "zoomLinkRepeater": enlaceZoom,
            "nivel": clase.nivel,
            "step": clase.step
        }];

        setupNextClassRepeaterItems();
    } catch (err) {
        console.error("Error actualizando repetidor:", err);
    }
}

function setupNextClassRepeaterItems() {
    $w("#nextClassRepeater").forEachItem(($item, itemData, index) => {
        $item("#nivelTextRepeater").text = itemData.nivelTextRepeater;
        $item("#advisorClassRepeater").text = itemData.advisorClassRepeater;
        $item("#fechaClassRepeater").text = itemData.fechaClassRepeater;

        $item("#zoomIcono").link = itemData.zoomLinkRepeater;
        $item("#zoomIcono").target = "_blank";

        // Handle zoom visibility
        const fechaEventoMoment = moment(itemData.fechaClassRepeater, 'dddd D, hh:mm A', 'es');
        const ahora = moment();

        const beforeLimit = fechaEventoMoment.clone().subtract(CONSTANTS.TIME_LIMITS.ZOOM_SHOW_BEFORE, 'minutes');
        const afterLimit = fechaEventoMoment.clone().add(CONSTANTS.TIME_LIMITS.ZOOM_SHOW_AFTER, 'minutes');

        if (ahora.isBefore(beforeLimit) || ahora.isAfter(afterLimit)) {
            $item("#zoomIcono").hide();
        } else {
            $item("#zoomIcono").show();
        }

        // Setup video button
        $item("#verVideoButton").onClick(() => {
            wixWindow.openLightbox("VIDEOS", {
                nivel: itemData.nivel,
                step: itemData.step
            });
        });
    });
}

function mostrarEsqueletoNextClassRepeater() {
    const skeletonData = [{
        "_id": "skeleton",
        "nivelTextRepeater": "Nivel: ---",
        "advisorClassRepeater": "Asesor: ---",
        "fechaClassRepeater": "Fecha: ---",
        "zoomLinkRepeater": "Zoom: ---"
    }];

    $w("#nextClassRepeater").data = skeletonData;
    $w("#nextClassRepeater").forEachItem(($item, itemData) => {
        $item("#nivelTextRepeater").text = itemData.nivelTextRepeater;
        $item("#advisorClassRepeater").text = itemData.advisorClassRepeater;
        $item("#fechaClassRepeater").text = itemData.fechaClassRepeater;
        $item("#zoomIcono").hide();
        $item("#verVideoButton").hide();
    });

    $w('#tituloNextSession').show();
}

// ===== BOOKING MANAGEMENT =====

async function filtrarHorasSession(dia, nivel, tipoEvento) {
    let inicioDia = new Date(dia);
    inicioDia.setHours(0, 0, 0, 0);
    let finDia = new Date(dia);
    finDia.setHours(23, 0, 0, 0);

    let horasOcupadas = [];
    let ahora = new Date().getTime();

    const stepActualStr = (datosEstudiante.step || "").replace("Step ", "");
    const stepActual = parseInt(stepActualStr);
    const estaEnJump = CONSTANTS.JUMP_STEPS.includes(stepActual);

    try {
        const clasesResults = await wixData.query("BOOKING")
            .eq("idEstudiante", datosEstudiante._id)
            .ge("fechaEvento", inicioDia)
            .lt("fechaEvento", finDia)
            .ne("nombreEvento", "WELCOME")
            .isEmpty("cancelo")
            .find();

        horasOcupadas = clasesResults.items.map(clase => new Date(clase.fechaEvento).getTime());

        const results = await wixData.query("CALENDARIO")
            .eq("tituloONivel", nivel)
            .eq("evento", tipoEvento)
            .ge("dia", inicioDia)
            .lt("dia", finDia)
            .ne("nombreEvento", "WELCOME")
            .find();

        eventosDisponibles = results.items.filter(item => {
            let horaEvento = new Date(item.dia).getTime();

            const nombreEvento = item.nombreEvento || "";
            const stepMatch = nombreEvento.match(/Step\s*(\d+)/i);
            const esStep = !!stepMatch;
            const stepNumber = esStep ? parseInt(stepMatch[1]) : null;
            const esJumpEvento = CONSTANTS.JUMP_STEPS.includes(stepNumber);

            if (tipoEvento === "SESSION") {
                if (estaEnJump) {
                    if (!esJumpEvento || stepNumber !== stepActual) return false;
                } else {
                    if (esJumpEvento) return false;
                }
            }

            if (tipoEvento === "CLUB") {
                if (estaEnJump) {
                    if (!esStep || stepNumber !== stepActual) return false;
                } else {
                    if (esJumpEvento) return false;
                }
            }

            return !horasOcupadas.includes(horaEvento) && 
                   (horaEvento - ahora) >= (CONSTANTS.TIME_LIMITS.BOOKING_MIN_ADVANCE * 60 * 1000);
        });

        eventosDisponibles.sort((a, b) => moment(a.dia).valueOf() - moment(b.dia).valueOf());

        // Verificar capacidad para cada evento disponible y marcar los llenos
        eventosConCapacidad = await Promise.all(eventosDisponibles.map(async (item, index) => {
            const usuariosInscritos = await contarUsuariosInscritos(item._id);
            const cupoCompleto = usuariosInscritos >= item.limiteUsuarios;
            
            let horaFormateada = moment(item.dia).tz(zonaUsuario).format('HH:mm');
            let label;
            
            if (cupoCompleto) {
                label = `${horaFormateada} - ${item.tituloONivel} - ${item.nombreEvento} - ⚠️ CUPO LLENO`;
            } else {
                label = `${horaFormateada} - ${item.tituloONivel} - ${item.nombreEvento}`;
            }

            return { 
                label: label, 
                value: index.toString(),
                cupoCompleto: cupoCompleto,
                item: item
            };
        }));

        // Mostrar TODOS los eventos (incluso los llenos) para que el usuario vea el horario completo
        $w("#horaBooking").options = eventosConCapacidad.map(({ label, value }) => ({ label, value }));

        // Los eventos con información de capacidad ya están en la variable global eventosConCapacidad

        if (eventosConCapacidad.length === 0) {
            $w("#confirmacionButton").disable();
        } else {
            $w("#confirmacionButton").enable();
        }
    } catch (err) {
        console.error("Error al filtrar los eventos:", err);
    }
}

function getStepLabel(nombreEvento) {
    const stepMatch = (nombreEvento || "").match(/Step\s*(\d+)/i);
    if (stepMatch) {
        const stepNumber = parseInt(stepMatch[1]);
        return CONSTANTS.JUMP_STEPS.includes(stepNumber) ? "Jump" : `Step ${stepNumber}`;
    }
    return nombreEvento || "Sin Step";
}

function actualizarConfirmacionEvento() {
    let diaSeleccionado = $w("#diaBooking").value;
    let horaSeleccionada = $w("#horaBooking").value;

    if (diaSeleccionado && horaSeleccionada) {
        let selectedIndex = parseInt(horaSeleccionada);
        let eventoSeleccionado = eventosDisponibles[selectedIndex];
        let horaTexto = new Date(eventoSeleccionado.dia).toLocaleTimeString();

        const fechaSeleccionada = getSelectedDate(diaSeleccionado);
        let fechaTexto = fechaSeleccionada.toLocaleDateString('es-ES');

        // Verificar si el evento seleccionado tiene cupo lleno
        const eventoCapacidad = eventosConCapacidad.find(e => parseInt(e.value) === selectedIndex);
        const tieneCupoLleno = eventoCapacidad?.cupoCompleto || false;

        let confirmacionTexto;
        if (tieneCupoLleno) {
            confirmacionTexto = `⚠️ CUPO LLENO - NO DISPONIBLE PARA RESERVA\n\nEvento: ${eventoSeleccionado.evento}\nDía: ${fechaTexto}\nHora: ${horaTexto}`;
            $w("#confirmacionButton").disable();
            $w("#confirmacionButton").hide(); // Ocultar el botón completamente
        } else {
            confirmacionTexto = `Evento: ${eventoSeleccionado.evento}\nDía seleccionado: ${fechaTexto}\nHora seleccionada: ${horaTexto}`;
            $w("#confirmacionButton").enable();
            $w("#confirmacionButton").show(); // Mostrar el botón
        }
        
        $w("#confirmacionEvento").text = confirmacionTexto;
    }
}

// ===== VALIDATION HELPERS =====

async function contarEventosSemanales(tipoEvento, idEstudiante) {
    let inicioSemana = new Date();
    inicioSemana.setDate(inicioSemana.getDate() - inicioSemana.getDay() + 1);
    inicioSemana.setHours(0, 0, 0, 0);

    let finSemana = new Date(inicioSemana);
    finSemana.setDate(finSemana.getDate() + 5);
    finSemana.setHours(23, 59, 59, 999);

    // Contar todas las sesiones no canceladas de la semana (incluyendo futuras y pasadas)
    let resultados = await wixData.query("BOOKING")
        .eq("idEstudiante", idEstudiante)
        .eq("tipoEvento", tipoEvento)
        .between("fechaEvento", inicioSemana, finSemana)
        .isEmpty("cancelo")
        .count();

    return resultados;
}

async function verificarSesionDia(tipoEvento, idEstudiante, diaSeleccionado) {
    let inicioDia = new Date(diaSeleccionado);
    inicioDia.setHours(0, 0, 0, 0);

    let finDia = new Date(diaSeleccionado);
    finDia.setHours(23, 59, 59, 999);

    // Verificar si hay sesiones en el día seleccionado
    let resultados = await wixData.query("BOOKING")
        .eq("idEstudiante", idEstudiante)
        .eq("tipoEvento", tipoEvento)
        .between("fechaEvento", inicioDia, finDia)
        .find();

    if (resultados.items.length > 0) {
        let sesionAgendada = resultados.items[0];
        
        // Si la sesión fue cancelada, puede agendar libremente
        if (sesionAgendada.cancelo) {
            return false; // No hay impedimento
        }
        
        // Si la sesión aún no ha pasado, no puede agendar otra en el mismo día
        let fechaEvento = new Date(sesionAgendada.fechaEvento);
        let ahora = new Date();
        
        if (ahora <= fechaEvento) {
            return true; // Tiene sesión pendiente, no puede agendar
        }
        
        // Si la sesión ya pasó, verificar si es para hoy o días futuros
        let hoy = new Date();
        hoy.setHours(0, 0, 0, 0);
        
        let diaSeleccionadoSinHora = new Date(diaSeleccionado);
        diaSeleccionadoSinHora.setHours(0, 0, 0, 0);
        
        // Si está intentando agendar para HOY
        if (diaSeleccionadoSinHora.getTime() === hoy.getTime()) {
            // Para HOY: Solo puede agendar si la sesión anterior fue cancelada (ya cubierto arriba)
            // Si asistió o no asistió, NO puede agendar para HOY
            return true; // No puede agendar para hoy
        } else {
            // Para días futuros: Siempre puede agendar si ya pasó su sesión de hoy
            return false; // Puede agendar para días futuros
        }
    }

    return false; // No hay sesiones ese día, puede agendar
}

async function contarUsuariosInscritos(eventoId) {
    return await wixData.query("BOOKING")
        .eq("idEvento", eventoId)
        .isEmpty("cancelo")  // Solo contar los que NO han cancelado
        .count();
}

async function tieneSesionPendiente(idEstudiante) {
    let ahora = new Date();
    let resultado = await wixData.query("BOOKING")
        .eq("idEstudiante", idEstudiante)
        .eq("tipoEvento", "SESSION")
        .ge("fechaEvento", ahora)
        .isEmpty("cancelo")
        .find();
        
    return resultado.items.length > 0;
}

// ===== BOOKING CONFIRMATION =====

async function confirmarBooking() {
    try {
        $w('#loadingConfirmar').show();

        if (!datosEstudiante || !datosEstudiante._id) {
            console.error("datosEstudiante o idEstudiante no están definidos.");
            $w('#loadingConfirmar').hide();
            $w('#confirmacionEvento').text = "Ocurrió un error al procesar tu reserva. Por favor, intenta de nuevo.";
            return;
        }

        // Validar sesión pendiente para SESSION
        if (tipoEventoActual === "SESSION") {
            const pendiente = await tieneSesionPendiente(datosEstudiante._id);
            if (pendiente) {
                $w('#confirmacionEvento').text = "Ya tienes una sesión reservada y pendiente. Solo puedes reservar otra cuando pase tu sesión actual.";
                $w('#loadingConfirmar').hide();
                return;
            }
        }

        // Validaciones de límites
        const [sesionesSemanales, clubesSemanales] = await Promise.all([
            contarEventosSemanales("SESSION", datosEstudiante._id),
            contarEventosSemanales("CLUB", datosEstudiante._id)
        ]);

        if (tipoEventoActual === "SESSION" && sesionesSemanales >= CONSTANTS.BOOKING_LIMITS.SESSIONS_PER_WEEK) {
            $w('#confirmacionEvento').text = "No se puede reservar más sesiones esta semana.";
            $w('#loadingConfirmar').hide();
            return;
        }

        if (tipoEventoActual === "CLUB" && 
            clubesSemanales >= CONSTANTS.BOOKING_LIMITS.CLUBS_PER_WEEK) {
            $w('#confirmacionEvento').text = "No se puede reservar más clubes esta semana.";
            $w('#loadingConfirmar').hide();
            return;
        }

        let selectedIndex = parseInt($w("#horaBooking").value);
        let eventoSeleccionado = eventosDisponibles[selectedIndex];
        
        // Validar si ya tiene una sesión en el día seleccionado que impida agendar otra
        if (tipoEventoActual === "SESSION") {
            let fechaEventoSeleccionado = new Date(eventoSeleccionado.dia);
            const sesionEnMismoDia = await verificarSesionDia("SESSION", datosEstudiante._id, fechaEventoSeleccionado);
            if (sesionEnMismoDia) {
                $w('#confirmacionEvento').text = "Ya tienes una sesión programada para este día que no ha sido completada o cancelada.";
                $w('#loadingConfirmar').hide();
                return;
            }
        }

        if (!eventoSeleccionado) {
            $w('#confirmacionEvento').text = "No se encontró el evento seleccionado.";
            $w('#loadingConfirmar').hide();
            return;
        }

        // Verificar límite de usuarios
        let usuariosInscritos = await contarUsuariosInscritos(eventoSeleccionado._id);
        if (usuariosInscritos >= eventoSeleccionado.limiteUsuarios) {
            $w('#confirmacionEvento').text = "El límite de usuarios para este evento está lleno.";
            $w('#loadingConfirmar').hide();
            return;
        }

        let fechaEvento = new Date(eventoSeleccionado.dia);

        let nuevoBooking = {
            "idEvento": eventoSeleccionado._id,
            "idEstudiante": datosEstudiante._id,
            "primerNombre": datosEstudiante.primerNombre,
            "primerApellido": datosEstudiante.primerApellido,
            "numeroId": datosEstudiante.idEstudiante,
            "nivel": datosEstudiante.nivel,
            "fechaEvento": fechaEvento,
            "tipoEvento": tipoEventoActual,
            "advisor": eventoSeleccionado.advisor,
            "step": eventoSeleccionado.nombreEvento,
            "celular": datosEstudiante.celular,
        };

        console.log("Intentando insertar:", nuevoBooking);

        await wixData.insert("BOOKING", nuevoBooking);
        await wixData.insert("CLASSES", nuevoBooking);

        // Limpiar formulario
        $w('#diaBooking').value = "";
        $w('#horaBooking').value = "";
        $w('#book').hide();
        $w('#confirmacionEventoBox').hide();
        $w('#loadingConfirmar').hide();

        console.log("Reserva confirmada:", nuevoBooking);

        // Actualizar repetidores
        obtenerProximaClase(datosEstudiante._id);
        await actualizarMisEventosRepeater(datosEstudiante._id);

        // Enviar mensaje para actualizar otros canales
        try {
            await sendmessage("sesionAdvisor", { type: "updateComplete" });
            console.log("Mensaje enviado con éxito");
        } catch (err) {
            console.error("Error enviando mensaje:", err);
        }

        wixWindow.lightbox.close({ "updated": true });

    } catch (err) {
        console.error("Error al guardar la reserva:", err);
        $w('#loadingConfirmar').hide();
        $w('#confirmacionEvento').text = "Ocurrió un error al procesar tu reserva. Por favor, intenta de nuevo.";
    }
}

// ===== MATERIAL MANAGEMENT =====

function configurarTabla() {
    $w("#materialTable").columns = [
        { 
            id: "name", 
            dataPath: "name", 
            label: "File Name", 
            width: 300, 
            visible: true, 
            type: "string" 
        }
    ];
}

function cargarMaterial() {
    configurarTabla();

    wixData.query("NIVELES")
        .eq("code", datosEstudiante.nivel)
        .find()
        .then((results) => {
            if (results.items.length > 0) {
                const item = results.items[0];
                const materiales = item.materialUsuario;

                if (materiales && Array.isArray(materiales)) {
                    const tableData = materiales.map((material, index) => {
                        return {
                            "index": index + 1,
                            "step": item.step,
                            "name": decodeURIComponent(extractFileName(material)),
                            "url": material
                        };
                    });

                    $w('#materialTable').rows = tableData;
                } else if (typeof materiales === 'string') {
                    const tableData = [{
                        "index": 1,
                        "step": item.step,
                        "name": decodeURIComponent(extractFileName(materiales)),
                        "url": materiales
                    }];

                    $w('#materialTable').rows = tableData;
                } else {
                    console.warn("No se encontraron materiales.");
                    $w('#materialTable').rows = [];
                }

                $w("#materialTable").onRowSelect((event) => {
                    const rowData = event.rowData;
                    const fileUrl = rowData.url;
                    if (fileUrl) {
                        wixLocation.to(fileUrl);
                    } else {
                        console.error("No se encontró la URL del archivo.");
                    }
                });

            } else {
                console.warn("No se encontraron resultados para el nivel proporcionado.");
                $w('#materialTable').rows = [];
            }
        })
        .catch((error) => {
            console.error("Error al consultar la base de datos NIVELES:", error);
        });
}

function extractFileName(url) {
    const parts = url.split('/');
    return parts[parts.length - 1];
}

// ===== CLASSES REPORT MANAGEMENT =====

async function mostrarRegistroClases() {
    wixLocation.to("#anchor1");
    
    $w('#nivelStatusTitleBox').text = "Status Nivel " + nivelEstudiante;
    $w('#loading').show();
    $w('#materialBox').hide();

    try {
        const { formattedItems, diagnostico, porcentajeAvance } = 
            await getFormattedClasses(datosEstudiante._id, nivelEstudiante);

        console.log("🟢 Datos que llegaron al frontend:", formattedItems);

        const transformedItems = formattedItems.map(item => {
            const ajustada = moment(item.fechaEvento).format('D MMM YYYY, hh:mm A');

            return {
                fechaEvento: ajustada,
                tipoEvento: item.tipoEvento,
                nivel: item.nivel,
                step: item.step,
                advisorName: item.advisorName,
                asistencia: item.asistencia,
                participacion: item.participacion,
                advisorId: item.advisorId,
                idEvento: item.idEvento
            };
        });

        $w("#tablaAsistencia").columns = [
            { id: "fechaEvento", dataPath: "fechaEvento", label: "Fecha", width: 150, type: "string" },
            { id: "tipoEvento", dataPath: "tipoEvento", label: "Tipo", width: 100, type: "string" },
            { id: "nivel", dataPath: "nivel", label: "Nivel", width: 80, type: "string" },
            { id: "step", dataPath: "step", label: "Step", width: 80, type: "string" },
            { id: "advisorName", dataPath: "advisorName", label: "Advisor", width: 150, type: "string" },
            { id: "asistencia", dataPath: "asistencia", label: "Asistió", width: 80, type: "string" },
            { id: "participacion", dataPath: "participacion", label: "Participó", width: 80, type: "string" },
            { id: "linkZoom", dataPath: "linkZoom", label: "Zoom", width: 220, type: "link" }
        ];

        $w("#tablaAsistencia").rows = transformedItems;

        let fechaFormateada = moment().format('dddd D, hh:mm A');

        let diagnosticoHTML = diagnostico.replace(/evento_id_placeholder/g, "evento_id_real")
            .replace(/nombre_placeholder/g, datosEstudiante.primerNombre)
            .replace(/apellido_placeholder/g, datosEstudiante.primerApellido)
            .replace(/numeroId_placeholder/g, datosEstudiante.idEstudiante)
            .replace(/fecha_placeholder/g, fechaFormateada)
            .replace(/tipo_placeholder/g, "COMPLEMENTARIA")
            .replace(/advisor_placeholder/g, "advisor_real")
            .replace(/studentId_placeholder/g, datosEstudiante._id);

        $w("#statusClasses").html = `<div style="font-family: Helvetica, sans-serif; font-size: 12px; color: black; line-height: 1.2;">${diagnosticoHTML}</div>`;

        $w('#loading').hide();
        $w('#historicoClasesBox').show();
    } catch (error) {
        console.error("Error cargando registro de clases:", error);
        $w('#loading').hide();
    }
}

// ===== EVENT HANDLERS SETUP =====

function setupEventHandlers() {
    // Confirmation handlers
    $w("#confirmacionButton").onClick(() => {
        $w('#confirmacionEventoBox').show();
    });

    $w("#noConfirmarBooking").onClick(() => {
        $w('#confirmacionEventoBox').hide();
        $w('#diaBooking').value = "";
        $w('#horaBooking').value = "";
        $w('#book').hide();
    });

    $w("#confirmarBooking").onClick(() => {
        confirmarBooking();
    });

    // Booking type handlers
    $w('#bookingSession').onClick(() => {
        $w('#book').show();
        tipoEventoActual = "SESSION";

        const diaSeleccionado = getSelectedDate($w("#diaBooking").value || "1");
        filtrarHorasSession(diaSeleccionado, datosEstudiante.nivel, tipoEventoActual);
        actualizarConfirmacionEvento();
    });

    $w('#bookingClub').onClick(() => {
        $w('#book').show();
        tipoEventoActual = "CLUB";

        const diaSeleccionado = getSelectedDate($w("#diaBooking").value || "1");
        filtrarHorasSession(diaSeleccionado, datosEstudiante.nivel, tipoEventoActual);
        actualizarConfirmacionEvento();
    });

    // Hour selection handler
    $w("#horaBooking").onChange(() => {
        actualizarConfirmacionEvento();
    });

    // Material handlers
    $w('#descargarMaterial').onClick(() => {
        cargarMaterial();
        $w('#materialBox').show();
    });

    $w('#closeMaterial').onClick(() => {
        $w('#materialBotonesGroup').hide();
        $w('#materialBox').hide();
    });

    // General close handlers
    $w('#button2').onClick(() => {
        $w('#book').hide();
    });
}

// ===== MAIN INITIALIZATION =====
$w.onReady(function () {
    console.log("Inicializando aplicación...");

    // Validar autenticación
    if (!validateToken()) {
        return;
    }

    // Configurar suscripciones en tiempo real
    suscribeToUpdates();
    suscribeToUpdates2();

    // Cargar datos del estudiante
    cargarDatosEstudiante();

    // Configurar UI inicial
    setupWhatsAppLinks();
    setupMaterialLink();
    setupDateOptions();

    // Configurar manejadores de eventos
    setupEventHandlers();

    console.log("Aplicación inicializada correctamente");
});

// ===== EXPORTED FUNCTIONS =====

export function materialBoxButton_click(event) {
    $w('#materialBotonesGroup').show();
}

export function registroClasesButton_click(event) {
    mostrarRegistroClases();
}

export function closeRegistroClasesButton_click(event) {
    $w('#historicoClasesBox').hide();
}