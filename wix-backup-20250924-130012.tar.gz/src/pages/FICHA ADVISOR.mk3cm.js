import wixData from 'wix-data';
import wixStorage from 'wix-storage';
import moment from 'moment';
import { v4 as uuidv4 } from 'uuid';
import { getFormattedClasses } from 'backend/ACADEMICA';

// Variables globales
let resourceId = uuidv4();
let selectedStudentId = wixStorage.local.getItem('numeroId');
let eventId = "cbdd452f-e427-46a3-8dc3-f7a88110ee4e"; // Ajusta según sea necesario
moment.locale('es'); // Configura moment en español
let numeroId = "141940910"

$w.onReady(() => {
    initializePage();
    loadEventDropdown();

    $w("#eventoDropdown").onChange(() => {
        const selectedStep = $w("#eventoDropdown").value;
        loadDateDropdown(selectedStep);
    });

});

// Inicializa los eventos de los botones y carga inicial
function initializePage() {
    $w('#advisorNotesButton').onClick(toggleElementVisibility('#advisorNotes'));
    $w('#commentToUserButton').onClick(toggleElementVisibility('#rateStudent'));

    loadStudentData(numeroId); // Reemplaza con el valor dinámico
    setupTableRowSelection();
}

// Alterna la visibilidad de un elemento
function toggleElementVisibility(elementId) {
    return () => {
        const element = $w(elementId);
        element.hidden ? element.show() : element.hide();
    };
}

// Carga los datos del estudiante y sus clases
async function loadStudentData(numeroId) {
    try {
        // Buscar el estudiante en ACADEMICA
        const student = await queryAcademica(numeroId);
        if (!student) {
            console.warn(`No se encontró un estudiante con el numeroId: ${numeroId}`);
            return;
        }

        // Cargar las clases del estudiante
        const { clases, nivelesCompletados } = await queryClasses(student._id, student.nivel);
        updateTable(clases);
        updateCheckboxGroup(nivelesCompletados);
    } catch (error) {
        console.error("Error al cargar los datos del estudiante:", error);
    }
}

// Realiza un query en la base de datos ACADEMICA
async function queryAcademica(numeroId) {
    const result = await wixData.query("ACADEMICA").eq("numeroId", numeroId).find();
    return result.items[0] || null;
}

// Realiza un query en la base de datos CLASSES y devuelve las clases formateadas
async function queryClasses(academicaId, nivel) {
    const { formattedItems, nivelesCompletados } = await getFormattedClasses(academicaId, nivel);

    const clases = formattedItems.map(item => ({
        ...item,
        idEvento: item.idEvento || "Sin ID",
        fechaEvento: moment.utc(item.fechaEvento).local().format('D MMM YYYY, hh:mm A')
    }));

    return { clases, nivelesCompletados };
}

// Actualiza la tabla con las clases formateadas
function updateTable(clases) {
    // Configurar las columnas de la tabla
    $w("#tablaAsistencia").columns = [
        { "id": "idEvento", "dataPath": "idEvento", "label": "ID Evento", "width": 150, "visible": false, "type": "string" },
        { "id": "fechaEvento", "dataPath": "fechaEvento", "label": "Fecha", "width": 150, "visible": true, "type": "string" },
        { "id": "tipoEvento", "dataPath": "tipoEvento", "label": "Tipo", "width": 100, "visible": true, "type": "string" },
        { "id": "nivel", "dataPath": "nivel", "label": "Nivel", "width": 80, "visible": true, "type": "string" },
        { "id": "step", "dataPath": "step", "label": "Step", "width": 80, "visible": true, "type": "string" },
        { "id": "advisorName", "dataPath": "advisorName", "label": "Advisor", "width": 150, "visible": true, "type": "string" },
        { "id": "asistencia", "dataPath": "asistencia", "label": "Asistió", "width": 80, "visible": true, "type": "string" },
        { "id": "participacion", "dataPath": "participacion", "label": "Participó", "width": 80, "visible": true, "type": "string" },
    ];
    $w("#tablaAsistencia").rows = clases;
}

// Actualiza el grupo de checkboxes con los niveles completados
function updateCheckboxGroup(nivelesCompletados) {
    const options = Object.keys(nivelesCompletados).map(nivel => ({
        label: nivel,
        value: nivel
    }));
    const values = Object.keys(nivelesCompletados).filter(nivel => nivelesCompletados[nivel]);

    $w("#nivelesStatus").options = options;
    $w("#nivelesStatus").value = values;
}

// Configura el evento de selección de filas en la tabla
function setupTableRowSelection() {
    $w("#tablaAsistencia").onRowSelect(async (event) => {

        const rowData = event.rowData;
        if (!rowData.idEvento) {
            console.warn("La fila seleccionada no contiene un idEvento.");
            return;
        }

        try {
            $w('#grupoInfoGeneral').show();
            // Buscar información del evento en CLASSES
            const eventDetails = await queryClassesById(rowData.idEvento);
            displayEventDetails(eventDetails);

            // Buscar el nombre del advisor
            if (eventDetails.advisor) {
                const advisorName = await queryAdvisorName(eventDetails.advisor);
                $w('#advisor').text = advisorName || "No asignado";
            }
        } catch (error) {
            console.error("Error al procesar la fila seleccionada:", error);
        }
    });
}

// Realiza un query en la base de datos CLASSES para obtener detalles del evento
async function queryClassesById(idEvento) {
    const result = await wixData.query("CLASSES").eq("idEvento", idEvento).find();
    return result.items[0] || null;
}

// Muestra los detalles del evento en los campos correspondientes
function displayEventDetails(eventDetails) {
    if (!eventDetails) return;

    $w('#fechaEvento').text = moment(eventDetails.fechaEvento).format('D MMM YYYY, hh:mm A');
    $w('#nivel').text = eventDetails.nivel || "N/A";
    $w('#step').text = eventDetails.step || "N/A";
    $w('#asistenciaCheckBox').checked = !!eventDetails.asistencia;
    $w('#participacionCheckBox').checked = !!eventDetails.participacion;
    $w('#calificacion').value = eventDetails.calificacion || 0;
    $w('#advisorAnotaciones').value = eventDetails.advisorAnotaciones;
    $w('#comentarios').value = eventDetails.comentarios

}

// Realiza un query en la base de datos ADVISORS para obtener el nombre del advisor
async function queryAdvisorName(advisorId) {
    const result = await wixData.query("ADVISORS").eq("_id", advisorId).find();
    if (result.items.length > 0) {
        const advisor = result.items[0];
        return `${advisor.primerNombre} ${advisor.primerApellido}`;
    }
    return null;
}

// Carga los valores únicos del campo "step" en el dropdown de eventos
async function loadEventDropdown() {
    try {
        const results = await wixData.aggregate("CLASSES")
            .group("step")
            .run();

        const options = results.items.map(item => ({
            label: item.step || "Sin nombre",
            value: item.step
        }));

        $w("#eventoDropdown").options = options;
    } catch (error) {
        console.error("Error al cargar los eventos:", error);
    }
}

// Carga los valores correspondientes al step seleccionado en el dropdown de fechas
async function loadDateDropdown(selectedStep) {
    try {
        const now = new Date(); // Obtener la fecha y hora actual

        const results = await wixData.query("CALENDARIO")
            .eq("nombreEvento", selectedStep) // Filtrar por el step seleccionado
            .ge("dia", now) // Filtrar solo eventos posteriores o iguales al momento actual
            .ascending("dia") // Ordenar por fecha
            .find();

        const options = results.items.map(item => ({
            label: item.dia ?
                moment(item.dia).format('dddd, D MMM, hh:mm A') // Formato con día, fecha y hora
                :
                "Sin fecha",
            value: item._id // Identificador único del evento
        }));

        $w("#diaDropdown").options = options;
    } catch (error) {
        console.error("Error al cargar las fechas desde CALENDARIO:", error);
    }
}


$w("#guardarEvento").onClick(async () => {
    try {
        const selectedDateId = $w("#diaDropdown").value; // Obtener el _id del item seleccionado
        if (!selectedDateId) {
            console.warn("No se ha seleccionado una fecha válida");
            return;
        }

        // Hacer un query en CALENDARIO para obtener la información del item seleccionado
        const eventDataResult = await wixData.query("CALENDARIO")
            .eq("_id", selectedDateId) // Filtrar por el _id del item seleccionado
            .find();

        if (eventDataResult.items.length === 0) {
            console.warn("No se encontró información para el _id seleccionado:", selectedDateId);
            return;
        }

        const eventData = eventDataResult.items[0]; // Obtenemos el item correspondiente

        // Llamar a queryAcademica para obtener los datos del estudiante
        const studentData = await queryAcademica(numeroId); // `numeroId` debe estar definido previamente
        if (!studentData) {
            console.warn("No se encontró información del estudiante:", numeroId);
            return;
        }

        // Crear el nuevo registro para insertar en CLASSES
        const newItem = {
            fechaEvento: eventData.dia, // Fecha del evento desde CALENDARIO
            idEstudiante: studentData._id, // ID del estudiante
            primerNombre: studentData.primerNombre, // Nombre del estudiante
            primerApellido: studentData.primerApellido,
            nivel: eventData.tituloONivel, // Nivel del estudiante
            numeroId: studentData.idEstudiante,
            tipoEvento: eventData.evento, // Información del evento desde CALENDARIO
            step: eventData.nombreEvento,
            idEvento: eventData._id,
            advisor: eventData.advisor,
            celular: studentData.celular
        };

        

        // Inserta el nuevo registro en la base de datos CLASSES
        try {
            const result = await wixData.insert("CLASSES", newItem);
            console.log("Nuevo registro guardado en CLASSES:", result);
        } catch (error) {
            console.error("Error al guardar en CLASSES:", error);
        }

        try {
            const bookingResult = await wixData.insert("BOOKING", newItem);
            console.log("Nuevo registro guardado en BOOKING:", bookingResult);
        } catch (error) {
            console.error("Error al guardar en BOOKING:", error);
        }

        // Notificación visual de éxito
        $w("#guardarEvento").disable();
        $w("#guardarEvento").label = "Evento guardado";
    } catch (error) {
        console.error("Error al guardar el evento:", error);
    }
});

$w('#asignarButton').onClick((event) => {
    $w('#grupoAgendar').show()
    $w('#grupoInfoGeneral').hide()
})