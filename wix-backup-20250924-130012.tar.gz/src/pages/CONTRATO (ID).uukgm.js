import wixData from 'wix-data';
import { sendTextMessage, sendPdf, sendTextMessageServicioUsuario  } from 'backend/WHP';
import wixLocation from 'wix-location';



// Estado global
let appState = {
    celular: null,
    itemId: null,
    primerNombre: null,
    isForReview: false,
    isInitialized: false
};

// Configuración centralizada
const CONFIG = {
    COLLECTIONS: {
        PEOPLE: 'PEOPLE',
        FINANCIERA: 'FINANCIERA',
        TEMPLATES: 'ContractTemplates'
    },
    URLS: {
        REDIRECT: 'https://letsgospeak.cl/',
        CONTRACT_BASE: 'https://www.lgsplataforma.com/contrato/'
    },
    MESSAGES: {
        CONTRACT_READY: id => `Hola: 👋\n\n*¡Tu contrato con LetsGoSpeak está listo!* 🎉\n\nPara revisarlo sigue este enlace:\n\n${CONFIG.URLS.CONTRACT_BASE}${id}`
    }
};

// Gestor de plantillas
class TemplateManager {
    // Reemplaza la función loadTemplate en tu TemplateManager con esta versión corregida:

static async loadTemplate(platform) {
    try {
        console.log("🔍 Buscando plantilla para plataforma:", platform);

        // Primero, veamos qué plantillas están disponibles
        const allTemplates = await wixData.query(CONFIG.COLLECTIONS.TEMPLATES).find();
        console.log("📚 Todas las plantillas disponibles:", allTemplates.items.map(t => ({
            id: t._id,
            plataforma: t.Plataforma || t.plataforma, // Verificar ambas variantes
            templateLength: t.template?.length || 0,
            campos: Object.keys(t) // Ver todos los campos disponibles
        })));

        // Intentar búsqueda exacta primero
        let res = await wixData.query(CONFIG.COLLECTIONS.TEMPLATES)
            .eq('Plataforma', platform)
            .limit(1)
            .find();

        console.log("📄 Resultado de búsqueda exacta:", res);

        // Si no encuentra, intentar con minúsculas
        if (!res.items[0] && platform) {
            console.log("🔄 Intentando búsqueda con campo 'plataforma' (minúsculas)");
            res = await wixData.query(CONFIG.COLLECTIONS.TEMPLATES)
                .eq('plataforma', platform)
                .limit(1)
                .find();
        }

        // Si aún no encuentra, intentar búsqueda case-insensitive
        if (!res.items[0] && platform) {
            console.log("🔄 Intentando búsqueda case-insensitive");
            const allItems = await wixData.query(CONFIG.COLLECTIONS.TEMPLATES).find();
            const found = allItems.items.find(item => 
                (item.Plataforma && item.Plataforma.toLowerCase() === platform.toLowerCase()) ||
                (item.plataforma && item.plataforma.toLowerCase() === platform.toLowerCase())
            );
            
            if (found) {
                console.log("✅ Plantilla encontrada con búsqueda case-insensitive:", found.Plataforma || found.plataforma);
                return found.template || '';
            }
        }

        let template = res.items[0]?.template || '';

        if (!template) {
            console.warn("⚠️ No se encontró plantilla para la plataforma:", platform);
            console.log("💡 Intentando cargar plantilla por defecto...");

            // Intentar cargar cualquier plantilla disponible como fallback
            const fallbackRes = await wixData.query(CONFIG.COLLECTIONS.TEMPLATES)
                .limit(1)
                .find();

            if (fallbackRes.items[0]?.template) {
                console.log("🔄 Usando plantilla fallback de:", fallbackRes.items[0].Plataforma || fallbackRes.items[0].plataforma || 'campo desconocido');
                template = fallbackRes.items[0].template;
            } else {
                console.error("❌ No se encontró ninguna plantilla en la base de datos");
                // Retornar una plantilla básica como último recurso
                return `
CONTRATO BÁSICO
Número de contrato: {{contrato}}
Fecha: {{fecha}}

TITULAR:
Nombre: {{primerNombre}} {{segundoNombre}} {{primerApellido}} {{segundoApellido}}
Documento: {{numeroId}}
Teléfono: {{celular}}
Email: {{email}}

BENEFICIARIOS:
{{beneficiarios}}

CONDICIONES FINANCIERAS:
Total: {{totalPlan}}
Cuotas: {{numeroCuotas}} de {{valorCuota}}
Forma de pago: {{formaPago}}

{{firma}}
`;
            }
        }

        console.log("📝 Plantilla obtenida (primeros 500 caracteres):", template.substring(0, 500));
        return template;
    } catch (error) {
        console.error('❌ Error cargando plantilla:', error);
        // Retornar plantilla de emergencia
        return `Error cargando plantilla. Datos básicos:
Contrato: {{contrato}}
Titular: {{primerNombre}} {{primerApellido}}
Documento: {{numeroId}}
{{firma}}`;
    }
}

    static fillTemplate(template, data) {
        console.log("🔧 Iniciando llenado de plantilla");
        
        // Verificar que template es string
        if (typeof template !== 'string') {
            console.error("❌ Template no es string:", typeof template);
            return 'Error: Plantilla inválida';
        }
        
        // Verificar que data es objeto
        if (!data || typeof data !== 'object') {
            console.error("❌ Data no es objeto válido:", typeof data);
            return 'Error: Datos inválidos';
        }
        
        console.log("📋 Datos disponibles para llenar:", Object.keys(data));
        console.log("🎯 Valores de algunos campos clave:", {
            primerNombre: data.primerNombre,
            celular: data.celular,
            numeroId: data.numeroId
        });

        // Buscar todos los placeholders en la plantilla
        const placeholders = template.match(/\{\{(\w+)\}\}/g) || [];
        console.log("🏷️ Placeholders encontrados en plantilla:", placeholders);

        const filledTemplate = template.replace(/\{\{(\w+)\}\}/g, (match, key) => {
            let value = data[key];
            
            // Convertir a string si no lo es
            if (value === null || value === undefined) {
                value = '';
            } else if (typeof value !== 'string') {
                value = String(value);
            }
            
            console.log(`🔄 Reemplazando ${match} con: "${value}"`);
            return value;
        });

        console.log("✅ Plantilla llenada (primeros 500 caracteres):", filledTemplate.substring(0, 500));
        console.log("🔍 Tipo de plantilla llenada:", typeof filledTemplate);

        return filledTemplate;
    }

    static generateBeneficiariosText(list) {
        if (!Array.isArray(list) || list.length === 0) return '';

        return list.map((b, i) =>
            `Beneficiario ${i+1}:\n` +
            `- Número de Contrato: ${b.contrato || 'Sin asignar'}\n` + // ← NUEVO CAMPO
            `- Nombre Completo: ${b.primerNombre || ''} ${b.segundoNombre || ''} ${b.primerApellido || ''} ${b.segundoApellido || ''}\n` +
            `- Documento: ${b.numeroId || ''}\n` +
            `- Fecha de nacimiento: ${b.fechaNacimiento || ''}\n` +
            `- Teléfono: ${b.celular || ''}\n` +
            `- País: ${b.plataforma || ''}\n` +
            `- Ciudad: ${b.ciudad || ''}\n` +
            `- Domicilio: ${b.domicilio || ''}\n` +
            `- Email: ${b.email || ''}\n`
        ).join('\n');
    }
    static buildData(titular, beneficiarios, fin, ref) {
        console.log("🏗️ Construyendo datos del contrato");
        console.log("👤 Titular recibido:", titular?.primerNombre);
        console.log("👥 Beneficiarios recibidos:", beneficiarios?.length);
        
        // 🚨 DEBUG: Mostrar TODOS los campos del titular
        console.log("📋 TODOS LOS CAMPOS DEL TITULAR:");
        if (titular) {
            Object.keys(titular).forEach(key => {
                if (key.toLowerCase().includes('ref')) {
                    console.log(`  ${key}: "${titular[key]}"`);
                }
            });
        }

        // 🚨 AGREGA ESTE LOG ESPECÍFICO PARA DEBUGGEAR EL CONTRATO:
        console.log("📋 Número de contrato del titular:", titular?.contrato);
        console.log("💰 FIN completo recibido en buildData:", fin);
        console.log("💳 medioPago específico:", fin?.medioPago);
        console.log("📞 Referencias recibidas:", ref);
        
        // 🚨 DEBUG ESPECÍFICO PARA REFERENCIAS
        console.log("🔍 DEBUG REFERENCIAS:");
        console.log("  referenciaUno:", ref?.referenciaUno);
        console.log("  parentezcoRefUno:", ref?.parentezcoRefUno);
        console.log("  telefonoRefUno:", ref?.telefonoRefUno);
        console.log("  referenciaDos:", ref?.referenciaDos);
        console.log("  parentezcoRefDos:", ref?.parentezcoRefDos);
        console.log("  telefonoRefDos:", ref?.telefonoRefDos);

        const data = {
            // ← AGREGAR ESTE CAMPO AL INICIO
            contrato: titular?.contrato || 'SIN NÚMERO DE CONTRATO',

            primerNombre: titular?.primerNombre || '',
            segundoNombre: titular?.segundoNombre || '',
            primerApellido: titular?.primerApellido || '',
            segundoApellido: titular?.segundoApellido || '',
            numeroId: titular?.numeroId || '',
            fechaNacimiento: titular?.fechaNacimiento || '',
            domicilio: titular?.domicilio || '',
            ciudad: titular?.ciudad || '',
            celular: titular?.celular || '',
            email: titular?.email || '',
            ingresos: titular?.ingresos || '',
                    observaciones: titular?.observacionesContrato || '', 

            medioPago: fin?.medioPago || '',

            empresa: titular?.empresa || '',
            cargo: titular?.cargo || '',

            // ✅ NUEVO: Fecha de creación
            fecha: titular?._createdDate ? new Date(titular._createdDate).toLocaleDateString('es-CO', {
                day: '2-digit',
                month: 'long',
                year: 'numeric'
            }) : '',

            // ✅ SISTEMA DE CONSENTIMIENTO DECLARATIVO
            firma: titular?.consentimientoDeclarativo ? 
                this.generarElementoConsentimiento(titular.consentimientoDeclarativo, titular.hashConsentimiento) : 
                '<p style="border: 1px solid #ccc; padding: 20px; margin: 10px 0; text-align: center; color: #666;">Sin consentimiento</p>',

            firmaUrl: titular?.consentimientoDeclarativo || '',
            beneficiarios: this.generateBeneficiariosText(beneficiarios),
            totalPlan: fin?.totalPlan || '',
            pagoInscripcion: fin?.pagoInscripcion || '',
            saldo: fin?.saldo || '',
            numeroCuotas: fin?.numeroCuotas || '',
            valorCuota: fin?.valorCuota || '',
            formaPago: fin?.formaPago || '',
            fechaPago: fin?.fechaPago || '',
            referenciaUno: ref?.referenciaUno || '',
            parentezcoRefUno: ref?.parentezcoRefUno || '',
            telefonoRefUno: ref?.telefonoRefUno || '',
            referenciaDos: ref?.referenciaDos || '',
            parentezcoRefDos: ref?.parentezcoRefDos || '',
            telefonoRefDos: ref?.telefonoRefDos || ''
        };

        // 🚨 AGREGA ESTE LOG PARA VER EL RESULTADO:
        console.log("📊 Número de contrato en data final:", data.contrato);
        console.log("📊 Datos construidos para el contrato:", data);
        
        // 🚨 DEBUG ESPECÍFICO: Verificar referencias en data final
        console.log("🔍 REFERENCIAS EN DATA FINAL:");
        console.log("  referenciaUno:", data.referenciaUno);
        console.log("  parentezcoRefUno:", data.parentezcoRefUno);
        console.log("  telefonoRefUno:", data.telefonoRefUno);
        console.log("  referenciaDos:", data.referenciaDos);
        console.log("  parentezcoRefDos:", data.parentezcoRefDos);
        console.log("  telefonoRefDos:", data.telefonoRefDos);

        return data;
    }

    static generarElementoConsentimiento(consentimientoJSON, hash) {
        try {
            const consentimiento = JSON.parse(consentimientoJSON);
            const fecha = new Date(consentimiento.timestampAcceptacion).toLocaleString('es-CO');
            
            return `
            <div style="border: 2px solid #2196F3; padding: 15px; margin: 10px 0; background-color: #f8f9ff; border-radius: 8px;">
                <h4 style="color: #1976D2; margin: 0 0 10px 0;">✅ CONSENTIMIENTO DECLARATIVO VERIFICADO</h4>
                <p style="margin: 5px 0;"><strong>Documento:</strong> ${consentimiento.numeroDocumento}</p>
                <p style="margin: 5px 0;"><strong>Fecha:</strong> ${fecha}</p>
                <p style="margin: 5px 0;"><strong>IP:</strong> ${consentimiento.ipAddress}</p>
                <p style="margin: 5px 0;"><strong>Celular Verificado:</strong> ${consentimiento.celularValidado}</p>
                <p style="margin: 5px 0; font-size: 10px; color: #666;"><strong>Hash de Verificación:</strong> ${hash?.substring(0, 16)}...</p>
                <p style="margin: 10px 0 0 0; font-weight: bold; color: #1976D2;">
                    ✅ Declaración aceptada con validación biométrica por WhatsApp
                </p>
            </div>`;
        } catch (error) {
            console.error('Error generando elemento de consentimiento:', error);
            return '<p style="color: red;">Error procesando consentimiento</p>';
        }
    }

    static async generateContractText(titular, beneficiarios, fin, ref) {
        try {
            console.log("🎭 Generando texto del contrato");
            console.log("🏢 Plataforma del titular:", titular?.plataforma);

            // 🚨 AGREGA ESTOS LOGS:
            console.log("💰 FIN recibido en generateContractText:", fin);
            console.log("💳 medioPago en generateContractText:", fin?.medioPago);

            const tpl = await this.loadTemplate(titular?.plataforma || '');

            if (!tpl) {
                console.warn("⚠️ No se obtuvo plantilla, usando plantilla por defecto");
                return `
CONTRATO DE SERVICIOS EDUCATIVOS

Número de contrato: ${titular?.contrato || 'SIN NÚMERO'}
Fecha: ${new Date().toLocaleDateString('es-CO')}

TITULAR:
Nombre: ${titular?.primerNombre || ''} ${titular?.segundoNombre || ''} ${titular?.primerApellido || ''} ${titular?.segundoApellido || ''}
Documento: ${titular?.numeroId || ''}
Teléfono: ${titular?.celular || ''}
Email: ${titular?.email || ''}

CONDICIONES FINANCIERAS:
Total: ${fin?.totalPlan || ''}
Cuotas: ${fin?.numeroCuotas || ''} de ${fin?.valorCuota || ''}
Forma de pago: ${fin?.formaPago || ''}

CONSENTIMIENTO:
${titular?.consentimientoDeclarativo ? 
    'Contrato aceptado mediante consentimiento declarativo verificado' : 
    'Pendiente de firma/consentimiento'}
                `.trim();
            }

            const data = this.buildData(titular, beneficiarios, fin, ref);
            console.log("💡 DEBUG DATOS FINALES PARA PLANTILLA:", data);
            const result = this.fillTemplate(tpl, data);

            console.log("✅ Texto del contrato generado exitosamente");
            console.log("🔍 Tipo de resultado:", typeof result);
            console.log("📄 Primeros 200 caracteres del resultado:", result?.substring(0, 200));
            
            // Asegurar que el resultado es string
            if (typeof result === 'string') {
                return result;
            } else {
                console.error("❌ El resultado no es string, convirtiendo...");
                return String(result || 'Error: contenido vacío');
            }
        } catch (error) {
            console.error('❌ Error generando texto del contrato:', error);
            return `ERROR AL GENERAR CONTRATO:
            
Hubo un problema técnico al generar el contrato.
Error: ${error.message || 'Error desconocido'}

Por favor contacte al administrador.`;
        }
    }
}

// Campos del contrato centralizados
// ========== CORRECCIONES PRINCIPALES ==========

// 1. AGREGAR el campo 'contrato' a CAMPOS_CONTRATO (si quieres que sea editable)
const CAMPOS_CONTRATO = [
    { campo: 'contrato', label: 'Número de Contrato', tipo: 'readonly' }, // ← NUEVO CAMPO (readonly para que no se pueda editar)
    { campo: 'primerNombre', label: 'Primer Nombre' },
    { campo: 'segundoNombre', label: 'Segundo Nombre' },
    { campo: 'primerApellido', label: 'Primer Apellido' },
    { campo: 'segundoApellido', label: 'Segundo Apellido' },
    { campo: 'numeroId', label: 'Número de ID' },
    { campo: 'fechaNacimiento', label: 'Fecha de Nacimiento' },
    { campo: 'edad', label: 'Edad' },
    {
        campo: 'plataforma',
        label: 'Plataforma',
        tipo: 'drop',
        opciones: ['Perú', 'Mosaico', 'Internacional', 'Ecuador', 'Colombia', 'Chile']
    },
    { campo: 'domicilio', label: 'Domicilio' },
    { campo: 'ciudad', label: 'Ciudad' },
    { campo: 'celular', label: 'Celular' },
    { campo: 'ingresos', label: 'Ingresos' },
    { campo: 'medioPago', label: 'Medio de Pago' },
    { campo: 'email', label: 'Email' },
    { campo: 'empresa', label: 'Empresa' },
    { campo: 'cargo', label: 'Cargo' },
    { campo: 'genero', label: 'Género' },
    { campo: 'tipoUsuario', label: 'Tipo de Usuario' },
    { campo: 'telefono', label: 'Teléfono' },
    { campo: 'referenciaUno', label: 'Referencia 1' },
    { campo: 'parentezcoRefUno', label: 'Parentesco Ref 1' },
    { campo: 'telefonoRefUno', label: 'Teléfono Ref 1' },
    { campo: 'referenciaDos', label: 'Referencia 2' },
    { campo: 'telefonoRefDos', label: 'Teléfono Ref 2' },
    { campo: 'parentezcoRefDos', label: 'Parentesco Ref 2' },
    { campo: 'vigencia', label: 'Vigencia' },
    { campo: 'observacionesContrato', label: 'Observaciones del Contrato', soloTitular: true }
];

// Clase para manejar la UI
class UIManager {
    static showLoading() {
        try {
            $w('#loading').show();
        } catch (error) {
            console.error('Error mostrando loading:', error);
        }
    }

    static hideLoading() {
        try {
            $w('#loading').hide();
        } catch (error) {
            console.error('Error ocultando loading:', error);
        }
    }

    static updateButtonLabel(buttonId, label) {
        try {
            const element = $w(buttonId);
            if (element) {
                element.label = label;
                console.log(`✅ Botón ${buttonId} actualizado a: ${label}`);
            } else {
                console.error(`❌ Elemento ${buttonId} no encontrado`);
            }
        } catch (error) {
            console.error(`❌ Error actualizando botón ${buttonId}:`, error);
        }
    }

    static toggleButtons(forReview) {
        try {
            if (forReview) {
                // Modo revisión: mostrar botones del asesor
                $w('#guardar').hide();
                $w('#enviar').show();
                $w('#botonesAsesor').show();
                $w('#botonesAsesor').expand();
            } else {
                // Modo normal: ocultar botones del asesor
                $w('#guardar').show();
                $w('#enviar').hide();
                $w('#botonesAsesor').hide();
                $w('#botonesAsesor').collapse();
            }
        } catch (error) {
            console.error('Error configurando botones:', error);
        }
    }

    static disableSignatureElements() {
        try {
            $w('#guardar').disable();
        } catch (error) {
            console.error('Error deshabilitando elementos de firma:', error);
        }
    }

    static expandEditBox() {
        try {
            $w('#edicionBox').expand();
        } catch (error) {
            console.error('Error expandiendo caja de edición:', error);
        }
    }

    static collapseEditBox() {
        try {
            $w('#edicionBox').collapse();
        } catch (error) {
            console.error('Error colapsando caja de edición:', error);
        }
    }
}

// Sistema de Consentimiento Declarativo
class ConsentimientoManager {
    static generarCodigoOTP() {
        return Math.floor(100000 + Math.random() * 900000).toString();
    }

    static async obtenerIP() {
        try {
            const response = await fetch('https://api.ipify.org?format=json');
            const data = await response.json();
            return data.ip;
        } catch (error) {
            console.error('Error obteniendo IP:', error);
            return 'IP_NO_DISPONIBLE';
        }
    }

    static async generarHashConsentimiento(consentimiento) {
        const mensaje = JSON.stringify(consentimiento);
        const encoder = new TextEncoder();
        const data = encoder.encode(mensaje);
        const hashBuffer = await crypto.subtle.digest('SHA-256', data);
        const hashArray = Array.from(new Uint8Array(hashBuffer));
        return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
    }

    static async enviarCodigoOTP(celular, codigo) {
        try {
            const mensaje = `🔐 Código de verificación LetsGoSpeak: ${codigo}\n\nEste código confirma la aceptación de tu contrato. No lo compartas con nadie.`;
            return await sendTextMessageServicioUsuario(celular, mensaje);
        } catch (error) {
            console.error('Error enviando OTP:', error);
            throw error;
        }
    }

    static validarFormulario() {
        const numeroDocumento = $w('#inputDocumento').value?.trim();
        const declaracionAceptada = $w('#checkboxDeclaracion').checked;
        const codigoOTP = $w('#inputOTP').value?.trim();

        if (!numeroDocumento) {
            throw new Error('Debe ingresar su número de documento');
        }
        if (!declaracionAceptada) {
            throw new Error('Debe aceptar la declaración legal');
        }
        if (!codigoOTP) {
            throw new Error('Debe ingresar el código de verificación');
        }
        if (codigoOTP.length !== 6) {
            throw new Error('El código debe tener 6 dígitos');
        }

        return { numeroDocumento, declaracionAceptada, codigoOTP };
    }
}

// Estado para el sistema OTP
let otpState = {
    codigoGenerado: null,
    codigoEnviado: false,
    numeroDocumentoValidado: false,
    timestampEnvio: null
};

// Función para configurar UI basada en consentimiento
function configureUIBasedOnConsent(hasConsent) {
    try {
        if (hasConsent) {
            // Cuando YA hay consentimiento:
            $w('#consentimientoBox').collapse();
            $w('#guardar').disable();
            console.log("✅ UI configurada: Consentimiento existe - formulario oculto");
        } else {
            // Cuando NO hay consentimiento:
            $w('#consentimientoBox').expand();
            
            // Estado inicial: solo mostrar campo de documento y botón
            $w('#inputDocumento').show();
            $w('#enviarOTP').show();
            
            // Ocultar elementos que aparecen después del OTP
            try {
                $w('#inputOTP').hide();
                $w('#checkboxDeclaracion').hide();
                $w('#mensajeOTP').hide();
            } catch (e) {
                console.log('Algunos elementos OTP no encontrados:', e);
            }
            
            $w('#guardar').enable();
            UIManager.updateButtonLabel('#guardar', "COMPLETAR FORMULARIO");
            console.log("✅ UI configurada: Sin consentimiento - formulario visible");
        }
    } catch (error) {
        console.error('Error configurando UI basada en consentimiento:', error);
    }
}

// Clase para manejar consultas de datos
class DataManager {
    static async getTitularAndBeneficiarios(itemId) {
        try {
            console.log("🔍 Obteniendo titular y beneficiarios para itemId:", itemId);

            const [titularResult, beneficiariosResult] = await Promise.all([
                wixData.get(CONFIG.COLLECTIONS.PEOPLE, itemId),
                wixData.query(CONFIG.COLLECTIONS.PEOPLE)
                .eq("titularId", itemId) // 🔧 CORREGIDO: era "titularId"
                .find()
            ]);

            console.log("👤 Titular obtenido:", {
                id: titularResult._id,
                nombre: titularResult.primerNombre,
                apellido: titularResult.primerApellido,
                plataforma: titularResult.plataforma,
                celular: titularResult.celular,
                email: titularResult.email
            });

            console.log("👥 Beneficiarios obtenidos:", beneficiariosResult.items.map(b => ({
                id: b._id,
                nombre: b.primerNombre,
                apellido: b.primerApellido,
                titularId: b.titularId
            })));

            return {
                titular: titularResult,
                beneficiarios: beneficiariosResult.items || []
            };
        } catch (error) {
            console.error('❌ Error obteniendo titular y beneficiarios:', error);
            throw error;
        }
    }

    static async getFinancialData(itemId) {
        try {
            console.log("💰 Obteniendo datos financieros para itemId:", itemId);
            const result = await wixData.query(CONFIG.COLLECTIONS.FINANCIERA)
                .eq('titularId', itemId) // 🔧 CORREGIDO: era "titularId"
                .find();

            const financialData = result.items[0] || null;
            console.log("💰 Datos financieros obtenidos:", financialData ? {
                totalPlan: financialData.totalPlan,
                valorCuota: financialData.valorCuota,
                numeroCuotas: financialData.numeroCuotas,
                titularId: financialData.titularId
            } : "Sin datos financieros");

            return financialData;
        } catch (error) {
            console.error('❌ Error obteniendo datos financieros:', error);
            return null;
        }
    }

    static async getPersonByNumeroId(numeroId) {
        try {
            const result = await wixData.query(CONFIG.COLLECTIONS.PEOPLE)
                .eq("numeroId", numeroId)
                .find();

            return result.items[0] || null;
        } catch (error) {
            console.error('Error obteniendo persona por número ID:', error);
            return null;
        }
    }

    static async getBeneficiarios(itemId) {
        try {
            const result = await wixData.query(CONFIG.COLLECTIONS.PEOPLE)
                .eq('titularId', itemId)
                .eq("tipoUsuario", "BENEFICIARIO")
                .find();
            console.log("BENEFICIARITOS", result)

            return result.items || [];
        } catch (error) {
            console.error('Error obteniendo beneficiarios:', error);
            return [];
        }
    }

    static async updatePerson(itemId, data) {
        try {
            const original = await wixData.get(CONFIG.COLLECTIONS.PEOPLE, itemId);
            const updated = { ...original, ...data };
            return await wixData.update(CONFIG.COLLECTIONS.PEOPLE, updated);
        } catch (error) {
            console.error('Error actualizando persona:', error);
            throw error;
        }
    }
}

async function debugTitularFields(itemId) {
    try {
        console.log("🔍 DEBUGGING: Verificando todos los campos del titular");

        const titular = await wixData.get(CONFIG.COLLECTIONS.PEOPLE, itemId);

        console.log("📋 TODOS LOS CAMPOS del titular:");
        console.log("Campos disponibles:", Object.keys(titular));

        // Verificar campos específicos que están faltando
        const camposBuscados = ['fechaNacimiento', 'domicilio', 'ciudad', 'ingresos', 'empresa', 'cargo'];

        console.log("🔎 Verificando campos específicos:");
        camposBuscados.forEach(campo => {
            const valor = titular[campo];
            console.log(`  ${campo}: ${valor !== undefined ? `"${valor}"` : 'NO EXISTE'} (tipo: ${typeof valor})`);
        });

        // Buscar campos similares (en caso de que tengan nombres ligeramente diferentes)
        console.log("🔍 Buscando campos similares:");
        const todosCampos = Object.keys(titular);

        camposBuscados.forEach(campoBuscado => {
            const similares = todosCampos.filter(campo =>
                campo.toLowerCase().includes(campoBuscado.toLowerCase()) ||
                campoBuscado.toLowerCase().includes(campo.toLowerCase())
            );

            if (similares.length > 0) {
                console.log(`  Campos similares a "${campoBuscado}":`, similares);
                similares.forEach(similar => {
                    console.log(`    ${similar}: "${titular[similar]}"`);
                });
            }
        });

        // Mostrar el objeto completo para revisión manual
        console.log("📄 OBJETO TITULAR COMPLETO:", titular);

        return titular;
    } catch (error) {
        console.error("❌ Error en debug:", error);
    }
}

// Inicialización optimizada y centralizada
$w.onReady(async function () {
    console.log("🚀 Iniciando aplicación...");

    try {

         await debugTemplates();
        // Prevenir inicialización múltiple
        if (appState.isInitialized) {
            console.log("⚠️ Aplicación ya inicializada, saltando...");
            return;
        }

        // Configurar estado inicial
        appState.isForReview = 'forReview' in wixLocation.query;
        UIManager.toggleButtons(appState.isForReview);

        // Obtener datos del dataset
        const item = $w('#dynamicDataset').getCurrentItem();
        if (!item || !item._id) {
            throw new Error('No se pudo obtener el item del dataset');
        }

        appState.itemId = item._id;
        console.log("📋 Item ID obtenido:", appState.itemId);

        await debugTitularFields(appState.itemId);
        // Configurar UI basada en consentimiento (solo si NO estamos en modo revisión)
        if (!appState.isForReview) {
            configureUIBasedOnConsent(item.consentimientoDeclarativo?.trim());
        }

        console.log("📡 Iniciando carga de datos en paralelo...");
        console.log("🔍 Buscando beneficiarios con titularId =", appState.itemId);
        console.log("🔍 Buscando datos financieros con titularId =", appState.itemId);

        const [{ titular, beneficiarios }, fin] = await Promise.all([
            DataManager.getTitularAndBeneficiarios(appState.itemId),
            DataManager.getFinancialData(appState.itemId),
        ]);

        console.log("👤 Datos del titular cargados:", titular);
        console.log("👥 Beneficiarios cargados:", beneficiarios?.length || 0, "registros");
        console.log("💰 Datos financieros cargados:", fin ? "✅ Sí" : "❌ No");

        // Mostrar detalles de los beneficiarios encontrados
        if (beneficiarios && beneficiarios.length > 0) {
            console.log("📋 Detalles de beneficiarios:");
            beneficiarios.forEach((ben, index) => {
                console.log(`   ${index + 1}. ${ben.primerNombre} ${ben.primerApellido} (titularId: ${ben.titularId})`);
            });
        } else {
            console.warn("⚠️ No se encontraron beneficiarios para el titular:", appState.itemId);
        }

        // Actualizar estado global
        appState.celular = titular?.celular || null;
        appState.primerNombre = titular?.primerNombre || null;

        console.log("📞 Celular guardado:", appState.celular);
        console.log("👤 Primer nombre guardado:", appState.primerNombre);

        // Verificar que tenemos datos básicos
        if (!titular) {
            throw new Error("No se pudieron cargar los datos del titular");
        }

        // Generar y mostrar contrato
        console.log("📝 Iniciando generación del contrato...");
        const contractText = await TemplateManager.generateContractText(
            titular,
            beneficiarios,
            fin, {
                referenciaUno: titular?.referenciaUno,
                parentezcoRefUno: titular?.parentezcoRefUno,
                telefonoRefUno: titular?.telefonoRefUno,
                referenciaDos: titular?.referenciaDos,
                parentezcoRefDos: titular?.parentezcoRefDos,
                telefonoRefDos: titular?.telefonoRefDos
            }
        );

        // Verificar que contractText es string antes de enviarlo
        if (typeof contractText === 'string') {
            $w('#text1').postMessage(contractText);
            console.log("✅ Contrato mostrado en la UI");
        } else {
            console.error("❌ contractText no es string:", typeof contractText, contractText);
            $w('#text1').postMessage("Error: El contrato no se pudo generar correctamente");
        }

        // Marcar como inicializado
        appState.isInitialized = true;
        console.log("✅ Aplicación inicializada correctamente");

    } catch (error) {
        console.error("❌ Error en la inicialización:", error);
        // Mostrar error en la UI - asegurar que sea string
        const errorMessage = typeof error.message === 'string' ? error.message : 'Error desconocido en la inicialización';
        $w('#text1').postMessage(errorMessage);
    }

    await debugFirma(appState.itemId);
});

// Nueva función para recargar todos los datos del contrato
async function reloadAllContractData() {
    try {
        console.log("🔄 Recargando todos los datos del contrato...");

        // Regenerar el contrato con datos actualizados
        console.log("🔍 Recargando con titularId =", appState.itemId);
        const [{ titular, beneficiarios }, fin] = await Promise.all([
            DataManager.getTitularAndBeneficiarios(appState.itemId),
            DataManager.getFinancialData(appState.itemId)
        ]);

        console.log("📊 Datos recargados - Beneficiarios:", beneficiarios?.length || 0);
        console.log("💰 Datos financieros recargados:", fin ? "✅ Sí" : "❌ No");

        const contractText = await TemplateManager.generateContractText(
            titular, beneficiarios, fin, {
                referenciaUno: titular?.referenciaUno,
                parentezcoRefUno: titular?.parentezcoRefUno,
                telefonoRefUno: titular?.telefonoRefUno,
                referenciaDos: titular?.referenciaDos,
                parentezcoRefDos: titular?.parentezcoRefDos,
                telefonoRefDos: titular?.telefonoRefDos
            }
        );

        // Verificar que contractText es string antes de enviarlo
        if (typeof contractText === 'string') {
            $w('#text1').postMessage(contractText);
        } else {
            console.error("❌ Error en reloadAllContractData - contractText no es string:", typeof contractText);
            $w('#text1').postMessage("Error: No se pudo recargar el contrato");
        }

        console.log("✅ Todos los datos del contrato recargados");
    } catch (error) {
        console.error("Error recargando datos del contrato:", error);
        throw error;
    }
}

// Manejo de edición de contrato optimizado
$w("#abrirCorregirContrato").onClick(async () => {
    try {
        UIManager.expandEditBox();

        const { titular, beneficiarios } = await DataManager.getTitularAndBeneficiarios(appState.itemId);

        // Construir datos para el repeater
        const datosTitular = buildRepeaterData(titular, 'TITULAR', 'titular');
        const datosBeneficiarios = beneficiarios.flatMap((beneficiario, index) =>
            buildRepeaterData(beneficiario, 'BENEFICIARIO', `bene${index + 1}`, `(Beneficiario ${index + 1})`)
        );

        const todosLosDatos = [
            ...datosTitular,
            ...datosBeneficiarios,
            // <<<< Agrega observaciones como un ítem aparte al final
            {
                campo: 'observacionesContrato',
                label: 'Observaciones del Contrato',
                valor: titular.observacionesContrato || '',
                _id: `observacionesContrato-unico`,
                tipoUsuario: 'OBSERVACION_CONTRATO',
                itemId: titular._id,
                labelCustom: 'Observaciones del Contrato'
            }
        ];
        $w("#repeaterContrato").data = todosLosDatos;

        // Configurar repeater
        setupRepeater();

    } catch (error) {
        console.error("Error al abrir edición:", error);
    }
});

function buildRepeaterData(item, tipoUsuario, prefix, suffix = '') {
    if (!item) return [];

    // Saca por completo el campo 'observacionesContrato' aquí
    let fields = CAMPOS_CONTRATO
        .filter(campo =>
            // Si es beneficiario, excluye los campos soloTitular
            !campo.soloTitular || tipoUsuario === 'TITULAR'
        )
        .filter(campo =>
            campo.campo !== 'observacionesContrato' // <-- Este filtro SÍ o SÍ
        )
        .map((campo, index) => ({
            ...campo,
            valor: item[campo.campo] || '',
            _id: `${campo.campo}-${prefix}-${index}`,
            tipoUsuario,
            itemId: item._id,
            label: `${campo.label} ${suffix}`
        }));

    // **YA NO agregues el campo observaciones al final aquí**
    return fields;
}

function setupRepeater() {
    $w("#repeaterContrato").onItemReady(($item, itemData) => {
        try {
            $item("#etiquetaCampo").text = itemData.label;

            if (itemData.tipo === 'drop') {
                // Campo dropdown
                $item("#campoInput").collapse();
                $item("#campoDropdown").expand();
                $item("#campoDropdown").options = itemData.opciones.map(op => ({ label: op, value: op }));
                $item("#campoDropdown").value = itemData.valor;

            } else if (itemData.tipo === 'readonly') {
                // ✅ NUEVO: Campo de solo lectura (para firma)
                $item("#campoDropdown").collapse();
                $item("#campoInput").expand();
                $item("#campoInput").value = itemData.valor;
                $item("#campoInput").disable(); // Deshabilitar edición

                // Agregar texto explicativo si es el campo firma
                if (itemData.campo === 'firma') {
                    $item("#etiquetaCampo").text = itemData.label + " (Solo lectura)";
                }

            } else {
                // Campo de texto normal
                $item("#campoDropdown").collapse();
                $item("#campoInput").expand();
                $item("#campoInput").value = itemData.valor;
                $item("#campoInput").enable(); // Asegurar que esté habilitado
            }
        } catch (error) {
            console.error('Error configurando item del repeater:', error);
        }
    });
}

// Guardar edición optimizado
$w('#guardarEdicionButt').onClick(async () => {
    try {
        UIManager.showLoading();
        UIManager.updateButtonLabel('#guardarEdicionButt', "Guardando...");

        const cambiosPorItem = collectChanges();
        await saveChanges(cambiosPorItem);

        // Recargar todos los datos del contrato para reflejar los cambios
        await reloadAllContractData();

        UIManager.updateButtonLabel('#guardarEdicionButt', "DATOS GUARDADOS ✅");

        // Cerrar automáticamente después de 2 segundos
        setTimeout(() => {
            UIManager.collapseEditBox();
            UIManager.updateButtonLabel('#guardarEdicionButt', "GUARDAR DATOS");
        }, 2000);

    } catch (error) {
        console.error("Error al guardar:", error);
        UIManager.updateButtonLabel('#guardarEdicionButt', "ERROR AL GUARDAR ❌");

        // Resetear botón después de 3 segundos
        setTimeout(() => {
            UIManager.updateButtonLabel('#guardarEdicionButt', "GUARDAR DATOS");
        }, 3000);
    } finally {
        UIManager.hideLoading();
    }
});

function collectChanges() {
    const cambiosPorItem = {};

    try {
        $w("#repeaterContrato").forEachItem(($item, itemData) => {
            const { campo, itemId, tipo } = itemData;

            // ✅ IGNORAR campos readonly (como firma)
            if (tipo === 'readonly') {
                console.log(`🔒 Campo readonly ignorado: ${campo}`);
                return; // Saltar este campo
            }

            const valor = tipo === 'drop' ?
                $item("#campoDropdown").value :
                $item("#campoInput").value;

            if (!cambiosPorItem[itemId]) {
                cambiosPorItem[itemId] = {};
            }

            cambiosPorItem[itemId][campo] = valor;
        });
    } catch (error) {
        console.error('Error recolectando cambios:', error);
    }

    console.log("📝 Cambios recolectados (sin campos readonly):", cambiosPorItem);
    return cambiosPorItem;
}

async function saveChanges(cambiosPorItem) {
    try {
        const updatePromises = Object.entries(cambiosPorItem).map(([itemId, changes]) =>
            DataManager.updatePerson(itemId, changes)
        );

        await Promise.all(updatePromises);
        console.log("✅ Todos los datos actualizados correctamente");
    } catch (error) {
        console.error("Error guardando cambios:", error);
        throw error;
    }
}

// Manejo del nuevo sistema de consentimiento declarativo
async function procesarConsentimientoDeclarativo(itemId) {
    try {
        UIManager.updateButtonLabel('#guardar', "Procesando...");
        
        // 1. Validar formulario
        const { numeroDocumento, declaracionAceptada, codigoOTP } = ConsentimientoManager.validarFormulario();
        
        // 2. Verificar código OTP
        if (codigoOTP !== otpState.codigoGenerado) {
            throw new Error('Código de verificación incorrecto');
        }
        
        // 3. Verificar que no haya expirado (10 minutos)
        const tiempoTranscurrido = Date.now() - otpState.timestampEnvio;
        if (tiempoTranscurrido > 10 * 60 * 1000) {
            throw new Error('El código ha expirado. Solicite uno nuevo.');
        }

        UIManager.showLoading();

        // 4. Crear objeto de consentimiento
        const consentimiento = {
            declaracionAceptada: true,
            numeroDocumento: numeroDocumento,
            timestampAcceptacion: new Date().toISOString(),
            ipAddress: await ConsentimientoManager.obtenerIP(),
            userAgent: navigator.userAgent,
            codigoOTPUtilizado: codigoOTP,
            celularValidado: appState.celular
        };

        // 5. Generar hash inmutable
        const hashConsentimiento = await ConsentimientoManager.generarHashConsentimiento(consentimiento);

        // 6. Guardar en base de datos
        const now = new Date();
        await DataManager.updatePerson(itemId, {
            consentimientoDeclarativo: JSON.stringify(consentimiento),
            hashConsentimiento: hashConsentimiento,
            inicioContrato: now,
            numeroDocumentoVerificado: numeroDocumento
        });

        // 7. Actualizar UI
        configureUIBasedOnConsent(true);
        UIManager.updateButtonLabel('#guardar', "Espera...");

        // 8. Generar PDF en paralelo
        generatePDF(itemId).catch(err => {
            console.error("❌ Error generando PDF:", err);
        });

        console.log("✅ Consentimiento declarativo procesado exitosamente");

    } catch (error) {
        console.error("Error procesando consentimiento:", error);
        UIManager.updateButtonLabel('#guardar', error.message);
        
        // Resetear botón después de 3 segundos
        setTimeout(() => {
            UIManager.updateButtonLabel('#guardar', "PROCESAR CONSENTIMIENTO");
        }, 3000);
    }
}

// Función para generar PDF
// Reemplaza la función generatePDF en Wix con esta versión:

async function generatePDF(itemId) {
    try {
        console.log("🚀 Iniciando generación de PDF para Drive...");
        
        // URL correcta del contrato usando el itemId
        const urlContrato = `${CONFIG.URLS.CONTRACT_BASE}${itemId}`;
        console.log("🔗 URL del contrato para PDF:", urlContrato);

        const apiEndpoint = "https://v2018.api2pdf.com/chrome/url";
        const apiKey = "9450b12a-4c5f-4e8e-a605-2b61fe4807f2";

        console.log("📡 Generando PDF con API2PDF...");

        // ✅ USAR LAS MISMAS OPCIONES QUE enviarPDF
        const pdfResponse = await fetch(apiEndpoint, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': apiKey
            },
            body: JSON.stringify({
                url: urlContrato,
                options: {
                    printBackground: true,
                    delay: 10000,
                    scale: 0.75
                }
            })
        });

        if (!pdfResponse.ok) {
            throw new Error(`HTTP error! status: ${pdfResponse.status}`);
        }

        const pdfData = await pdfResponse.json();
        
        if (!pdfData.success) {
            throw new Error(`API2PDF falló: ${pdfData.error || 'Error desconocido'}`);
        }

        const pdfUrl = pdfData.pdf;
        console.log("📄 PDF generado, URL:", pdfUrl);

        // ✅ AHORA SÍ LLAMAR A TU BACKEND PARA SUBIR A DRIVE
        const uploadResponse = await fetch("https://bsl-utilidades-yp78a.ondigitalocean.app/subir-pdf-directo", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                pdfUrl: pdfUrl,
                documento: itemId,
                empresa: "LGS"
            })
        });

        if (!uploadResponse.ok) {
            throw new Error(`Error subiendo PDF: ${uploadResponse.status}`);
        }

        const uploadData = await uploadResponse.json();
        console.log("✅ PDF subido a Drive exitosamente:", uploadData);
                UIManager.hideLoading();

        wixLocation.to("https://letsgospeak.cl/");
        return uploadData;

    } catch (error) {
        console.error("❌ Error en generatePDF:", error);
        throw error;
    }
}

// Manejo de WhatsApp optimizado
async function enviarWhatsApp() {
    try {
        if (!appState.celular) {
            UIManager.updateButtonLabel('#enviar', "SIN NÚMERO DE CELULAR");
            return;
        }

        if (!appState.itemId) {
            UIManager.updateButtonLabel('#enviar', "SIN ID DE CONTRATO");
            return;
        }

        UIManager.showLoading();
        UIManager.updateButtonLabel('#enviar', "Enviando...");

        const message = CONFIG.MESSAGES.CONTRACT_READY(appState.itemId);
        const response = await sendTextMessageServicioUsuario(appState.celular, message);

        UIManager.updateButtonLabel('#enviar', "MENSAJE ENVIADO ✅");
        console.log("Mensaje enviado con éxito", response);

    } catch (error) {
        console.error("Error al enviar mensaje", error);
        UIManager.updateButtonLabel('#enviar', "ERROR AL ENVIAR");
    } finally {
        UIManager.hideLoading();
    }
}

// Event handlers
$w('#cerrarEditarContrato').onClick(() => {
    UIManager.collapseEditBox();
});

// Evento para enviar/reenviar código OTP
$w('#enviarOTP').onClick(async () => {
    try {
        if (!appState.celular) {
            UIManager.updateButtonLabel('#enviarOTP', "SIN CELULAR");
            return;
        }

        const numeroDocumento = $w('#inputDocumento').value?.trim();
        if (!numeroDocumento) {
            UIManager.updateButtonLabel('#enviarOTP', "INGRESE DOCUMENTO");
            return;
        }

        const isReenvio = otpState.codigoEnviado;
        UIManager.updateButtonLabel('#enviarOTP', isReenvio ? "Reenviando..." : "Enviando...");
        
        // Generar nuevo código (tanto para envío inicial como reenvío)
        otpState.codigoGenerado = ConsentimientoManager.generarCodigoOTP();
        otpState.timestampEnvio = Date.now();
        
        // Enviar código por WhatsApp
        await ConsentimientoManager.enviarCodigoOTP(appState.celular, otpState.codigoGenerado);
        
        otpState.codigoEnviado = true;
        otpState.numeroDocumentoValidado = true;
        
        // Habilitar campo OTP y mostrar instrucciones
        $w('#inputOTP').enable();
        $w('#inputOTP').show();
        $w('#inputOTP').placeholder = "Ingrese código de 6 dígitos";
        
        // Mostrar mensaje de instrucciones
        $w('#mensajeOTP').show();
        const mensajeTexto = isReenvio ? 
            `📱 Nuevo código reenviado a ${appState.celular}. Revise su WhatsApp.` :
            `📱 Código enviado a ${appState.celular}. Revise su WhatsApp e ingrese el código de 6 dígitos.`;
        $w('#mensajeOTP').text = mensajeTexto;
        
        // Mostrar checkbox de declaración (solo la primera vez)
        if (!isReenvio) {
            $w('#checkboxDeclaracion').show();
            UIManager.updateButtonLabel('#guardar', "PROCESAR CONSENTIMIENTO");
        }
        
        // Cambiar botón para permitir reenvío
        UIManager.updateButtonLabel('#enviarOTP', "REENVIAR CÓDIGO");
        $w('#enviarOTP').disable();
        
        // Permitir reenvío después de 30 segundos
        setTimeout(() => {
            $w('#enviarOTP').enable();
        }, 30000);
        
    } catch (error) {
        console.error('Error enviando OTP:', error);
        UIManager.updateButtonLabel('#enviarOTP', "ERROR AL ENVIAR");
        
        // Resetear botón en caso de error
        setTimeout(() => {
            $w('#enviarOTP').enable();
            UIManager.updateButtonLabel('#enviarOTP', "SOLICITAR CÓDIGO");
        }, 3000);
    }
});

$w('#guardar').onClick(() => {
    if (!appState.itemId) {
        console.error("No hay itemId disponible");
        return;
    }
    procesarConsentimientoDeclarativo(appState.itemId);
});

$w('#enviar').onClick(() => {
    enviarWhatsApp();
});

// Event handler para aprobación automática
$w('#aprobacionAutomatica').onClick(async () => {
    try {
        if (!appState.itemId) {
            console.error("No hay itemId disponible");
            return;
        }
        
        UIManager.updateButtonLabel('#aprobacionAutomatica', "Procesando...");
        UIManager.showLoading();

        // Crear objeto de consentimiento automático
        const consentimiento = {
            declaracionAceptada: true,
            numeroDocumento: appState.itemId, // Usar el ID como documento
            timestampAcceptacion: new Date().toISOString(),
            ipAddress: await ConsentimientoManager.obtenerIP(),
            userAgent: navigator.userAgent,
            codigoOTPUtilizado: 'AUTOMATICO',
            celularValidado: appState.celular,
            tipoAprobacion: 'AUTOMATICA'
        };

        // Generar hash inmutable
        const hashConsentimiento = await ConsentimientoManager.generarHashConsentimiento(consentimiento);

        // Guardar en base de datos
        const now = new Date();
        await DataManager.updatePerson(appState.itemId, {
            consentimientoDeclarativo: JSON.stringify(consentimiento),
            hashConsentimiento: hashConsentimiento,
            inicioContrato: now,
            numeroDocumentoVerificado: appState.itemId
        });

        // Actualizar UI
        configureUIBasedOnConsent(true);
        UIManager.updateButtonLabel('#aprobacionAutomatica', "Generando PDF...");

        // Generar PDF automáticamente
        await generatePDF(appState.itemId);

        console.log("✅ Consentimiento automático procesado exitosamente");
        
    } catch (error) {
        console.error("Error en aprobación automática:", error);
        UIManager.updateButtonLabel('#aprobacionAutomatica', "ERROR");
        
        setTimeout(() => {
            UIManager.updateButtonLabel('#aprobacionAutomatica', "APROBACIÓN AUTOMÁTICA");
        }, 3000);
    } finally {
        UIManager.hideLoading();
    }
});

$w('#enviarPDF').onClick(async () => {
    console.log("🚀 Iniciando envío de PDF...");

    try {
        // Verificar que tenemos los datos necesarios
        if (!appState.itemId) {
            throw new Error("No se encontró itemId en appState");
        }

        if (!appState.celular) {
            throw new Error("No se encontró número de celular en appState");
        }

        console.log("📋 Datos verificados:", {
            itemId: appState.itemId,
            celular: appState.celular
        });

        UIManager.showLoading();
        UIManager.updateButtonLabel('#enviarPDF', "Generando PDF...");
        console.log("⏳ Loading mostrado");

        // URL correcta del contrato usando el itemId del estado global
        const urlContrato = `${CONFIG.URLS.CONTRACT_BASE}${appState.itemId}`;
        console.log("🔗 URL del contrato generada:", urlContrato);

        const apiEndpoint = "https://v2018.api2pdf.com/chrome/url";
        const apiKey = "9450b12a-4c5f-4e8e-a605-2b61fe4807f2";

        console.log("📡 Enviando solicitud a API2PDF...");

        // Generar PDF del contrato
        const pdfResponse = await fetch(apiEndpoint, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': apiKey
            },
            body: JSON.stringify({
                url: urlContrato,
                options: {
                    printBackground: true,
                    delay: 10000,
                    scale: 0.75
                }
            })
        });

        console.log("📥 Respuesta recibida de API2PDF:", {
            status: pdfResponse.status,
            statusText: pdfResponse.statusText,
            ok: pdfResponse.ok
        });

        if (!pdfResponse.ok) {
            const errorText = await pdfResponse.text();
            console.error("❌ Error en respuesta HTTP:", errorText);
            throw new Error(`Error HTTP ${pdfResponse.status}: ${errorText}`);
        }

        const pdfData = await pdfResponse.json();
        console.log("📄 Datos del PDF recibidos:", pdfData);

        if (!pdfData.success) {
            console.error("❌ API2PDF reportó fallo:", pdfData);
            throw new Error(`API2PDF falló: ${pdfData.error || 'Error desconocido'}`);
        }

        if (!pdfData.pdf) {
            console.error("❌ No se recibió URL del PDF:", pdfData);
            throw new Error("No se recibió la URL del PDF generado");
        }

        // Usar la URL del PDF generado para enviar por WhatsApp
        const pdfUrl = pdfData.pdf;

        UIManager.updateButtonLabel('#enviarPDF', "Enviando por WA...");

        console.log("📱 Enviando PDF por WhatsApp:", {
            celular: appState.celular,
            pdfUrl: pdfUrl
        });

        // Enviar PDF por WhatsApp
        const whatsappResponse = await sendPdf(appState.celular, pdfUrl);
        console.log("📨 Respuesta de WhatsApp:", whatsappResponse);

        UIManager.updateButtonLabel('#enviarPDF', "PDF ENVIADO ✅");
        console.log("✅ PDF enviado exitosamente por WhatsApp");

        // Resetear botón después de 3 segundos
        setTimeout(() => {
            UIManager.updateButtonLabel('#enviarPDF', "ENVIAR PDF");
        }, 3000);

    } catch (error) {
        console.error("❌ Error completo al enviar PDF:", {
            message: error.message,
            stack: error.stack,
            error: error
        });

        // Mostrar error más específico en el botón
        let errorMessage = "ERROR AL ENVIAR PDF ❌";
        if (error.message.includes("itemId")) {
            errorMessage = "ERROR: SIN ID ❌";
        } else if (error.message.includes("celular")) {
            errorMessage = "ERROR: SIN CELULAR ❌";
        } else if (error.message.includes("API2PDF")) {
            errorMessage = "ERROR: GENERAR PDF ❌";
        } else if (error.message.includes("WhatsApp")) {
            errorMessage = "ERROR: ENVÍO WA ❌";
        }

        UIManager.updateButtonLabel('#enviarPDF', errorMessage);

        // Resetear botón después de 5 segundos
        setTimeout(() => {
            UIManager.updateButtonLabel('#enviarPDF', "ENVIAR PDF");
        }, 5000);

    } finally {
        UIManager.hideLoading();
        console.log("🏁 Proceso de envío de PDF finalizado");
    }
});

// Agregar esta función para debuggear la firma
async function debugFirma(itemId) {
    try {
        console.log("🖊️ DEBUGGING: Verificando firma del titular");

        const titular = await wixData.get(CONFIG.COLLECTIONS.PEOPLE, itemId);

        console.log("🔍 Campo firma en la base de datos:");
        console.log(`  firma: ${titular.firma ? `"${titular.firma}"` : 'NO EXISTE'}`);
        console.log(`  tipo: ${typeof titular.firma}`);
        console.log(`  longitud: ${titular.firma ? titular.firma.length : 0} caracteres`);

        if (titular.firma) {
            console.log("✅ Firma encontrada");
            console.log(`🔗 URL de la firma: ${titular.firma.substring(0, 100)}...`);

            // Verificar si es una URL válida
            try {
                new URL(titular.firma);
                console.log("✅ URL de firma válida");
            } catch (e) {
                console.log("⚠️ URL de firma podría ser inválida");
            }
        } else {
            console.log("❌ No se encontró firma para este titular");
        }

        return titular.firma;
    } catch (error) {
        console.error("❌ Error verificando firma:", error);
    }
}

// Agrega esta función de debug y llámala en $w.onReady para verificar tus templates

async function debugTemplates() {
    try {
        console.log("🔍 DEBUGGING: Verificando colección de templates");
        
        const allTemplates = await wixData.query(CONFIG.COLLECTIONS.TEMPLATES).find();
        
        console.log("📊 Total de templates en la base:", allTemplates.totalCount);
        console.log("📋 Templates encontrados:", allTemplates.items.length);
        
        if (allTemplates.items.length === 0) {
            console.error("❌ NO HAY TEMPLATES EN LA BASE DE DATOS");
            return;
        }
        
        allTemplates.items.forEach((template, index) => {
            console.log(`📄 Template ${index + 1}:`);
            console.log(`  ID: ${template._id}`);
            console.log(`  Campos disponibles:`, Object.keys(template));
            console.log(`  Plataforma (mayúscula): ${template.Plataforma}`);
            console.log(`  plataforma (minúscula): ${template.plataforma}`);
            console.log(`  template existe: ${!!template.template}`);
            console.log(`  longitud del template: ${template.template?.length || 0}`);
            if (template.template) {
                console.log(`  primeros 100 chars: ${template.template.substring(0, 100)}...`);
            }
            console.log("  ---");
        });
        
        // Buscar específicamente Chile
        console.log("🇨🇱 Buscando template para Chile:");
        const chileTemplate = allTemplates.items.find(t => 
            (t.Plataforma && t.Plataforma.toLowerCase() === 'chile') ||
            (t.plataforma && t.plataforma.toLowerCase() === 'chile')
        );
        
        if (chileTemplate) {
            console.log("✅ Template de Chile encontrado:", chileTemplate);
        } else {
            console.log("❌ NO se encontró template para Chile");
            console.log("💡 Valores de Plataforma disponibles:", 
                allTemplates.items.map(t => t.Plataforma || t.plataforma).filter(Boolean)
            );
        }
        
    } catch (error) {
        console.error("❌ Error en debug de templates:", error);
    }
}

