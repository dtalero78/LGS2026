const secuencia = [
  { pagina: 1, nombre: "group15" },
  { pagina: 2, nombre: "image78" },
  { pagina: 3, nombre: "group14" },
  { pagina: 4, nombre: "group13" },
  { pagina: 5, nombre: "image75" },
  { pagina: 6, nombre: "group12" },
  { pagina: 7, nombre: "group11" },
  { pagina: 8, nombre: "group10" },
  { pagina: 9, nombre: "image71" },
  { pagina: 10, nombre: "image70" },
  { pagina: 11, nombre: "image69" },
  { pagina: 12, nombre: "image68" },
  { pagina: 13, nombre: "image67" },
  { pagina: 14, nombre: "image66" },
  { pagina: 15, nombre: "image65" },
  { pagina: 16, nombre: "image64" },
  { pagina: 17, nombre: "image63" },
  { pagina: 18, nombre: "image62" },
  { pagina: 19, nombre: "image61" },
  { pagina: 20, nombre: "group9" },
  { pagina: 21, nombre: "group8" },
  { pagina: 22, nombre: "group7" },
  { pagina: 23, nombre: "image57" },
  { pagina: 24, nombre: "image56" },
  { pagina: 25, nombre: "image55" },
  { pagina: 26, nombre: "image54" },
  { pagina: 27, nombre: "image53" },
  { pagina: 28, nombre: "image52" },
  { pagina: 29, nombre: "image51" },
  { pagina: 30, nombre: "image50" },
  { pagina: 31, nombre: "image49" },
  { pagina: 32, nombre: "group6" },
  { pagina: 33, nombre: "image47" },
  { pagina: 34, nombre: "group5" },
  { pagina: 35, nombre: "group4" },
  { pagina: 36, nombre: "image44" },
  { pagina: 37, nombre: "image43" },
  { pagina: 38, nombre: "image42" },
  { pagina: 39, nombre: "image41" },
  { pagina: 40, nombre: "image40" },
  { pagina: 41, nombre: "image39" },
  { pagina: 42, nombre: "group3" },
  { pagina: 43, nombre: "image37" },
  { pagina: 44, nombre: "group2" },
  { pagina: 45, nombre: "group1" },
  { pagina: 46, nombre: "image34" },
  { pagina: 47, nombre: "image33" },
  { pagina: 48, nombre: "image32" },
  { pagina: 49, nombre: "image31" },
  { pagina: 50, nombre: "image30" },
  { pagina: 51, nombre: "image29" },
  { pagina: 52, nombre: "image28" },
  { pagina: 53, nombre: "image27" },
  { pagina: 54, nombre: "image26" },
  { pagina: 55, nombre: "image25" },
  { pagina: 56, nombre: "image24" },
  { pagina: 57, nombre: "image23" },
  { pagina: 58, nombre: "image22" },
  { pagina: 59, nombre: "image21" },
  { pagina: 60, nombre: "image20" },
  { pagina: 61, nombre: "image19" },
  { pagina: 62, nombre: "image18" },
  //ESTA PÁGINA NO EXISTE { pagina: 63, nombre: "image17" },
  { pagina: 64, nombre: "image16" },
  { pagina: 65, nombre: "image15" },
  { pagina: 66, nombre: "image14" },
  { pagina: 67, nombre: "image13" },
  { pagina: 68, nombre: "image12" },
  { pagina: 69, nombre: "image11" },
  { pagina: 70, nombre: "image10" },
  { pagina: 71, nombre: "image9" },
  { pagina: 72, nombre: "image8" },
  { pagina: 73, nombre: "image7" },
  { pagina: 74, nombre: "image6" },
  { pagina: 75, nombre: "image5" },
  { pagina: 76, nombre: "image4" },
  { pagina: 77, nombre: "image3" }
];



	let currentIndex = 0;


$w.onReady(function () {

    // Oculta todos los elementos de la secuencia
    secuencia.forEach(item => {
        // Asegúrate que los IDs en Wix coincidan con item.nombre
        $w("#" + item.nombre).hide();
    });

    // Muestra el primer elemento (group15)
    $w("#" + secuencia[currentIndex].nombre).show();
});

$w('#adelanteButton').onClick((event) => {
    // Oculta el elemento actual
    $w("#" + secuencia[currentIndex].nombre).hide();

    // Comprueba que no sea el último elemento y actualiza el índice
    if (currentIndex < secuencia.length - 1) {
        currentIndex++;
    }
    // Muestra el siguiente elemento
    $w("#" + secuencia[currentIndex].nombre).show();
})

$w('#atrasButton').onClick((event) => {
    // Oculta el elemento actual
    $w("#" + secuencia[currentIndex].nombre).hide();

    // Comprueba que no sea el primer elemento y actualiza el índice
    if (currentIndex > 0) {
        currentIndex--;
    }
    // Muestra el elemento anterior
    $w("#" + secuencia[currentIndex].nombre).show();
})