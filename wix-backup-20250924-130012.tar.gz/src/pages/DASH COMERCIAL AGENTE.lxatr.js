import wixData from 'wix-data';
import { local, session } from 'wix-storage';
import wixWindow from 'wix-window';
import wixRealtimeFrontend from 'wix-realtime-frontend';
import wixLocation from 'wix-location';
import moment from 'moment';

// ==================== CONSTANTES Y CONFIGURACIÓN ====================
const CONFIG = {
    DEBOUNCE_DELAY: 500,
    MIN_SEARCH_LENGTH: 3,
    RECORDS_PER_PAGE: 7,
    COLLECTIONS: {
        COMERCIAL: 'COMERCIAL',
        PROSPECTOS: 'PROSPECTOS',
        PEOPLE: 'PEOPLE'
    },
    LIGHTBOXES: {
        CREAR_PROSPECTO: 'CREAR PROSPECTO',
        GESTIONAR_PROSPECTOS: 'CRM GESTIONAR PROSPECTOS',
        FICHA_ADMINISTRATIVA: 'FICHA ADMINISTRATIVO'
    }
};

// ==================== ESTADO GLOBAL ====================
const AppState = {
    debounceTimer: null,
    lastButtonClicked: '', // 'gestionNueva' o 'pendientesHoy'
    tipoDeRepeater: 'contratos',
    titularSeleccionado: null,
    originalRepeaterData: [],
    isSearchActive: false, // Nueva propiedad para rastrear si hay búsqueda activa
    currentCommercialId: null, // <--- NUEVO: _id del item en COMERCIAL del usuario logueado
    usuarioEmail: null,

    // Estado de paginación
    currentPage: 1,
    totalRecords: 0,
    totalPages: 0,
    allData: [], // Todos los datos sin paginar

    // Getters y setters para mejor control
    setTipoRepeater(tipo) {
        console.log(`Cambiando tipo de repetidor a: ${tipo}`);
        this.tipoDeRepeater = tipo;
        this.resetPagination();
    },

    setLastButtonClicked(button) {
        console.log(`Último botón clickeado: ${button}`);
        this.lastButtonClicked = button;
    },

    resetPagination() {
        this.currentPage = 1;
        this.totalRecords = 0;
        this.totalPages = 0;
        this.allData = [];
        this.isSearchActive = false;
    },

    setAllData(data) {
        console.log(`Configurando datos: ${data.length} registros`);
        this.allData = [...data]; // Crear copia para evitar referencias
        this.totalRecords = data.length;
        this.totalPages = Math.ceil(data.length / CONFIG.RECORDS_PER_PAGE);
        this.currentPage = 1;
    },

    getCurrentPageData() {
        const startIndex = (this.currentPage - 1) * CONFIG.RECORDS_PER_PAGE;
        const endIndex = startIndex + CONFIG.RECORDS_PER_PAGE;
        return this.allData.slice(startIndex, endIndex);
    },

    canGoNext() {
        return this.currentPage < this.totalPages;
    },

    canGoPrevious() {
        return this.currentPage > 1;
    },

    nextPage() {
        if (this.canGoNext()) {
            this.currentPage++;
            console.log(`Navegando a página: ${this.currentPage}`);
            return true;
        }
        return false;
    },

    previousPage() {
        if (this.canGoPrevious()) {
            this.currentPage--;
            console.log(`Navegando a página: ${this.currentPage}`);
            return true;
        }
        return false;
    }
};

// ==================== UTILIDADES ====================
const Utils = {
    capitalizeFirstLetter(string) {
        if (!string) return '';
        return string.charAt(0).toUpperCase() + string.slice(1).toLowerCase();
    },

    formatDate(date, format = 'DD/MM/YYYY') {
        return date ? moment(date).format(format) : '';
    },

    buildFullName(firstName, lastName, secondLastName = '') {
        return `${firstName || ''} ${lastName || ''} ${secondLastName || ''}`.trim();
    },

    debounce(func, delay) {
        clearTimeout(AppState.debounceTimer);
        AppState.debounceTimer = setTimeout(func, delay);
    },

    // Nueva función para logging consistente
    logItemData(itemData, location) {
        console.log(`=== DEBUG ${location} ===`);
        console.log('_id:', itemData._id);
        console.log('primerNombre:', itemData.primerNombre);
        console.log('primerApellido:', itemData.primerApellido);
        console.log('Tipo de repetidor:', AppState.tipoDeRepeater);
        console.log('========================');
    }
};

// ==================== AUTENTICACIÓN ====================
const Auth = {
    async validateToken() {
        const tokenData = JSON.parse(session.getItem('accessToken'));
        if (!tokenData) {
            this.redirectToLogin();
            return false;
        }

        const currentTime = new Date().getTime();
        const expirationDate = new Date(tokenData.expiresAt);

        if (currentTime > tokenData.expiresAt) {
            session.removeItem('accessToken');
            console.log("Token expirado");
            this.redirectToLogin();
            return false;
        }

        console.log(`Token válido hasta: ${expirationDate.toLocaleString()}`);
        return true;
    },

    redirectToLogin() {
        wixLocation.to('/login');
    },

    async initializeUser() {
    const usuarioEmail = decodeURIComponent(wixLocation.query.email || "").trim();
    if (!usuarioEmail) {
      console.error("No se encontró el parámetro 'email' en la URL");
      return false;
    }

    try {
      // Busca al comercial por email
      const results = await wixData.query(CONFIG.COLLECTIONS.COMERCIAL)
        .eq("email", usuarioEmail)        // si usas email en minúscula guarda también .toLowerCase() y filtra igual
        .limit(1)
        .find();

      if (results.items.length > 0) {
        const user = results.items[0];

        // Guarda saludo y el _id del comercial logueado
        $w('#nombreComercial').text = `¡Hola ${user.primerNombre}!`;
        AppState.currentCommercialId = user._id;   // <--- clave para filtrar PEOPLE
        AppState.usuarioEmail = usuarioEmail;

        console.log("Usuario inicializado:", {
          email: usuarioEmail,
          comercialId: AppState.currentCommercialId
        });

        return true;
      } else {
        console.error("Usuario no encontrado en COMERCIAL para:", usuarioEmail);
        return false;
      }
    } catch (error) {
      console.error("Error al inicializar usuario:", error);
      return false;
    }
  },
};

// ==================== GESTIÓN DE PAGINACIÓN ====================
const PaginationManager = {
    updatePaginationControls() {
        // Actualizar visibilidad de botones
        if (AppState.canGoPrevious()) {
            $w('#backButton').enable();
            $w('#backButton').show();
        } else {
            $w('#backButton').disable();
        }

        if (AppState.canGoNext()) {
            $w('#nextButton').enable();
            $w('#nextButton').show();
        } else {
            $w('#nextButton').disable();
        }

        // Mostrar información de paginación
        const startRecord = (AppState.currentPage - 1) * CONFIG.RECORDS_PER_PAGE + 1;
        const endRecord = Math.min(AppState.currentPage * CONFIG.RECORDS_PER_PAGE, AppState.totalRecords);

        $w('#paginationInfo').text = `${startRecord}-${endRecord} de ${AppState.totalRecords}`;

        // Ocultar botones si solo hay una página
        if (AppState.totalPages <= 1) {
            $w('#backButton').hide();
            $w('#nextButton').hide();
            $w('#paginationInfo').hide();
        } else {
            $w('#paginationInfo').show();
        }
    },

    goToNextPage() {
        if (AppState.nextPage()) {
            this.updateCurrentView();
        }
    },

    goToPreviousPage() {
        if (AppState.previousPage()) {
            this.updateCurrentView();
        }
    },

    updateCurrentView() {
        const currentPageData = AppState.getCurrentPageData();
        DataManager.updateRepeater(currentPageData, this.getTitleWithPagination());
        this.updatePaginationControls();
    },

    getTitleWithPagination() {
        let baseTitle = '';

        if (AppState.isSearchActive) {
            baseTitle = AppState.tipoDeRepeater === 'contratos' ? 'Contratos filtrados' : 'Prospectos filtrados';
        } else {
            baseTitle = AppState.tipoDeRepeater === 'contratos' ? 'Contratos Efectivos' :
                AppState.lastButtonClicked === 'gestionNueva' ? 'Prospectos desde hoy' :
                'Gestión Segunda Vez';
        }

        return `${baseTitle} (${AppState.totalRecords})`;
    },

    setupPaginationEvents() {
        $w('#backButton').onClick(() => {
            this.goToPreviousPage();
        });

        $w('#nextButton').onClick(() => {
            this.goToNextPage();
        });
    }
};

// ==================== GESTIÓN DE DATOS ====================
const DataManager = {
    async loadContratos() {
        console.log('Cargando contratos');
        AppState.setTipoRepeater('contratos');

        try {
            let query = wixData.query(CONFIG.COLLECTIONS.PEOPLE)
                .eq("tipoUsuario", "TITULAR")
                .descending("_createdDate");

            // 🔒 Filtro por el comercial logueado (agenteAsignado es referencia a COMERCIAL)
            if (AppState.currentCommercialId) {
                query = query.eq("agenteAsignado", AppState.currentCommercialId);
                console.log("Aplicando filtro por agenteAsignado:", AppState.currentCommercialId);
            } else {
                console.warn("No hay currentCommercialId aún; mostrando todo (solo si así lo deseas).");
            }

            const results = await query.find();
            console.log(`Contratos cargados (filtrados): ${results.items.length}`);

            // Log de algunos _ids para verificar
            if (results.items.length > 0) {
                console.log('Primeros 3 _ids de contratos:', results.items.slice(0, 3).map(item => item._id));
            }

            // Configurar paginación
            AppState.setAllData(results.items);
            const currentPageData = AppState.getCurrentPageData();

            this.updateRepeater(currentPageData, PaginationManager.getTitleWithPagination());
            PaginationManager.updatePaginationControls();
        } catch (error) {
            console.error("Error al cargar contratos:", error);
        }
    },

    updateRepeater(data, title) {
        console.log(`Actualizando repetidor con ${data.length} elementos`);
        AppState.originalRepeaterData = [...data]; // Crear copia
        $w('#repeaterNuevosProspectos').data = data;
        $w('#tituloRepeaters').text = title;
    },

    async searchInDatabase(query) {
        if (!query || query.length < CONFIG.MIN_SEARCH_LENGTH) {
            return [];
        }

        try {
            console.log(`Buscando en base de datos: "${query}"`);
            const results = await wixData.query(CONFIG.COLLECTIONS.PROSPECTOS)
                .contains("primerNombre", query)
                .or(wixData.query(CONFIG.COLLECTIONS.PROSPECTOS)
                    .contains("primerApellido", query))
                .or(wixData.query(CONFIG.COLLECTIONS.PROSPECTOS)
                    .contains("celular", query))
                .find();

            console.log(`Resultados de búsqueda en BD: ${results.items.length}`);

            return results.items.map(item => ({
                ...item,
                segundoApellido: item.segundoApellido || "",
                fechaProximaGestionFormatted: Utils.formatDate(item.fechaProximaGestion)
            }));
        } catch (error) {
            console.error("Error en búsqueda:", error);
            return [];
        }
    }
};


// ==================== GESTIÓN DE BÚSQUEDA ====================
const SearchManager = {
    async performSearch(query) {
        console.log(`Iniciando búsqueda: "${query}"`);
        $w('#todosLosRepeaters').collapse();
        $w('#noExiste').hide();

        if (!query || query.length === 0) {
            this.resetSearch();
            return;
        }

        if (query.length < CONFIG.MIN_SEARCH_LENGTH) {
            $w("#resultadoBusqueda").data = [];
            $w('#resultadoBusqueda').collapse();
            return;
        }

        $w('#loading').expand();
        AppState.isSearchActive = true;

        try {
            // Buscar en base de datos
            const databaseResults = await DataManager.searchInDatabase(query);
            this.displaySearchResults(databaseResults);

            // Filtrar datos actuales del repetidor
            this.filterCurrentRepeaterData(query);
        } catch (error) {
            console.error("Error en búsqueda:", error);
            this.showNoResults();
        } finally {
            $w('#loading').collapse();
        }
    },

    displaySearchResults(results) {
        if (results.length > 0) {
            console.log(`Mostrando ${results.length} resultados de búsqueda`);

            // Preparar datos para mostrar en el dropdown de resultados
            const displayResults = results.map(item => ({
                ...item,
                displayText: `${Utils.capitalizeFirstLetter(item.primerNombre)} ${Utils.capitalizeFirstLetter(item.primerApellido)} ${item.segundoApellido ? Utils.capitalizeFirstLetter(item.segundoApellido) : ''} ${item.fechaProximaGestionFormatted || ''}`
            }));

            $w("#resultadoBusqueda").data = displayResults;
            $w('#resultadoBusqueda').forEachItem(($item, itemData) => {
                $item("#resultados").text = itemData.displayText;
                $item("#resultados").onClick(() => {
                    console.log('Click en resultado de búsqueda, _id:', itemData._id);
                    Utils.logItemData(itemData, 'RESULTADO_BUSQUEDA_CLICK');

                    // Ir directamente al lightbox con el _id correcto
                    Navigation.redirectUserProfile(itemData._id, false, true);
                });
            });
            $w('#resultadoBusqueda').expand();
        } else {
            this.showNoResults();
        }
    },

    filterCurrentRepeaterData(query) {
        // Filtrar de todos los datos actuales del estado
        const queryLower = query.toLowerCase();

        const datosFiltrados = AppState.allData.filter(item => {
            const nombreCompleto = `${item.primerNombre || ''} ${item.primerApellido || ''}`.toLowerCase();
            const celular = (item.celular || '').toString();

            return nombreCompleto.includes(queryLower) ||
                celular.includes(query) ||
                (item.primerNombre || '').toLowerCase().includes(queryLower) ||
                (item.primerApellido || '').toLowerCase().includes(queryLower);
        });

        console.log(`Datos filtrados en repetidor: ${datosFiltrados.length}`);

        if (datosFiltrados.length > 0) {
            // Configurar paginación para los resultados filtrados
            AppState.setAllData(datosFiltrados);
            const currentPageData = AppState.getCurrentPageData();

            $w('#repeaterNuevosProspectos').data = currentPageData;
            $w('#todosLosRepeaters').expand();

            $w('#tituloRepeaters').text = PaginationManager.getTitleWithPagination();

            // Actualizar controles de paginación
            PaginationManager.updatePaginationControls();
        } else {
            $w('#repeaterNuevosProspectos').data = [];
            $w('#todosLosRepeaters').expand();
            $w('#tituloRepeaters').text = "Sin resultados";

            // Ocultar controles de paginación
            $w('#backButton').hide();
            $w('#nextButton').hide();
            $w('#paginationInfo').hide();
        }
    },

    resetSearch() {
        console.log('Reseteando búsqueda');
        $w("#resultadoBusqueda").data = [];
        $w('#resultadoBusqueda').collapse();
        AppState.isSearchActive = false;

        if (AppState.allData.length > 0) {
            // Recargar datos originales según el tipo de repetidor
            if (AppState.tipoDeRepeater === 'contratos') {
                DataManager.loadContratos();
            } else {
                const filterType = AppState.lastButtonClicked === 'gestionNueva' ? 'nuevos' : 'pendientes';
                DataManager.loadProspectos(filterType);
            }
        }
    },

    showNoResults() {
        $w('#noExiste').show();
        $w('#resultadoBusqueda').collapse();
    }
};

// ==================== NAVEGACIÓN ====================
const Navigation = {
    redirectUserProfile(userId, showPrimerContactoBox, showSegundoContactoBox) {
        console.log('=== NAVIGATION DEBUG ===');
        console.log('userId recibido:', userId);
        console.log('showPrimerContactoBox:', showPrimerContactoBox);
        console.log('showSegundoContactoBox:', showSegundoContactoBox);
        console.log('Tipo de userId:', typeof userId);

        // Validar que el userId no esté vacío o undefined
        if (!userId) {
            console.error('ERROR: userId está vacío o undefined');
            return;
        }

        local.setItem('userId', userId.toString()); // Asegurar que sea string
        local.setItem('showPrimerContactoBox', showPrimerContactoBox.toString());
        local.setItem('showSegundoContactoBox', showSegundoContactoBox.toString());

        // Verificar que se guardó correctamente
        const savedUserId = local.getItem('userId');
        console.log('userId guardado en local:', savedUserId);
        console.log('========================');

        if (savedUserId !== userId.toString()) {
            console.error('ERROR: El userId no se guardó correctamente');
            return;
        }

        wixWindow.openLightbox(CONFIG.LIGHTBOXES.GESTIONAR_PROSPECTOS);
    },

    openAdminProfile(userId) {
        console.log('=== ADMIN NAVIGATION DEBUG ===');
        console.log('userId para admin:', userId);
        console.log('Tipo de userId:', typeof userId);

        if (!userId) {
            console.error('ERROR: userId para admin está vacío o undefined');
            return;
        }

        local.setItem('userId', userId.toString());

        const savedUserId = local.getItem('userId');
        console.log('userId guardado para admin:', savedUserId);
        console.log('===============================');

        wixWindow.openLightbox(CONFIG.LIGHTBOXES.FICHA_ADMINISTRATIVA);
    }
};

// ==================== GESTIÓN DE DOCUMENTOS ====================
const DocumentManager = {
    loadDocuments() {
        if (!AppState.titularSeleccionado) {
            console.warn("No hay titular seleccionado para cargar documentos");
            return;
        }

        const docs = AppState.titularSeleccionado.documentacion || [];
        console.log("Cargando documentos:", docs.length, "archivos");

        const repeaterData = docs.map((url, i) => ({
            _id: `doc-${i}`,
            fileUrl: url,
            nombre: decodeURIComponent(url.split("/").pop())
        }));

        // Actualizar datos del repeater
        $w("#docsRepeater").data = repeaterData;

        // Configurar eventos para cada item
        $w("#docsRepeater").onItemReady(($item, itemData) => {
            $item("#nombreItemDoc").text = itemData.nombre;

            // MODIFICACIÓN: Hacer clic en el nombre del documento para abrir
            $item("#nombreItemDoc").onClick(() => {
                console.log('Abriendo documento:', itemData.fileUrl);

                // Detectar si es una URL de Wix (imágenes subidas a Wix)
                const isWixUrl = itemData.fileUrl.startsWith('wix:');

                if (isWixUrl) {
                    console.log('Detectada URL de Wix, convirtiendo a URL pública...');

                    // Convertir URL de Wix a URL pública
                    try {
                        // Extraer el ID de la imagen y el nombre del archivo
                        const wixMatch = itemData.fileUrl.match(/wix:image:\/\/v1\/([^\/]+)\/([^#]+)/);

                        if (wixMatch) {
                            const imageId = wixMatch[1]; // 1b6586_9b32d82d43264ddeabaa8f51393c7ca4~mv2.jpeg
                            const fileName = wixMatch[2]; // hijo.jpeg

                            // Extraer dimensiones de la URL original si están disponibles
                            const dimensionsMatch = itemData.fileUrl.match(/originWidth=(\d+)&originHeight=(\d+)/);
                            let width = 720,
                                height = 1280; // valores por defecto

                            if (dimensionsMatch) {
                                width = dimensionsMatch[1];
                                height = dimensionsMatch[2];
                            }

                            // Construir la URL pública
                            const publicUrl = `https://static.wixstatic.com/media/${imageId}/v1/fill/w_${width},h_${height},al_c,q_85,enc_auto/${fileName}`;

                            console.log('URL pública generada:', publicUrl);

                            // OPCIÓN 1: Usar wixLocation.to() con la URL pública
                            wixLocation.to(publicUrl);

                            // OPCIÓN 2: Si quieres que se abra en nueva pestaña, podrías crear
                            // un elemento de imagen en tu página y mostrarlo en un modal/lightbox

                        } else {
                            console.error('No se pudo parsear la URL de Wix:', itemData.fileUrl);
                            // Fallback: usar wixLocation con URL original
                            wixLocation.to(itemData.fileUrl);
                        }
                    } catch (error) {
                        console.error('Error al convertir URL de Wix:', error);
                        // Fallback: usar wixLocation con URL original
                        wixLocation.to(itemData.fileUrl);
                    }
                } else {
                    // Para URLs normales (PDFs externos, etc.)
                    console.log('URL normal detectada');
                    wixLocation.to(itemData.fileUrl);
                }
            });

            $item("#downloadDoc").onClick(() => {
                wixLocation.to(itemData.fileUrl);
            });

            $item("#deleteDoc").onClick(() => {
                this.deleteDocument(itemData.fileUrl);
            });
        });

        // Mostrar/ocultar el repeater según haya documentos
        if (docs.length > 0) {
            $w("#docsRepeater").show();
            console.log("Repeater actualizado con", docs.length, "documentos");
        } else {
            $w("#docsRepeater").hide();
            console.log("No hay documentos para mostrar");
        }
    },

    // NUEVA FUNCIÓN: Limpiar campos de upload
    clearUploadFields() {
        console.log("Limpiando campos de upload...");

        // Limpiar el campo de documentos
        if ($w("#uploadDocs")) {
            $w("#uploadDocs").reset();
            console.log("Campo uploadDocs limpiado");
        }

        // Limpiar el campo de imágenes JPG
        if ($w("#uploadJPG")) {
            $w("#uploadJPG").reset();
            console.log("Campo uploadJPG limpiado");
        }
    },

    // NUEVA FUNCIÓN: Inicializar box de documentos
    initializeDocumentBox(titularData) {
        console.log("Inicializando box de documentos para:", titularData.primerNombre, titularData.primerApellido);

        // Establecer titular seleccionado
        AppState.titularSeleccionado = titularData;

        // Mostrar nombre del titular
        $w("#nombreTitular").text = Utils.buildFullName(titularData.primerNombre, titularData.primerApellido);

        // Limpiar campos de upload
        this.clearUploadFields();

        // Recargar documentos
        this.loadDocuments();

        // Mostrar el box
        $w("#subirDocumentosBox").show();

        console.log("Box de documentos inicializado correctamente");
    },

    // ... resto de las funciones se mantienen igual
    async deleteDocument(urlEliminar) {
        if (!AppState.titularSeleccionado) return;

        console.log("Eliminando documento:", urlEliminar);

        let documentos = AppState.titularSeleccionado.documentacion || [];
        const documentosOriginales = documentos.length;
        documentos = documentos.filter(url => url !== urlEliminar);

        console.log(`Documentos antes: ${documentosOriginales}, después: ${documentos.length}`);

        try {
            const res = await wixData.update(CONFIG.COLLECTIONS.PEOPLE, {
                ...AppState.titularSeleccionado,
                documentacion: documentos
            });

            AppState.titularSeleccionado = res;
            console.log("Documento eliminado exitosamente de la base de datos");

            // Recargar la vista de documentos
            this.loadDocuments();

            // Forzar actualización si es necesario
            setTimeout(() => {
                this.loadDocuments();
            }, 100);

        } catch (error) {
            console.error("Error al eliminar documento:", error);
        }
    },

    async uploadDocuments() {
        $w('#loadingSubir').show();

        if (!AppState.titularSeleccionado) {
            console.warn("No hay titular seleccionado");
            $w('#loadingSubir').hide();
            return;
        }

        const docsFiles = $w("#uploadDocs").value || [];
        const jpgFiles = $w("#uploadJPG").value || [];

        if (docsFiles.length === 0 && jpgFiles.length === 0) {
            console.warn("No se ha seleccionado ningún archivo");
            $w('#loadingSubir').hide();
            return;
        }

        try {
            // Obtener documentos actuales ANTES de subir
            const documentosActuales = AppState.titularSeleccionado.documentacion || [];
            console.log("Documentos actuales:", documentosActuales.length);

            const uploadPromises = [];

            // Solo subir si hay archivos seleccionados
            if (docsFiles.length > 0) {
                console.log("Subiendo documentos:", docsFiles.length, "archivos");
                uploadPromises.push($w("#uploadDocs").uploadFiles());
            }

            if (jpgFiles.length > 0) {
                console.log("Subiendo imágenes:", jpgFiles.length, "archivos");
                uploadPromises.push($w("#uploadJPG").uploadFiles());
            }

            // Esperar a que se suban todos los archivos
            const results = await Promise.all(uploadPromises);
            const nuevasRutas = results.flat().map(file => file.fileUrl);

            console.log("Nuevas rutas subidas:", nuevasRutas.length);

            // CRÍTICO: Combinar documentos actuales con los nuevos
            const documentosFinales = [...documentosActuales, ...nuevasRutas];

            console.log("Documentos finales a guardar:", documentosFinales.length);

            // Actualizar en la base de datos
            const res = await wixData.update(CONFIG.COLLECTIONS.PEOPLE, {
                ...AppState.titularSeleccionado,
                documentacion: documentosFinales
            });

            // Actualizar el estado local
            AppState.titularSeleccionado = res;
            console.log("Archivos subidos exitosamente. Total documentos:", documentosFinales.length);

            // CRÍTICO: ACTUALIZAR EL REPEATER DESPUÉS DE SUBIR
            console.log("Actualizando repeater de documentos...");
            this.loadDocuments();

            // Limpiar campos de upload después de subir exitosamente
            this.clearUploadFields();

            // Forzar actualización adicional por si acaso
            setTimeout(() => {
                console.log("Forzando segunda actualización del repeater...");
                this.loadDocuments();
            }, 300);

            // Opcional: Mostrar mensaje de éxito
            // $w('#mensajeExito').show();
            // setTimeout(() => $w('#mensajeExito').hide(), 3000);

        } catch (error) {
            console.error("Error al subir archivos:", error);
            // Opcional: Mostrar mensaje de error
            // $w('#mensajeError').show();
            // setTimeout(() => $w('#mensajeError').hide(), 3000);
        } finally {
            $w('#loadingSubir').hide();
        }
    }
};

// ==================== SUSCRIPCIONES EN TIEMPO REAL ====================
const RealtimeManager = {
    subscribe() {
        wixRealtimeFrontend.subscribe({ name: "gestionProspectos" },
                (message, channel) => {
                    const payload = message.payload;
                    console.log("Mensaje recibido:", message, channel);

                    if (payload.type === "updateComplete") {
                        console.log("Ejecutando cargarNuevosProspectos...");
                        DataManager.loadProspectos('nuevos');
                    } else {
                        console.log("Tipo de mensaje no procesado:", payload.type);
                    }
                }
            )
            .then(id => {
                console.log("Suscripción exitosa con ID:", id);
            })
            .catch(error => {
                console.error("Error en suscripción:", error);
            });
    }
};

// ==================== EVENTOS DEL REPEATER ====================
const RepeaterEvents = {
    setupRepeaterEvents() {
        $w('#repeaterNuevosProspectos').onItemReady(($item, itemData) => {
            // LOGGING CRÍTICO: Verificar el _id al configurar cada item
            Utils.logItemData(itemData, 'REPEATER_ITEM_READY');

            const nombreCompleto = Utils.buildFullName(itemData.primerNombre, itemData.primerApellido);
            $item('#nombreRepeaterNuevosProspectos').text = nombreCompleto;

            // Configurar fechas según el tipo de repetidor
            this.setupDateDisplay($item, itemData);

            // Configurar otros campos
            $item('#paisRepeaterNuevosProspectos').text = itemData.plataforma || "";
            $item('#celularRepeaterNuevosProspectos').text = itemData.celular || "";

            if (itemData.firma && !itemData.aprobacion) {
                $item('#estado').text = "Firmado sin Aprobar";
            } else if (itemData.aprobacion) {
                $item('#estado').text = itemData.aprobacion;
            } else {
                $item('#estado').text = ""; // O algún estado por defecto si quieres
            }

            // Configurar eventos de click
            this.setupClickEvents($item, itemData);

            // 🎯 MÉTODO SIMPLIFICADO - SIN FETCH, SOLO REDIRECCIÓN
            $item("#descargarContrato").onClick(() => {
                try {
                    console.log(`📄 Descargando contrato para: ${itemData._id}`);

                    // URL del endpoint que maneja la redirección
                    const downloadUrl = `https://bsl-utilidades-yp78a.ondigitalocean.app/descargar-pdf-drive/${itemData._id}?empresa=LGS`;

                    console.log(`🔗 Redirigiendo a: ${downloadUrl}`);

                    // Redirección directa - el backend se encarga de todo
                    wixLocation.to(downloadUrl);

                } catch (error) {
                    console.error("❌ Error al descargar contrato:", error);
                }
            });

        });
    },

    setupDateDisplay($item, itemData) {
        if (AppState.tipoDeRepeater === 'contratos') {
            const fechaCreada = Utils.formatDate(itemData._createdDate);
            $item('#fechaCreadaRepeaterNuevosProspectos').text = fechaCreada;
            $item('#fechaProximaGestionfechaCreadaRepeaterNuevosProspectos').text = "";
        } else {
            const fechaProximaGestion = Utils.formatDate(itemData.fechaProximaGestion, 'DD/MM/YYYY HH:mm');
            $item('#fechaCreadaRepeaterNuevosProspectos').text = fechaProximaGestion;
            $item('#fechaProximaGestionfechaCreadaRepeaterNuevosProspectos').text = fechaProximaGestion;
        }
    },

    setupClickEvents($item, itemData) {
        const handleItemClick = () => {
            // LOGGING CRÍTICO: Verificar el _id antes de navegar
            Utils.logItemData(itemData, 'ANTES_DE_NAVEGAR');

            if (AppState.tipoDeRepeater === "contratos") {
                // *** CAMBIO PRINCIPAL: Usar la nueva función initializeDocumentBox ***
                DocumentManager.initializeDocumentBox(itemData);

            } else {
                const showPrimerContacto = AppState.lastButtonClicked === 'gestionNueva';
                const showSegundoContacto = AppState.lastButtonClicked === 'pendientesHoy';

                // VALIDACIÓN CRÍTICA: Verificar que el _id existe
                if (!itemData._id) {
                    console.error('ERROR CRÍTICO: itemData._id está undefined en handleItemClick');
                    console.log('itemData completo:', itemData);
                    return;
                }

                console.log('Enviando _id al lightbox:', itemData._id);
                Navigation.redirectUserProfile(itemData._id, showPrimerContacto, showSegundoContacto);
            }
        };

        $item("#nombreRepeaterNuevosProspectos").onClick(handleItemClick);
        $item("#vectorImage3").onClick(handleItemClick);
        $item("#verFicha").onClick(() => {
            Utils.logItemData(itemData, 'ANTES_DE_ABRIR_FICHA');

            if (!itemData._id) {
                console.error('ERROR CRÍTICO: itemData._id está undefined en verFicha');
                console.log('itemData completo:', itemData);
                return;
            }

            console.log('Abriendo ficha admin para _id:', itemData._id);
            Navigation.openAdminProfile(itemData._id);
        });
    }
};

// ==================== INICIALIZACIÓN PRINCIPAL ====================
$w.onReady(async function () {
    console.log('=== INICIALIZANDO APLICACIÓN ===');

    // Validar token y autenticación
    if (!await Auth.validateToken()) {
        console.log('Token inválido, redirigiendo al login');
        return;
    }

    // Inicializar usuario (solo para mostrar saludo)
    const userInitialized = await Auth.initializeUser();
    await DataManager.loadContratos();  // <-- ahora ya filtrará por agenteAsignado

    if (!userInitialized) {
        console.log('Error al inicializar usuario');
    }

    // Configurar suscripciones en tiempo real
    RealtimeManager.subscribe();

    // Configurar eventos de paginación
    PaginationManager.setupPaginationEvents();

    // Cargar datos iniciales - PRIMER QUERY (contratos por defecto)
    console.log('Cargando datos iniciales...');
    await DataManager.loadContratos();

    // Configurar eventos del repeater
    RepeaterEvents.setupRepeaterEvents();

    // Configurar upload de documentos
    if ($w("#uploadDocs")) {
        console.log("Upload de documentos configurado para múltiples archivos");
    }

    if ($w("#uploadJPG")) {
        console.log("Upload de imágenes configurado para múltiples archivos");
    }

    // Configurar eventos de búsqueda con debounce
    $w("#search").onKeyPress(() => {
        Utils.debounce(() => {
            const searchValue = $w("#search").value;
            console.log(`Búsqueda iniciada: "${searchValue}"`);
            SearchManager.performSearch(searchValue);
        }, CONFIG.DEBOUNCE_DELAY);
    });

    // IMPORTANTE: También escuchar cuando se borra el texto de búsqueda
    $w("#search").onInput(() => {
        const searchValue = $w("#search").value;
        if (searchValue === '' || searchValue.length === 0) {
            console.log('Campo de búsqueda vacío, reseteando');
            SearchManager.resetSearch();
        }
    });

    // Configurar botones de filtrado
    $w('#gestionNuevaButton').onClick(async () => {
        console.log('Click en Gestión Nueva');
        AppState.setLastButtonClicked('gestionNueva');

        // Limpiar búsqueda si está activa
        if (AppState.isSearchActive) {
            $w("#search").value = '';
            AppState.isSearchActive = false;
        }

        await DataManager.loadProspectos('nuevos');
    });

    $w('#pendientesHoyButton').onClick(async () => {
        console.log('Click en Pendientes Hoy');
        AppState.setLastButtonClicked('pendientesHoy');

        // Limpiar búsqueda si está activa
        if (AppState.isSearchActive) {
            $w("#search").value = '';
            AppState.isSearchActive = false;
        }

        await DataManager.loadProspectos('pendientes');
    });

    $w('#todosLosContratosButt').onClick(async () => {
        console.log('Click en Todos los Contratos');
        AppState.setLastButtonClicked('');

        // Limpiar búsqueda si está activa
        if (AppState.isSearchActive) {
            $w("#search").value = '';
            AppState.isSearchActive = false;
        }

        await DataManager.loadContratos();
    });

    // Configurar otros botones
    $w("#crearProspecto").onClick(() => {
        console.log('Abriendo lightbox para crear prospecto');
        wixWindow.openLightbox(CONFIG.LIGHTBOXES.CREAR_PROSPECTO);
    });

    $w('#subir').onClick(() => {
        console.log('Iniciando subida de documentos');
        DocumentManager.uploadDocuments();
    });

    $w('#cerrarDocumentacionbutt').onClick(() => {
        console.log('Cerrando box de documentación');
        $w('#subirDocumentosBox').hide();
        AppState.titularSeleccionado = null; // Limpiar selección
    });

    console.log('=== APLICACIÓN INICIALIZADA CORRECTAMENTE ===');
});

// ==================== FUNCIONES ADICIONALES ====================

// Función para manejar actualizaciones en tiempo real desde otras páginas
export function refreshProspectos() {
    console.log('Función refreshProspectos llamada externamente');
    if (AppState.tipoDeRepeater === 'prospectos') {
        const filterType = AppState.lastButtonClicked === 'gestionNueva' ? 'nuevos' : 'pendientes';
        DataManager.loadProspectos(filterType);
    }
}

// Función para refresh general
export function refreshData() {
    console.log('Función refreshData llamada externamente');
    if (AppState.tipoDeRepeater === 'contratos') {
        DataManager.loadContratos();
    } else {
        const filterType = AppState.lastButtonClicked === 'gestionNueva' ? 'nuevos' : 'pendientes';
        DataManager.loadProspectos(filterType);
    }
}

// ==================== EXPORTS ====================
export function guardarDocs_click() {
    console.log("Función guardarDocs_click llamada - implementar si es necesaria");
    // Esta función puede ser llamada desde elementos del editor
    // Implementar lógica específica si es requerida
}

// Funciones para debugging (remover en producción)
export function debugAppState() {
    console.log('=== DEBUG APP STATE ===');
    console.log('tipoDeRepeater:', AppState.tipoDeRepeater);
    console.log('lastButtonClicked:', AppState.lastButtonClicked);
    console.log('isSearchActive:', AppState.isSearchActive);
    console.log('currentPage:', AppState.currentPage);
    console.log('totalRecords:', AppState.totalRecords);
    console.log('totalPages:', AppState.totalPages);
    console.log('allData length:', AppState.allData.length);
    if (AppState.allData.length > 0) {
        console.log('Primer elemento _id:', AppState.allData[0]._id);
        console.log('Primer elemento completo:', AppState.allData[0]);
    }
    console.log('========================');
}

export function debugCurrentPageData() {
    const currentData = AppState.getCurrentPageData();
    console.log('=== DEBUG CURRENT PAGE DATA ===');
    console.log('Datos página actual:', currentData.length);
    currentData.forEach((item, index) => {
        console.log(`Item ${index}:`, {
            _id: item._id,
            nombre: `${item.primerNombre} ${item.primerApellido}`,
            tipoUsuario: item.tipoUsuario
        });
    });
    console.log('================================');
}

// ==================== VALIDACIONES FINALES ====================

// Validar que todos los elementos existen en el DOM
$w.onReady(() => {
    const requiredElements = [
        '#repeaterNuevosProspectos',
        '#search',
        '#gestionNuevaButton',
        '#pendientesHoyButton',
        '#todosLosContratosButt',
        '#backButton',
        '#nextButton',
        '#paginationInfo',
        '#tituloRepeaters',
        '#todosLosRepeaters',
        '#resultadoBusqueda',
        '#loading',
        '#noExiste'
    ];

    const missingElements = requiredElements.filter(selector => {
        try {
            const element = $w(selector);
            return !element;
        } catch (error) {
            return true;
        }
    });

    if (missingElements.length > 0) {
        console.warn('Elementos faltantes en el DOM:', missingElements);
    } else {
        console.log('Todos los elementos requeridos están presentes en el DOM');
    }
});

/*
==================== NOTAS IMPORTANTES ====================

1. CORRECCIONES PRINCIPALES IMPLEMENTADAS:
   - Logging detallado para rastrear _ids en cada paso
   - Preservación completa de objetos en búsquedas
   - Validaciones de _id antes de navegar
   - Control mejorado del estado de búsqueda
   - Gestión correcta de paginación con datos filtrados

2. DEBUGGING:
   - Usar debugAppState() y debugCurrentPageData() para inspeccionar estado
   - Verificar logs en consola para rastrear _ids
   - El campo #tipoUsuario muestra el _id real para verificación

3. FLUJO DE DATOS:
   - Los datos siempre se cargan completos desde la BD
   - Las búsquedas mantienen todos los campos originales
   - La paginación trabaja sobre datos completos
   - Navigation recibe siempre el _id original

4. PRÓXIMOS PASOS PARA TESTING:
   - Verificar que los _ids en consola coincidan
   - Probar búsquedas y navegación
   - Verificar que el lightbox recibe el _id correcto
   - Confirmar que la paginación no corrompe datos

*/