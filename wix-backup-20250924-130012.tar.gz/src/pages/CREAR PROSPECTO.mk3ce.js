import wixStorage from 'wix-storage';
import wixWindow from 'wix-window';
import wixData from 'wix-data';
import { sendmessage } from 'backend/realTimeChat'; // AsegÃºrate de que esta ruta es correcta

// OJO!!!! CÓMO ESTA PÁGINA SOLO VA A ENVIAR LOS MENSAJES PARA ACTUALIZAR LOS DASH DE gestionarProspectos NO NECESITA SUSCRIBIRSE SOLO USAR sendmessage

$w.onReady(async function () {

    
        const prefijos = [
            { pais: "Argentina", prefijo: "+54" },
            { pais: "Bolivia", prefijo: "+591" },
            { pais: "Chile", prefijo: "+56" },
            { pais: "Colombia", prefijo: "+57" },
            { pais: "Costa Rica", prefijo: "+506" },
            { pais: "Cuba", prefijo: "+53" },
            { pais: "Ecuador", prefijo: "+593" },
            { pais: "El Salvador", prefijo: "+503" },
            { pais: "España", prefijo: "+34" },
            { pais: "Guatemala", prefijo: "+502" },
            { pais: "Honduras", prefijo: "+504" },
            { pais: "México", prefijo: "+52" },
            { pais: "Nicaragua", prefijo: "+505" },
            { pais: "Panamá", prefijo: "+507" },
            { pais: "Paraguay", prefijo: "+595" },
            { pais: "Perú", prefijo: "+51" },
            { pais: "Puerto Rico", prefijo: "+1 787" },
            { pais: "República Dominicana", prefijo: "+1 809" },
            { pais: "Uruguay", prefijo: "+598" },
            { pais: "Venezuela", prefijo: "+58" }
        ];

        // Asignar los valores al dropdown
        let options = prefijos.map(item => {
            return {
                label: `${item.pais} ${item.prefijo}`,
                value: item.prefijo
            };
        });

        $w('#prefijo').options = options;
    

    const userId = wixStorage.local.getItem('userId');

    // 4. ConfiguraciÃ³n de los comentarios
    $w('#comentarios').onFocus(() => prepararCampoComentario('#comentarios'));

    wixData.query("COMERCIAL")
    .limit(1000)
    .find()
    .then(results => {
        console.log("Resultados de la consulta:", results); // Verifica si hay resultados

        // Mapear los resultados para concatenar primerNombre, primerApellido y filial
        const optionsPromises = results.items.map(async item => {
            try {
                // Obtener el nombre de la filial asociada al ID
                const filialId = item.filial;
                console.log("Filial ID:", filialId); // Verifica el ID de la filial

                const filial = await getFilialName(filialId);
                console.log("Nombre de la filial:", filial); // Verifica el nombre de la filial obtenido

                // Concatenar primerNombre, primerApellido y nombre de la filial
                const label = `${capitalizeFirstLetter(item.primerNombre)} ${capitalizeFirstLetter(item.primerApellido)} - ${capitalizeFirstLetter(filial)}`;
                console.log("Label creado:", label); // Verifica el label creado

                return {
                    label: label,
                    value: item._id // Usar el _id como valor del dropdown
                };
            } catch (error) {
                console.error("Error en el mapeo del item:", error);
                return null; // Devuelve null si hay un error en este item
            }
        });

        // Esperar a que todas las promesas se resuelvan
        Promise.all(optionsPromises)
            .then(options => {
                console.log("Opciones antes de ordenar:", options); // Verifica las opciones antes de ordenar

                // Filtrar valores nulos
                options = options.filter(option => option !== null);

                // Ordenar las opciones por el label de la A a la Z
                options.sort((a, b) => a.label.localeCompare(b.label, 'es', { sensitivity: 'base' }));
                console.log("Opciones ordenadas:", options); // Verifica las opciones ordenadas

                // Establecer las opciones en el dropdown agenteAsignado
                $w("#agenteAsignado").options = options;
            })
            .catch(error => {
                console.error("Error al procesar las opciones del dropdown:", error);
            });
    })
    .catch(error => {
        console.error("Error en la consulta a la base de datos:", error);
    });

});

// Función para obtener el nombre de la filial a partir de su ID
async function getFilialName(filialId) {
    try {
        const result = await wixData.query("FILIALES")
            .eq("_id", filialId)
            .find();
        if (result.items.length > 0) {
            return result.items[0].filial; // Retornar el nombre de la filial
        } else {
            return "Filial no encontrada";
        }
    } catch (error) {
        console.error("Error al obtener el nombre de la filial:", error);
        return "Error";
    }
}

export function crearButton_click(event) {
    let fechaInput, horaInput, fecha;
    fechaInput = $w("#fechaProximaGestion").value;
    horaInput = $w("#horaProximaGestion").value;
    fecha = new Date(fechaInput);
    let [horas, minutos] = horaInput.split(":").map(Number);
    fecha.setHours(horas, minutos);
    console.log(fecha);

    // Obtener los valores de los campos del formulario
    const primerNombre = $w('#primerNombre').value;
    const segundoNombre = $w('#segundoNombre').value;
    const primerApellido = $w('#primerApellido').value;
    const segundoApellido = $w('#segundoApellido').value;
    const pais = $w('#pais').value;
    const prefijo = $w('#prefijo').value; // Obtener el prefijo seleccionado
    let celular = $w('#celular').value;

    // Eliminar espacios, guiones y puntos del número de celular
    celular = celular.replace(/[\s.-]/g, '');

    // Concatenar el prefijo con el número de celular
    celular = `${prefijo}${celular}`;

    const email = $w('#email').value;
    const direccion = $w('#direccion').value;
    const origen = $w('#origen').value;
    const agenteAsignadoId = $w('#agenteAsignado').value;
    const comentarios = $w('#comentarios').value;

    // Guardar los valores en la base de datos PROSPECTOS
    wixData.insert("PROSPECTOS", {
            primerNombre: primerNombre,
            segundoNombre: segundoNombre,
            primerApellido: primerApellido,
            segundoApellido: segundoApellido,
            pais: pais,
            celular: celular, // Guardar el celular concatenado
            email: email,
            direccion: direccion,
            origen: origen,
            agenteAsignado: agenteAsignadoId,
            comentarios: comentarios,
            fechaProximaGestion: fecha,
            callToAction: " Llamardespués"
        })
        .then(result => {

            // ----------------------------------------------------------
            // Enviar mensaje PARA ACTUALIZAR CANAL en este caso el repeater porContactar del Dash Comercial 
            sendmessage("gestionProspectos", { type: "updateComplete" })
                .then(response => {
                    wixWindow.lightbox.close({ "updated": true });
                });
            // ----------------------------------------------------------

            wixWindow.lightbox.close();
            // Manejar el éxito de la inserción
            console.log("Prospecto creado con éxito:", result);
            // Puedes redirigir al usuario a una página de confirmación o realizar otra acción
        })
        .catch(error => {
            // Manejar cualquier error que ocurra durante la inserción
            console.error("Error al crear prospecto:", error);
        });
}

// II.2 FunciÃ³n de comentario
function prepararCampoComentario(elementId) {
    let comentarioActual = $w(elementId).value;
    // Agregar una fecha solo si el campo estÃ¡ completamente vacÃ­o
    if (!comentarioActual.trim()) {
        comentarioActual = `Fecha: ${obtenerFechaActualComoString()}\n`;
        $w(elementId).value = comentarioActual;
    }
}

// II.3 Obtener la fecha actual como string en formato DD/MM/AAAA
function obtenerFechaActualComoString() {
    const fecha = new Date();
    return fecha.toLocaleDateString('es-CL', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric'
    });
}

function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1).toLowerCase();
}