import wixData from 'wix-data';
import moment from 'moment-timezone';
import { v4 as uuidv4 } from 'uuid';
import { getFormattedClasses } from 'backend/ACADEMICA';
import wixWindow from 'wix-window';
import { actualizarNivelYStepDeUnEstudiante } from 'backend/clases.jsw';


// Variables globales
let resourceId = uuidv4();
moment.locale('es');
let numeroId;
let usuarioEmail;
let selectedRowData = null; // Almacena la fila seleccionada
let nivel;
let selectedEventType = ""; // "SESSION" o "CLUB", según el botón que el usuario presione
let idEnAcademica;
$w.onReady(() => {

    // Obtener el contexto enviado al Lightbox
    const context = wixWindow.lightbox.getContext();
    console.log("Contexto recibido en Lightbox:", context);

    // Extraer el userId y el email del contexto
    // En este caso, context.userId es el idEstudiante que se usará para buscar en ACADEMICA.
    usuarioEmail = context.email || ""; // Si no existe, será una cadena vacía
    idEnAcademica = context._id || "no se recibió idAcademica"
    console.log("userId recibido:", context.userId);
    console.log("email recibido:", usuarioEmail);
        console.log("id Recibido2:", idEnAcademica);


    if (!context.userId || !usuarioEmail) {
        console.error("No se recibió un userId o email válido.");
        return;
    }

    // Botón para sesiones
    $w("#sesionButton").onClick(() => {
        selectedEventType = "SESSION";
        loadEventDropdown();
    });

    // Botón para clubes
    $w("#clubButton").onClick(() => {
        selectedEventType = "CLUB";
        loadEventDropdown();
    });

    // Cuando el usuario seleccione un día, cargamos las horas disponibles
    $w("#eventoDropdown").onChange(() => {
        const selectedDay = $w("#eventoDropdown").value; // "YYYY-MM-DD"
        loadDateDropdown(selectedDay);
    });
    // Realizamos un query en ACADEMICA buscando en _id o en numeroId
    wixData.query("ACADEMICA")
        .eq("_id", context.userId) // Busca por _id
        .or(wixData.query("ACADEMICA").eq("numeroId", context.userId)) // O busca por numeroId
        .find()
        .then((result) => {
            if (result.items.length > 0) {
                // Extraer el campo numeroId del estudiante encontrado
                numeroId = result.items[0].numeroId;
                nivel = result.items[0].nivel
                console.log("numeroId obtenido:", numeroId);
                // Inicializar la página con el numeroId obtenido
                initializePage(numeroId);
                cargarStepsDelNivel(nivel, context.userId); // <--- solo aquí

                // Configurar los eventos de toggle
                setupToggleButtons();

                // Cargar el dropdown de eventos
                loadEventDropdown();

                $w("#eventoDropdown").onChange(() => {
                    const selectedStep = $w("#eventoDropdown").value;
                    loadDateDropdown(selectedStep);
                });
            } else {
                console.error("No se encontró un estudiante en ACADEMICA con _id o numeroId:", context.userId);
            }
        })
        .catch((err) => {
            console.error("Error al consultar ACADEMICA:", err);
        });

    $w("#repeaterSteps").onItemReady(($item, itemData, index) => {
        $item("#checkCompletado").checked = itemData.checkCompletado || false;
        // Si tienes un campo para mostrar el nombre del step:
        if ($item("#stepLabel")) $item("#stepLabel").text = itemData.step;
    });

    $w("#repeaterSteps").onItemReady(($item, itemData, index) => {
    $item("#checkCompletado").checked = itemData.checkCompletado || false;
    if ($item("#stepLabel")) $item("#stepLabel").text = itemData.step;

    $item("#confirmarStep").onClick(async () => {
        $item("#confirmarStep").label = "Actualizando...";

        try {
            if ($item("#checkCompletado").checked) {
                await wixData.save("STEP_OVERRIDES", {
                    userId: context.userId,
                    idEnAcademica: context._id,
                    step: itemData.step,
                    nivel: nivel,
                    primerNombre: $w('#nombres').text.split(' ')[0],
                    primerApellido: $w('#nombres').text.split(' ')[1] || "",
                    academicaId: context.userId
                });
            } else {
                const overrideResult = await wixData.query("STEP_OVERRIDES")
                    .eq("userId", context.userId)
                    .eq("step", itemData.step)
                    .find();

                if (overrideResult.items.length > 0) {
                    await wixData.remove("STEP_OVERRIDES", overrideResult.items[0]._id);
                }
            }

            // ✅ Actualiza el step y nivel automáticamente
            await actualizarNivelYStepDeUnEstudiante(context._id);
            console.log(`🟢 Nivel y step actualizados para ${context._id}`);

            $item("#confirmarStep").label = "Actualizado ✔";
        } catch (error) {
            console.error("❌ Error al confirmar override o actualizar nivel/step:", error);
            $item("#confirmarStep").label = "Error ⚠️";
        }

        setTimeout(() => {
            $item("#confirmarStep").label = "Confirmar";
        }, 2000);
    });
});


});

console.log("NIVEL:", nivel);

function setupToggleButtons() {
    const buttonGroupMap = {
        generalButton: 'grupoInfoGeneral',
        comentariosButton: 'grupoComentarios',
        agendarButton: 'grupoAgendar',
        asignarStepButton: 'grupoAsignarStep'
    };

    // Asigna el evento de clic a cada botón
    Object.keys(buttonGroupMap).forEach(buttonId => {
        $w(`#${buttonId}`).onClick(() => {
            toggleGroup(buttonGroupMap[buttonId], buttonGroupMap);
        });
    });
}

function toggleGroup(activeGroupId, groupMap) {
    // Itera sobre los grupos y solo muestra el activo
    Object.values(groupMap).forEach(groupId => {
        if (groupId === activeGroupId) {
            $w(`#${groupId}`).show();
        } else {
            $w(`#${groupId}`).hide();
        }
    });
}

// Inicializa los eventos de los botones y carga inicial
function initializePage(numeroId) {

    loadStudentData(numeroId); // Cargar los datos del estudiante
    setupTableRowSelection();
}

// Carga los datos del estudiante y sus clases
async function loadStudentData(numeroId) {
    try {
        console.log("Cargando datos del estudiante con numeroId:", numeroId);
        $w('#eliminarButton').label = "Eliminar Evento"

        // Crear un mapeo entre las plataformas y las banderas
        const banderas = {
            "Chile": "🇨🇱",
            "Colombia": "🇨🇴",
            "Ecuador": "🇪🇨",
            "Perú": "🇵🇪",
            "Bolivia": "🇧🇴",
            "Argentina": "🇦🇷"
        };

        // Buscar el estudiante en ACADEMICA
        const student = await queryAcademica(numeroId);
        if (!student) {
            console.warn(`No se encontró un estudiante con el numeroId: ${numeroId}`);
            return;
        }
        console.log(student.step, "EL STEP")
        // 👇 Aquí ya existe "student", así que esto es seguro:
        $w("#stepActual").value = "Step Actual: " + student.step || "Sin Step";

        // Opciones de nuevoStep
        const opcionesStep = Array.from({ length: 50 }, (_, i) => {
            const num = (i + 1).toString();
            return { label: `Step ${num}`, value: num };
        });
        $w("#nuevoStep").options = opcionesStep;

        console.log("Datos del estudiante encontrados:", student);

        // Mostrar los datos del estudiante
        $w('#nombres').text = `${student.primerNombre} ${student.primerApellido} - ${student.nivel} - ${student.step}`;
        $w('#foto').src = student.foto;

        // Obtener la bandera correspondiente a la plataforma
        const bandera = banderas[student.plataforma] || ""; // Si no hay bandera, usa una cadena vacía
        $w('#plataforma').text = `${student.plataforma} ${bandera}`;

        // Cargar las clases del estudiante
        const { clases, nivelesCompletados } = await queryClasses(student._id, student.nivel);
        updateTable(clases);
        updateCheckboxGroup(nivelesCompletados);
    } catch (error) {
        console.error("Error al cargar los datos del estudiante:", error);
    }

    $w('#advisorAnotaciones').onFocus(() => prepararCampoComentario('#advisorAnotaciones', usuarioEmail));
    $w('#comentariosParaUsuario').onFocus(() => prepararCampoComentario('#comentariosParaUsuario', usuarioEmail));

}

// Alterna la visibilidad de un elemento
function toggleElementVisibility(elementId) {
    return () => {
        const element = $w(elementId);
        element.hidden ? element.show() : element.hide();
    };
}

// Realiza un query en la base de datos ACADEMICA
async function queryAcademica(numeroId) {
    const result = await wixData.query("ACADEMICA").eq("numeroId", numeroId).find();
    return result.items[0] || null;
}

// Realiza un query en la base de datos CLASSES y devuelve las clases formateadas
async function queryClasses(academicaId, nivel) {
    const { formattedItems, nivelesCompletados } = await getFormattedClasses(academicaId, nivel);

    const clases = formattedItems.map(item => ({
        ...item,
        // Solo formateamos la fecha, sin tocar advisorName ni otros campos ya formateados
        fechaEvento: moment.utc(item.fechaEvento).local().format('D MMM YYYY, hh:mm A')
    }));

    return { clases, nivelesCompletados };
}

// Actualiza la tabla con las clases formateadas
function updateTable(clases) {
    // Configurar las columnas de la tabla
    $w("#tablaAsistencia").columns = [
        { "id": "idEvento", "dataPath": "idEvento", "label": "ID Evento", "width": 150, "visible": false, "type": "string" },
        { "id": "fechaEvento", "dataPath": "fechaEvento", "label": "Fecha", "width": 150, "visible": true, "type": "string" },
        { "id": "tipoEvento", "dataPath": "tipoEvento", "label": "Tipo", "width": 100, "visible": true, "type": "string" },
        { "id": "nivel", "dataPath": "nivel", "label": "Nivel", "width": 80, "visible": true, "type": "string" },
        { "id": "step", "dataPath": "step", "label": "Step", "width": 80, "visible": true, "type": "string" },
        //{ "id": "advisorName", "dataPath": "advisorName", "label": "Advisor", "width": 150, "visible": true, "type": "string" },
        { "id": "asistencia", "dataPath": "asistencia", "label": "Asistió", "width": 80, "visible": true, "type": "string" },
        { "id": "participacion", "dataPath": "participacion", "label": "Participó", "width": 80, "visible": true, "type": "string" },
    ];
    $w("#tablaAsistencia").rows = clases;
}

// Actualiza el grupo de checkboxes con los niveles completados
function updateCheckboxGroup(nivelesCompletados) {
    const options = Object.keys(nivelesCompletados).map(nivel => ({
        label: nivel,
        value: nivel
    }));
    const values = Object.keys(nivelesCompletados).filter(nivel => nivelesCompletados[nivel]);

    $w("#nivelesStatus").options = options;
    $w("#nivelesStatus").value = values;
}

// Configura el evento de selección de filas en la tabla
function setupTableRowSelection() {
    $w("#tablaAsistencia").onRowSelect(async (event) => {
        selectedRowData = event.rowData; // Guarda la fila seleccionada en la variable global
        console.log("Fila seleccionada en tabla:", selectedRowData);
        console.log("ID (_id) del registro seleccionado:", selectedRowData._id);
        if (!selectedRowData.idEvento) {
            console.warn("La fila seleccionada no contiene un idEvento.");
            return;
        }

        try {
            $w('#grupoInfoGeneral').show();
            $w('#grupoAgendar').hide();
            $w('#grupoComentarios').hide();

            // Buscar información del evento en CLASSES
            const eventDetails = await queryClassesById(selectedRowData.idEvento);

            if (!eventDetails) {
                console.warn("No se pudo cargar el evento correspondiente a la fila seleccionada.");
                return;
            }

            console.log("Valores crudos desde CLASSES:", {
                asistencia: eventDetails.asistencia,
                participacion: eventDetails.participacion,
                id: eventDetails._id
            });

            displayEventDetails(eventDetails);

            console.log("ID EVENTO PARA TABLA", selectedRowData.idEvento)

            // Buscar el nombre del advisor
            if (eventDetails.advisor) {
                const advisorData = await queryAdvisorName(eventDetails.advisor);

                if (advisorData) {
                    $w('#advisor').text = advisorData.nombre;
                    console.log("Nombre del teacher:", advisorData.nombre,
                        "Del evento:", selectedRowData.idEvento,
                        "Id del Advisor:", advisorData.id);
                } else {
                    $w('#advisor').text = "No asignado";
                    console.log("Advisor no encontrado");
                }
            }

        } catch (error) {
            console.error("Error al procesar la fila seleccionada:", error);
        }
    });
}

// Realiza un query en la base de datos CLASSES para obtener detalles del evento
async function queryClassesById(idEvento) {
    const result = await wixData.query("CLASSES")
        .eq("idEvento", idEvento)
        .find();

    for (let item of result.items) {
        if (!item.idEstudiante) continue;

        const academica = await wixData.get("ACADEMICA", item.idEstudiante);
        if (String(academica.numeroId) === String(numeroId)) {
            return item;
        }
    }

    console.warn(`⚠️ No se encontró evento con idEvento = ${idEvento} y numeroId = ${numeroId}`);
    return null;
}

// Muestra los detalles del evento en los campos correspondientes
function displayEventDetails(eventDetails) {
    if (!eventDetails) return;

    $w('#fechaEvento').text = moment(eventDetails.fechaEvento).format('D MMM YYYY, hh:mm A');
    $w('#nivel').text = eventDetails.nivel || "N/A";
    $w('#step').text = eventDetails.step || "N/A";
    $w('#asistenciaCheckBox').checked = eventDetails.asistencia === true;
    $w('#participacionCheckBox').checked = eventDetails.participacion === true;
    $w('#calificacion').value = eventDetails.calificacion || 0;
    $w('#advisorAnotaciones').value = eventDetails.advisorAnotaciones;
    $w('#comentariosParaUsuario').value = eventDetails.comentarios;

}

// Realiza un query en la base de datos ADVISORS para obtener el nombre del advisor
async function queryAdvisorName(advisorId) {
    const result = await wixData.query("ADVISORS").eq("_id", advisorId).find();
    if (result.items.length > 0) {
        const advisor = result.items[0];
        return {
            id: advisor._id,
            nombre: `${advisor.primerNombre} ${advisor.primerApellido}`
        };
    }
    return null;
}

async function loadEventDropdown() {
    try {
        if (!nivel) {
            console.warn("El nivel del usuario no está definido.");
            return;
        }

        if (!selectedEventType) {
            console.warn("No se ha seleccionado SESSION o CLUB.");
            return;
        }

        // Creamos un arreglo con los próximos 5 días (incluyendo hoy)
        const today = new Date();
        const days = [];
        for (let i = 0; i < 5; i++) {
            const d = new Date();
            d.setDate(today.getDate() + i);
            days.push(d);
        }

        // Formateamos cada día
        const options = days.map(d => {
            return {
                label: moment(d).format('dddd, D MMM'), // Ej: "lunes, 13 mar"
                value: moment(d).format('YYYY-MM-DD') // "YYYY-MM-DD"
            };
        });

        // Asignamos las opciones al dropdown
        $w("#eventoDropdown").options = options;
        // Opcionalmente, podrías resetear diaDropdown:
        $w("#diaDropdown").options = [];

    } catch (error) {
        console.error("Error al cargar los próximos 5 días:", error);
    }
}

/**
 * Carga en #diaDropdown las horas de eventos disponibles
 * para el nivel y día seleccionados, filtrando por el tipo (SESSION o CLUB).
 */
async function loadDateDropdown(selectedDay) {
    try {
        if (!nivel) {
            console.warn("El nivel del usuario no está definido.");
            return;
        }

        if (!selectedEventType) {
            console.warn("No se ha seleccionado SESSION o CLUB.");
            return;
        }

        // Convertir 'YYYY-MM-DD' a objeto Date
        const dayDate = new Date(selectedDay);

        // Definir inicio y fin del día
        const zonaUsuario = Intl.DateTimeFormat().resolvedOptions().timeZone;
        const startOfDay = moment.tz(selectedDay, zonaUsuario).startOf('day').toDate();
        const endOfDay = moment.tz(selectedDay, zonaUsuario).endOf('day').toDate();

        // Consulta a la colección CALENDARIO
        const results = await wixData.query("CALENDARIO")
            .eq("tituloONivel", nivel)
            .eq("evento", selectedEventType)
            .ge("dia", startOfDay)
            .le("dia", endOfDay)
            .ascending("dia")
            .find();

        // Mapeamos cada item para mostrar la hora, el nivel y el step
        const options = results.items.map(item => {
            const hora = moment(item.dia).format('hh:mm A');
            const nivelTitulo = item.tituloONivel;

            // Aquí aplicamos tu lógica de Step vs Jump
            let stepLabel = "Sin Step";
            if (item.nombreEvento) {
                const stepNumber = parseInt(item.nombreEvento.replace("Step ", ""));
                const jumps = [5, 10, 15, 20, 25, 30, 35, 40, 45];
                if (jumps.includes(stepNumber)) {
                    stepLabel = "Jump";
                } else {
                    stepLabel = `Step ${stepNumber}`;
                }
            }

            return {
                label: `${hora} - ${nivelTitulo} (${stepLabel})`,
                value: item._id
            };
        });

        $w("#diaDropdown").options = options;
    } catch (error) {
        console.error("Error al cargar las fechas y horas:", error);
    }
}

$w("#guardarEvento").onClick(async () => {
    try {
        const selectedDateId = $w("#diaDropdown").value; // Obtener el _id del item seleccionado
        if (!selectedDateId) {
            console.warn("No se ha seleccionado una fecha válida");
            return;
        }

        // Hacer un query en CALENDARIO para obtener la información del item seleccionado
        const eventDataResult = await wixData.query("CALENDARIO")
            .eq("_id", selectedDateId) // Filtrar por el _id del item seleccionado
            .find();

        if (eventDataResult.items.length === 0) {
            console.warn("No se encontró información para el _id seleccionado:", selectedDateId);
            return;
        }

        const eventData = eventDataResult.items[0]; // Obtenemos el item correspondiente

        // Llamar a queryAcademica para obtener los datos del estudiante
        const studentData = await queryAcademica(numeroId); // `numeroId` debe estar definido previamente
        if (!studentData) {
            console.warn("No se encontró información del estudiante:", numeroId);
            return;
        }

        // Crear el nuevo registro para insertar en CLASSES
        const newItem = {
            fechaEvento: eventData.dia, // Fecha del evento desde CALENDARIO
            idEstudiante: studentData._id, // ID del estudiante
            primerNombre: studentData.primerNombre, // Nombre del estudiante
            primerApellido: studentData.primerApellido,
            nivel: eventData.tituloONivel, // Nivel del estudiante
            numeroId: studentData.idEstudiante,
            tipoEvento: eventData.evento, // Información del evento desde CALENDARIO
            step: eventData.nombreEvento,
            idEvento: eventData._id,
            advisor: eventData.advisor,
            celular: studentData.celular,
        };
        console.log("idEvento que se está guardando:", newItem.idEvento);

        // Inserta el nuevo registro en la base de datos CLASSES
        try {
            const result = await wixData.insert("CLASSES", newItem);
            console.log("Nuevo registro guardado en CLASSES:", result);
        } catch (error) {
            console.error("Error al guardar en CLASSES:", error);
        }

        try {
            const bookingResult = await wixData.insert("BOOKING", newItem);
            console.log("Nuevo registro guardado en BOOKING:", bookingResult);
        } catch (error) {
            console.error("Error al guardar en BOOKING:", error);
        }

        // Notificación visual de éxito
        $w("#guardarEvento").disable();
        $w("#guardarEvento").label = "Evento guardado";
    } catch (error) {
        console.error("Error al guardar el evento:", error);
    }
});

// PREPARAR COMENTARIOS

async function prepararCampoComentario(elementId, email) {
    console.log("usuario email para coments:", email); // Verifica si el email llega correctamente aquí

    if (!email) {
        console.warn("El email proporcionado es inválido o no existe.");
        return;
    }

    try {
        // Realizar la consulta a ADVISORS
        const advisorResults = await wixData.query("ADVISORS")
            .eq("email", email)
            .find();

        if (advisorResults.items.length === 0) {
            console.warn("No se encontró un advisor con el email proporcionado:", email);
            return;
        }

        const advisor = advisorResults.items[0];
        const advisorName = `${advisor.primerNombre} ${advisor.primerApellido}`;

        let comentarioActual = $w(elementId).value;
        if (!comentarioActual.trim()) {
            comentarioActual = `Fecha: ${obtenerFechaActualComoString()}\nAdvisor: ${advisorName}\n`;
            $w(elementId).value = comentarioActual;
        }
    } catch (error) {
        console.error("Error al preparar el campo de comentario:", error);
    }
}

function obtenerFechaActualComoString() {
    const fecha = new Date();
    return fecha.toLocaleDateString('es-CL', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric'
    });
}

$w("#guardarButton").onClick(async () => {
    console.log("guardando");
    try {
        if (!selectedRowData || !selectedRowData._id) {
            console.warn("No hay una fila válida seleccionada en la tabla.");
            return;
        }

        // Obtener el item directamente por _id
        const itemToUpdate = await wixData.get("CLASSES", selectedRowData._id);

        // Obtener los valores de los campos a actualizar
        const updatedFields = {
            asistencia: $w("#asistenciaCheckBox").checked,
            participacion: $w("#participacionCheckBox").checked,
            calificacion: $w("#calificacion").value,
            advisorAnotaciones: $w("#advisorAnotaciones").value.trim(),
            comentarios: $w("#comentariosParaUsuario").value.trim()
        };

        const updatedItem = { ...itemToUpdate, ...updatedFields };

        await wixData.update("CLASSES", updatedItem);
        console.log("Registro actualizado exitosamente:", updatedItem);

        $w("#guardarButton").label = "Guardado ✔";
        setTimeout(() => $w("#guardarButton").label = "Guardar", 2000);
    } catch (error) {
        console.error("Error al actualizar el registro:", error);
    }
});

$w("#eliminarButton").onClick(async () => {
    try {
        if (!selectedRowData || !selectedRowData._id) {
            console.warn("No hay una fila válida seleccionada para eliminar.");
            return;
        }

        $w('#eliminarButton').label = "Eliminando...";

        await wixData.remove("CLASSES", selectedRowData._id);
        console.log("Evento eliminado correctamente:", selectedRowData._id);

        // Feedback visual
        $w('#eliminarButton').label = "Eliminado ✔";
        setTimeout(() => $w('#eliminarButton').label = "Eliminar Evento", 2000);

        // Recargar los datos actualizados
        loadStudentData(numeroId);

    } catch (error) {
        console.error("Error al eliminar el evento:", error);
    }
});

$w("#cambiarStepButton").onClick(async () => {
    try {
        const stepSeleccionado = $w("#nuevoStep").value;
        const nuevoStep = "Step " + stepSeleccionado
        if (!nuevoStep) {
            console.warn("Debes seleccionar un nuevo Step.");
            return;
        }
        console.log("ESTE ES STEP PARA MODIFICAR: ", nuevoStep)
        // 1. Buscar el nivel asociado al nuevoStep en NIVELES
        const nivelesResult = await wixData.query("NIVELES")
            .eq("step", nuevoStep)
            .find();

        if (nivelesResult.items.length === 0) {
            console.warn(`No se encontró un nivel asociado al step: ${nuevoStep}`);
            return;
        }

        const nuevoNivel = nivelesResult.items[0].code; // El campo 'code' será el nuevo nivel
        console.log(`Nuevo nivel obtenido desde NIVELES: ${nuevoNivel}`);

        // 2. Actualizar en ACADEMICA
        const academicaResult = await wixData.query("ACADEMICA")
            .eq("numeroId", numeroId)
            .find();

        if (academicaResult.items.length === 0) {
            console.warn("No se encontró el estudiante en ACADEMICA.");
            return;
        }

        const academicaItem = academicaResult.items[0];
        academicaItem.step = nuevoStep;
        academicaItem.nivel = nuevoNivel;
        await wixData.update("ACADEMICA", academicaItem);
        console.log("Step y nivel actualizados en ACADEMICA:", nuevoStep, nuevoNivel);

        // 3. Actualizar en PEOPLE usando usuarioId = _id de ACADEMICA
        const userId = academicaItem.usuarioId;
        const peopleResult = await wixData.query("PEOPLE")
            .eq("_id", userId)
            .find();

        if (peopleResult.items.length === 0) {
            console.warn("No se encontró el usuario en PEOPLE con _id:", userId);
            return;
        }

        const peopleItem = peopleResult.items[0];
        peopleItem.step = nuevoStep;
        peopleItem.nivel = nuevoNivel;
        await wixData.update("PEOPLE", peopleItem);
        console.log("Step y nivel actualizados en PEOPLE:", nuevoStep, nuevoNivel);

        // Mostrar feedback visual
        $w("#stepActual").value = nuevoStep;
        $w("#cambiarStepButton").label = "Step actualizado ✔";
        setTimeout(() => $w("#cambiarStepButton").label = "Actualizar Step", 2000);
    } catch (error) {
        console.error("Error al actualizar el Step y Nivel:", error);
    }
});

function esStepCompletado(step, stepInfo) {
    return stepInfo?.sesionesAprobadas >= 2 && stepInfo?.tieneTraining;
}

async function cargarStepsDelNivel(nivel, idAcademica) {
    // 1. Todos los steps posibles de ese nivel
    const result = await wixData.query("NIVELES")
        .eq("code", nivel)
        .ascending("step")
        .find();

    // 2. Steps marcados manualmente
    const overrides = await wixData.query("STEP_OVERRIDES")
        .eq("userId", idAcademica)
        .find();

    // 3. Steps completados realmente
    const progreso = await getFormattedClasses(idAcademica, nivel);
    // progreso.asistenciaMap es un Map con step -> info
    // Usa tu función esStepCompletado para cada uno

    // 4. Marca los steps que ya están completos o override manual
    const steps = result.items.map(item => {
        let completado = false;
        if (progreso.asistenciaMap && typeof progreso.asistenciaMap.get === "function") {
            const stepInfo = progreso.asistenciaMap.get(item.step);
            completado = esStepCompletado(item.step, stepInfo);
        }
        const override = overrides.items.some(o => o.step === item.step);

        return {
            _id: item._id,
            step: item.step,
            checkCompletado: completado || override
        };
    });

    $w("#repeaterSteps").data = steps;
}