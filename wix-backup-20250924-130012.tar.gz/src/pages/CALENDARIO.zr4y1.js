import wixData from 'wix-data';
import moment from 'moment';
import { exportarClasesComoCsv } from 'backend/excel';
import wixLocation from 'wix-location';

let modoEdicion = false;
let idEventoActual = null;

$w.onReady(function () {
    cargarHorasDropdown();
    cargarMeses(); // Llenar el dropdown con los meses

    // Agrega el evento onChange para actualizar el calendario cuando se cambia el mes
    $w("#mes").onChange(() => {
        repetidorDias();
    });

    cargarSteps();
    cargarCodigos();
    cargarNombreClub();
    cargarAdvisors();
    repetidorDias(); // Cargar el calendario inicialmente

    $w("#tipoEvento").onChange(() => {
        const tipoSeleccionado = $w("#tipoEvento").value;
        if (tipoSeleccionado === "CLUB") {
            $w("#clubStep").show();
            $w('#nombreClub').hide();
            cargarStepsPorNivel();
        } else {
            $w("#clubStep").hide();
            $w("#nombreClub").options = [];
        }
    });

});

function cargarStepsPorNivel() {
    const nivelSeleccionado = $w("#nivelDropDown").value;
    if (!nivelSeleccionado) return;

    wixData.query("NIVELES")
        .eq("code", nivelSeleccionado)
        .find()
        .then((results) => {
            const steps = results.items.map(item => item.step);
            const opciones = steps.map(step => ({
                value: step,
                label: getStepLabel(step)
            }));
            $w("#clubStep").options = opciones;

        })
        .catch((err) => {
            console.error("Error al cargar steps en clubStep:", err);
        });
}

$w("#clubStep").onChange(() => {
    const stepSeleccionado = $w("#clubStep").value;
    const nivelSeleccionado = $w("#nivelDropDown").value;
    if (!stepSeleccionado || !nivelSeleccionado) return;

    wixData.query("NIVELES")
        .eq("code", nivelSeleccionado)
        .eq("step", stepSeleccionado)
        .find()
        .then((results) => {
            if (results.items.length > 0) {
                const clubs = results.items[0].clubs || [];
                const opcionesClub = clubs.map(club => ({
                    value: club,
                    label: club
                }));
                $w("#nombreClub").options = opcionesClub;
                $w('#nombreClub').show()
                $w('#clubStep').hide();
            }
        })
        .catch((err) => {
            console.error("Error al cargar clubs:", err);
        });
});

function cargarMeses() {
    const meses = [
        { label: "ENERO", value: "0" },
        { label: "FEBRERO", value: "1" },
        { label: "MARZO", value: "2" },
        { label: "ABRIL", value: "3" },
        { label: "MAYO", value: "4" },
        { label: "JUNIO", value: "5" },
        { label: "JULIO", value: "6" },
        { label: "AGOSTO", value: "7" },
        { label: "SEPTIEMBRE", value: "8" },
        { label: "OCTUBRE", value: "9" },
        { label: "NOVIEMBRE", value: "10" },
        { label: "DICIEMBRE", value: "11" }
    ];
    $w("#mes").options = meses;
    $w("#mes").value = new Date().getMonth().toString();
}

function repetidorDias() {
    // Usar el mes seleccionado en el dropdown "mes"
    const mesSeleccionado = parseInt($w("#mes").value, 10);
    const anoActual = new Date().getFullYear();

    // Definir el primer día del mes seleccionado
    const primerDiaDelMes = moment(new Date(anoActual, mesSeleccionado, 1));
    let primerDiaAMostrar = moment(primerDiaDelMes);
    while (primerDiaAMostrar.day() !== 0) { // Iniciar en domingo
        primerDiaAMostrar.subtract(1, 'days');
    }

    // Definir el último día del mes seleccionado
    const ultimoDiaDelMes = moment(new Date(anoActual, mesSeleccionado + 1, 0));
    let ultimoDiaAMostrar = moment(ultimoDiaDelMes);
    while (ultimoDiaAMostrar.day() !== 6) { // Terminar en sábado
        ultimoDiaAMostrar.add(1, 'days');
    }

    let diasParaMostrar = ultimoDiaAMostrar.diff(primerDiaAMostrar, 'days') + 1;

    // Crear el arreglo de días
    let dias = [];
    for (let i = 0; i < diasParaMostrar; i++) {
        const fecha = moment(primerDiaAMostrar).add(i, 'days');
        const dia = fecha.date();
        const diaSemana = fecha.day();
        // Comparar con el mes seleccionado para marcar los días que corresponden
        const esDiaDelMesActual = fecha.month() === mesSeleccionado;
        const etiquetaDia = `${dia}`;

        dias.push({
            _id: i.toString(),
            etiquetaDia,
            esDiaDelMesActual,
            diaSemana,
            fecha: fecha.toDate()
        });
    }

    // Asignar los días al repetidor
    $w("#repetidorDias").data = dias;

    // Configurar cada item del repetidor
    $w("#repetidorDias").onItemReady(($item, itemData) => {
        // Asignar el texto del día
        $item("#dia").text = itemData.etiquetaDia;

        // Ocultar días fuera del mes
        if (!itemData.esDiaDelMesActual) {
            $item("#containerRegistros").hide();
        } else {
            $item("#containerRegistros").show();
        }

        // Cambiar el fondo según si es sábado o domingo
        if (itemData.diaSemana === 0 || itemData.diaSemana === 6) {
            $item("#boxEventos").style.backgroundColor = "#f0f0f0";
        } else {
            $item("#boxEventos").style.backgroundColor = "#ffffff";
        }

        // Cambiar el estilo del texto según si pertenece al mes seleccionado
        if (!itemData.esDiaDelMesActual) {
            $item("#dia").html = `<span style="font-family: Arial; font-size: 15px; color: #808080;">${itemData.etiquetaDia}</span>`;
        } else {
            $item("#dia").html = `<span style="font-family: Arial; font-size: 15px; color: #000000;">${itemData.etiquetaDia}</span>`;
        }

        // Agregar evento onClick para ejecutar la consulta al hacer clic en el día
        $item("#dia").onClick(() => {
            // Definir inicio y fin del día (para tu query)
            const startOfDay = moment(itemData.fecha).startOf('day').toDate();
            const endOfDay = moment(itemData.fecha).endOf('day').toDate();

            // Formatear la fecha para mostrar el mes y el día.
            // Si deseas los nombres de los meses en español, puedes configurar moment en español.
            moment.locale('es');
            const fechaFormateada = moment(itemData.fecha).format('MMMM');
            const diaFormateado = moment(itemData.fecha).format('DD');

            // Asignar la fecha formateada al campo de texto "fechaTitulo"
            $w('#diaTitulo').text = diaFormateado;
            $w('#diaTituloGroup').show();
            $w("#fechaTitulo").text = fechaFormateada;
            $w('#fechaTitulo').show();

            // Ejecutar la consulta de eventos para ese día (tu lógica existente)
            wixData.query("CALENDARIO")
                .between("dia", startOfDay, endOfDay)
                .limit(1000)  // Aumentar límite para obtener todos los eventos del día
                .find()
                .then((results) => {
                    console.log("Eventos encontrados para el día:", results.items);
                    mostrarAgendaDia(itemData.fecha, results.items);
                })
                .catch((err) => {
                    console.error("Error al obtener eventos:", err);
                });
        });

    });

    console.log("Días generados en el calendario:", dias.length);
}

$w("#guardar").onClick(async event => {
    let fechaEvento;
    if (modoEdicion) {
        fechaEvento = await actualizarEvento();
    } else {
        fechaEvento = await guardarEvento();
    }
    // Actualizar la agenda del día con la fecha del evento guardado o actualizado
    mostrarAgendaDia(fechaEvento);
});

async function actualizarEvento() {
    let tipoEvento = $w("#tipoEvento").value;
    let advisorId = $w("#advisor").value;
    let tituloONivel = $w("#nivelDropDown").value;
    let observaciones = $w("#observacionesBox").value;
    let hora = $w("#horaDropDown").value;
    
    // Validar campos obligatorios
    if (!advisorId) {
        alert("Por favor, selecciona un advisor antes de actualizar el evento.");
        return;
    }
    
    if (!tipoEvento) {
        alert("Por favor, selecciona el tipo de evento.");
        return;
    }
    
    if (!tituloONivel) {
        alert("Por favor, selecciona el nivel.");
        return;
    }
    
    if (!hora) {
        alert("Por favor, selecciona la hora.");
        return;
    }

    // Asegurar que la hora tenga formato correcto HH:00
    let horaFormateada = hora;
    if (!hora.includes(':')) {
        horaFormateada = `${hora}:00`;
    }
    let fechaEventoObj = parsearFechaYHora(`${$w("#fechaEvento").text} ${horaFormateada}`);

    let limiteUsuarios = $w('#limiteUsuariosDrop').value;
    let nombreEvento = $w('#nombreClub').value;
    let linkZoom = $w('#zoomAdvisor').value.trim();

    if (!limiteUsuarios) {
        limiteUsuarios = tipoEvento === "SESSION" ? "7" : "20";
    }

    let eventoAActualizar = {
        _id: idEventoActual,
        dia: fechaEventoObj,
        evento: tipoEvento,
        tituloONivel: tituloONivel,
        advisor: advisorId,
        observaciones: observaciones,
        limiteUsuarios: limiteUsuarios,
        nombreEvento: nombreEvento,
        linkZoom: linkZoom
    };

    console.log("Actualizando evento con datos:", eventoAActualizar);

    try {
        await wixData.update("CALENDARIO", eventoAActualizar);
        console.log("Evento actualizado correctamente!");

        // Actualizar la colección BOOKING si corresponde
        let bookingResults = await wixData.query("BOOKING")
            .eq("idEvento", idEventoActual)
            .limit(1000)  // Por seguridad, aunque no debería haber tantos bookings por evento
            .find();

        if (bookingResults.items.length > 0) {
            let updates = bookingResults.items.map(async (booking) => {
                booking.dia = fechaEventoObj;
                booking.evento = tipoEvento;
                booking.tituloONivel = tituloONivel;
                booking.advisor = advisorId;
                booking.observaciones = observaciones;
                booking.limiteUsuarios = limiteUsuarios;
                booking.nombreEvento = nombreEvento;
                booking.linkZoom = linkZoom;

                await wixData.update("BOOKING", booking);
                console.log("Evento actualizado correctamente en BOOKING!");
            });

            await Promise.all(updates);
        } else {
            console.log("No se encontraron registros en BOOKING para este evento.");
        }

        // Limpiar los campos
        $w("#tipoEvento").value = "";
        $w("#advisor").value = "";
        $w("#nivelDropDown").value = "";
        $w("#observacionesBox").value = "";
        $w("#horaDropDown").value = "";
        $w("#limiteUsuariosDrop").value = "";
        $w("#zoomAdvisor").value = "";

        modoEdicion = false;
        idEventoActual = null;

        return fechaEventoObj;
    } catch (err) {
        console.error("Error al actualizar el evento:", err);
    }
}

async function guardarEvento() {
    let tipoEvento = $w("#tipoEvento").value;
    let advisorId = $w("#advisor").value;
    let fechaEvento = $w("#fechaEvento").text;
    let tituloONivel = $w("#nivelDropDown").value;
    let observaciones = $w("#observacionesBox").value;
    let hora = $w("#horaDropDown").value;
    let limiteUsuarios = $w("#limiteUsuariosDrop").value;
    let nombreEvento = $w("#nombreClub").value;
    let linkZoom = $w("#zoomAdvisor").value.trim(); // Obtener el valor del zoom y asegurarse de eliminar espacios en blanco

    // Validar campos obligatorios
    if (!advisorId) {
        alert("Por favor, selecciona un advisor antes de guardar el evento.");
        return;
    }
    
    if (!tipoEvento) {
        alert("Por favor, selecciona el tipo de evento.");
        return;
    }
    
    if (!tituloONivel) {
        alert("Por favor, selecciona el nivel.");
        return;
    }
    
    if (!hora) {
        alert("Por favor, selecciona la hora.");
        return;
    }

    if (!limiteUsuarios) {
        limiteUsuarios = tipoEvento === "SESSION" ? "7" : "20";
    }

    // Asegurar que la hora tenga formato correcto HH:00
    let horaFormateada = hora;
    if (!hora.includes(':')) {
        horaFormateada = `${hora}:00`;
    }
    let fechaEventoObj = parsearFechaYHora(`${fechaEvento} ${horaFormateada}`);

    let eventoAGuardar = {
        dia: fechaEventoObj,
        evento: tipoEvento,
        tituloONivel: tituloONivel,
        advisor: advisorId,
        observaciones: observaciones,
        limiteUsuarios: limiteUsuarios,
        nombreEvento: nombreEvento,
        linkZoom: linkZoom // Asegurar que el linkZoom se incluya en la estructura del evento
    };

    console.log("Guardando evento con datos:", eventoAGuardar);

    try {
        await wixData.insert("CALENDARIO", eventoAGuardar);
        console.log("Evento guardado correctamente!");
        $w("#crearEventoBox").hide();

        // Llamar a la función para actualizar solo la tabla de la hora del evento guardado
        actualizarTablaDiaRepetidor(fechaEventoObj);

        // Limpiar los campos
        $w("#tipoEvento").value = "";
        $w("#advisor").value = "";
        $w("#nivelDropDown").value = "";
        $w("#observacionesBox").value = "";
        $w("#horaDropDown").value = "";
        $w("#nombreClub").value = "";
        $w("#limiteUsuariosDrop").value = "";
        $w("#zoomAdvisor").value = ""; // Limpiar el campo de zoom después de guardar

        return fechaEventoObj;
    } catch (err) {
        console.error("Error al guardar el evento:", err);
    }
}

function mostrarAgendaDia(fechaSeleccionada, eventos) {
    // Si eventos no está definido, hacer la consulta a la base de datos
    if (!eventos) {
        const startOfDay = moment(fechaSeleccionada).startOf('day').toDate();
        const endOfDay = moment(fechaSeleccionada).endOf('day').toDate();

        wixData.query("CALENDARIO")
            .between("dia", startOfDay, endOfDay)
            .limit(1000)

            .find()
            .then((results) => {
                console.log("Eventos encontrados para el día (query interna):", results.items.length);
                
                // Verificar y reportar eventos con horas problemáticas  
                const eventosConHoraCero = results.items.filter(evento => {
                    const hora = new Date(evento.dia).getHours();
                    return hora === 0;
                });
                
                if (eventosConHoraCero.length > 0) {
                    console.warn(`⚠️ Hay ${eventosConHoraCero.length} eventos con hora 00:00 que podrían tener la hora incorrecta`);
                    eventosConHoraCero.forEach(evento => {
                        console.warn(`  - Evento ${evento._id}: ${evento.evento} ${evento.tituloONivel}`);
                    });
                }
                
                // Mostrar resumen de eventos por hora
                const eventosPorHora = {};
                results.items.forEach(evento => {
                    const hora = new Date(evento.dia).getHours();
                    eventosPorHora[hora] = (eventosPorHora[hora] || 0) + 1;
                });
                
                console.log("Distribución de eventos por hora:", eventosPorHora);
                
                procesarEventosDelDia(fechaSeleccionada, results.items);
            })
            .catch((err) => {
                console.error("Error al obtener eventos:", err);
            });
    } else {
        // Si ya se pasaron eventos, procesarlos directamente
        procesarEventosDelDia(fechaSeleccionada, eventos);
    }
}

function procesarEventosDelDia(fechaSeleccionada, eventos) {
    // 1) Definir las horas del día (de 6 a 20)
    const horasDelDia = [];
    for (let hora = 6; hora <= 22; hora++) {
        horasDelDia.push({
            _id: `${hora}`,
            hora: `${hora < 10 ? '0' : ''}${hora}:00`,
            eventos: []
        });
    }

    // 2) Obtener nombres de los advisors y contar inscripciones para cada evento
    Promise.all(eventos.map(async (evento) => {
        try {
            const nombreAdvisor = evento.advisor ? await obtenerNombreAdvisor(evento.advisor) : "Sin asignar";

            // Contar inscripciones en BOOKING donde idEvento es igual al _id del evento y el campo "cancelo" está vacío
            const inscritos = await wixData.query("BOOKING")
                .eq("idEvento", evento._id)
                .isEmpty("cancelo")
                .count();
            console.log("Inscritos para evento:", inscritos, evento._id, evento.dia);

            return {
                _id: evento._id,
                evento: evento.evento,
                tituloONivel: evento.tituloONivel,
                nombreEvento: evento.nombreEvento,
                advisorId: evento.advisor || null,
                advisorNombre: nombreAdvisor,
                dia: evento.dia,
                observaciones: evento.observaciones || "",
                inscritos: inscritos
            };
        } catch (error) {
            console.error("Error procesando evento:", evento._id, error);
            return {
                _id: evento._id,
                evento: evento.evento || "Error",
                tituloONivel: evento.tituloONivel || "",
                nombreEvento: evento.nombreEvento || "",
                advisorId: evento.advisor || null,
                advisorNombre: "Error al cargar",
                dia: evento.dia,
                observaciones: evento.observaciones || "",
                inscritos: 0
            };
        }
    }))
        .then((eventosConAdvisors) => {
            // 3) Agrupar eventos por hora - Optimizado
            // Primero, crear un mapa de eventos por hora para evitar múltiples iteraciones
            const eventosPorHora = {};
            
            eventosConAdvisors.forEach(evento => {
                if (!evento.dia) {
                    console.warn('Evento sin fecha:', evento);
                    return;
                }
                const eventoHora = new Date(evento.dia).getHours();
                
                if (!eventosPorHora[eventoHora]) {
                    eventosPorHora[eventoHora] = [];
                }
                eventosPorHora[eventoHora].push(evento);
            });
            
            // Luego asignar los eventos a cada hora
            horasDelDia.forEach(horaObj => {
                const horaBase = parseInt(horaObj._id, 10);
                horaObj.eventos = eventosPorHora[horaBase] || [];
                
                if (horaObj.eventos.length > 0) {
                    console.log(`Hora ${horaBase}:00 tiene ${horaObj.eventos.length} evento(s)`);
                }
            });

            // 4) Asignar los datos al repetidor
            $w("#agendaDiaRepetidor").data = horasDelDia;

            // 5) Configurar onItemReady para mostrar los eventos en la tabla
            $w("#agendaDiaRepetidor").onItemReady(($item, itemData) => {
                $item("#hora").text = itemData.hora;
                $item("#tablaDiaRepetidor").rows = itemData.eventos;
                $item("#tablaDiaRepetidor").columns = [
                    { id: "evento", label: "Evento", dataPath: "evento", type: "string" },
                    { id: "tituloONivel", label: "Título/Nivel", dataPath: "tituloONivel", type: "string" },
                    { id: "nombreEvento", label: "Nombre del Evento", dataPath: "nombreEvento", type: "string" },
                    { id: "advisorNombre", label: "Asesor", dataPath: "advisorNombre", type: "string" },
                    { id: "inscritos", label: "Inscritos", dataPath: "inscritos", type: "number" }
                ];

                // Ocultar la tabla por defecto
                $item("#tablaDiaRepetidor").collapse();

                // Al hacer clic en la hora, expandir/colapsar la tabla
                $item("#hora").onClick(() => {
                    console.log(`Click en hora ${itemData.hora} (ID: ${itemData._id})`);
                    console.log(`Eventos encontrados: ${itemData.eventos.length}`);
                    
                    if (itemData.eventos.length > 0) {
                        console.log("Eventos para esta hora:", itemData.eventos);
                        itemData.eventos.forEach(evt => {
                            console.log(`  - ${evt.evento} ${evt.tituloONivel} ${evt.nombreEvento} - Advisor: ${evt.advisorNombre}`);
                        });
                        
                        // Primero colapsar todas las otras tablas
                        $w("#agendaDiaRepetidor").forEachItem(($otherItem, otherItemData) => {
                            if (otherItemData._id !== itemData._id) {
                                $otherItem("#tablaDiaRepetidor").collapse();
                            }
                        });
                        
                        // Luego alternar el estado de la tabla actual
                        if ($item("#tablaDiaRepetidor").collapsed) {
                            $item("#tablaDiaRepetidor").expand();
                        } else {
                            $item("#tablaDiaRepetidor").collapse();
                        }
                    } else {
                        console.log(`No hay eventos para la hora ${itemData.hora}`);
                    }
                });

                // onRowSelect para manejar la selección de un evento
                $item("#tablaDiaRepetidor").onRowSelect(async event => {
                    const eventDetails = event.rowData;

                    // Establecer modo de edición y asignar el ID del evento
                    modoEdicion = true;
                    idEventoActual = eventDetails._id; // <-- Este es el ID real en la BD

                    $w("#crearEventoBox").show();

                    // Mostrar la fecha del evento en el formato correcto
                    let fechaEvento = moment(eventDetails.dia).toDate();
                    $w("#fechaEvento").text = moment(fechaEvento).format('DD/MM/YYYY') || "Fecha no disponible";

                    let eventHour = moment(fechaEvento).hours();
                    let horasDropdown = $w("#horaDropDown").options.map(opt => opt.value);
                    if (!horasDropdown.includes(eventHour.toString())) {
                        console.warn(`Hora "${eventHour}" no encontrada en el dropdown. Se añadirá.`);
                        $w("#horaDropDown").options = [...$w("#horaDropDown").options, { label: `${eventHour}:00`, value: eventHour.toString() }];
                    }
                    $w("#horaDropDown").value = eventHour.toString();
                    setDropdownValue($w("#tipoEvento"), eventDetails.evento);
                    setDropdownValue($w("#nivelDropDown"), eventDetails.tituloONivel);
                    setDropdownValue($w("#nombreClub"), eventDetails.nombreEvento);
                    $w("#observacionesBox").value = eventDetails.observaciones;

                    await cargarAdvisors();
                    setDropdownValue($w("#advisor"), eventDetails.advisorId);

                    try {
                        if (eventDetails.advisorId) {
                            const result = await wixData.query("ADVISORS")
                                .eq("_id", eventDetails.advisorId)
                                .find();
                            if (result.items.length > 0) {
                                const zoomValue = result.items[0].zoom;
                                $w("#zoomAdvisor").value = zoomValue;
                            } else {
                                $w("#zoomAdvisor").value = "";
                            }
                        } else {
                            $w("#zoomAdvisor").value = "";
                        }
                    } catch (error) {
                        console.error("Error obteniendo zoom del advisor:", error);
                    }
                });
            });
        })
        .catch((error) => {
            console.error("Error procesando los advisors e inscripciones:", error);
        });
}

function cargarHorasDropdown() {
    let opcionesHoras = [];
    for (let hora = 6; hora <= 22; hora++) {
        let horaFormateada = `${hora < 10 ? '0' + hora : hora}:00`;
        opcionesHoras.push({
            label: horaFormateada,
            value: hora.toString() // El valor es el número de la hora en formato string
        });
    }
    $w("#horaDropDown").options = opcionesHoras;
}

// Función para obtener el nombre del advisor concatenando primerNombre + primerApellido
async function obtenerNombreAdvisor(advisorId) {
    if (!advisorId) return "Sin asignar";

    try {
        const result = await wixData.query("ADVISORS")
            .eq("_id", advisorId)
            .find();

        if (result.items.length > 0) {
            const advisor = result.items[0];
            return `${advisor.primerNombre} ${advisor.primerApellido}`;
        }
    } catch (error) {
        console.error("Error obteniendo el nombre del advisor:", error);
    }

    return "Sin asignar";
}

// Función para cargar todos los advisors en el dropdown
async function cargarAdvisors() {
    try {
        const results = await wixData.query("ADVISORS").find();
        if (results.items.length > 0) {
            // Mapear y ordenar alfabéticamente por nombre completo
            let opciones = results.items
                .map(advisor => ({
                    label: `${advisor.primerNombre} ${advisor.primerApellido}`,
                    value: advisor._id
                }))
                .sort((a, b) => a.label.localeCompare(b.label)); // Orden alfabético

            $w("#advisor").options = opciones;
        }
    } catch (error) {
        console.error("Error cargando los advisors:", error);
    }
}

// Función para asignar valores en dropdowns asegurando que existan en las opciones
function setDropdownValue(dropdown, value) {
    let options = dropdown.options.map(opt => opt.value);

    if (!options.includes(value)) {
        console.warn(`Valor "${value}" no encontrado en el dropdown ${dropdown.id}. Se añadirá.`);
        dropdown.options = [...dropdown.options, { label: value, value: value }];
    }

    dropdown.value = value;
}

// Función para cargar los códigos (BN1, BN2, etc.) en el dropdown nivelDropDown
function cargarCodigos() {
    wixData.query("NIVELES")
        .distinct("code") // Obtener valores únicos del campo code
        .then((results) => {
            let opciones = results.items.map(item => {
                return { value: item, label: item };
            });
            $w("#nivelDropDown").options = opciones;
            //$w("#nivelDropSemana").options = opciones;
        })
        .catch((err) => {
            console.log(err);
        });
}

// Función para cargar los steps asociados a un código seleccionado
function cargarSteps() {
    const codigoSeleccionado = $w("#nivelDropDown").value;
    wixData.query("NIVELES")
        .eq("code", codigoSeleccionado)
        .find()
        .then((results) => {
            let opciones = results.items.map(item => {
                return { value: item.step, label: getStepLabel(item.step) };
            });

            console.log(results)
            $w("#nombreClub").options = opciones;
            // Asumiendo que tienes un dropdown para los steps
        })
        .catch((err) => {
            console.log(err);
        });
}

// Función para cargar los nombres de club si el tipo de evento es "CLUB"
async function cargarNombreClub(eventDetails) {
    const nivelSeleccionado = $w("#nivelDropDown").value;
    try {
        const result = await wixData.query("NIVELES")
            .eq("code", nivelSeleccionado)
            .find();

        if (result.items.length > 0) {
            const clubs = result.items[0].clubs;
            let opcionesClub = clubs.map(club => {
                return { value: club, label: club };
            });
            $w("#nombreClub").options = opcionesClub;

            // Después de cargar las opciones, establece el valor si existe en las opciones.
            if (eventDetails && opcionesClub.some(option => option.value === eventDetails.nombreEvento)) {
                $w("#nombreClub").value = eventDetails.nombreEvento;
            } else {
                console.warn("El nombre del evento no coincide con ninguna opción disponible en el dropdown.");
            }
        }
    } catch (err) {
        console.error("Error al cargar los nombres de club:", err);
    }
}

// Nueva función para cargar los nombres de step si el tipo de evento es "SESSION"
function cargarNombreStep() {
    const nivelSeleccionado = $w("#nivelDropDown").value;
    const tipoEventoSeleccionado = $w("#tipoEvento").value; // Obtener el valor del dropdown tipoEvento
    console.log("Nivel seleccionado:", nivelSeleccionado);
    console.log("Tipo de evento seleccionado:", tipoEventoSeleccionado);

    // Consultar la base de datos para obtener el nivel seleccionado
    wixData.query("NIVELES")
        .eq("code", nivelSeleccionado)
        .find()
        .then((result) => {
            console.log(result);

            if (result.items.length > 0) {
                let opciones = [];

                if (tipoEventoSeleccionado === "CLUB") {
                    // Si el evento es CLUB, obtener los valores del array "clubs"
                    const clubs = result.items[0].clubs || []; // Si el campo clubs no existe, se asigna un array vacío
                    opciones = clubs.map(club => ({
                        value: club,
                        label: club
                    }));
                    console.log("Opciones cargadas desde clubs:", opciones);
                } else {
                    // Si no es CLUB, obtener los valores de step
                    const steps = result.items.map(item => item.step);
                    opciones = steps.map(step => ({
                        value: step,
                        label: getStepLabel(step)
                    }));

                    console.log("Opciones cargadas desde steps:", opciones);
                }

                // Asignar las opciones al dropdown #nombreClub
                $w("#nombreClub").options = opciones;
            }
        })
        .catch((err) => {
            console.error("Error al cargar los nombres de step/clubs:", err);
        });
}

$w('#tipoEvento').onChange((event) => {
    cargarNombreStep();
})

$w('#button1').onClick((event) => {
    $w('#crearEventoBox').hide()
    modoEdicion = false; // Reinicia el estado de edición
    idEventoActual = null; // Reinicia el ID del evento actual   
})

// Función para parsear la fecha y la hora desde un formato "DD/MM/YYYY HH:MM"
function parsearFechaYHora(fechaHoraStr) {
    // Si solo viene la hora sin minutos, agregar :00
    if (fechaHoraStr && !fechaHoraStr.includes(':')) {
        const partes = fechaHoraStr.split(' ');
        if (partes.length === 2) {
            fechaHoraStr = `${partes[0]} ${partes[1]}:00`;
        }
    }
    console.log('Parseando fecha y hora:', fechaHoraStr);
    const resultado = moment(fechaHoraStr, 'DD/MM/YYYY HH:mm').toDate();
    console.log('Resultado del parseo:', resultado);
    return resultado;
}

$w("#eliminarRegistro").onClick(() => {
    if (idEventoActual) {

        eliminarEvento(idEventoActual);
    } else {
        console.log("No hay evento seleccionado para eliminar.");
    }
});

function eliminarEvento(idEvento) {
    // Verificar si hay usuarios asignados a esta sesión en la colección BOOKING
    wixData.query("BOOKING")
        .eq("idEvento", idEvento)
        .limit(1000)  // Por seguridad
        .find()
        .then((bookingResults) => {
            if (bookingResults.items.length > 0) {
                // Si hay usuarios asignados, muestra el avisoBox y el mensaje de error
                $w("#avisoBox").show();
                $w("#avisoText").text = "Hay usuarios asignados. No se puede eliminar.";
            } else {
                // No hay usuarios asignados, proceder a eliminar el evento
                wixData.get("CALENDARIO", idEvento)
                    .then((eventDetails) => {
                        if (eventDetails) {
                            const fechaEvento = eventDetails.dia;

                            // Proceder a eliminar el evento
                            wixData.remove("CALENDARIO", idEvento)
                                .then(() => {
                                    console.log("Evento eliminado con éxito");
                                    $w('#crearEventoBox').hide(); // Opcional: ocultar el cuadro después de la eliminación

                                    // Actualizar la agenda del día
                                    mostrarAgendaDia(fechaEvento); // Actualizar la agenda del día
                                })
                                .catch((err) => {
                                    console.error("Error al eliminar el evento:", err);
                                });
                        } else {
                            console.error("El evento no se encontró en la base de datos.");
                        }
                    })
                    .catch((err) => {
                        console.error("Error al obtener detalles del evento para actualizar la agenda:", err);
                    });
            }
        })
        .catch((err) => {
            console.error("Error al verificar si hay usuarios asignados:", err);
        });
}

//actualizar repetidor luego de borrar, actualizar o guardar un evento nuevo
function actualizarTablaDiaRepetidor(fechaEvento) {
    const horaEvento = new Date(fechaEvento).getHours();

    wixData.query("CALENDARIO")
        .between("dia", moment(fechaEvento).startOf('day').toDate(), moment(fechaEvento).endOf('day').toDate())
        .limit(1000)  // Aumentar límite para obtener todos los eventos
        .find()
        .then((results) => {
            const eventosDelDia = results.items;

            $w("#agendaDiaRepetidor").forEachItem(($item, itemData) => {
                const horaItem = parseInt(itemData._id, 10); // Suponiendo que _id almacena la hora

                if (horaItem === horaEvento) {
                    const eventosPorHora = eventosDelDia.filter(evento =>
                        new Date(evento.dia).getHours() === horaEvento
                    );

                    $item("#tablaDiaRepetidor").rows = eventosPorHora;
                }

            });

        })
        .catch((err) => {
            console.error("Error al actualizar la tabla del ítem:", err);
        });
}

//PAra crear un evento nuevo
$w('#diaTitulo').onClick(() => {
    modoEdicion = false;
    idEventoActual = null;

    // Limpiar los campos
    $w("#tipoEvento").value = "";
    $w("#advisor").value = "";
    $w("#nivelDropDown").value = "";
    $w("#observacionesBox").value = "";
    $w("#horaDropDown").value = "";
    $w("#nombreClub").value = "";
    $w("#limiteUsuariosDrop").value = "";
    $w("#zoomAdvisor").value = "";

    $w('#crearEventoBox').show();

    // Construir la fecha según el día y el mes
    $w("#fechaEvento").text = $w("#diaTitulo").text + "/" + (parseInt($w("#mes").value, 10) + 1) + "/" + new Date().getFullYear();
});

$w("#advisor").onChange(async () => {
    const advisorId = $w("#advisor").value;

    if (advisorId) {
        try {
            const result = await wixData.query("ADVISORS")
                .eq("_id", advisorId)
                .find();

            if (result.items.length > 0) {
                const advisor = result.items[0];
                $w("#zoomAdvisor").value = advisor.zoom || "";
            } else {
                $w("#zoomAdvisor").value = "";
                console.warn("Advisor no encontrado.");
            }
        } catch (err) {
            console.error("Error al consultar el zoom del advisor:", err);
        }
    }
});

$w("#descargarXLS").onClick(async () => {
    const fechaInicial = $w('#datePicker1').value;
    const fechaFinal = $w('#datePicker2').value;

    if (!fechaInicial || !fechaFinal) {
        console.warn("Debes seleccionar ambas fechas.");
        $w('#descargarXLS').label = "Selecciona las fechas!"
        return;
    }

    try {
        $w('#descargarXLS').label = "Descargando..."
        const resultados = await wixData.query("CALENDARIO")
            .between("dia", fechaInicial, fechaFinal)
            .limit(1000)
            .find();

        const eventos = await Promise.all(resultados.items.map(async (item) => {
            let primerNombre = "";
            let primerApellido = "";

            if (item.advisor) {
                const advisorResult = await wixData.get("ADVISORS", item.advisor);
                primerNombre = advisorResult?.primerNombre || "";
                primerApellido = advisorResult?.primerApellido || "";
            }

            return {
                Fecha: item.dia ? new Date(item.dia).toLocaleString() : "",
                Evento: item.evento || "",
                Nivel: item.tituloONivel || "",
                NombreEvento: item.nombreEvento || "",
                Observaciones: item.observaciones || "",
                Zoom: item.linkZoom || "",
                AdvisorNombre: primerNombre,
                AdvisorApellido: primerApellido
            };
        }));

        if (eventos.length === 0) {
            $w('#descargarXLS').label = "No hay eventos"

            console.warn("No hay eventos para exportar.");
            return;
        }

        const fileUrl = await exportarClasesComoCsv(eventos);
        wixLocation.to(fileUrl);
        $w('#descargarXLS').label = "Listo!"

    } catch (err) {
        console.error("❌ Error exportando calendario:", err);
        $w('#descargarXLS').label = "Error 😢";
    } finally {
        // Después de unos segundos, restaurar el texto original
        setTimeout(() => {
            $w('#descargarXLS').label = "Descargar XLS";
        }, 3000);
    }
});

function getStepLabel(step) {
    if (!step) return "Sin Step";

    const jumps = [5, 10, 15, 20, 25, 30, 35, 40, 45];
    let stepNumber = parseInt(step.replace("Step ", ""));

    if (jumps.includes(stepNumber)) {
        return `Jump (Step ${stepNumber})`;
    } else if (!isNaN(stepNumber)) {
        return `Step ${stepNumber}`;
    } else {
        return step;
    }
}