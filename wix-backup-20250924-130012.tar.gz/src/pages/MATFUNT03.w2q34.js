// Array con la secuencia (puedes colocarlo en un archivo separado o en el mismo script)
const secuencia = [
    { pagina: 1, nombre: "group15" },
    { pagina: 2, nombre: "image72" },
    { pagina: 3, nombre: "group14" },
    { pagina: 4, nombre: "group13" },
    { pagina: 5, nombre: "image69" },
    { pagina: 6, nombre: "group12" },
    { pagina: 7, nombre: "image67" },
    { pagina: 8, nombre: "group11" },
    { pagina: 9, nombre: "group10" },
    { pagina: 10, nombre: "image64" },
    { pagina: 11, nombre: "image63" },
    { pagina: 12, nombre: "image62" },
    { pagina: 13, nombre: "image61" },
    { pagina: 14, nombre: "image60" },
    { pagina: 15, nombre: "image59" },
    { pagina: 16, nombre: "group9" },
    { pagina: 17, nombre: "group8" },
    { pagina: 18, nombre: "group7" },
    { pagina: 19, nombre: "image55" },
    { pagina: 20, nombre: "image54" },
    { pagina: 21, nombre: "image53" },
    { pagina: 22, nombre: "image52" },
    { pagina: 23, nombre: "image51" },
    { pagina: 24, nombre: "image50" },
    { pagina: 25, nombre: "image49" },
    { pagina: 26, nombre: "image48" },
    { pagina: 27, nombre: "group6" },
    { pagina: 28, nombre: "group5" },
    { pagina: 29, nombre: "group4" },
    { pagina: 30, nombre: "image44" },
    { pagina: 31, nombre: "image43" },
    { pagina: 32, nombre: "image42" },
    { pagina: 33, nombre: "image41" },
    { pagina: 34, nombre: "image40" },
    { pagina: 35, nombre: "image39" },
    { pagina: 36, nombre: "group3" },
    { pagina: 37, nombre: "group2" },
    { pagina: 38, nombre: "group1" },
    { pagina: 39, nombre: "image35" },
    { pagina: 40, nombre: "image34" },
    { pagina: 41, nombre: "image33" },
    { pagina: 42, nombre: "image32" },
    { pagina: 43, nombre: "image31" },
    { pagina: 44, nombre: "image30" },
    { pagina: 45, nombre: "image29" },
    { pagina: 46, nombre: "image28" },
    { pagina: 47, nombre: "image27" },
    { pagina: 48, nombre: "image26" },
    { pagina: 49, nombre: "image25" },
    { pagina: 50, nombre: "image24" },
    { pagina: 51, nombre: "image23" },
    { pagina: 52, nombre: "image22" },
    { pagina: 53, nombre: "image21" },
    { pagina: 54, nombre: "image20" },
    { pagina: 55, nombre: "image19" },
    { pagina: 56, nombre: "image18" },
    { pagina: 57, nombre: "image17" },
    { pagina: 58, nombre: "image16" },
    { pagina: 59, nombre: "image15" },
    { pagina: 60, nombre: "image14" },
    { pagina: 61, nombre: "image13" },
    { pagina: 62, nombre: "image12" },
    { pagina: 63, nombre: "image11" },
    { pagina: 64, nombre: "image10" },
    { pagina: 65, nombre: "image9" },
    { pagina: 66, nombre: "image8" },
    { pagina: 67, nombre: "image7" },
    { pagina: 68, nombre: "image6" },
    { pagina: 69, nombre: "image5" },
    { pagina: 70, nombre: "image4" },
    { pagina: 71, nombre: "image3" }
];

let currentIndex = 0;

$w.onReady(function () {
    // Oculta todos los elementos de la secuencia
    secuencia.forEach(item => {
        // Asegúrate que los IDs en Wix coincidan con item.nombre
        $w("#" + item.nombre).hide();
    });

    // Muestra el primer elemento (group15)
    $w("#" + secuencia[currentIndex].nombre).show();
});

$w('#adelanteButton').onClick((event) => {
    // Oculta el elemento actual
    $w("#" + secuencia[currentIndex].nombre).hide();

    // Comprueba que no sea el último elemento y actualiza el índice
    if (currentIndex < secuencia.length - 1) {
        currentIndex++;
    }
    // Muestra el siguiente elemento
    $w("#" + secuencia[currentIndex].nombre).show();
})

$w('#atrasButton').onClick((event) => {
    // Oculta el elemento actual
    $w("#" + secuencia[currentIndex].nombre).hide();

    // Comprueba que no sea el primer elemento y actualiza el índice
    if (currentIndex > 0) {
        currentIndex--;
    }
    // Muestra el elemento anterior
    $w("#" + secuencia[currentIndex].nombre).show();
})