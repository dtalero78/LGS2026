import wixWindow from 'wix-window';
import wixWindowFrontend from "wix-window-frontend";


let currentPage = 1; // Página inicial

$w.onReady(function () {

    const context = wixWindow.lightbox.getContext();
    const nivelEstudiante = context.nivel;

    // Ahora puedes usar el valor de `nivelEstudiante` en tu lógica
    console.log("Nivel del estudiante recibido:", nivelEstudiante);


    // Asegúrate de que sólo la primera página esté visible al cargar
    mostrarPagina(currentPage);

    // Evento para el botón "adelante"
    $w('#adelante').onClick(() => {
        if (currentPage < 17) {
            currentPage++;
            mostrarPagina(currentPage);
        }
    });

    // Evento para el botón "atras"
    $w('#atras').onClick(() => {
        if (currentPage > 1) {
            currentPage--;
            mostrarPagina(currentPage);
        }
    });
});

function mostrarPagina(pagina) {
    // Colapsar todas las páginas
    const allPages = ['#1', '#2', '#3', '#4', '#5', '#6', '#7', '#8', '#9', '#10', '#11', '#12', '#13', '#14', '#15', '#16', '#17'];
    allPages.forEach(id => $w(id).collapse());

    // Expandir la página actual
    $w(`#${pagina}`).expand();
    
    // Deshabilitar botones si es necesario
    $w('#adelante').enable();
    $w('#atras').enable();

    if (pagina === 1) {
        $w('#atras').disable(); // Deshabilita "atras" en la primera página
    } else if (pagina === 17) {
        $w('#adelante').disable(); // Deshabilita "adelante" en la última página
    }
}


$w('#button1').onClick((event) => {
wixWindowFrontend.lightbox.close();
})