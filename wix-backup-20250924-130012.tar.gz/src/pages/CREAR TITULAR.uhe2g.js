import wixData from 'wix-data';
import wixLocation from 'wix-location';
import { sendmessage } from 'backend/realTimeChat';
import { contacts } from "wix-crm-frontend";
import { triggeredEmails } from 'wix-crm-frontend';

// ========== VARIABLES GLOBALES ==========
let isTitularSaved = false;
let savedPersonId = null;
let contactId = null;
let numeroId;
let fotoUrl;
let numeroContratoGenerado = null;

// ========== CONSTANTES ==========
const PREFIJOS_PAISES = [
    { pais: "Argentina", prefijo: "+54" },
    { pais: "Bolivia", prefijo: "+591" },
    { pais: "Chile", prefijo: "+56" },
    { pais: "Colombia", prefijo: "+57" },
    { pais: "Costa Rica", prefijo: "+506" },
    { pais: "Cuba", prefijo: "+53" },
    { pais: "Ecuador", prefijo: "+593" },
    { pais: "El Salvador", prefijo: "+503" },
    { pais: "España", prefijo: "+34" },
    { pais: "Guatemala", prefijo: "+502" },
    { pais: "Honduras", prefijo: "+504" },
    { pais: "México", prefijo: "+52" },
    { pais: "Nicaragua", prefijo: "+505" },
    { pais: "Panamá", prefijo: "+507" },
    { pais: "Paraguay", prefijo: "+595" },
    { pais: "Perú", prefijo: "+51" },
    { pais: "Puerto Rico", prefijo: "+1 787" },
    { pais: "República Dominicana", prefijo: "+1 809" },
    { pais: "Uruguay", prefijo: "+598" },
    { pais: "Venezuela", prefijo: "+58" }
];

const CAMPOS_NUMERICOS = ['#totalPlan', '#pagoInscripcion', '#valorCuota', '#ingresos'];

const CAMPOS_VALIDACION = {
    1: ["#asesorCreadorContrato"],
    2: ["#primerNombre", "#primerApellido", "#numeroId"],
    3: ["#fechaNacimiento", "#pais", "#domicilio", "#ciudad", "#celular"],
    4: ["#ingresos", "#email", "#genero"],
    5: ["#referenciaUno", "#parentezcoRefUno", "#telRefUno"],
    6: ["#totalPlan", "#pagoInscripcion", "#saldo", "#numeroCuotas", "#valorCuota", "#fechaPago", "#vigencia", "#medioPago"]
};

const OPCIONES_MEDIO_PAGO = {
    "Colombia": [
        { label: "Transferencia", value: "Transferencia" },
        { label: "Epayco", value: "Epayco" },
        { label: "Paypal", value: "Paypal" }
    ],
    "Ecuador": [
        { label: "Transferencia", value: "Transferencia" },
        { label: "Datafast", value: "Datafast" },
        { label: "Paypal", value: "Paypal" }
    ],
    "Chile": [
        { label: "Transferencia", value: "Transferencia" },
        { label: "Webpay", value: "Webpay" },
        { label: "Paypal", value: "Paypal" }
    ],
    "Perú": [
        { label: "Transferencia", value: "Transferencia" },
        { label: "Niubiz", value: "Niubiz" }
    ]
};

const CODIGOS_PAIS_CONTRATO = {
    "Chile": "01",
    "Colombia": "02",
    "Ecuador": "03",
    "Perú": "04"
};

// Variable global para almacenar el número de contrato generado

// ========== INICIALIZACIÓN ==========
$w.onReady(function () {
    initializePage();
    setupFinancialFieldHandlers();
    configurarValidacionCamposNumericos();
});

function initializePage() {
    hideAllGroupsExceptFirst();
    setupEventHandlers();
    setupPrefijos();
    actualizarVisibilidadBotones(1); // Configurar botones para el grupo inicial

    $w("#pais").onChange(() => {
        const paisSeleccionado = $w("#pais").value;
        actualizarOpcionesMedioPago(paisSeleccionado);
    });

}

function setupPrefijos() {
    const options = PREFIJOS_PAISES.map(item => ({
        label: `${item.pais} ${item.prefijo}`,
        value: item.prefijo
    }));
    $w('#prefijo').options = options;
}

function setupCalculationHandlers() {
    // Event handlers movidos a setupFinancialFieldHandlers()
    // para evitar duplicación
}

//========== FUNCIONES PARA GENERACIÓN DE NÚMEROS DE CONTRATO ==========

/**
 * Genera el siguiente número de contrato para un país específico
 * @param {string} pais - El país seleccionado
 * @returns {Promise<string>} - El número de contrato generado
 */
async function generarNumeroContrato(pais) {
    try {
        const codigoPais = CODIGOS_PAIS_CONTRATO[pais];
        if (!codigoPais) {
            throw new Error(`País no válido para generación de contrato: ${pais}`);
        }

        const anoActual = new Date().getFullYear().toString().slice(-2); // Últimos 2 dígitos del año
        const siguienteNumero = await obtenerSiguienteNumeroSecuencial(codigoPais);

        const numeroContrato = `${codigoPais}-${siguienteNumero}-${anoActual}`;
        console.log(`Número de contrato generado: ${numeroContrato}`);

        return numeroContrato;
    } catch (error) {
        console.error("Error al generar número de contrato:", error);
        throw error;
    }
}

/**
 * Obtiene el siguiente número secuencial disponible para un país
 * @param {string} codigoPais - Código del país (01, 02, 03, 04)
 * @returns {Promise<string>} - Número secuencial formateado (ej: "10001")
 */
async function obtenerSiguienteNumeroSecuencial(codigoPais) {
    try {
        const anoActual = new Date().getFullYear().toString().slice(-2);
        const patronContrato = `${codigoPais}-`;
        const patronAno = `-${anoActual}`;

        // Buscar TODOS los contratos para este país y año
        const resultado = await wixData.query("PEOPLE")
            .contains("contrato", patronContrato)
            .contains("contrato", patronAno)
            .limit(1000) // Obtener hasta 1000 registros para análisis
            .find();

        let maxNumero = 9999; // Número inicial (el siguiente será 10000)

        if (resultado.items.length > 0) {
            console.log(`Encontrados ${resultado.items.length} contratos para país ${codigoPais} y año ${anoActual}`);
            
            // Recorrer todos los contratos para encontrar el número máximo
            resultado.items.forEach(item => {
                if (item.contrato) {
                    // Extraer el número secuencial del formato XX-NNNNN-YY
                    const partes = item.contrato.split('-');
                    if (partes.length === 3) {
                        const numeroActual = parseInt(partes[1], 10);
                        if (!isNaN(numeroActual) && numeroActual > maxNumero) {
                            maxNumero = numeroActual;
                        }
                    }
                }
            });
            
            console.log("Número máximo encontrado:", maxNumero);
        } else {
            console.log(`No se encontraron contratos previos para país ${codigoPais} y año ${anoActual}`);
        }

        const siguienteNumero = maxNumero + 1;
        console.log("Siguiente número a asignar:", siguienteNumero);

        // Formatear con 5 dígitos
        return siguienteNumero.toString().padStart(5, '0');

    } catch (error) {
        console.error("Error al obtener siguiente número secuencial:", error);
        // En caso de error, usar número base
        return "10000";
    }
}

/**
 * Obtiene el número de contrato del titular para asignarlo a beneficiarios
 * @param {string} titularId - ID del titular
 * @returns {Promise<string|null>} - Número de contrato del titular
 */
async function obtenerNumeroContratoTitular(titularId) {
    try {
        const titular = await wixData.get("PEOPLE", titularId);
        return titular.contrato || null;
    } catch (error) {
        console.error("Error al obtener número de contrato del titular:", error);
        return null;
    }
}

// ========== FUNCIONES DE NORMALIZACIÓN NUMÉRICA ==========
function normalizarNumero(valor) {
    console.log('🔍 normalizarNumero - Input:', valor, 'Type:', typeof valor);
    
    if (typeof valor === 'number') {
        console.log('✅ normalizarNumero - Es número, return:', valor);
        return valor;
    }

    if (typeof valor === 'string') {
        const valorOriginal = valor;
        valor = valor.trim();
        console.log('📝 normalizarNumero - Después de trim:', valor);
        
        if (!valor) {
            console.log('⚠️ normalizarNumero - Valor vacío, return: 0');
            return 0;
        }

        // Detectar formato de números
        if (valor.includes('.') && valor.includes(',')) {
            const ultimoPunto = valor.lastIndexOf('.');
            const ultimaComa = valor.lastIndexOf(',');
            console.log('🔄 normalizarNumero - Contiene puntos y comas. UltimoPunto:', ultimoPunto, 'UltimaComa:', ultimaComa);

            if (ultimaComa > ultimoPunto) {
                // Formato europeo: 1.234.567,89
                valor = valor.replace(/\./g, '').replace(',', '.');
                console.log('🇪🇺 normalizarNumero - Formato europeo aplicado:', valor);
            } else {
                // Formato americano: 1,234,567.89
                valor = valor.replace(/,/g, '');
                console.log('🇺🇸 normalizarNumero - Formato americano aplicado:', valor);
            }
        } else if (valor.includes(',') && !valor.includes('.')) {
            const comas = (valor.match(/,/g) || []).length;
            console.log('📊 normalizarNumero - Solo comas. Cantidad:', comas);
            
            if (comas > 1) {
                valor = valor.replace(/,/g, '');
                console.log('🔢 normalizarNumero - Múltiples comas removidas:', valor);
            } else {
                const partesDespuesComa = valor.split(',')[1];
                if (partesDespuesComa && partesDespuesComa.length <= 2) {
                    valor = valor.replace(',', '.');
                    console.log('💰 normalizarNumero - Coma convertida a punto decimal:', valor);
                } else {
                    valor = valor.replace(',', '');
                    console.log('🔢 normalizarNumero - Coma removida (separador miles):', valor);
                }
            }
        } else if (valor.includes('.') && !valor.includes(',')) {
            const puntos = (valor.match(/\./g) || []).length;
            console.log('📍 normalizarNumero - Solo puntos. Cantidad:', puntos);
            
            if (puntos > 1) {
                // Múltiples puntos = separadores de miles
                valor = valor.replace(/\./g, '');
                console.log('🔢 normalizarNumero - Múltiples puntos removidos (separadores miles):', valor);
            } else {
                // Un solo punto: en contexto colombiano, verificar si es separador de miles
                const partesDespuesPunto = valor.split('.')[1];
                if (partesDespuesPunto && partesDespuesPunto.length === 3) {
                    // Formato colombiano: 90.000 = noventa mil
                    valor = valor.replace('.', '');
                    console.log('🇨🇴 normalizarNumero - Punto como separador de miles removido:', valor);
                } else {
                    // Probablemente decimal: 90.5
                    console.log('📝 normalizarNumero - Un solo punto mantenido como decimal:', valor);
                }
            }
        }

        // Usar Number() en lugar de parseFloat() para mejor precisión con enteros
        const numeroFinal = Number(valor);
        const resultado = isNaN(numeroFinal) ? 0 : numeroFinal;
        console.log('✅ normalizarNumero - Resultado final:', resultado, 'para input original:', valorOriginal);
        return resultado;
    }

    console.log('⚠️ normalizarNumero - Tipo no válido, return: 0');
    return 0;
}

function obtenerValorNormalizado(selector) {
    const valorTexto = $w(selector).value;
    console.log('🎯 obtenerValorNormalizado - Selector:', selector, 'Valor obtenido:', valorTexto);
    const resultado = normalizarNumero(valorTexto);
    console.log('🎯 obtenerValorNormalizado - Resultado normalizado:', resultado);
    return resultado;
}

function configurarValidacionCamposNumericos() {
    CAMPOS_NUMERICOS.forEach(selector => {
        $w(selector).onInput((event) => {
            const valorOriginal = event.target.value;
            const valorNormalizado = normalizarNumero(valorOriginal);

            // Feedback visual
            if (valorNormalizado > 0) {
                $w(selector).style.borderColor = "#00C851"; // Verde
            } else if (valorOriginal.trim() !== "") {
                $w(selector).style.borderColor = "#FF4444"; // Rojo
            } else {
                $w(selector).style.borderColor = ""; // Default
            }
        });
    });
}

// ========== MANEJADORES DE EVENTOS ==========
function setupEventHandlers() {
    setupDateValidation();
    setupButtonHandlers();
    setupFieldChangeHandlers();
}

function setupDateValidation() {
    try {
        $w("#fechaNacimiento").onInput(validateDateRealTime);
        $w('#fechaPago').onChange(validateDatePickerSelection);
    } catch (error) {
        console.warn("Error setting up date handlers:", error);
    }
}

function setupButtonHandlers() {
    $w('#siguiente').onClick(handleNextButtonClick);
    $w('#anterior').onClick(handlePreviousButtonClick);

    // Botón crear beneficiario - Crea beneficiario vacío y redirige
    $w('#crearBeneficiario').onClick(async () => {
        try {
            await crearBeneficiario();
            // Se redirige automáticamente en la función crearBeneficiario()
        } catch (error) {
            console.error("Error al crear beneficiario:", error);
            showElementWithText("#aviso", "Error al crear el beneficiario. Por favor, intente de nuevo.");
        }
    });

    // Botón duplicar usuario - Duplica titular como beneficiario con todos los datos
    $w('#duplicarUsuario').onClick(async () => {
        try {
            await duplicarTitularComoBeneficiario();
            actualizarInterfazBeneficiario("¡Beneficiario duplicado exitosamente! ¿Deseas crear otro beneficiario?");
        } catch (error) {
            console.error("Error al duplicar usuario como beneficiario:", error);
            showElementWithText("#aviso", "Error al duplicar el usuario. Por favor, intente de nuevo.");
        }
    });

    $w('#no').onClick(() => {
        $w('#loading').show();
        actualizarInterfazBeneficiario("¿Deseas crear un beneficiario?");
    });

    $w('#noFinalizar').onClick(() => {
        $w('#loading').show();
        const redirectUrl = `/contrato/${savedPersonId}?forReview`;
        wixLocation.to(redirectUrl);
        finalizarProceso();
    });
}

// ========== FUNCIONES DE BENEFICIARIOS ==========
async function crearBeneficiario() {
    try {
        // Obtener número de contrato del titular
        const numeroContrato = await obtenerNumeroContratoTitular(savedPersonId);

        if (!numeroContrato) {
            throw new Error("No se pudo obtener el número de contrato del titular");
        }

        // Crear beneficiario vacío con número de contrato
        const beneficiario = {
            titularId: savedPersonId,
            tipoUsuario: "BENEFICIARIO",
            contrato: numeroContrato // ← Asignar mismo número que el titular
        };

        const result = await wixData.insert("PEOPLE", beneficiario);

        console.log("Beneficiario creado exitosamente:", result);
        console.log("Vinculado al titular con ID:", savedPersonId);
        console.log("Número de contrato asignado:", numeroContrato);

        // Redirigir a la página del nuevo beneficiario
        const redirectUrl = `/new-beneficiario/${result._id}`;
        wixLocation.to(redirectUrl);

        return result;
    } catch (error) {
        console.error("Error al crear beneficiario:", error);
        throw error;
    }
}

async function duplicarTitularComoBeneficiario() {
    try {
        // Duplicar el titular con todos sus datos como beneficiario
        const person = await createPersonObject("BENEFICIARIO");
        person.titularId = savedPersonId;
        person.crmContactId = contactId;

        const result = await wixData.insert("PEOPLE", person);

        console.log("Titular duplicado como beneficiario exitosamente:", result);
        console.log("Vinculado al titular con ID:", savedPersonId);
        console.log("Número de contrato asignado:", person.contrato);

        return result;
    } catch (error) {
        console.error("Error al duplicar titular como beneficiario:", error);
        throw error;
    }
}

function actualizarInterfazBeneficiario(mensaje) {
    $w('#anuncioFinal').text = mensaje;
    $w('#crearBeneficiario').show();
    $w('#duplicarUsuario').hide();
    $w('#noFinalizar').show();
    $w('#no').hide();
}

function finalizarProceso() {
    $w('#anuncioFinal').text = "REGISTRO CREADO!";
    ['#crearBeneficiario', '#duplicarUsuario', '#no', '#noFinalizar'].forEach(hideElement);
}

// ========== FUNCIONES DE GUARDADO ==========
async function saveUsuario(isBeneficiario = false) {
    try {
        const person = await createPersonObject(isBeneficiario ? "BENEFICIARIO" : "TITULAR");
        
        if (isBeneficiario) {
            person.titularId = savedPersonId;
            person.crmContactId = contactId;
        }
        
        const result = await wixData.insert("PEOPLE", person);
        
        if (!isBeneficiario) {
            await procesarTitular(person, result);
            // Mostrar número de contrato generado
        }
        
        console.log("Usuario guardado con éxito (con contrato):", result);
        console.log("Número de contrato asignado:", person.contrato);
        
        return result;
    } catch (err) {
        handleError(err);
        throw err;
    }
}



async function procesarTitular(person, result) {
    const contactInfo = {
        name: { first: person.primerNombre, last: person.primerApellido },
        emails: [{ email: person.email, tag: "personal" }],
        phones: [{ phone: person.celular, tag: "mobile" }]
    };

    const contactResult = await contacts.appendOrCreateContact(contactInfo);
    contactId = contactResult.contactId;
    console.log("ID del contacto guardado:", contactId);

    // Actualizar registro con contactId
    const currentRecord = await wixData.get("PEOPLE", result._id);
    currentRecord.crmContactId = contactId;
    await wixData.update("PEOPLE", currentRecord);

    // Enviar email
    try {
        await triggeredEmails.emailContact('pruebaLGS', contactId);
        console.log("Correo electrónico enviado al contacto con ID:", contactId);
    } catch (err) {
        console.error("Error al enviar el correo electrónico:", err);
    }

    savedPersonId = result._id;
}

async function saveTitular() {
    try {
        await saveUsuario(false);
        await crearRegistroFinanciero();
        await enviarMensajeActualizacion();
    } catch (err) {
        console.error("Error al guardar la información del titular y financiera:", err);
        handleError(err);
    }
}

async function crearRegistroFinanciero() {
    // Obtener número de contrato del titular guardado
    let numeroContrato = numeroContratoGenerado;
    if (!numeroContrato && savedPersonId) {
        numeroContrato = await obtenerNumeroContratoTitular(savedPersonId);
    }

    // Obtener valores numéricos normalizados
    const totalPlanNum = obtenerValorNormalizado('#totalPlan');
    const valorCuotaNum = obtenerValorNormalizado('#valorCuota');
    const pagoInscripcionNum = obtenerValorNormalizado('#pagoInscripcion');
    const saldoNum = obtenerValorNormalizado('#saldo');
    const numeroCuotas = parseInt($w('#numeroCuotas').value, 10) || 0;

    const financialRecord = {
        primerNombre: $w("#primerNombre").value,
        primerApellido: $w("#primerApellido").value,
        numeroId: $w("#numeroId").value,
        totalPlan: formatearValorMonetario(totalPlanNum),
        valorCuota: numeroCuotas === 0 ? "0" : formatearValorMonetario(valorCuotaNum),
        pagoInscripcion: formatearValorMonetario(pagoInscripcionNum),
        saldo: formatearValorMonetario(saldoNum),
        numeroCuotas: numeroCuotas,
        fechaPago: obtenerFechaPagoISO(),
        titularId: savedPersonId,
        vigencia: $w('#vigencia').value,
        medioPago: $w("#medioPago").value,
        contrato: numeroContrato // ← AGREGAR ESTE CAMPO
    };

    const result = await wixData.insert("FINANCIERA", financialRecord);
    console.log("Registro financiero creado con éxito:", result);
    console.log("Número de contrato en registro financiero:", numeroContrato);
}

function obtenerFechaPagoISO() {
    try {
        const fechaPagoDate = $w('#fechaPago').value;

        if (fechaPagoDate instanceof Date && !isNaN(fechaPagoDate.getTime())) {
            return fechaPagoDate.toISOString().split('T')[0];
        } else {
            console.warn("Fecha de pago no válida, usando fecha actual");
            return new Date().toISOString().split('T')[0];
        }
    } catch (dateError) {
        console.error("Error procesando fecha de pago:", dateError);
        return new Date().toISOString().split('T')[0];
    }
}

async function enviarMensajeActualizacion() {
    try {
        const response = await sendmessage("gestionProspectos", { type: "updateComplete" });
        console.log("Mensaje enviado con éxito:", response);
    } catch (error) {
        console.error("Error enviando mensaje:", error);
    }
}

// ========== FUNCIONES DE VALIDACIÓN ==========
async function handleNextButtonClick() {
    const currentGroup = getCurrentGroup();

    // Validaciones específicas por grupo
    if (currentGroup === 1) {
        const agenteValido = await verifyAgenteAsignado();
        if (!agenteValido) {
            showElementWithText("#aviso", "Asesor no válido. Por favor, ingrese un asesor válido antes de continuar.");
            return;
        }
    }

    if (currentGroup === 2) {
        // Validación de numeroId removida - permitir duplicados
    }

    // NUEVA VALIDACIÓN: Verificar que el país sea válido para contratos
    if (currentGroup === 3) {
        try {
            const paisSeleccionado = $w("#pais").value;
            validarPaisParaContrato(paisSeleccionado);
        } catch (error) {
            showElementWithText("#aviso", error.message);
            return;
        }
    }

    // Navegación entre grupos (resto del código sin cambios)
    if (currentGroup < 7) {
        const validation = validateCurrentGroupFields(currentGroup);
        if (validation.isValid) {
            if (currentGroup === 6 && !isTitularSaved) {
                await saveTitular();
                isTitularSaved = true;
            }

            avanzarAlSiguienteGrupo(currentGroup);
        } else {
            showElementWithText("#aviso", `Por favor complete los siguientes campos: ${validation.missingFields.join(", ")}`);
        }
    }
}

function validarPaisParaContrato(pais) {
    const paisesValidos = Object.keys(CODIGOS_PAIS_CONTRATO);
    if (!paisesValidos.includes(pais)) {
        throw new Error(`El país "${pais}" no está configurado para generar contratos. Países válidos: ${paisesValidos.join(', ')}`);
    }
    return true;
}


function handlePreviousButtonClick() {
    const currentGroup = getCurrentGroup();

    // No permitir retroceder desde el primer grupo
    if (currentGroup <= 1) {
        console.warn("Ya estás en el primer grupo del formulario");
        return;
    }

    // Ocultar mensajes de error al retroceder
    hideElement("#aviso");

    // Si estamos en el grupo final (7) y retrocedemos, mostrar botón siguiente
    if (currentGroup === 7) {
        showElement("#siguiente");
    }

    // Navegar al grupo anterior
    retrocederAlGrupoAnterior(currentGroup);
}

function avanzarAlSiguienteGrupo(currentGroup) {
    toggleGroupVisibility(currentGroup, false);
    const nextGroup = currentGroup + 1;
    toggleGroupVisibility(nextGroup, true);
    actualizarVisibilidadBotones(nextGroup);
}

function retrocederAlGrupoAnterior(currentGroup) {
    toggleGroupVisibility(currentGroup, false);
    const previousGroup = currentGroup - 1;
    toggleGroupVisibility(previousGroup, true);
    actualizarVisibilidadBotones(previousGroup);
}

function actualizarVisibilidadBotones(grupoActual) {
    // Botón Anterior: ocultar en grupo 1 Y en grupo 7 (después de crear titular)
    if (grupoActual === 1 || grupoActual === 7) {
        hideElement("#anterior");
    } else {
        showElement("#anterior");
    }

    // Botón Siguiente: ocultar en grupo 7, mostrar en los demás
    if (grupoActual === 7) {
        hideElement("#siguiente");
    } else {
        showElement("#siguiente");
    }
}

function validateCurrentGroupFields(groupNumber) {
    const groupFields = CAMPOS_VALIDACION[groupNumber];
    let isValid = true;
    let missingFields = [];

    groupFields.forEach(fieldId => {
        try {
            const fieldValue = $w(fieldId).value;

            if (fieldId === "#fechaPago") {
                if (!fieldValue || !(fieldValue instanceof Date)) {
                    missingFields.push("Fecha de Pago");
                    isValid = false;
                }
            } else {
                if (!fieldValue ||
                    (typeof fieldValue === 'string' && fieldValue.trim() === "") ||
                    (typeof fieldValue !== 'string' && typeof fieldValue !== 'number' && !fieldValue)) {
                    missingFields.push($w(fieldId).placeholder || fieldId.replace('#', ''));
                    isValid = false;
                }
            }
        } catch (error) {
            console.error(`Error validating field ${fieldId}:`, error);
            missingFields.push(fieldId.replace('#', ''));
            isValid = false;
        }
    });

    return { isValid, missingFields };
}

function validateDateRealTime(event) {
    const inputId = "#" + event.target.id;
    let inputDate = $w(inputId).value;
    const regexSimple = /^[0-9/]*$/;

    if (!regexSimple.test(inputDate)) {
        $w(inputId).value = inputDate.slice(0, -1);
        return;
    }

    const parts = inputDate.split('/').filter(Boolean);
    if (parts.length === 1 && parts[0].length === 2 && !inputDate.endsWith('/') && inputDate.length < 6) {
        $w(inputId).value += '/';
    } else if (parts.length === 2 && parts[1].length === 2 && !inputDate.endsWith('/') && inputDate.length === 5) {
        $w(inputId).value += '/';
    } else if (inputDate.length > 10) {
        $w(inputId).value = inputDate.slice(0, 10);
    }
}

function validateDatePickerSelection(event) {
    try {
        const selectedDate = event.target.value;

        if (!selectedDate || !(selectedDate instanceof Date) || isNaN(selectedDate.getTime())) {
            showElementWithText("#aviso", "Por favor seleccione una fecha de pago válida.");
            return;
        }

        const today = new Date();
        today.setHours(0, 0, 0, 0);

        if (selectedDate < today) {
            showElementWithText("#aviso", "La fecha de pago no puede ser en el pasado.");
            return;
        }

        hideElement("#aviso");
    } catch (error) {
        console.error("Error in validateDatePickerSelection:", error);
        showElementWithText("#aviso", "Error al validar la fecha de pago.");
    }
}

// ========== FUNCIONES AUXILIARES ==========
async function checkIfNumeroIdExists(numeroId) {
    const result = await wixData.query("PEOPLE").eq("numeroId", numeroId).find();
    return result.items.length > 0;
}

async function verifyAgenteAsignado() {
    const agenteEmail = $w("#asesorCreadorContrato").value;
    if (!agenteEmail.length) return false;

    try {
        const result = await wixData.query("COMERCIAL").eq("email", agenteEmail).find();
        return result.items.length > 0;
    } catch (err) {
        handleError(err);
        return false;
    }
}

async function findAgenteAsignadoId() {
    const agenteEmail = $w("#asesorCreadorContrato").value;
    try {
        const result = await wixData.query("COMERCIAL").eq("email", agenteEmail).find();
        if (result.items.length > 0) {
            console.log("exito usuario");
            return result.items[0]._id;
        } else {
            console.error("No se encontró el agente con el email proporcionado");
            return null;
        }
    } catch (err) {
        handleError(err);
        return null;
    }
}

async function createPersonObject(tipoUsuario) {
    const agenteAsignadoId = await findAgenteAsignadoId();

    const fechaNacimientoStr = $w("#fechaNacimiento").value;
    const fechaNacimientoDate = new Date(fechaNacimientoStr.split('/').reverse().join('-'));
    const fechaNacimientoISO = fechaNacimientoDate.toISOString().split('T')[0];
    const edad = calculateAge(fechaNacimientoDate);

    const prefijo = $w("#prefijo").value;
    const celularCompleto = prefijo + $w("#celular").value;
    const paisSeleccionado = $w("#pais").value;

    // Generar o obtener número de contrato
    let numeroContrato;

    if (tipoUsuario === "TITULAR") {
        // Para titular, generar nuevo número de contrato
        numeroContrato = await generarNumeroContrato(paisSeleccionado);
        numeroContratoGenerado = numeroContrato; // Guardar para beneficiarios
    } else {
        // Para beneficiarios, usar el número del titular
        if (savedPersonId) {
            numeroContrato = await obtenerNumeroContratoTitular(savedPersonId);
        } else if (numeroContratoGenerado) {
            numeroContrato = numeroContratoGenerado;
        } else {
            console.warn("No se pudo obtener número de contrato para beneficiario");
            numeroContrato = await generarNumeroContrato(paisSeleccionado);
        }
    }

    return {
        primerNombre: capitalizeFirstLetter($w("#primerNombre").value),
        segundoNombre: capitalizeFirstLetter($w("#segundoNombre").value),
        primerApellido: capitalizeFirstLetter($w("#primerApellido").value),
        segundoApellido: capitalizeFirstLetter($w("#segundoApellido").value),
        numeroId: limpiarTexto($w("#numeroId").value),
        fechaNacimiento: fechaNacimientoISO,
        edad: edad.toString(),
        plataforma: paisSeleccionado,
        domicilio: $w("#domicilio").value,
        ciudad: $w("#ciudad").value,
        celular: limpiarTexto(celularCompleto),
        ingresos: $w("#ingresos").value,
        email: $w("#email").value,
        empresa: $w("#empresa").value,
        cargo: capitalizeFirstLetter($w("#cargo").value),
        genero: $w("#genero").value,
        tipoUsuario: tipoUsuario,
        telefono: $w('#telefono').value,
        referenciaUno: capitalizeFirstLetter($w('#referenciaUno').value),
        parentezcoRefUno: $w('#parentezcoRefUno').value,
        telefonoRefUno: $w('#telRefUno').value,
        referenciaDos: capitalizeFirstLetter($w('#referenciaDos').value),
        telefonoRefDos: $w('#telRefDos').value,
        parentezcoRefDos: $w('#parentezcoRefDos').value,
        foto: fotoUrl,
        titularId: savedPersonId,
        agenteAsignado: agenteAsignadoId,
        vigencia: $w('#vigencia').value,
        contrato: numeroContrato // ← NUEVO CAMPO
    };
}

// ========== FUNCIONES DE CÁLCULO ==========
function calcularSaldo() {
    console.log('🧮 calcularSaldo - INICIO');
    
    const totalPlan = obtenerValorNormalizado('#totalPlan');
    const pagoInscripcion = obtenerValorNormalizado('#pagoInscripcion');
    
    console.log('💰 calcularSaldo - Total Plan:', totalPlan);
    console.log('💰 calcularSaldo - Pago Inscripción:', pagoInscripcion);
    console.log('🔍 calcularSaldo - isNaN totalPlan:', isNaN(totalPlan));
    console.log('🔍 calcularSaldo - isNaN pagoInscripcion:', isNaN(pagoInscripcion));

    if (!isNaN(totalPlan) && !isNaN(pagoInscripcion)) {
        const saldo = totalPlan - pagoInscripcion;
        console.log('➕ calcularSaldo - Operación:', totalPlan, '-', pagoInscripcion, '=', saldo);
        
        const saldoFormateado = saldo.toLocaleString('es-CO', {
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        });
        console.log('💫 calcularSaldo - Saldo formateado:', saldoFormateado);
        
        $w('#saldo').value = saldoFormateado;
        calcularValorCuota();
    } else {
        console.log('❌ calcularSaldo - No se pudo calcular, valores inválidos');
    }
    
    console.log('🧮 calcularSaldo - FIN');
}

function calcularValorCuota() {
    const saldo = obtenerValorNormalizado('#saldo');
    const numeroCuotas = parseInt($w('#numeroCuotas').value, 10);

    if (!isNaN(saldo) && !isNaN(numeroCuotas)) {
        if (numeroCuotas === 0) {
            // Pago de contado - establecer valor cuota en 0 con formato
            $w('#valorCuota').value = "0,00";
        } else if (numeroCuotas > 0) {
            const valorCuota = saldo / numeroCuotas;
            $w('#valorCuota').value = valorCuota.toLocaleString('es-CO', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            });
        }
    }
}

function aplicarFormatoNumero(selector) {
    console.log('🎨 aplicarFormatoNumero - INICIO para selector:', selector);
    
    // Obtener el valor sin formato
    let valorOriginal = $w(selector).value;
    console.log('📝 aplicarFormatoNumero - Valor original:', valorOriginal);
    
    let valor = valorOriginal.replace(/\./g, '').replace(/,/g, '');
    console.log('📝 aplicarFormatoNumero - Después de remover puntos y comas:', valor);
    
    valor = valor.replace(/\D/g, '');
    console.log('📝 aplicarFormatoNumero - Solo dígitos:', valor);
    
    // Si hay valor, formatearlo con punto como separador de miles
    if (valor) {
        const numero = Number(valor);
        console.log('🔢 aplicarFormatoNumero - Número convertido:', numero);
        
        if (!isNaN(numero)) {
            const valorFormateado = numero.toLocaleString('es-CO');
            console.log('💫 aplicarFormatoNumero - Valor formateado:', valorFormateado);
            $w(selector).value = valorFormateado;
        }
    } else {
        console.log('⚠️ aplicarFormatoNumero - Valor vacío');
        $w(selector).value = '';
    }
    
    console.log('🎨 aplicarFormatoNumero - FIN');
}

// ========== FUNCIONES DE UI ==========
function hideAllGroupsExceptFirst() {
    ['2', '3', '4', '5', '6', '7'].forEach(group => hideElement(`#group${group}`));
}

function toggleGroupVisibility(groupNumber, show) {
    const groupId = `#group${groupNumber}`;
    if (show) {
        $w(groupId).show();
    } else {
        $w(groupId).hide();
    }
}

function setupFinancialFieldHandlers() {
    // Configurar event handlers para campos financieros una sola vez
    $w('#totalPlan').onInput(() => {
        aplicarFormatoNumero('#totalPlan');
        calcularSaldo();
    });
    
    $w('#pagoInscripcion').onInput(() => {
        aplicarFormatoNumero('#pagoInscripcion');
        calcularSaldo();
    });
    
    $w('#numeroCuotas').onInput(() => {
        calcularValorCuota();
    });
    
    $w('#ingresos').onInput(() => {
        aplicarFormatoNumero('#ingresos');
    });
}

function setupFieldChangeHandlers() {
    const allFields = [
        "#asesorCreadorContrato", "#primerNombre", "#segundoNombre", "#primerApellido",
        "#segundoApellido", "#numeroId", "#fechaNacimiento", "#pais", "#domicilio",
        "#ciudad", "#celular", "#telefono", "#ingresos", "#email", "#empresa", "#cargo",
        "#genero", "#referenciaUno", "#parentezcoRefUno", "#telRefUno", "#referenciaDos",
        "#parentezcoRefDos", "#telRefDos", "#totalPlan", "#pagoInscripcion", "#saldo",
        "#numeroCuotas", "#valorCuota", "#vigencia"
    ];

    allFields.forEach(fieldId => {
        try {
            $w(fieldId).onChange(() => {
                const currentGroup = getCurrentGroup();
                const validation = validateCurrentGroupFields(currentGroup);
                if (validation.isValid) {
                    hideElement("#aviso");
                }
            });
        } catch (error) {
            console.warn(`Could not set onChange handler for ${fieldId}:`, error);
        }
    });

    try {
        $w("#fechaPago").onChange(() => {
            const currentGroup = getCurrentGroup();
            const validation = validateCurrentGroupFields(currentGroup);
            if (validation.isValid) {
                hideElement("#aviso");
            }
        });
    } catch (error) {
        console.warn("DatePicker #fechaPago not found or error setting handler:", error);
    }
}

function getCurrentGroup() {
    for (let i = 1; i <= 7; i++) {
        if (!$w(`#group${i}`).hidden) {
            return i;
        }
    }
    return 1;
}

// ========== FUNCIONES UTILITARIAS ==========
function formatearValorMonetario(valor) {
    // Si el valor es 0 o no válido, retornar "0"
    if (!valor || valor === 0) return "0";
    
    // Asegurar que es un número
    const numero = typeof valor === 'number' ? valor : parseFloat(valor);
    
    if (isNaN(numero)) return "0";
    
    // Formatear con separador de miles y 2 decimales
    return numero.toLocaleString('es-CO', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    });
}

function calculateAge(fechaNacimiento) {
    const hoy = new Date();
    let edad = hoy.getFullYear() - fechaNacimiento.getFullYear();
    const mes = hoy.getMonth() - fechaNacimiento.getMonth();
    if (mes < 0 || (mes === 0 && hoy.getDate() < fechaNacimiento.getDate())) {
        edad--;
    }
    return edad;
}

function capitalizeFirstLetter(string) {
    if (!string) return string;
    return string.charAt(0).toUpperCase() + string.slice(1).toLowerCase();
}

function limpiarTexto(texto) {
    return texto.replace(/[.\s-]|[^a-zA-Z0-9]/g, '');
}

function showElement(selector) {
    $w(selector).show();
}

function hideElement(selector) {
    $w(selector).hide();
}

function showElementWithText(selector, text) {
    const element = $w(selector);
    element.text = text;
    element.show();
}

function handleError(err) {
    console.error("Error: ", err);
    showElementWithText("#aviso", "Error al guardar la información. Por favor, intente de nuevo.");
}

function elementExists(selector) {
    try {
        $w(selector);
        return true;
    } catch (error) {
        return false;
    }
}

function debugDatePicker() {
    try {
        const fechaValue = $w('#fechaPago').value;
        console.log("Tipo de fechaPago:", typeof fechaValue);
        console.log("Valor de fechaPago:", fechaValue);
        console.log("Es Date?:", fechaValue instanceof Date);
        console.log("Es válida?:", fechaValue instanceof Date ? !isNaN(fechaValue.getTime()) : false);
    } catch (error) {
        console.error("Error al debuggear DatePicker:", error);
    }
}

function actualizarOpcionesMedioPago(pais) {
    const opciones = OPCIONES_MEDIO_PAGO[pais] || [];
    $w("#medioPago").options = opciones;
    $w("#medioPago").value = opciones.length ? opciones[0].value : "";
}