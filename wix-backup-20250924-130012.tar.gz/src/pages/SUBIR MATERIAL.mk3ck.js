import wixData from 'wix-data';
import wixLocation from 'wix-location';

$w.onReady(function () {
    // Manejar cambios en el dropdown tipoMaterial
    $w("#tipoMaterial").onChange(() => {
        const tipo = $w("#tipoMaterial").value;

        if (tipo === "pdf") {
            $w("#myUploadButton").show();
            $w("#myUploadVideo").hide();
        } else if (tipo === "video") {
            $w("#myUploadVideo").show();
            $w("#myUploadButton").hide();
        }
    });

    // Vincular evento de clic al botón subir
    $w("#subir").onClick(subir_click);

    // Manejar cambios en el dropdown niveles
    $w("#niveles").onChange(() => {
        cargarMaterial();
    });

    // Poblar el dropdown niveles desde la base de datos
    wixData.query("NIVELES")
        .find()
        .then((results) => {
            let nivelesOptions = results.items.map(item => {
                if (item.step && item.step.startsWith('Step')) {
                    let step = parseInt(item.step.split(' ')[1]);
                    return { label: item.step, value: step };
                } else {
                    return null;
                }
            }).filter(option => option !== null);

            nivelesOptions.sort((a, b) => a.value - b.value);

            $w("#niveles").options = nivelesOptions.map(option => ({
                label: option.label,
                value: option.label
            }));
        })
        .catch((err) => {
            console.error("Error al cargar niveles:", err);
        });
});

export function subir_click() {
    $w('#loading').show();

    const selectedTipo = $w("#tipoMaterial").value;
    const selectedStep = $w("#niveles").value;

    if (!selectedTipo || !selectedStep) {
        console.warn("Por favor, selecciona un tipo de material y un nivel antes de subir el archivo.");
        $w('#loading').hide();
        return;
    }

    const uploadButtonId = selectedTipo === "pdf" ? "#myUploadButton" : "#myUploadVideo";

    if ($w(uploadButtonId).value.length === 0) {
        console.warn("Por favor, selecciona un archivo antes de subir.");
        $w('#loading').hide();
        return;
    }

    $w(uploadButtonId).uploadFiles()
        .then((uploadedFiles) => {
            uploadedFiles.forEach((uploadedFile) => {
                const fileUrl = uploadedFile.fileUrl;

                wixData.query("NIVELES")
                    .eq("step", selectedStep)
                    .find()
                    .then((results) => {
                        if (results.items.length > 0) {
                            let item = results.items[0];

                            if (selectedTipo === "pdf") {
                                item.material = Array.isArray(item.material) ? [...item.material, fileUrl] : [fileUrl];
                            } else if (selectedTipo === "video") {
                                item.video = Array.isArray(item.video) ? [...item.video, fileUrl] : [fileUrl];
                            }

                            wixData.update("NIVELES", item)
                                .then(() => {
                                    console.log(`Archivo (${selectedTipo}) subido y base de datos actualizada.`);
                                    $w('#loading').hide();
                                    cargarMaterial();
                                })
                                .catch((err) => {
                                    console.error("Error al actualizar la base de datos:", err);
                                    $w('#loading').hide();
                                });
                        } else {
                            console.warn("No se encontró el step seleccionado.");
                            $w('#loading').hide();
                        }
                    })
                    .catch((err) => {
                        console.error("Error al consultar la base de datos:", err);
                        $w('#loading').hide();
                    });
            });
        })
        .catch((uploadError) => {
            console.error("Error al subir el archivo:", uploadError);
            $w('#loading').hide();
        });
}

export function cargarMaterial() {
    const selectedStep = $w("#niveles").value; // Step seleccionado
    const selectedTipo = $w("#tipoMaterial").value; // Tipo seleccionado (pdf o video)

    if (!selectedStep) {
        console.warn("Selecciona un step antes de cargar el material.");
        return;
    }

    if (!selectedTipo) {
        console.warn("Selecciona un tipo de material antes de cargar el material.");
        return;
    }

    console.log("Cargando material para el step:", selectedStep, "y tipo:", selectedTipo);

    // Consultar la base de datos para el step seleccionado
    wixData.query("NIVELES")
        .eq("step", selectedStep)
        .find()
        .then((results) => {
            if (results.items.length > 0) {
                const item = results.items[0]; // El registro correspondiente al step
                let repeaterData = [];

                // Filtrar datos según el tipo seleccionado
                if (selectedTipo === "pdf") {
                    const materiales = item.material; // Campo "material" en la base de datos
                    if (Array.isArray(materiales)) {
                        repeaterData = materiales.map((material, index) => ({
                            _id: `pdf-${index}`,
                            nombreItem: decodeURIComponent(extractFileName(material)),
                            fileUrl: material
                        }));
                    }
                } else if (selectedTipo === "video") {
                    const videos = item.video; // Campo "video" en la base de datos
                    if (Array.isArray(videos)) {
                        repeaterData = videos.map((video, index) => ({
                            _id: `video-${index}`,
                            nombreItem: decodeURIComponent(extractFileName(video)),
                            fileUrl: video
                        }));
                    }
                }

                // Vincular datos al repetidor
                $w("#material").data = repeaterData;

                // Configurar elementos del repetidor
                $w("#material").onItemReady(($item, itemData) => {
                    $item("#nombreItem").text = itemData.nombreItem;

                    // Botón de descarga
                    $item("#download").onClick(() => {
                        wixLocation.to(itemData.fileUrl); // Redirigir para descargar el archivo
                    });

                    // Botón de eliminación
                    $item("#delete").onClick(() => {
                        eliminarMaterial(selectedStep, itemData.fileUrl, selectedTipo === "pdf" ? "material" : "video");
                    });
                });

                if (repeaterData.length === 0) {
                    console.warn(`No se encontraron ${selectedTipo}s en el step seleccionado.`);
                }
            } else {
                console.warn("No se encontraron resultados para el step proporcionado.");
                $w("#material").data = []; // Limpiar el repetidor si no hay resultados
            }
        })
        .catch((err) => {
            console.error("Error al consultar la base de datos:", err);
        });
}


function eliminarMaterial(step, fileUrl, type) {
    wixData.query("NIVELES")
        .eq("step", step)
        .find()
        .then((results) => {
            if (results.items.length > 0) {
                const item = results.items[0];
                let field = type === "material" ? item.material : item.video;

                if (Array.isArray(field)) {
                    field = field.filter((file) => file !== fileUrl);
                }

                item[type] = field;
                wixData.update("NIVELES", item)
                    .then(() => {
                        console.log("Material eliminado exitosamente.");
                        cargarMaterial();
                    })
                    .catch((err) => {
                        console.error("Error al actualizar la base de datos:", err);
                    });
            }
        })
        .catch((err) => {
            console.error("Error al consultar la base de datos:", err);
        });
}

function extractFileName(url) {
    return url.substring(url.lastIndexOf('/') + 1);
}
