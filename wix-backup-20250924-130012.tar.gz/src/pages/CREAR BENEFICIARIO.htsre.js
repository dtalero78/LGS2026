import wixData from 'wix-data';
import wixLocation from 'wix-location';

// ========== VARIABLES GLOBALES ==========
let currentGroup = 1;
let titularId = null;
let fotoUrl = null;
let savedPersonId = null;
let beneficiarioId = null; // ID del beneficiario actual

// ========== CONSTANTES ==========
const CAMPOS_VALIDACION = {
    1: ["#primerNombre", "#primerApellido", "#numeroId"],
    2: ["#fechaNacimiento", "#pais", "#domicilio", "#ciudad", "#celular", "#email", "#genero"]
};

const CAMPOS_FORMULARIO = [
    "#primerNombre", "#segundoNombre", "#primerApellido", "#segundoApellido",
    "#numeroId", "#fechaNacimiento", "#pais", "#domicilio", "#ciudad",
    "#celular", "#email", "#genero"
];

const PREFIJOS_PAISES = [
    { pais: "Argentina", prefijo: "+54" },
    { pais: "Bolivia", prefijo: "+591" },
    { pais: "Chile", prefijo: "+56" },
    { pais: "Colombia", prefijo: "+57" },
    { pais: "Costa Rica", prefijo: "+506" },
    { pais: "Cuba", prefijo: "+53" },
    { pais: "Ecuador", prefijo: "+593" },
    { pais: "El Salvador", prefijo: "+503" },
    { pais: "España", prefijo: "+34" },
    { pais: "Guatemala", prefijo: "+502" },
    { pais: "Honduras", prefijo: "+504" },
    { pais: "México", prefijo: "+52" },
    { pais: "Nicaragua", prefijo: "+505" },
    { pais: "Panamá", prefijo: "+507" },
    { pais: "Paraguay", prefijo: "+595" },
    { pais: "Perú", prefijo: "+51" },
    { pais: "Puerto Rico", prefijo: "+1 787" },
    { pais: "República Dominicana", prefijo: "+1 809" },
    { pais: "Uruguay", prefijo: "+598" },
    { pais: "Venezuela", prefijo: "+58" }
];

// ========== INICIALIZACIÓN ==========
$w.onReady(async function () {
    console.log("Página de nuevo beneficiario iniciada");
    await obtenerDatosTitular(); // Ahora es async
    initializePage();
});

async function obtenerDatosTitular() {
    try {
        // Obtener el beneficiario actual del dataset (siempre debe existir ahora)
        const beneficiarioActual = $w('#dynamicDataset').getCurrentItem();
        beneficiarioId = beneficiarioActual._id;
        titularId = beneficiarioActual.titularId;
        
        console.log("Datos obtenidos del dataset:", { beneficiarioId, titularId });

        if (!titularId) {
            throw new Error("No se pudo obtener el ID del titular");
        }

        // Hacer query para obtener los datos del titular
        const resultTitular = await wixData.query("PEOPLE")
            .eq("_id", titularId)
            .find();

        if (resultTitular.items.length > 0) {
            const titular = resultTitular.items[0];
            const nombreTitular = `Este será un beneficiario del titular: ${titular.primerNombre} ${titular.primerApellido}`;
            $w('#nombreTitular').text = nombreTitular.toUpperCase();
            console.log("Datos del titular obtenidos:", {
                titularId,
                beneficiarioId,
                nombreTitular: `${titular.primerNombre} ${titular.primerApellido}`
            });
            
            return titular;
        } else {
            throw new Error("No se encontró el titular padre");
        }
    } catch (error) {
        console.error("Error al obtener datos del titular:", error);
        showElementWithText("#aviso", "Error al cargar los datos del titular.");
        throw error;
    }
}

function initializePage() {
    hideAllGroupsExceptFirst();
    setupEventHandlers();
    actualizarVisibilidadBotones(1);
    setupPrefijos();

}

// ========== FUNCIONES DE UI ==========
function hideAllGroupsExceptFirst() {
    ['2', '3'].forEach(group => hideElement(`#group${group}`));
}

function actualizarVisibilidadBotones(grupoActual) {
    // Botón Anterior: ocultar en grupo 1, mostrar en grupos 2-3
    if (grupoActual === 1) {
        hideElement("#anterior");
    } else {
        showElement("#anterior");
    }

    // Botón Siguiente: ocultar en grupo 3, mostrar en grupos 1-2
    if (grupoActual === 3) {
        hideElement("#siguiente");
    } else {
        showElement("#siguiente");
    }
}

// ========== MANEJADORES DE EVENTOS ==========
function setupEventHandlers() {
    setupDateValidation();
    setupButtonHandlers();
    setupFieldChangeHandlers();
}

function setupDateValidation() {
    try {
        $w("#fechaNacimiento").onInput(validateDateRealTime);
    } catch (error) {
        console.warn("Error setting up date validation:", error);
    }
}

function setupPrefijos() {
    const options = PREFIJOS_PAISES.map(item => ({
        label: `${item.pais} ${item.prefijo}`,
        value: item.prefijo
    }));
    $w('#prefijo').options = options;
}

function setupButtonHandlers() {
    $w('#siguiente').onClick(handleNextButtonClick);
    $w('#anterior').onClick(handlePreviousButtonClick);

    $w('#crearBeneficiario').onClick(async () => {
        try {
            await guardarBeneficiario();
            mostrarMensajeExito();
        } catch (error) {
            console.error("Error al crear beneficiario:", error);
            showElementWithText("#aviso", "Error al guardar el beneficiario. Por favor, intente de nuevo.");
        }
    });

    $w('#terminar').onClick(async () => {
        try {
            await guardarBeneficiario();
            finalizarProceso();
        } catch (error) {
            console.error("Error al terminar:", error);
            showElementWithText("#aviso", "Error al finalizar el proceso. Por favor, intente de nuevo.");
        }
    });

}

// ========== FUNCIONES DE NAVEGACIÓN ==========
async function handleNextButtonClick() {
    const currentGroup = getCurrentGroup();

    if (currentGroup < 3) {
        const validation = validateCurrentGroupFields(currentGroup);
        if (validation.isValid) {
            avanzarAlSiguienteGrupo(currentGroup);
        } else {
            showElementWithText("#aviso", `Por favor complete los siguientes campos: ${validation.missingFields.join(", ")}`);
        }
    }
}

function handlePreviousButtonClick() {
    const currentGroup = getCurrentGroup();

    if (currentGroup > 1) {
        hideElement("#aviso");
        retrocederAlGrupoAnterior(currentGroup);
    }
}

function avanzarAlSiguienteGrupo(currentGroup) {
    toggleGroupVisibility(currentGroup, false);
    const nextGroup = currentGroup + 1;
    toggleGroupVisibility(nextGroup, true);
    actualizarVisibilidadBotones(nextGroup);
}

function retrocederAlGrupoAnterior(currentGroup) {
    toggleGroupVisibility(currentGroup, false);
    const previousGroup = currentGroup - 1;
    toggleGroupVisibility(previousGroup, true);
    actualizarVisibilidadBotones(previousGroup);
}

// ========== FUNCIONES DE GUARDADO ==========
async function guardarBeneficiario() {
    showElement('#loading');

    try {
        // Crear objeto con los datos del nuevo beneficiario
        const nuevosBeneficiario = createPersonObject();
        
        // Obtener información del titular para asociar el beneficiario
        const titularData = await obtenerDatosTitular();
        
        // Obtener el registro actual del beneficiario para mantener campos existentes
        const beneficiarioActual = await wixData.get("PEOPLE", beneficiarioId);
        
        // Agregar datos necesarios del titular al beneficiario
        const beneficiarioCompleto = {
            ...beneficiarioActual, // Mantener todos los campos existentes
            ...nuevosBeneficiario, // Sobrescribir con nuevos datos del formulario
            titularId: titularData._id, // Asociar con el titular
            numeroContrato: titularData.numeroContrato, // Mismo contrato que el titular
            asesorAsignado: titularData.asesorAsignado, // Asesor del titular
            vigencia: titularData.vigencia, // Vigencia del contrato del titular
            tipoUsuario: "BENEFICIARIO"
        };

        // Actualizar el registro existente del beneficiario
        const result = await wixData.update("PEOPLE", beneficiarioCompleto);

        savedPersonId = result._id;
        console.log("Beneficiario actualizado exitosamente:", result);

        return result;
    } catch (error) {
        console.error("Error al actualizar beneficiario:", error);
        throw error;
    } finally {
        hideElement('#loading');
    }
}

function createPersonObject() {
    const fechaNacimientoStr = $w("#fechaNacimiento").value;
    const fechaNacimientoDate = new Date(fechaNacimientoStr.split('/').reverse().join('-'));
    const fechaNacimientoISO = fechaNacimientoDate.toISOString().split('T')[0];
    const edad = calculateAge(fechaNacimientoDate);
    const prefijo = $w("#prefijo").value;
    const celularCompleto = prefijo + $w("#celular").value;

    return {
        primerNombre: capitalizeFirstLetter($w("#primerNombre").value),
        segundoNombre: capitalizeFirstLetter($w("#segundoNombre").value),
        primerApellido: capitalizeFirstLetter($w("#primerApellido").value),
        segundoApellido: capitalizeFirstLetter($w("#segundoApellido").value),
        numeroId: limpiarTexto($w("#numeroId").value),
        fechaNacimiento: fechaNacimientoISO,
        edad: edad.toString(),
        plataforma: $w("#pais").value,
        domicilio: $w("#domicilio").value,
        ciudad: $w("#ciudad").value,
        celular: limpiarTexto(celularCompleto),
        email: $w("#email").value,
        genero: $w("#genero").value,
        tipoUsuario: "BENEFICIARIO",
        titularId: titularId
    };
}

// ========== FUNCIONES DE FINALIZACIÓN ==========
function mostrarMensajeExito() {
    // Resetear formulario para crear otro beneficiario
    resetFields();
    volverAlPrimerGrupo();
    showElementWithText("#aviso", "¡Beneficiario creado exitosamente! Puedes crear otro beneficiario.");
}

async function finalizarProceso() {
    try {
        $w('#anuncioFinal').text = "¡REGISTRO CREADO!";
        hideElement('#crearBeneficiario');

        // Redirigir al contrato del titular
        const redirectUrl = `/contrato/${titularId}?forReview`;
        wixLocation.to(redirectUrl);
    } catch (error) {
        console.error("Error al finalizar proceso:", error);
    }
}

function resetFields() {
    CAMPOS_FORMULARIO.forEach(fieldId => {
        try {
            $w(fieldId).value = "";
        } catch (error) {
            console.warn(`No se pudo resetear el campo ${fieldId}:`, error);
        }
    });
}

function volverAlPrimerGrupo() {
    // Ocultar todos los grupos
    ['2', '3'].forEach(group => hideElement(`#group${group}`));

    // Mostrar solo el primer grupo
    showElement('#group1');
    showElement('#siguiente');

    // Actualizar visibilidad de botones
    actualizarVisibilidadBotones(1);
}

// ========== FUNCIONES DE VALIDACIÓN ==========
function validateCurrentGroupFields(groupNumber) {
    const groupFields = CAMPOS_VALIDACION[groupNumber];
    let isValid = true;
    let missingFields = [];

    groupFields.forEach(fieldId => {
        try {
            const fieldValue = $w(fieldId).value;
            if (!fieldValue || fieldValue.trim() === "") {
                missingFields.push($w(fieldId).placeholder || fieldId.replace('#', ''));
                isValid = false;
            }
        } catch (error) {
            console.error(`Error validating field ${fieldId}:`, error);
            missingFields.push(fieldId.replace('#', ''));
            isValid = false;
        }
    });

    return { isValid, missingFields };
}

function validateDateRealTime(event) {
    const inputId = "#" + event.target.id;
    let inputDate = $w(inputId).value;
    const regexSimple = /^[0-9/]*$/;

    if (!regexSimple.test(inputDate)) {
        $w(inputId).value = inputDate.slice(0, -1);
        return;
    }

    const parts = inputDate.split('/').filter(Boolean);
    if (parts.length === 1 && parts[0].length === 2 && !inputDate.endsWith('/') && inputDate.length < 6) {
        $w(inputId).value += '/';
    } else if (parts.length === 2 && parts[1].length === 2 && !inputDate.endsWith('/') && inputDate.length === 5) {
        $w(inputId).value += '/';
    } else if (inputDate.length > 10) {
        $w(inputId).value = inputDate.slice(0, 10);
    }
}

function setupFieldChangeHandlers() {
    CAMPOS_FORMULARIO.forEach(fieldId => {
        try {
            $w(fieldId).onChange(() => {
                const currentGroup = getCurrentGroup();
                const validation = validateCurrentGroupFields(currentGroup);
                if (validation.isValid) {
                    hideElement("#aviso");
                }
            });
        } catch (error) {
            console.warn(`Could not set onChange handler for ${fieldId}:`, error);
        }
    });
}

// ========== FUNCIONES DE UI AUXILIARES ==========
function toggleGroupVisibility(groupNumber, show) {
    const groupId = `#group${groupNumber}`;
    if (show) {
        showElement(groupId);
    } else {
        hideElement(groupId);
    }
}

function getCurrentGroup() {
    for (let i = 1; i <= 3; i++) {
        if (!$w(`#group${i}`).hidden) {
            return i;
        }
    }
    return 1;
}

// ========== FUNCIONES UTILITARIAS ==========
function calculateAge(fechaNacimiento) {
    const hoy = new Date();
    let edad = hoy.getFullYear() - fechaNacimiento.getFullYear();
    const mes = hoy.getMonth() - fechaNacimiento.getMonth();
    if (mes < 0 || (mes === 0 && hoy.getDate() < fechaNacimiento.getDate())) {
        edad--;
    }
    return edad;
}

function capitalizeFirstLetter(string) {
    if (!string) return string;
    return string.charAt(0).toUpperCase() + string.slice(1).toLowerCase();
}

function limpiarTexto(texto) {
    if (!texto) return "";
    return texto.replace(/[.\s-]|[^a-zA-Z0-9]/g, '');
}

function showElement(selector) {
    try {
        $w(selector).show();
    } catch (error) {
        console.warn(`No se pudo mostrar el elemento ${selector}:`, error);
    }
}

function hideElement(selector) {
    try {
        $w(selector).hide();
    } catch (error) {
        console.warn(`No se pudo ocultar el elemento ${selector}:`, error);
    }
}

function showElementWithText(selector, text) {
    try {
        const element = $w(selector);
        element.text = text;
        element.show();
    } catch (error) {
        console.warn(`No se pudo mostrar el elemento ${selector} con texto:`, error);
    }
}

function handleError(err) {
    console.error("Error: ", err);
    showElementWithText("#aviso", "Error al guardar la información. Por favor, intente de nuevo.");
}