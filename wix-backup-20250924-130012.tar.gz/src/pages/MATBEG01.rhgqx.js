const secuencia = [
  { pagina: 1, nombre: "group25" },
  { pagina: 2, nombre: "image74" },
  { pagina: 3, nombre: "group24" },
  { pagina: 4, nombre: "group23" },
  { pagina: 5, nombre: "image71" },
  { pagina: 6, nombre: "group22" },
  { pagina: 7, nombre: "group21" },
  { pagina: 8, nombre: "image68" },
  { pagina: 9, nombre: "image67" },
  { pagina: 10, nombre: "image66" },
  { pagina: 11, nombre: "image65" },
  { pagina: 12, nombre: "image64" },
  { pagina: 13, nombre: "image63" },
  { pagina: 14, nombre: "image62" },
  { pagina: 15, nombre: "image61" },
  { pagina: 16, nombre: "image60" },
  { pagina: 17, nombre: "group20" },
  { pagina: 18, nombre: "group19" },
  { pagina: 19, nombre: "group18" },
  { pagina: 20, nombre: "image56" },
  { pagina: 21, nombre: "image55" },
  { pagina: 22, nombre: "image54" },
  { pagina: 23, nombre: "image53" },
  { pagina: 24, nombre: "image52" },
  { pagina: 25, nombre: "image51" },
  { pagina: 26, nombre: "image50" },
  { pagina: 27, nombre: "image49" },
  { pagina: 28, nombre: "image48" },
  { pagina: 29, nombre: "image47" },
  { pagina: 30, nombre: "image46" },
  { pagina: 31, nombre: "group17" },
  { pagina: 32, nombre: "group16" },
  { pagina: 33, nombre: "image43" },
  { pagina: 34, nombre: "group15" },
  { pagina: 35, nombre: "image38" },
  { pagina: 36, nombre: "image41" },
  { pagina: 37, nombre: "image40" },
  { pagina: 38, nombre: "image39" },
  { pagina: 39, nombre: "image38" },
  { pagina: 40, nombre: "image37" },
  { pagina: 41, nombre: "image36" },
  { pagina: 42, nombre: "image35" },
  { pagina: 43, nombre: "image34" },
  { pagina: 44, nombre: "image33" },
  { pagina: 45, nombre: "group14" },
  { pagina: 46, nombre: "group13" },
  { pagina: 47, nombre: "group12" },
  { pagina: 48, nombre: "image29" },
  { pagina: 49, nombre: "image28" },
  { pagina: 50, nombre: "image27" },
  { pagina: 51, nombre: "image26" },
  { pagina: 52, nombre: "image25" },
  { pagina: 53, nombre: "image24" },
  { pagina: 54, nombre: "image23" },
  { pagina: 55, nombre: "image22" },
  { pagina: 56, nombre: "image21" },
  { pagina: 57, nombre: "image20" },
  { pagina: 58, nombre: "image19" },
  { pagina: 59, nombre: "image18" },
  { pagina: 60, nombre: "image16" },
  { pagina: 61, nombre: "image15" },
  { pagina: 62, nombre: "image14" },
  { pagina: 63, nombre: "image13" },
  { pagina: 64, nombre: "image12" },
  { pagina: 65, nombre: "image11" },
  { pagina: 66, nombre: "image10" },
  { pagina: 67, nombre: "image9" },
  { pagina: 68, nombre: "image8" },
  { pagina: 69, nombre: "image7" },
  { pagina: 70, nombre: "image6" },
  { pagina: 71, nombre: "image5" },
  { pagina: 72, nombre: "image4" }
];




	let currentIndex = 0;


$w.onReady(function () {

    // Oculta todos los elementos de la secuencia
    secuencia.forEach(item => {
        // Asegúrate que los IDs en Wix coincidan con item.nombre
        $w("#" + item.nombre).hide();
    });

    // Muestra el primer elemento (group15)
    $w("#" + secuencia[currentIndex].nombre).show();
});

$w('#adelanteButton').onClick((event) => {
    // Oculta el elemento actual
    $w("#" + secuencia[currentIndex].nombre).hide();

    // Comprueba que no sea el último elemento y actualiza el índice
    if (currentIndex < secuencia.length - 1) {
        currentIndex++;
    }
    // Muestra el siguiente elemento
    $w("#" + secuencia[currentIndex].nombre).show();
})

$w('#atrasButton').onClick((event) => {
    // Oculta el elemento actual
    $w("#" + secuencia[currentIndex].nombre).hide();

    // Comprueba que no sea el primer elemento y actualiza el índice
    if (currentIndex > 0) {
        currentIndex--;
    }
    // Muestra el elemento anterior
    $w("#" + secuencia[currentIndex].nombre).show();
})