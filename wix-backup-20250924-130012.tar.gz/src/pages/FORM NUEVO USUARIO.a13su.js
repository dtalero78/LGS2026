import wixData from 'wix-data';
import wixLocation from 'wix-location';
import wixWindow from 'wix-window';

let usuarioId;
let nombres;
let idAcademica;
let celular;
let nivel;

$w.onReady(function () {
    usuarioId = $w('#dynamicDataset').getCurrentItem().idEstudiante;
    nombres = $w('#dynamicDataset').getCurrentItem();
    nivel = nombres.nivel;
    celular = nombres.celular;
    idAcademica = nombres._id;
    let plataforma = nombres.plataforma;
    console.log(usuarioId, plataforma);
    $w('#nombres').text = `${nombres.primerNombre}, te estábamos esperando!`;

    // Verificar si ya tiene una sesión agendada WELCOME a futuro
    verificarSesionAgendada(usuarioId)
        .then(tieneSesion => {
            if (tieneSesion) {
                $w("#welcomeBooking").options = [
                    { label: "Ya tienes una sesión agendada", value: "" }
                ];
                $w("#welcomeBooking").disable();
            } else {
                cargarOpcionesDropdown();
            }
        })
        .catch(err => {
            console.error("Error verificando sesión agendada: ", err);
            // En caso de error, igual carga las opciones normales
            cargarOpcionesDropdown();
        });

    // Oculta #box por 3 segundos
    $w('#box').hide();

    // Dispara la ventana de bienvenida pasando nombres
    wixWindow.openLightbox("VIDEO BIENVENIDA", {
        nombres: nombres
    });

    // Después de 3 segundos, muestra #box nuevamente
    setTimeout(() => {
        $w('#box').show();
    }, 3000);

    if (nivel !== "WELCOME") {
        $w('#welcomeBooking').hide()
    }

    initializePage();
    cargarOpcionesDropdown();
});


async function verificarSesionAgendada(usuarioId) {
    const now = new Date();
    try {
        const result = await wixData.query("CLASSES")
            .eq("numeroId", usuarioId) // o "idEstudiante" según el campo en tu colección CLASSES
            .eq("tipoEvento", "WELCOME")
            .gt("fechaEvento", now)
            .find();
        // Retorna true si encuentra al menos un registro con fecha futura
        return result.items.length > 0;
    } catch (e) {
        console.error("Error consultando CLASSES:", e);
        return false;
    }
}


async function cargarOpcionesDropdown() {
    // Obtener la fecha de hoy
    let today = new Date();
    console.log("hola hoy")

    // Realizar query en la colección "CALENDARIO"
    wixData.query("CALENDARIO")
        .eq("nombreEvento", "WELCOME") // Filtrar por el campo tituloONivel con el valor "WELCOME"
        .gt("dia", today) // Filtrar por fechas iguales o superiores a la de hoy
        .ascending("dia") // Ordenar los resultados por fecha ascendente
        .find()
        .then((results) => {
            if (results.items.length > 0) {
                console.log("FEchas disponibles", results)
                let options = results.items.map((item) => {
                    // Validar que la fecha es válida
                    let fecha = new Date(item.dia);
                    if (isNaN(fecha.getTime())) {
                        console.error("Fecha no válida en el registro: ", item);
                        return { label: "Fecha no válida", value: item._id };
                    }

                    // Obtener el nombre del día (en español), número del día y la hora
                    let diaNombre = fecha.toLocaleString('es-ES', { weekday: 'long' });
                    let diaNumero = fecha.getDate();
                    let hora = fecha.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit', hour12: true });

                    // Formatear la hora a 12 horas con am/pm
                    let label = `${capitalizeFirstLetter(diaNombre)} ${diaNumero} - ${hora}`;

                    // Retornar el objeto con valor y etiqueta para el dropdown
                    return { label: label, value: item._id };
                });

                // Asignar las opciones al dropdown
                $w("#welcomeBooking").options = options;
            } else {
                console.log("No se encontraron resultados.");
                $w("#welcomeBooking").options = [{ label: "No hay eventos disponibles", value: "" }];
            }
        })
        .catch((err) => {
            console.error("Error al consultar la base de datos CALENDARIO: ", err);
        });
}

// Función auxiliar para capitalizar la primera letra de una cadena
function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
}

let fotoUrl; // ID de la persona guardada, se usa globalmente

// Prepara la página para su uso
function initializePage() {
    setupEventHandlers();
}

function setupEventHandlers() {
    // Botón de acción para pasar al siguiente grupo de formulario
    $w('#siguiente').onClick(handleNextButtonClick);
}

// Maneja el evento de clic en el botón "Siguiente"
async function handleNextButtonClick() {
    wixWindow.scrollTo(0, 0);
    let currentGroup = getCurrentGroup();
    if (currentGroup === 1) {
        let validation = validateFields();
        if (validation.isValid) {
            $w('#loading').show();
            // Verifica si el visitante del sitio eligió un archivo
            if ($w("#uploadButton1").value.length > 0) {
                // Espera a que la carga del archivo se complete
                await $w("#uploadButton1").uploadFiles().then((uploadedFiles) => {
                    uploadedFiles.forEach(uploadedFile => {
                        fotoUrl = uploadedFile.fileUrl; // Asigna la URL de la foto cargada a fotoUrl
                        console.log("Foto url:" + uploadedFile.fileUrl);
                    });
                    console.log("Upload successful.");
                    $w('#textoNuevoComercial').hide();
                    $w('#nombres').text = "Te esperamos en tu sesión Welcome!"
                    $w('#group1').hide();
                    $w('#grupoDespedida').show();
                    $w('#loading').hide();
                });
            } else if (!fotoUrl) { // Si el visitante del sitio no eligió un archivo y no hay una URL de foto existente
                console.log("Please choose a file to upload.");
                showElementWithText("#aviso", "Por favor, elige un archivo para subir.");
                return;
            }
            // Espera a que la información del titular se guarde después de la carga de archivos
            await actualizarRegistro();

            hideElement("#siguiente"); // Oculta el botón si es el último grupo
        } else {
            // Muestra advertencia si la validación falla
            showElementWithText("#aviso", `Por favor complete los siguientes campos: ${validation.missingFields.join(", ")}`);
        }
    }
}

// Valida los campos del formulario
function validateFields() {
    let isValid = true;
    let missingFields = [];

    if (!$w("#detallesPersonales").value.trim()) {
        isValid = false;
        missingFields.push("detalles personales");
    }
    if (!$w("#hobbies").value.trim()) {
        isValid = false;
        missingFields.push("hobbies");
    }
    if (!$w("#usuario").value.trim()) {
        isValid = false;
        missingFields.push("usuario");
    }
    if (!$w("#clave").value.trim()) {
        isValid = false;
        missingFields.push("clave");
    }
    if ($w("#uploadButton1").value.length === 0 && !fotoUrl) {
        isValid = false;
        missingFields.push("foto");
    }

    return { isValid, missingFields };
}

// Guarda información del titular
async function actualizarRegistro() {
    const person = createPersonObject();
    try {
        const existingRecord = await wixData.query("ACADEMICA").eq("idEstudiante", usuarioId).find();
        if (existingRecord.items.length > 0) {
            // Actualiza el registro existente sin borrar otros datos
            const updatedRecord = { ...existingRecord.items[0], ...person };
            const result = await wixData.update("ACADEMICA", updatedRecord);
            console.log("Registro actualizado con éxito en ACADEMICA:", result);

            // Ahora inserta un nuevo registro en BOOKING
            await guardarEnBooking();
        } else {
            console.log("No se encontró un registro con el idEstudiante proporcionado.");
        }
    } catch (err) {
        handleError(err);
    }
}

// Función para guardar el nuevo booking en la colección "BOOKING"
// Función para guardar el nuevo booking en la colección "BOOKING"
async function guardarEnBooking() {
    try {
        const datosEstudiante = $w("#dynamicDataset").getCurrentItem();
        const eventoSeleccionado = $w("#welcomeBooking").value;

        // Validar que haya seleccionado una opción
        if (!eventoSeleccionado) {
            showElementWithText("#aviso", "Selecciona una fecha para tu sesión Welcome.");
            $w('#loading').hide();
            return; // Sale de la función sin guardar nada
        }

        let nuevoBooking = {
            "idEstudiante": datosEstudiante._id,
            "primerNombre": datosEstudiante.primerNombre,
            "primerApellido": datosEstudiante.primerApellido,
            "numeroId": datosEstudiante.idEstudiante,
            "nivel": datosEstudiante.nivel,
            "tipoEvento": "WELCOME",
            "step": "WELCOME",
            "celular": datosEstudiante.celular,
            "plataforma": datosEstudiante.plataforma
        };

        // Si hay un evento seleccionado, agrega los detalles del evento
        const eventoData = await wixData.get("CALENDARIO", eventoSeleccionado);

        // Validar que la fecha del evento es válida
        let fechaEvento = new Date(eventoData.dia);
        if (isNaN(fechaEvento.getTime())) {
            showElementWithText("#aviso", "La fecha seleccionada no es válida.");
            return;
        }

        // Agregar los datos del evento al objeto nuevoBooking
        nuevoBooking.idEvento = eventoData._id;
        nuevoBooking.fechaEvento = fechaEvento;
        nuevoBooking.advisor = eventoData.advisor;

        // Inserción en BOOKING
        const bookingResults = await wixData.insert("BOOKING", nuevoBooking);
        console.log("Registro insertado con éxito en BOOKING:", bookingResults);

        // Inserción en CLASSES (opcional)
        const classesResults = await wixData.insert("CLASSES", nuevoBooking);
        console.log("Registro insertado con éxito en CLASSES:", classesResults);

    } catch (err) {
        console.error("Error al insertar en BOOKING o CLASSES:", err);
        showElementWithText("#aviso", "Error al guardar la información. Por favor, intente de nuevo.");
    }
}


// Crea el objeto de la persona con todos los campos necesarios
function createPersonObject() {
    return {
        usuarioId: usuarioId,
        detallesPersonales: $w("#detallesPersonales").value,
        hobbies: $w("#hobbies").value,
        email: $w("#usuario").value,
        clave: $w("#clave").value,
        foto: fotoUrl,

    };
}

// Muestra un elemento
function showElement(selector) {
    $w(selector).show();
}

// Oculta un elemento
function hideElement(selector) {
    $w(selector).hide();
}

// Muestra un elemento con texto específico
function showElementWithText(selector, text) {
    const element = $w(selector);
    element.text = text;
    element.show();
}

// Maneja errores generales
function handleError(err) {
    console.error("Error: ", err);
    showElementWithText("#aviso", "Error al guardar la información. Por favor, intente de nuevo.");
}

// Obtiene el grupo actual basado en la visibilidad de los grupos
function getCurrentGroup() {
    if (!$w(`#group1`).hidden) {
        return 1;
    }
    return 1; // Por defecto retorna el primer grupo si no se encuentra el actual
}