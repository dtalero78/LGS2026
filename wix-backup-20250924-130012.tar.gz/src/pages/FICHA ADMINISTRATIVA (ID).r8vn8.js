import wixData from 'wix-data';
import { sendTextMessage, sendTextMessageServicioUsuario } from 'backend/WHP';
import { sendmessage } from 'backend/realtime.jsw';

let idTitular;
let datos = $w('#dynamicDataset').getCurrentItem();
let numeroId = datos.numeroId;
let todosLosDatos = [];
let ultimoValorSlider = 0;
let edad;

// Función principal ejecutada al cargar la página
$w.onReady(function () {
    cargarDatosEstudianteYFinanciera();
    configurarEventosUI();

});

// Extiendo configurarEventosUI para incluir el resto de eventos
function configurarEventosUI() {
    $w('#comentarioTexto').onFocus(prepararCampoComentario);
    $w('#financieraButton').onClick(() => mostrarSeccion('financiera'));
    $w('#basicaButton').onClick(() => mostrarSeccion('basica'));
    $w('#comentariosButton').onClick(() => mostrarSeccion('comentarios'));
    $w('#guardar').onClick(guardarDatos);
    $w('#plataforma').onChange(filtrarPlanPorPlataforma);
    $w('#plan').onChange(filtrarConvenioPorPlan);
    $w('#convenio').onChange(actualizarTotalPlan);
    $w('#totalPlan').onChange(calcularYFormatoValorCuota);
    $w('#inscripcionPagada').onChange(calcularYFormatoValorCuota);
    $w('#numeroCuotas').onChange(calcularYFormatoValorCuota);
    $w('#aprobacion').onChange(handleAprobacionChange);

    $w('#guardarComentarioButton').onClick(() => guardarDatos());

    // Configurar validación de fechas en tiempo real
    const inputIds = ["#fechaIngreso", "#fechaPago"];
    inputIds.forEach(inputId => {
        $w(inputId).onInput(validateDateRealTime);
    });
}

async function handleAprobacionChange() {
    console.log("handleAprobacionChange ejecutado");
    const estadoAprobacion = $w('#aprobacion').value;
    console.log("Estado de aprobación:", estadoAprobacion); // Verificar el valor aquí

    if (estadoAprobacion === "Aprobado") {
        console.log("Estado aprobado, comenzando proceso...");
        const idAcademico = await crearRegistroAcademico();
        console.log("ID Académico generado:", idAcademico);

        // Enviar mensaje de texto de bienvenida
        const celular = $w('#celularInfoBox').value.toString();
        const message = `Hola 👋:\n\n*¡Eres parte de Lets Go Speak!* 🎉 \n\nPara terminar tu registro y crear tu usuario sigue este enlace:\n\nhttps://www.lgsplataforma.com/nuevo-usuario/${idAcademico}`;

        try {
            await enviarFormularioCreacionUsuario(celular, message);
            console.log("Formulario de creación de usuario enviado exitosamente.");
        } catch (error) {
            console.error("Error al enviar el formulario de creación de usuario:", error);
        }

        // Obtener crmContactId del estudiante
        try {
            let studentData = await wixData.get("PEOPLE", idTitular);
            let contactId = studentData.crmContactId; // Obtener el contactId
            console.log("crmContactId obtenido:", contactId);

            // Enviar correo electrónico de bienvenida

        } catch (err) {
            console.error("Error al obtener crmContactId o enviar el correo electrónico:", err);
        }
    } else {
        console.log("El estado de aprobación no es 'Aprobado'. No se ejecutará el proceso.");
    }
}

function enviarFormularioCreacionUsuario(celular, message) {
    $w('#avisoBox').show()
    $w('#avisoText').text = "Procesando..."

    sendTextMessageServicioUsuario(celular, message)
        .then(response => {
            console.log("Actividad enviada", response);
            $w('#avisoText').text = "Aprobado. Mensaje Enviado a Usuario"
            $w('#loading').hide()
        })
        .catch(err => {
            console.error("Error al enviar actividad", err);
        });
}

async function crearRegistroAcademico() {
    try {
        const primerNombre = $w('#primerNombre').value;
        const primerApellido = $w('#primerApellido').value;
        const email = $w('#email').value;
        const idEstudiante = idTitular;
        const plataforma = $w('#plataforma').value;
        const celular = $w('#celularInfoBox').value.toString();
        const aprobacion = $w('#aprobacion').value;
        const nivel = "BN1";
        const numeroId = $w('#numeroId').value


        const nuevoRegistroAcademico = {
            primerNombre,
            primerApellido,
            email,
            idEstudiante,
            plataforma,
            edad,
            celular,
            aprobacion,
            nivel,
            numeroId
        };

        const result = await wixData.insert("ACADEMICA", nuevoRegistroAcademico);
        console.log("Nuevo registro académico creado:", result);
        return result._id;
    } catch (err) {
        console.error("Error al crear el registro académico:", err);
    }
}

// Función asincrónica principal para cargar y manejar datos
async function cargarDatosEstudianteYFinanciera() {
    try {
        const userId = numeroId;

        // Query 1. Obtener datos del estudiante de la colección 'PEOPLE'
        const studentData = await obtenerDatos('PEOPLE', 'numeroId', userId);
        if (!studentData) {
            console.error("Estudiante no encontrado.");
            return;
        }

        idTitular = studentData._id;
        numeroId = studentData.numeroId;
        edad = studentData.edad;

        // Query 2. Para imprimir el primer Nombre y segundo Nombre del Asesor Asignado
        const comercialData = await obtenerDatos('COMERCIAL', '_id', studentData.agenteAsignado);
        if (!comercialData) {
            console.error("Datos comerciales no encontrados para el campo 'agenteAsignado'.");
        } else {
            // Query 3. Para obtener el nombre de la Filial en el campo asesorAsignado
            const filialData = await obtenerDatos('FILIALES', '_id', comercialData.filial);
            if (!filialData) {
                console.error("Datos de filial no encontrados para el campo 'filial' en COMERCIAL.");
            } else {
                const textoComercial = `${capitalizeFirstLetter(comercialData.primerNombre)} ${capitalizeFirstLetter(comercialData.primerApellido)} - ${filialData.filial}`;
                $w('#elTraining').value = textoComercial;

                // Query 4. Para obtener el valor de "lider" en el campo "superior1"
                const liderData = await obtenerDatos('COMERCIAL', '_id', comercialData.lider);
                if (!liderData) {
                    console.error("Datos del líder no encontrados para el campo 'lider' en COMERCIAL.");
                } else {
                    const liderText = `${capitalizeFirstLetter(liderData.primerNombre)} ${capitalizeFirstLetter(liderData.primerApellido)} - ${filialData.filial}`;
                    $w('#superior1').value = liderText;

                    // Query 5. Para obtener el nombre completo del superior del líder (líder del líder) junto con el nombre de la filial
                    const superiorData = await obtenerDatos('COMERCIAL', '_id', liderData.lider);
                    if (!superiorData) {
                        console.error("Datos del superior del líder no encontrados para el campo 'lider' en COMERCIAL.");
                    } else {
                        const superiorText = `${capitalizeFirstLetter(superiorData.primerNombre)} ${capitalizeFirstLetter(superiorData.primerApellido)} - ${filialData.filial}`;
                        $w('#superior2').value = superiorText;

                        // Query 6. Para obtener el nombre completo del superior del superior del líder (superior del líder del líder) junto con el nombre de la filial
                        const superior2Data = await obtenerDatos('COMERCIAL', '_id', superiorData.lider);
                        if (!superior2Data) {
                            console.error("Datos del superior del superior del líder no encontrados para el campo 'lider' en COMERCIAL.");
                        } else {
                            const superior2Text = `${capitalizeFirstLetter(superior2Data.primerNombre)} ${capitalizeFirstLetter(superior2Data.primerApellido)} - ${filialData.filial}`;
                            $w('#superior3').value = superior2Text;
                        }
                    }
                }
            }
        }
        $w('#primerNombre').value = studentData.primerNombre;
        $w('#segundoNombre').value = studentData.segundoNombre;
        $w('#primerApellido').value = studentData.primerApellido;
        $w('#segundoApellido').value = studentData.segundoApellido;
        $w('#numeroId').value = studentData.numeroId;
        $w('#numeroIdText').text = studentData.numeroId;
        $w('#nombres').text = studentData.primerNombre + " " + studentData.primerApellido + " " + studentData.tipoUsuario;
        $w('#nombresText2').text = capitalizeFirstLetter(studentData.primerNombre) + " " + capitalizeFirstLetter(studentData.segundoNombre) + " " + capitalizeFirstLetter(studentData.primerApellido) + " " + capitalizeFirstLetter(studentData.segundoApellido);
        $w('#nombreTextBoxInfoBasica').text = capitalizeFirstLetter(studentData.primerNombre) + " " + capitalizeFirstLetter(studentData.segundoNombre) + " - " + capitalizeFirstLetter(studentData.tipoUsuario);
        $w('#plataformaText').text = studentData.pais;
        $w('#celularText').text = studentData.celular;
        $w('#celularInfoBox').value = studentData.celular;
        $w('#statusText').text = studentData.aprobacion;
        $w('#plataforma').value = studentData.plataforma;
        $w('#plataformaText').text = studentData.plataforma;
        $w('#direccion').value = studentData.domicilio;
        $w('#email').value = studentData.email;
        $w('#numeroContrato').text = studentData.numeroContrato;
        $w('#fechaContratoText').text = studentData._createdDate.toLocaleDateString('es-ES', { day: '2-digit', month: 'short', year: 'numeric' });
        $w('#fechaContrato').value = studentData._createdDate.toLocaleDateString('es-ES', { day: '2-digit', month: 'short', year: 'numeric' });
        $w('#plan').value = studentData.plan;
        $w('#foto').src = studentData.foto;
        $w('#filialText').text = studentData.filial;
        $w('#origen').text = studentData.origen;
        $w('#plataformaCheckBox').checked = studentData.estadoPlataforma;
        $w('#comentarioTexto').value = studentData.comentariosAdministrativo;
        $w('#statusText').text = studentData.aprobacion;
        $w('#fechaIngreso').value = ajustarFormatoFecha(studentData.fechaIngreso);
        $w('#aprobacion').value = studentData.aprobacion;
        $w('#vigencia').text = studentData.vigencia

        // Obtener datos financieros del estudiante de la colección 'FINANCIERA'
        const financieraData = await obtenerDatos('FINANCIERA', 'numeroId', studentData.numeroId);
        if (!financieraData) {
            console.log("Datos financieros no encontrados.");
        } else {
            $w('#totalPlan').value = financieraData.totalPlan ? financieraData.totalPlan.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".") : "";
            $w('#fechaPago').value = ajustarFormatoFecha(financieraData.fechaPago);
            $w('#saldo').value = financieraData.saldo.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
            $w('#valorCuota').value = financieraData.valorCuota.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
            $w('#numeroCuotas').value = financieraData.numeroCuotas ? financieraData.numeroCuotas.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".") : "";
            $w('#inscripcionPagada').value = financieraData.inscripcionPagada ? financieraData.inscripcionPagada.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".") : "";
            $w('#formaPago').value = financieraData.formaPago;
            $w('#plan').value = financieraData.plan;
            $w('#confirmaJudithCheck').checked = financieraData.confirmaJudith;
            $w('#confirmaPrixusCheck').checked = financieraData.confirmaPrixus;
        }
    } catch (err) {
        console.error("Error al cargar los datos", err);
    }

    cargarComentarios();
}

async function cargarComentarios() {
    try {
        const studentData = await obtenerDatos('PEOPLE', 'numeroId', numeroId);
        if (!studentData || !studentData.comentarios) {
            console.error("No se encontraron comentarios o estudiante.");
            return;
        }

        todosLosDatos = studentData.comentarios.map((comment, index) => ({
            _id: `comment${index}`,
            fecha: new Date(comment.fecha).toLocaleDateString('es-ES') + ' ' + new Date(comment.fecha).toLocaleTimeString('es-ES'),
            texto: comment.comentario,
            fechaObj: new Date(comment.fecha) // Objeto Date para ordenamiento
        })).sort((a, b) => b.fechaObj - a.fechaObj); // Orden descendente

        configurarSlider();
        actualizarRepeater(0, 4); // Inicia mostrando los primeros dos elementos
    } catch (err) {
        console.error("Error al cargar y mostrar los comentarios", err);
    }
}

// SLIDER
function configurarSlider() {
    const itemsPorPagina = 4;
    $w('#slider1').max = Math.ceil(todosLosDatos.length / itemsPorPagina) - 1;
    $w('#slider1').value = 0;

    $w('#slider1').onChange((event) => {
        let paginaActual = parseInt(event.target.value, 10);
        if (paginaActual !== ultimoValorSlider) {
            actualizarRepeater(paginaActual, itemsPorPagina);
            setTimeout(() => {
                $w('#slider1').value = paginaActual;
                ultimoValorSlider = paginaActual;
            }, 100);
        }
    });
}

function actualizarRepeater(paginaActual, itemsPorPagina) {
    let startIndex = paginaActual * itemsPorPagina;
    let endIndex = startIndex + itemsPorPagina;
    let datosParaMostrar = todosLosDatos.slice(startIndex, endIndex);

    $w("#repeaterComentarios").data = datosParaMostrar;
    $w("#repeaterComentarios").forEachItem(($item, itemData, index) => {
        $item("#fechaRepeaterComentarios").text = itemData.fecha;
        $item("#comentarioRepeaterComentarios").text = itemData.texto;
    });
}

function validateDateRealTime(event) {
    const inputId = "#" + event.target.id; // Obtenemos el ID del campo de entrada que disparó el evento
    let inputDate = $w(inputId).value;
    const regexSimple = /^[0-9/]*$/;

    if (!regexSimple.test(inputDate)) {
        $w(inputId).value = inputDate.slice(0, -1);
        return; // Si el carácter introducido no es válido, salimos de la función
    }

    let parts = inputDate.split('/').filter(Boolean); // Divide la fecha en partes y elimina los elementos vacíos
    if (parts.length === 1 && parts[0].length === 2 && inputDate.endsWith('/') === false && inputDate.length < 6) {
        $w(inputId).value += '/';
    } else if (parts.length === 2 && parts[1].length === 2 && inputDate.endsWith('/') === false && inputDate.length === 5) {
        $w(inputId).value += '/';
    } else if (inputDate.length > 10) {
        $w(inputId).value = inputDate.slice(0, 10);
    }
    if (inputDate.length === 10) {
        // Actualización del regex para validar formato día/mes/año
        const regexComplete = /^(0[1-9]|[12][0-9]|3[01])\/(0[1-9]|1[0-2])\/\d{4}$/;
        if (!regexComplete.test(inputDate)) {
            console.warn("La fecha introducida en " + inputId + " no es válida");
        }
    }
}

function convertirCadenaAFecha(cadena) {
    if (!cadena) return undefined;

    // Verifica si la cadena ya está en el formato ISO 'YYYY-MM-DD'
    const regexISO = /^\d{4}-\d{2}-\d{2}$/;
    if (regexISO.test(cadena)) {
        // La cadena ya está en el formato correcto, retorna tal cual
        return cadena;
    }

    const partes = cadena.split('/');
    if (partes.length !== 3) {
        return undefined; // Retorna undefined si el formato no es correcto
    }

    const fechaFormatoISO = `${partes[2]}-${partes[1]}-${partes[0]}`;
    return fechaFormatoISO;
}

function ajustarFormatoFecha(cadena) {
    // Detecta si la entrada está en formato YYYY-MM-DD
    const regexISO = /^\d{4}-\d{2}-\d{2}$/;
    if (regexISO.test(cadena)) {
        // Convierte de YYYY-MM-DD a DD/MM/YYYY
        const [year, month, day] = cadena.split('-');
        return `${day}/${month}/${year}`;
    }
    // Si la entrada ya está en DD/MM/YYYY o cualquier otro caso, retorna sin cambios
    return cadena;
}

function convertirTextoANumero(texto) {
    if (!texto || isNaN(parseFloat(texto.replace(/\./g, '')))) {
        return undefined; // Retorna undefined solo si el texto no es convertible a número
    }
    // Elimina los puntos de la cadena y luego convierte el resultado a un número flotante
    return parseFloat(texto.replace(/\./g, ''));
}

// Función para obtener datos de la base de datos
async function obtenerDatos(coleccion, campo, valor) {
    const result = await wixData.query(coleccion).eq(campo, valor).find();
    return result.items.length > 0 ? result.items[0] : null;
}

// Función para preparar el campo de comentario con la fecha actual
function prepararCampoComentario() {
    let comentarioActual = $w('#comentarioTexto').value;
    let fechaActual = new Date();
    let fechaTexto = `${fechaActual.toLocaleDateString('es-ES', { day: '2-digit', month: 'short', year: 'numeric' })} ${fechaActual.toLocaleTimeString('es-ES')}`;

    // Añadimos la fecha solo si el campo está vacío para evitar sobre escribir
    if (!comentarioActual.trim()) {
        $w('#comentarioTexto').value = `${fechaTexto}:\n`;
    }
}

async function filtrarPlanPorPlataforma() {
    try {
        const plataformaSeleccionada = $w('#plataforma').value;
        const results = await wixData.query('TARIFAS').eq('pais', plataformaSeleccionada).find();
        const opcionesUnicas = [...new Set(results.items.map(item => item.plan))];

        $w('#plan').options = opcionesUnicas.map(plan => ({ label: plan, value: plan }));
    } catch (err) {
        console.error('Error al filtrar planes por plataforma', err);
    }
}

async function filtrarConvenioPorPlan() {
    try {
        const planSeleccionado = $w('#plan').value;
        const plataformaSeleccionada = $w('#plataforma').value;
        const results = await wixData.query('TARIFAS').eq('plan', planSeleccionado).eq('pais', plataformaSeleccionada).find();

        const opcionesUnicas = [...new Set(results.items.map(item => item.convenio))];
        $w('#convenio').options = opcionesUnicas.map(convenio => ({ label: convenio, value: convenio }));
    } catch (err) {
        console.error('Error al filtrar convenios por plan', err);
    }
}

async function actualizarTotalPlan() {
    try {
        const convenioSeleccionado = $w('#convenio').value;
        const planSeleccionado = $w('#plan').value;
        const plataformaSeleccionada = $w('#plataforma').value;
        const results = await wixData.query('TARIFAS').eq('convenio', convenioSeleccionado).eq('plan', planSeleccionado).eq('pais', plataformaSeleccionada).find();

        if (results.items.length > 0) {
            const tarifa = results.items[0].tarifa;
            $w('#totalPlan').value = tarifa.toString();
            // Asegurarse de convertir o manejar el valor del número de cuotas correctamente según la lógica de negocio
            $w('#numeroCuotas').value = $w('#plan').value; // Revisar esta línea para asegurar coherencia
        }
    } catch (err) {
        console.error('Error al actualizar el total del plan', err);
    }
}

function calcularYFormatoValorCuota() {
    // Parsear valores a números para realizar la operación
    let totalPlan = Math.round(parseFloat($w('#totalPlan').value.replace(/\./g, '').replace(/,/g, '.')) || 0);
    let inscripcionPagada = Math.round(parseFloat($w('#inscripcionPagada').value.replace(/\./g, '').replace(/,/g, '.')) || 0);
    let numeroCuotas = parseInt($w('#numeroCuotas').value, 10) || 1; // Asegura el manejo correcto como entero

    // Realizar la operación
    let valorCuota = Math.round((totalPlan - inscripcionPagada) / numeroCuotas);
    let saldo = Math.round(totalPlan - inscripcionPagada);

    // Asignar el resultado sin formato de decimales
    $w('#valorCuota').value = valorCuota.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
    $w('#saldo').value = saldo.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");

    // Formatear los valores de entrada para visualización
    $w('#totalPlan').value = totalPlan.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
    $w('#inscripcionPagada').value = inscripcionPagada.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
    $w('#numeroCuotas').value = numeroCuotas.toString();
}

// Manejar la interacción del usuario con la UI
function mostrarSeccion(seccion) {
    if (seccion === 'financiera') {
        $w('#infoBasicaBox').hide();
        $w('#comentariosBox').hide();
        $w('#infoFinancieraBox').show();
    } else if (seccion === 'basica') {
        $w('#infoBasicaBox').show();
        $w('#comentariosBox').hide();
        $w('#infoFinancieraBox').hide();
    } else if (seccion === 'comentarios') {
        $w('#comentariosBox').show();
        $w('#infoBasicaBox').hide();
        $w('#infoFinancieraBox').hide();
    }
}

// Asumiendo que 'idTitular' y 'numeroId' son globales y ya están establecidos
async function guardarDatos() {
    // Creamos un objeto donde almacenaremos solo los cambios
    let cambiosInfoBasica = {};
    let cambiosInfFinanciera = {};

    // Asignar valores a cambiosInfoBasica
    cambiosInfoBasica.segundoNombre = $w('#segundoNombre').value ? $w('#segundoNombre').value : undefined;
    cambiosInfoBasica.segundoApellido = $w('#segundoApellido').value ? $w('#segundoApellido').value : undefined;
    cambiosInfoBasica.primerNombre = $w('#primerNombre').value ? $w('#primerNombre').value : undefined;
    cambiosInfoBasica.primerApellido = $w('#primerApellido').value ? $w('#primerApellido').value : undefined;
    cambiosInfoBasica.plataforma = $w('#plataforma').value ? $w('#plataforma').value : undefined;
    cambiosInfoBasica.numeroId = $w('#numeroId').value ? $w('#numeroId').value : undefined;
    cambiosInfoBasica.fechaIngreso = $w('#fechaIngreso').value ? $w('#fechaIngreso').value : undefined;
    cambiosInfoBasica.email = $w('#email').value ? $w('#email').value : undefined;
    cambiosInfoBasica.elTraining = $w('#elTraining').value ? $w('#elTraining').value : undefined;
    cambiosInfoBasica.domicilio = $w('#direccion').value ? $w('#direccion').value : undefined;
    cambiosInfoBasica.celular = $w('#celularInfoBox').value ? $w('#celularInfoBox').value : undefined;
    cambiosInfoBasica.aprobacion = $w('#aprobacion').value ? $w('#aprobacion').value : undefined;
    cambiosInfoBasica.estadoPlataforma = $w('#plataformaCheckBox').checked ? $w('#plataformaCheckBox').checked : undefined;

    // Log para depuración
    console.log("Cambios en info básica antes de eliminar indefinidos:", cambiosInfoBasica);

    // Eliminar propiedades indefinidas antes de proceder
    Object.keys(cambiosInfoBasica).forEach(key => cambiosInfoBasica[key] === undefined && delete cambiosInfoBasica[key]);

    // Verificar si hay cambios
    if (Object.keys(cambiosInfoBasica).length === 0) {
        console.log("No hay cambios para actualizar.");
        return;
    }

    console.log("Cambios en info básica después de eliminar indefinidos:", cambiosInfoBasica);

    // Convertir fechaIngreso a formato adecuado
    console.log("Antes de la conversión de fechaIngreso: ", $w('#fechaIngreso').value);
    cambiosInfoBasica.fechaIngreso = convertirCadenaAFecha($w('#fechaIngreso').value);
    console.log(cambiosInfoBasica.plataforma);

    // Actualizar registro en la base de datos
    try {
        let resultados = await wixData.query('PEOPLE')
            .eq("_id", idTitular)
            .find();

        if (resultados.items.length > 0) {
            let datosActualizados = resultados.items[0];
            datosActualizados = { ...datosActualizados, ...cambiosInfoBasica };

            console.log("Datos actualizados antes de guardar:", datosActualizados);

            // Extraer la fecha y el comentario del campo de texto
            let valorCompleto = $w('#comentarioTexto').value;

            if (valorCompleto) {
                if (!valorCompleto.includes(':\n')) {
                    console.error('Formato de comentario incorrecto');
                } else {
                    let [fechaConEtiqueta, comentario] = valorCompleto.split(':\n');
                    let fecha = fechaConEtiqueta.replace('Fecha: ', '').trim();

                    let nuevoComentario = {
                        fecha: new Date(fecha), // Convertimos la fecha a objeto Date
                        comentario: comentario.trim() // Aseguramos que no hay espacios innecesarios
                    };

                    // Añadir comentario
                    datosActualizados.comentarios = datosActualizados.comentarios || [];
                    datosActualizados.comentarios.push(nuevoComentario);
                }
            }

            // Actualizar el registro
            await wixData.update("PEOPLE", datosActualizados);
            console.log("Registro actualizado correctamente");

            // Publicar mensaje en el canal
            sendmessage({
                type: "update", // tipo de mensaje para controlar la lógica en el suscriptor
                message: "Datos actualizados"
            });

            // Limpiar el campo de comentario después de guardar
            $w('#comentarioTexto').value = "";
            $w('#guardar').label = "¡GUARDADO!"

            // Actualizar campo aprobación para todos los registros con el mismo numeroId, excepto el actual
            await actualizarAprobacionParaTodosLosRegistrosExceptoActual(idTitular, cambiosInfoBasica.aprobacion);

        } else {
            throw new Error("Registro no encontrado.");
        }

    } catch (err) {
        console.error("Error al actualizar el registro:", err);
    }

    // Asignar valores a cambiosInfFinanciera
    cambiosInfFinanciera.valorCuota = $w('#valorCuota').value ? $w('#valorCuota').value : undefined;
    cambiosInfFinanciera.totalPlan = $w('#totalPlan').value ? $w('#totalPlan').value : undefined;
    cambiosInfFinanciera.saldo = $w('#saldo').value ? $w('#saldo').value : undefined;
    cambiosInfFinanciera.primerNombre = $w('#primerNombre').value ? $w('#primerNombre').value : undefined;
    cambiosInfFinanciera.primerApellido = $w('#primerApellido').value ? $w('#primerApellido').value : undefined;
    cambiosInfFinanciera.plan = $w('#plan').value ? $w('#plan').value : undefined;
    cambiosInfFinanciera.numeroCuotas = $w('#numeroCuotas').value ? $w('#numeroCuotas').value : undefined;
    //cambiosInfFinanciera.numeroContrato = $w('#numeroContrato').value ? $w('#numeroContrato').value : undefined;
    cambiosInfFinanciera.inscripcionPagada = $w('#inscripcionPagada').value ? $w('#inscripcionPagada').value : undefined;
    cambiosInfFinanciera.idUsuario = idTitular;
    cambiosInfFinanciera.formaPago = $w('#formaPago').value ? $w('#formaPago').value : undefined;
    cambiosInfFinanciera.fechaPago = $w('#fechaPago').value ? $w('#fechaPago').value : undefined;
    //cambiosInfFinanciera.facturaNo = $w('#facturaNo').value ? $w('#facturaNo').value : undefined;
    cambiosInfFinanciera.confirmaPrixus = $w('#confirmaPrixusCheck').checked ? $w('#confirmaPrixusCheck').checked : undefined;
    cambiosInfFinanciera.confirmaJudith = $w('#confirmaJudithCheck').checked ? $w('#confirmaJudithCheck').checked : undefined;

    // Eliminar propiedades indefinidas antes de proceder
    Object.keys(cambiosInfFinanciera).forEach(key => cambiosInfFinanciera[key] === undefined && delete cambiosInfFinanciera[key]);

    if (Object.keys(cambiosInfFinanciera).length > 0) {
        try {
            let resultados = await wixData.query('FINANCIERA')
                .eq("numeroId", numeroId)
                .find();

            if (resultados.items.length > 0) {
                let financieraData = resultados.items[0];
                await wixData.update("FINANCIERA", { ...financieraData, ...cambiosInfFinanciera });
            } else {
                let nuevoRegistroFinanciera = { ...cambiosInfFinanciera, "numeroId": numeroId };
                await wixData.insert("FINANCIERA", nuevoRegistroFinanciera);
            }
            await cargarDatosEstudianteYFinanciera();
            console.log("Información financiera procesada correctamente");
        } catch (err) {
            console.error("Error al procesar la información financiera:", err);
        }
    } else {
        console.log("No hay cambios en la información financiera para procesar.");
    }
}

async function actualizarAprobacionParaTodosLosRegistrosExceptoActual(idTitularActual, nuevaAprobacion) {
    try {
        const numeroId = $w('#numeroId').value;

        // Obtener todos los registros con el mismo numeroId excepto el actual
        const resultados = await wixData.query('PEOPLE')
            .eq('numeroId', numeroId)
            .ne('_id', idTitularActual) // Excluir el registro actual
            .find();

        // Actualizar el campo aprobacion para cada registro sin eliminar otros datos
        const actualizaciones = resultados.items.map(async (registro) => {
            let datosActualizados = { ...registro, aprobacion: nuevaAprobacion };
            return wixData.update('PEOPLE', datosActualizados);
        });

        await Promise.all(actualizaciones);
        console.log(`Campo aprobación actualizado para todos los registros duplicados con numeroId ${numeroId}`);
    } catch (err) {
        console.error("Error al actualizar el campo aprobación para todos los registros duplicados:", err);
    }
}

function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1).toLowerCase();
}

export function closeAvisoBox_click(event) {
    $w('#avisoBox').hide()
}