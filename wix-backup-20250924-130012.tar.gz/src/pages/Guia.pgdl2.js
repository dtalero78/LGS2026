import wixData from 'wix-data';
import { processBatch } from 'backend/PURGAR';
import { sendMessagesBasedOnEvent } from 'backend/jobs';
import { actualizarEstadosContratos } from 'backend/VIGENCIA';

let debounceTimer;
const debounceDelay = 500;
let idUsuario = ""

$w.onReady(function () {
    // Añade un evento onClick al botón
    $w('#yourButtonID').onClick(async () => {
        try {
            const result = await sendMessagesBasedOnEvent();
            console.log('Messages sent successfully:', result);
            // Opcional: muestra un mensaje de éxito al usuario
        } catch (error) {
            console.error('Error sending messages:', error);
            // Opcional: muestra un mensaje de error al usuario
        }
    });

    $w('#corregirCelButt').onClick(corregirCel_click);

});

$w.onReady(function () {
    $w("#search").onKeyPress((event) => {
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(() => {
            realizarBusqueda($w("#search").value);
        }, debounceDelay);
    });
});

function realizarBusqueda(query) {
    $w('#noExiste').hide();
    // Si el input está vacío o contiene menos de 3 caracteres, resetea el estado sin buscar
    if (query.length < 3) {
        $w("#resultadoBusqueda").data = []; // Limpia los datos del repetidor
        $w('#resultadoBusqueda').collapse(); // Esconde el repetidor
        return; // Sale de la función para no ejecutar una búsqueda
    }
    $w('#loading').expand();

    // Realiza consultas en todas las bases de datos relevantes
    const dbQueries = ["COMERCIAL", "ADVISORS", "PEOPLE", "PROSPECTOS"].map(collection =>
        wixData.query(collection)
        .contains("primerNombre", query)
        .find()
        .then(results => results.items)
        .catch(err => {
            console.error(`Error querying ${collection}:`, err);
            return []; // Retorna un array vacío en caso de error
        })
    );

    Promise.all(dbQueries)
        .then(resultsArrays => {
            const combinedResults = resultsArrays.flat(); // Combina los arrays de resultados
            if (combinedResults.length > 0) {
                $w('#resultadoBusqueda').expand(); // Muestra el repetidor con los resultados
                $w("#resultadoBusqueda").data = combinedResults.map(item => ({
                    ...item,
                    nombreCompleto: `${(item.primerNombre)} ${(item.primerApellido)}, ${item.email}`
                }));

                $w("#resultadoBusqueda").forEachItem(($item, itemData, index) => {
                    $item("#resultados").text = itemData.nombreCompleto;

                });
            } else {
                $w('#noExiste').show();
                $w("#resultadoBusqueda").data = [];
                $w('#resultadoBusqueda').collapse(); // Si no hay resultados, también esconde el repetidor
                console.log("No se encontraron resultados");
            }
            $w('#loading').collapse();
        })
        .catch(err => {
            console.error("Error processing combined results:", err);
            $w('#loading').collapse();
        });
}

$w.onReady(function () {
    $w("#botonActualizar").onClick(async () => {
        try {
            let allRecords = [];
            let hasMore = true;
            let skip = 0;
            const batchSize = 100; // Puedes subirlo a 1000 si estás seguro que no se rompe

            // Traer todos los registros en lotes
            while (hasMore) {
                const result = await wixData.query("PEOPLE")
                    .limit(batchSize)
                    .skip(skip)
                    .find();

                allRecords.push(...result.items);
                skip += batchSize;
                hasMore = result.hasNext();
            }

            if (allRecords.length === 0) {
                console.log("No hay registros en la colección PEOPLE.");
                return;
            }

            // Agrupar registros por contrato
            const groupedContracts = allRecords.reduce((acc, item) => {
                const contrato = item.contrato;
                if (!acc[contrato]) {
                    acc[contrato] = [];
                }
                acc[contrato].push(item);
                return acc;
            }, {});

            // Actualizar registros con el titularId
            const updatePromises = [];
            for (const contrato in groupedContracts) {
                const group = groupedContracts[contrato];
                const titularRecord = group.find(item => item.tipoUsuario === "TITULAR");

                if (titularRecord) {
                    const titularId = titularRecord._id;

                    group.forEach((record) => {
                        if (record.tipoUsuario !== "TITULAR") {
                            const updatedRecord = { ...record, titularId };
                            updatePromises.push(wixData.update("PEOPLE", updatedRecord));
                        }
                    });
                }
            }

            await Promise.all(updatePromises);

            console.log("✅ Todos los registros fueron actualizados correctamente.");
        } catch (error) {
            console.error("❌ Error actualizando registros:", error);
        }
    });
});

$w("#botonEnviar").onClick(async () => {
    try {
        $w("#botonEnviar").disable();
        $w("#statusText").text = "Iniciando el envío de mensajes...";
        console.log("Iniciando el envío de mensajes...");

        let skipCount = 0;
        const limit = 10; // Registros por lote
        let hasMoreRecords = true;

        while (hasMoreRecords) {
            // Llamar a la función backend para procesar un lote
            const result = await processBatch(skipCount, limit);
            console.log(result.message);
            $w("#statusText").text = result.message;

            // Incrementar el contador de registros procesados
            skipCount += limit;

            // Si no hay más registros, salir del bucle
            if (result.message === "No hay más registros para procesar.") {
                hasMoreRecords = false;
            }
        }

        $w("#statusText").text = "Proceso completado. Todos los mensajes fueron enviados.";
        console.log("Proceso completado.");
    } catch (error) {
        console.error("Error al enviar los mensajes:", error);
        $w("#statusText").text = "Ocurrió un error al enviar los mensajes.";
    } finally {
        $w("#botonEnviar").enable();
    }
});

$w('#VIGENCIAS').onClick((event) => {
    actualizarEstadosContratos().then(console.log).catch(console.error);
})

export async function corregirCel_click(event) {
    try {
        const resultadoCorrecciones = await wixData.query("CelCorregir").limit(1000).find();
        const correcciones = resultadoCorrecciones.items;

        const noEncontrados = [];

        for (const correccion of correcciones) {
            const numeroId = correccion.numeroId;
            const nuevoCelular = correccion.celular;
            const nombreCompleto = correccion.nombreCompleto;

            if (!numeroId || !nuevoCelular) continue;

            const resultadoPersona = await wixData.query("ACADEMICA").eq("numeroId", numeroId).find();

            if (resultadoPersona.items.length > 0) {
                const persona = resultadoPersona.items[0];
                persona.celular = nuevoCelular;
                await wixData.update("ACADEMICA", persona);
                console.log(`✅ Celular actualizado para numeroId ${numeroId}`);
            } else {
                console.warn(`⚠️ No se encontró persona con numeroId ${numeroId}`);
                noEncontrados.push({
                    numeroId,
                    celular: nuevoCelular,
                    nombreCompleto
                });
            }
        }

        if (noEncontrados.length > 0) {
            $w('#celNoEncontrados').columns = [
                { id: "numeroId", label: "Número ID", dataPath: "numeroId", type: "string" },
                { id: "celular", label: "Celular", dataPath: "celular", type: "string" },
                { id: "nombreCompleto", label: "Nombre Completo", dataPath: "nombreCompleto", type: "string" }
            ];

            $w('#celNoEncontrados').rows = noEncontrados;
            $w('#celNoEncontrados').expand();
        } else {
            $w('#celNoEncontrados').collapse();
        }

        console.log("🎉 Corrección de celulares finalizada.");
    } catch (error) {
        console.error("❌ Error al corregir celulares:", error);
    }
}


//---------------
//ACTUALIZAR STEPS
//---------------

import { actualizarTodosLosSteps } from 'backend/actualizarStep';

$w('#actualizarSteps').onClick(() => {
  actualizarTodosLosSteps().then(() => {
    console.log("Actualización completa ✅");
  }).catch(err => {
    console.error("Error al actualizar:", err);
  });
});
