import { enviarBase64AlBackend } from 'backend/excel';
import wixLocation from 'wix-location';

$w('#convertir').onClick(async () => {
  try {
    const url = "https://cb64693d-aa2a-40c7-beb5-acdea517e9da.usrfiles.com/ugd/cb6469_840df6536e274eb4ad0e5aa2640d25ce.xlsx";

    // 1. Hacer fetch del archivo como arrayBuffer
    const response = await fetch(url);
    const arrayBuffer = await response.arrayBuffer();

    // 2. Convertir buffer a base64 (requerido para backend)
    const uint8Array = new Uint8Array(arrayBuffer);
    const base64String = btoa(String.fromCharCode(...uint8Array));

    // 3. Enviar al backend para procesar y generar CSV
    const fileUrl = await enviarBase64AlBackend(base64String);

    console.log("✅ Archivo generado:", fileUrl);

    // 4. Redirigir para que el usuario descargue
    wixLocation.to(fileUrl);

  } catch (err) {
    console.error("❌ Error al procesar el Excel:", err);
  }
});
