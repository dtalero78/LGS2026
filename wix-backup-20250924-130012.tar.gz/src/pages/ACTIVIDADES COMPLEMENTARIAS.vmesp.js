import wixData from 'wix-data';
import { callOpenAI } from 'backend/OpenAI';
import wixLocation from 'wix-location';
import wixWindow from 'wix-window';

let attemptCount = 0;
let datosEstudiante = {};

const CONSTANTS = {
    LEVEL_MATERIAL_MAPPING: {
        "F1": "/material-f1", "F1 JUMP": "/material-f1",
        "F2": "/material-f2", "F2 JUMP": "/material-f2", 
        "F3": "/material-f3", "F3 JUMP": "/material-f3",
        "P1": "/material-p1", "P1 JUMP": "/material-p1",
        "P2": "/material-p2", "P2 JUMP": "/material-p2",
        "P3": "/material-p3", "P3 JUMP": "/material-p3",
        "BN1": "/material-bn1", "BN1 JUMP": "/material-bn1",
        "BN2": "/material-bn2", "BN2 JUMP": "/material-bn2",
        "BN3": "/material-bn3", "BN3 JUMP": "/material-bn3"
    },
    MAX_ATTEMPTS: 3
};

function splitQuestions(text) {
    const questions = text.split('\n\n').map(q => q.trim()).filter(q => q.length > 0);
    return questions.map(q => {
        const parts = q.split('\n').map(part => part.trim());
        const questionText = parts[0];
        const options = parts.slice(1).filter(part => part.length > 0).map(option => option.replace(/^- /, ''));

        let type;
        if (options.length === 2 && options.some(opt => opt.toLowerCase() === "verdadero") && options.some(opt => opt.toLowerCase() === "falso")) {
            type = "trueFalse";
        } else if (options.length > 1) {
            type = "multipleChoice";
        } else {
            type = "openEnded";
        }

        return {
            question: questionText,
            options: options,
            type: type
        };
    });
}

async function getGrades(responses, totalQuestions) {
    const prompt = `Califica las siguientes respuestas a las preguntas y asigna una puntuación porcentual total basado en el número total de preguntas (cada pregunta vale ${100 / totalQuestions}%). 
    Proporciona las correcciones y puntuaciones de cada pregunta sin introducciones adicionales. Usa emojis también. La calificación total siempre debe llevar la leyenda "Puntuación total:" \n\n${responses.map((r, index) => 
        `Pregunta ${index + 1}: ${r.question}\nRespuesta: ${r.answer}\n`).join('\n')}`;

    try {
        const response = await callOpenAI(prompt);
        const grades = response.choices[0].message.content;
        console.log("Calificaciones obtenidas:", grades);

        const percentage = extractPercentage(grades);
        console.log("Porcentaje extraído:", percentage);
        
        if (percentage !== null && percentage >= 80) {
            $w('#nivel').text = "¡Felicitaciones! Prueba superada";
        }

        return grades;
    } catch (error) {
        console.error('Error al calificar las respuestas:', error);
        throw error;
    }
}

function extractPercentage(gradeText) {
    const match = gradeText.match(/Puntuación total: (\d+)%/i);
    return match ? parseInt(match[1], 10) : null;
}

function showLoading() {
    if ($w('#loading')) {
        $w('#loading').show();
    }
}

function hideLoading() {
    if ($w('#loading')) {
        $w('#loading').hide();
    }
}

function clearRepeaterFields() {
    if ($w('#repeater1')) {
        $w('#repeater1').forEachItem(($item, itemData, index) => {
            const radioButtonGroup = $item("#radioButtonGroup");
            const textInputOpenEnded = $item("#textInputOpenEnded");

            if (radioButtonGroup) {
                radioButtonGroup.value = null;
            }
            if (textInputOpenEnded) {
                textInputOpenEnded.value = '';
            }
        });
    }
}

async function generateActivity(contenido) {
    const prompt = `Genera una prueba de 10 preguntas relacionadas con el siguiente contenido: "${contenido}". 
                    Las 4 primeras preguntas deben ser de opción múltiple, la quinta debe ser verdadero o falso y las sexta y séptima respuesta abierta y octava y novena opción múltiple
                    Genera las opciones sin numerarlas ni usar letras como "a)", "b)", etc. Solo imprime el test sin encabezados adicionales.`;

    try {
        const response = await callOpenAI(prompt);
        console.log("Prueba generada (raw):", response);

        const prueba = response.choices[0].message.content;
        console.log("Contenido de la prueba:", prueba);

        let questions = splitQuestions(prueba);
        console.log("Preguntas divididas:", questions);

        let repeater = $w('#repeater1');
        if ($w('#repetidorPreguntas')) {
            $w('#repetidorPreguntas').expand();
        }

        repeater.data = questions.map((question, index) => ({
            "_id": `${index}`,
            "questionText": question.question,
            "options": question.options,
            "type": question.type
        }));

        repeater.onItemReady(($item, itemData) => {
            $item("#textField").text = itemData.questionText;

            let radioButtonGroup = $item("#radioButtonGroup");
            let textInputOpenEnded = $item("#textInputOpenEnded");

            if (itemData.type === "multipleChoice") {
                radioButtonGroup.options = itemData.options.map(option => ({
                    label: option,
                    value: option
                }));
                radioButtonGroup.show();
                textInputOpenEnded.hide();
            } else if (itemData.type === "trueFalse") {
                radioButtonGroup.options = [
                    { label: "Verdadero", value: "Verdadero" },
                    { label: "Falso", value: "Falso" }
                ];
                radioButtonGroup.show();
                textInputOpenEnded.hide();
            } else {
                radioButtonGroup.hide();
                textInputOpenEnded.show();
            }
        });

        repeater.show();
        hideLoading();

    } catch (error) {
        console.error('Error al generar la prueba:', error);
        hideLoading();
        throw error;
    }
}

function collectResponses() {
    let responses = [];
    if ($w('#repeater1')) {
        $w('#repeater1').forEachItem(($item, itemData, index) => {
            const question = itemData.questionText;
            let answer = "";

            const radioButtonGroup = $item("#radioButtonGroup");
            const textInputOpenEnded = $item("#textInputOpenEnded");

            if (radioButtonGroup && radioButtonGroup.value) {
                answer = radioButtonGroup.value;
            } else if (textInputOpenEnded && textInputOpenEnded.value) {
                answer = textInputOpenEnded.value;
            }

            responses.push({ question, answer });
        });
    }
    return responses;
}

async function saveToDatabase(studentData, grades) {
    const newItem = {
        "primerNombre": studentData.primerNombre,
        "primerApellido": studentData.primerApellido,
        "idEstudiante": studentData.idEstudiante,
        "tipoEvento": "COMPLEMENTARIA",
        "step": studentData.step,
        "calificacion": grades,
        "numeroId": studentData.numeroId,
        "fechaEvento": new Date(),
        "asistencia": true,
        "participacion": true
    };

    try {
        const result = await wixData.insert("CLASSES", newItem);
        console.log("Nuevo ítem insertado en la base de datos 'CLASSES':", result);
        return result;
    } catch (dbError) {
        console.error('Error al insertar el ítem en la base de datos:', dbError);
        throw dbError;
    }
}

async function setupMaterialLink(step) {
    try {
        // Consultar la base de datos NIVELES para obtener el nivel basado en el step
        const result = await wixData.query("NIVELES")
            .eq("step", step)
            .find();

        if (result.items.length > 0) {
            const nivelEstudiante = result.items[0].code; // Obtener el código del nivel
            console.log("Nivel encontrado para step", step, ":", nivelEstudiante);
            
            const materialLink = CONSTANTS.LEVEL_MATERIAL_MAPPING[nivelEstudiante] || 
                                "https://www.lgsplataforma.com";
            
            console.log("Configurando link de material:", materialLink);
            
            $w('#verMaterial').link = materialLink;
            $w('#verMaterial').target = "_blank";
            
        } else {
            console.warn("No se encontró nivel para el step:", step);
            // Usar link por defecto
            $w('#verMaterial').link = "https://www.lgsplataforma.com";
            $w('#verMaterial').target = "_blank";
        }
    } catch (error) {
        console.error('Error al configurar el link de material:', error);
        // En caso de error, usar link por defecto
        $w('#verMaterial').link = "https://www.lgsplataforma.com";
        $w('#verMaterial').target = "_blank";
    }
}

function validateResponses(responses) {
    const unansweredQuestions = responses.filter((response, index) => 
        !response.answer || response.answer.trim() === ""
    );
    
    if (unansweredQuestions.length > 0) {
        console.warn(`Hay ${unansweredQuestions.length} preguntas sin responder`);
        return false;
    }
    return true;
}

$w.onReady(async function () {
    const urlParams = wixLocation.query;

    // Extraer parámetros de la URL
    const {
        idEvento,
        idEstudiante,
        primerNombre,
        primerApellido,
        numeroId,
        fechaEvento,
        advisor,
        step,
        studentId
    } = urlParams;

    console.log({ idEvento, idEstudiante, primerNombre, primerApellido, numeroId, fechaEvento, advisor, step, studentId });

    // Validar parámetros requeridos
    if (!primerNombre || !primerApellido || !step) {
        console.error("Faltan parámetros requeridos en la URL");
        return;
    }

    // Configurar datos del estudiante
    datosEstudiante = {
        idEvento,
        idEstudiante,
        primerNombre,
        primerApellido,
        numeroId,
        fechaEvento,
        advisor,
        step,
        studentId
    };

    // Configurar interfaz
    $w('#nombreCompleto').text = `${primerNombre} ${primerApellido}\n${step}`;
    $w('#nombreBoxBienvenida').text = "Hola " + primerNombre;
    $w('#nivel').text = `Step: ${step}`;

    let contenido = "";

    // Obtener contenido de la base de datos
    try {
        const result = await wixData.query("NIVELES")
            .eq("step", step)
            .find();

        if (result.items.length > 0) {
            contenido = result.items[0].contenido;
            console.log("Contenido obtenido de la base de datos:", contenido);
        } else {
            console.error("No se encontró contenido para el step especificado:", step);
        }
    } catch (error) {
        console.error('Error al obtener el contenido de la base de datos:', error);
    }

    // Configurar el link de material
    await setupMaterialLink(step);

    // Configurar evento del botón generar actividad
    $w('#generarActividad').onClick(async () => {
        attemptCount++;
        
        if (attemptCount > CONSTANTS.MAX_ATTEMPTS) {
            $w('#generarActividad').disable();
            console.error(`Se han alcanzado los ${CONSTANTS.MAX_ATTEMPTS} intentos permitidos.`);
            return;
        }

        if (!contenido) {
            console.error('No se puede generar la actividad porque el contenido no está disponible.');
            return;
        }

        // Limpiar campos del repetidor
        clearRepeaterFields();
        showLoading();

        console.log("Botón 'Generar Actividad' clickeado - Intento:", attemptCount);

        try {
            await generateActivity(contenido);
        } catch (error) {
            console.error('Error al generar la actividad:', error);
            hideLoading();
        }
    });

    // Configurar evento del botón finalizar
    $w('#finalizarButton').onClick(async () => {
        console.log("Botón 'Finalizar' clickeado");
        
        const responses = collectResponses();
        console.log("Respuestas recopiladas:", responses);

        // Validar que todas las preguntas estén respondidas
        if (!validateResponses(responses)) {
            console.warn("No todas las preguntas han sido respondidas");
            // Aquí podrías mostrar un mensaje al usuario
            return;
        }

        wixWindow.scrollTo(0, 0);
        showLoading();

        try {
            const grades = await getGrades(responses, responses.length);
            console.log("Calificaciones obtenidas:", grades);

            $w('#calificacion').text = grades;
            $w('#calificacionBox').show();
            if ($w('#repetidorPreguntas')) {
                $w('#repetidorPreguntas').collapse();
            }
            hideLoading();

            // Guardar en base de datos
            await saveToDatabase(datosEstudiante, grades);

        } catch (error) {
            console.error('Error al procesar las respuestas:', error);
            hideLoading();
        }
    });
});

// Funciones exportadas para eventos de la interfaz
export function closeRespuestasBox_click(event) {
    if ($w('#calificacionBox')) {
        $w('#calificacionBox').hide();
    }
}

export function closeBienvenidaBox_click(event) {
    if ($w('#bienvenidaBox')) {
        $w('#bienvenidaBox').hide();
    }
}