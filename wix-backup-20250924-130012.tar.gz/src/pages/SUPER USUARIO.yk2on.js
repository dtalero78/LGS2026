import wixData from 'wix-data';
import { sendTextMessage, sendTextMessageServicioUsuario } from 'backend/WHP';

$w.onReady(function () {

    /*
        // -----  BLOQUE DE RECONOCIMIENTO DE TOKEN LOGIN
        const tokenData = JSON.parse(session.getItem('accessToken'));
        if (tokenData) {
            const currentTime = new Date().getTime();
            // Convertir el tiempo de expiración a una fecha legible
            const expirationDate = new Date(tokenData.expiresAt);
            console.log(`El token expira el: ${expirationDate.toLocaleString()}`);
            if (currentTime > tokenData.expiresAt) {
                // Token ha expirado
                session.removeItem('accessToken');
                console.log("Token Acabado") // Eliminar el token expirado
                wixLocation.to(`/login`); // Redirigir a una página de error o login
            } else {
                // Token es válido
                // Aquí puedes continuar cargando el contenido de la página
            }
        } else {
            console.log("Token Expirado") // Eliminar el token expirado
            wixLocation.to(`/login`); // Redirigir a una página de error o login
        }
        //
        */

    $w('#createStepButton').target = "_blank"

    mostrarUsuarioSeleccionado(); // Cargar todos los datos inicialmente

});

// Variables de paginación
let paginaActual = 0;
const registrosPorPagina = 10;
let totalPaginas = 0;
let allUsersData = []; // Guardará todos los datos obtenidos de la consulta
let filteredData = []; // Datos filtrados por la búsqueda

function mostrarUsuarioSeleccionado() {
    wixData.query("PEOPLE")
        .eq("tipoUsuario", "BENEFICIARIO")
        .isEmpty("estado")
        .descending("_createdDate")
        .limit(1000)
        .find()
        .then((result) => {
            if (result.items.length > 0) {
                // Guardar todos los registros en memoria
                allUsersData = result.items.map((peopleData) => ({
                    _id: peopleData._id,
                    primerNombre: peopleData.primerNombre || "",
                    segundoNombre: peopleData.segundoNombre || "",
                    primerApellido: peopleData.primerApellido || "",
                    segundoApellido: peopleData.segundoApellido || "",
                    contrato: peopleData.contrato || "",
                    numeroId: peopleData.numeroId || "",
                    nivel: peopleData.nivel || "",
                    plataforma: peopleData.plataforma || "",
                }));

                // Inicialmente mostramos todos los datos
                filteredData = allUsersData;
                totalPaginas = Math.ceil(filteredData.length / registrosPorPagina);
                actualizarRepetidorFiltrado(""); // Mostrar sin filtros
                $w("#allUsers").expand();
            } else {
                console.log("No se encontraron datos en ACADEMICA.");
                $w("#allUsers").collapse();
            }
        })
        .catch((err) => {
            console.error("Error en la consulta a ACADEMICA:", err);
            $w("#allUsers").collapse();
        });
}

// Función para actualizar el repetidor según el filtro
function actualizarRepetidorFiltrado(query) {
    filteredData = allUsersData.filter(item => {
        return (
            item.primerNombre.toLowerCase().includes(query.toLowerCase()) ||
            item.segundoNombre.toLowerCase().includes(query.toLowerCase()) ||
            item.primerApellido.toLowerCase().includes(query.toLowerCase()) ||
            item.segundoApellido.toLowerCase().includes(query.toLowerCase()) ||
            item.contrato.toLowerCase().includes(query.toLowerCase()) ||
            item.numeroId.toLowerCase().includes(query.toLowerCase()) ||
            item.nivel.toLowerCase().includes(query.toLowerCase()) ||
            item.plataforma.toLowerCase().includes(query.toLowerCase())
        );
    });

    paginaActual = 0;
    totalPaginas = Math.ceil(filteredData.length / registrosPorPagina);
    actualizarRepetidor();
}

// Función para actualizar el repetidor con la página actual
function actualizarRepetidor() {
    console.log("iniciando")
    const inicio = paginaActual * registrosPorPagina;
    const fin = inicio + registrosPorPagina;
    const datosPagina = filteredData.slice(inicio, fin);

    $w("#allUsers").data = datosPagina;

    // Configurar los elementos del repetidor
    $w("#allUsers").forEachItem(($item, itemData, index) => {

        $item("#primerNombre").value = itemData.primerNombre;
        $item("#segundoNombre").value = itemData.segundoNombre;
        $item("#primerApellido").value = itemData.primerApellido;
        $item("#segundoApellido").value = itemData.segundoApellido;
        $item("#contrato").value = itemData.contrato;
        $item("#numeroId").value = itemData.numeroId;
        $item('#plataforma').value = itemData.plataforma;
        $item('#nivel').value = itemData.nivel;

        // Evitar múltiples registros del evento onClick
        if (!itemData._aprobarYaAgregado) {
            itemData._aprobarYaAgregado = true;
            
            $item("#aprobarButton").onClick(async () => {
                // Deshabilitar inmediatamente para evitar múltiples clics
                $item("#aprobarButton").disable();
                
                // Verificar que no se haya procesado ya
                if (!itemData._procesadoAprobar && !$item("#aprobarButton").label.includes("✔")) {
                    itemData._procesadoAprobar = true;
                    $item("#aprobarButton").label = "⏳ Procesando...";
                    
                    try {
                        await crearRegistroAcademico(itemData._id, $item);
                        $item("#aprobarButton").label = "✅ Listo";
                    } catch (error) {
                        console.error("Error al aprobar:", error);
                        $item("#aprobarButton").label = "❌ Error";
                        // Re-habilitar en caso de error para permitir reintentar
                        $item("#aprobarButton").enable();
                        itemData._procesadoAprobar = false;
                    }
                }
            });
        }

        // Configurar botón de WhatsApp (solo envío de mensaje)
        if (!itemData._whatsappYaAgregado) {
            itemData._whatsappYaAgregado = true;
            
            $item("#whatsappButton").onClick(async () => {
                // Deshabilitar inmediatamente para evitar múltiples clics
                $item("#whatsappButton").disable();
                $item("#whatsappButton").label = "📤 Enviando...";
                
                try {
                    // Verificar si ya existe en ACADEMICA para obtener el ID correcto
                    const existingAcademica = await wixData.query("ACADEMICA")
                        .eq("idEstudiante", itemData._id)
                        .find();
                    
                    let linkId = itemData._id; // Por defecto usar el ID de PEOPLE
                    
                    if (existingAcademica.items.length > 0) {
                        linkId = existingAcademica.items[0]._id; // Usar el ID de ACADEMICA si existe
                    }
                    
                    // Obtener datos del usuario para el celular
                    const personaData = await wixData.get("PEOPLE", itemData._id);
                    
                    if (!personaData.celular) {
                        throw new Error("No se encontró número de celular");
                    }
                    
                    // Preparar mensaje de WhatsApp con el ID correcto
                    const message = `Hola 👋:\n\n*¡Eres parte de Lets Go Speak!* 🎉 \n\nPara terminar tu registro y crear tu usuario sigue este enlace:\n\nhttps://www.lgsplataforma.com/nuevo-usuario/${linkId}`;
                    
                    await enviarFormularioCreacionUsuario(personaData.celular, message);
                    
                    $item("#whatsappButton").label = "✅ Enviado";
                    
                    // Re-habilitar después de 3 segundos para permitir reenvío si es necesario
                    setTimeout(() => {
                        $item("#whatsappButton").enable();
                        $item("#whatsappButton").label = "📱 WhatsApp";
                    }, 3000);
                    
                } catch (error) {
                    console.error("Error al enviar WhatsApp:", error);
                    $item("#whatsappButton").label = "❌ Error";
                    
                    // Re-habilitar para permitir reintento
                    setTimeout(() => {
                        $item("#whatsappButton").enable();
                        $item("#whatsappButton").label = "📱 WhatsApp";
                    }, 2000);
                }
            });
        }

        if (!itemData._duplicarYaAgregado) {
            itemData._duplicarYaAgregado = true;

            $item("#duplicarButton").onClick(async () => {
                try {
                    const originalPersona = await wixData.get("PEOPLE", itemData._id);

                    const nuevoPersona = {
                        ...originalPersona,
                        tipoUsuario: "BENEFICIARIO"
                    };
                    delete nuevoPersona._id;

                    const nuevaPersonaInsertada = await wixData.insert("PEOPLE", nuevoPersona);
                    const nuevoId = nuevaPersonaInsertada._id;

                    const nuevoAcademico = {
                        primerNombre: nuevaPersonaInsertada.primerNombre,
                        primerApellido: nuevaPersonaInsertada.primerApellido,
                        contrato: nuevaPersonaInsertada.contrato,
                        plataforma: nuevaPersonaInsertada.plataforma,
                        nivel: nuevaPersonaInsertada.nivel,
                        numeroId: nuevaPersonaInsertada.numeroId,
                        idEstudiante: nuevoId,
                        usuarioId: nuevoId,
                        celular: nuevaPersonaInsertada.celular,
                        email: nuevaPersonaInsertada.email,
                        step: nuevaPersonaInsertada.ultimoStep || "",
                        clave: nuevaPersonaInsertada.numeroId.substring(0, 4),
                        aprobacion: "Aprobado"
                    };

                    await wixData.insert("ACADEMICA", nuevoAcademico);

                    const message = `Hola 👋:\n\n*¡Eres parte de Lets Go Speak!* 🎉 \n\nPara terminar tu registro y crear tu usuario sigue este enlace:\n\nhttps://www.lgsplataforma.com/nuevo-usuario/${nuevoId}`;
                    await enviarFormularioCreacionUsuario(nuevaPersonaInsertada.celular, message);

                    $item("#duplicarButton").label = "📄 Duplicado";
                    $item("#duplicarButton").disable();

                    console.log("Duplicación completada");
                } catch (error) {
                    console.error("Error al duplicar el registro:", error);
                }
            });
        }

    });

    if (paginaActual > 0) {
        $w("#backButton").enable();
    } else {
        $w("#backButton").disable();
    }

    if (paginaActual < totalPaginas - 1) {
        $w("#nextButton").enable();
    } else {
        $w("#nextButton").disable();
    }

}

// Eventos de paginación
$w("#backButton").onClick(() => {
    if (paginaActual > 0) {
        paginaActual--;
        actualizarRepetidor();
    }
});

$w("#nextButton").onClick(() => {
    if (paginaActual < totalPaginas - 1) {
        paginaActual++;
        actualizarRepetidor();
    }
});

async function crearRegistroAcademico(idPersona, $item) {
    try {
        // Verificar si ya existe un registro en ACADEMICA para este usuario
        const existingRecord = await wixData.query("ACADEMICA")
            .eq("idEstudiante", idPersona)
            .find();
        
        if (existingRecord.items.length > 0) {
            console.log("Ya existe un registro en ACADEMICA para este usuario:", idPersona);
            return existingRecord.items[0]._id;
        }

        // Obtener todos los datos del estudiante en PEOPLE
        const personaData = await wixData.get("PEOPLE", idPersona);
        if (!personaData) {
            console.error("No se encontró la persona en PEOPLE con ID:", idPersona);
            return;
        }

        // Obtener valores del repetidor en el contexto del ítem (o usar valores originales si están vacíos)
        const primerNombre = $item("#primerNombre").value || personaData.primerNombre;
        const segundoNombre = $item("#segundoNombre").value || personaData.segundoNombre;
        const primerApellido = $item("#primerApellido").value || personaData.primerApellido;
        const segundoApellido = $item("#segundoApellido").value || personaData.segundoApellido;
        const plataforma = $item("#plataforma").value || personaData.plataforma;
        const numeroId = $item("#numeroId").value || personaData.numeroId;
        const nivel = $item("#nivel").value || personaData.nivel;
        const contrato = $item("#contrato").value || personaData.contrato;
        const step = personaData.ultimoStep || "";

        const idEstudiante = personaData._id;
        const usuarioId = personaData._id;
        const email = personaData.email;
        const celular = personaData.celular;

        // Crear el nuevo objeto para insertar en ACADEMICA
        const nuevoRegistroAcademico = {
            primerNombre,
            primerApellido,
            contrato,
            plataforma,
            nivel,
            numeroId,
            idEstudiante,
            usuarioId,
            celular,
            email,
            step,
            clave: numeroId.substring(0, 4),
            aprobacion: "Aprobado" // 👈 AÑADIR AQUÍ
        };

        // Insertar en la colección ACADEMICA
        const result = await wixData.insert("ACADEMICA", nuevoRegistroAcademico);
        $item('#creadoText').show(); // Mostrar texto de creado

        const idAcademico = result._id; // Capturar el _id del registro creado en ACADEMICA

        // Actualizar cambios en PEOPLE
        const cambios = {};
        if (personaData.primerNombre !== primerNombre) cambios.primerNombre = primerNombre;
        if (personaData.segundoNombre !== segundoNombre) cambios.segundoNombre = segundoNombre;
        if (personaData.primerApellido !== primerApellido) cambios.primerApellido = primerApellido;
        if (personaData.segundoApellido !== segundoApellido) cambios.segundoApellido = segundoApellido;
        if (personaData.plataforma !== plataforma) cambios.plataforma = plataforma;
        if (personaData.numeroId !== numeroId) cambios.numeroId = numeroId;
        if (personaData.nivel !== nivel) cambios.nivel = nivel;
        if (personaData.contrato !== contrato) cambios.contrato = contrato;
        if (personaData.ultimoStep !== step) cambios.ultimoStep = step;
        cambios.estado = "ACTIVA"; // Siempre se activa
        cambios.aprobacion = "Aprobado"; // 👈 AÑADIR AQUÍ

        if (Object.keys(cambios).length > 0) {
            const registroActualizado = { ...personaData, ...cambios };
            await wixData.update("PEOPLE", registroActualizado);
            console.log("Registro en PEOPLE actualizado correctamente:", step);
        } else {
            console.log("No hubo cambios en PEOPLE.");
        }

        // Preparar y enviar mensaje de WhatsApp
        const message = `Hola 👋:\n\n*¡Eres parte de Lets Go Speak!* 🎉 \n\nPara terminar tu registro y crear tu usuario sigue este enlace:\n\nhttps://www.lgsplataforma.com/nuevo-usuario/${idAcademico}`;
        await enviarFormularioCreacionUsuario(celular, message);

        return idAcademico;

    } catch (err) {
        console.error("Error al crear el registro académico y actualizar PEOPLE:", err);
    }
}

//-----------

$w('#search').onInput(() => {
    actualizarRepetidorFiltrado($w("#search").value);
});

// Control de envíos de WhatsApp para evitar duplicados
const mensajesEnviados = new Set();

function enviarFormularioCreacionUsuario(celular, message) {
    // Crear una clave única para este envío
    const claveEnvio = `${celular}-${message.substring(0, 50)}`;
    
    // Verificar si ya se envió este mensaje
    if (mensajesEnviados.has(claveEnvio)) {
        console.log("Mensaje ya enviado previamente, evitando duplicado");
        return Promise.resolve({ status: "already_sent" });
    }
    
    // Marcar como enviado
    mensajesEnviados.add(claveEnvio);
    
    return sendTextMessageServicioUsuario(celular, message)
        .then(response => {
            console.log("Actividad enviada", response);
            $w('#loading').hide();
            return response;
        })
        .catch(err => {
            console.error("Error al enviar actividad", err);
            // Si hay error, quitar de la lista para permitir reintento
            mensajesEnviados.delete(claveEnvio);
            throw err;
        });
}