import wixData from 'wix-data';
import wixWindow from 'wix-window';
import wixStorage from 'wix-storage';
import wixRealtimeFrontend from 'wix-realtime-frontend';
import { sendmessage } from 'backend/realTimeChat'; 
import wixLocation from 'wix-location';
import { session } from 'wix-storage';

let debounceTimer;
const debounceDelay = 500; // Tiempo en milisegundos
let idUsuario = ""
let cantidadBulk

// ESTE RECIBE LOS MENSAJES PERO NO LOS MANDA. PARA VER CÓMO MANDAR, ENTRAR AL LIGHTBOX "CREAR PROSPECT" Y REVISAR LA FUNCIÓN sendMessage
const suscribeToUpdates = () => {
    const channel = { "name": "gestionProspectos" }; // Nombre del canal específico para esta página.
    wixRealtimeFrontend.subscribe(channel, (message, channel) => {
            let payload = message.payload;
            if (payload.type === "updateComplete") {
                // Función específica para manejar la actualización en esta página
                porContactar();
                cerradosConExito();
                console.log("Mensaje EN VIVO recibido en otroCanal");
            }
        })
        .then((id) => {
            console.log("Suscripción a updates exitosa con ID:", id);
        });
};

suscribeToUpdates();

$w.onReady(async function () {

// -----  BLOQUE DE RECONOCIMIENTO DE TOKEN LOGIN
    const tokenData = JSON.parse(session.getItem('accessToken'));
    if (tokenData) {
        const currentTime = new Date().getTime();
        // Convertir el tiempo de expiración a una fecha legible
        const expirationDate = new Date(tokenData.expiresAt);
        console.log(`El token expira el: ${expirationDate.toLocaleString()}`);
        if (currentTime > tokenData.expiresAt) {
            // Token ha expirado
            session.removeItem('accessToken');
            console.log("Token Acabado") // Eliminar el token expirado
            wixLocation.to(`/login`); // Redirigir a una página de error o login
        } else {
            // Token es válido
            // Aquí puedes continuar cargando el contenido de la página
        }
    } else {
        console.log("Token Expirado") // Eliminar el token expirado
        wixLocation.to(`/login`); // Redirigir a una página de error o login
    }
//
                await bulk();


    $w("#crearProspecto").onClick((event) => {
        wixWindow.openLightbox("CREAR PROSPECTO")
    })

});

// INICIO BUSCADOR
$w("#search").onKeyPress((event) => {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => {
        realizarBusqueda($w("#search").value);
    }, debounceDelay);
});
// FIN BUSCADOR
$w('#boxCerradosconExito').hide()

$w('#todosLosRepeaters').expand()
/*$w("#asignarGestionButton").onClick(() => {
    $w('#todosLosRepeaters').expand()
    $w('#resultadoBusqueda').collapse()
})*/

$w("#gestionNuevaButton").onClick(() => {
    $w('#bulkBox').hide()
    $w('#porAsignar').show()
    $w('#porInsistirRepeater').hide()
    $w("#repeaterPorContactar").hide(); // Ocultar repeaterPorContactar
    $w("#repeaterAsignar").show();
    $w('#boxCerradosconExito').hide() // Mostrar repeaterAsignar
    porAsignar(); // Ejecutar función porAsignar
});

$w("#pendientesHoyButton").onClick(() => {
    $w('#bulkBox').hide()
    $w('#porAsignar').show()
    $w('#porInsistirRepeater').hide()
    $w("#repeaterAsignar").hide(); // Ocultar repeaterAsignar
    $w("#repeaterPorContactar").show(); // Mostrar repeaterPorContactar
    $w('#boxCerradosconExito').hide()
    porContactar(); // Ejecutar función porContactar
});

$w("#porInsistirButton").onClick(() => {
    $w('#porAsignar').show()
    $w('#bulkBox').hide()
    $w("#repeaterAsignar").hide(); // Ocultar repeaterAsignar
    $w("#repeaterPorContactar").hide();
    $w('#porInsistirRepeater').show() // Mostrar repeaterPorContactar
    $w('#boxCerradosconExito').hide()
    porInsistir(); // Ejecutar función porContactar
});

$w("#exitososButton").onClick(() => {
    $w('#bulkBox').hide()
    $w('#porAsignar').hide()
    $w("#repeaterAsignar").hide(); // Ocultar repeaterAsignar
    $w("#repeaterPorContactar").hide();
    $w('#porInsistirRepeater').hide()
    $w('#boxCerradosconExito').show() // Mostrar repeaterPorContactar
    cerradosConExito(); // Ejecutar función porContactar
});

$w("#bulkButton").onClick(() => {
    $w('#porAsignar').hide()
    $w("#repeaterAsignar").hide();
    $w("#repeaterPorContactar").hide();
    $w('#porInsistirRepeater').hide()
    $w('#boxCerradosconExito').hide()
    $w('#bulkBox').show()
    bulk();
});

cargarAsesoresDropdown();

$w("#search").onClick((event) => {
    const query = event.target.value;

    if (query.length === 0) {
        console.log("bucador en cero")
        // Si está vacío, expandir todos los repeaters
        $w('#todosLosRepeaters').expand();
    }

});

// 1. INICIO FUNCIONES GLOBALES

//-- 1.1 Asesores para repeaterAsignar

let opcionesDropdown = [];

function cargarAsesoresDropdown() {
    wixData.query('COMERCIAL')
        .limit(1000)
        .find()
        .then(res => {
            opcionesDropdown = res.items
                .sort((a, b) => a.primerNombre.localeCompare(b.primerNombre)) // Ordenar por primerNombre
                .map(item => ({
                    nombre: capitalizeFirstLetter(item.primerNombre) ? capitalizeFirstLetter(item.primerNombre) : '',
                    apellido: capitalizeFirstLetter(item.primerApellido) ? capitalizeFirstLetter(item.primerApellido) : '',
                    rol: item.rol ? capitalizeFirstLetter(item.rol) : '',
                    _id: item._id
                }));

            // Asignar opcionesDropdown a los dropdowns necesarios
            asignarOpcionesDropdown();
        });
}

function asignarOpcionesDropdown() {
    const opcionesParaDropdown = opcionesDropdown.map(item => ({
        label: `${item.nombre} ${item.apellido} - ${item.rol}`,
        value: item._id
    }));

    // Asignar opcionesParaDropdown a los dropdowns en los repeaters
    $w('#asesorAsignadoDrop').options = opcionesParaDropdown;
    $w('#asesorReAsignadoDrop').options = opcionesParaDropdown;
    $w('#asesorInsistir').options = opcionesParaDropdown;
    $w('#agenteRepeaterBulk').options = opcionesParaDropdown;
}

// -- 1.3 Reenvío de datos para lightBoxes
function redirectUserProfile(userId, numeroId) {
    wixStorage.local.setItem('userId', userId); // Guarda userId en el almacenamiento local
    wixStorage.local.setItem('numeroId', numeroId);

    // Guarda numeroId en el almacenamiento local
    wixWindow.openLightbox("FICHA COMERCIAL");
}

// -- 1.5 Función para la mayúscula de los items
function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1).toLowerCase();
}

// 2. INICIO QUERYS Y REPEATERS

// 2.1 INICIO BUSCADOR
function realizarBusqueda(query) {

    $w('#todosLosRepeaters').collapse()

    $w('#noExiste').hide()
    // Si el input estÃ¡ vacÃ­o o contiene menos de 3 caracteres, resetea el estado sin buscar
    if (query.length < 3) {
        $w("#resultadoBusqueda").data = []; // Limpia los datos del repetidor
        $w('#resultadoBusqueda').collapse(); // Esconde el repetidor

        return; // Sale de la funciÃ³n para no ejecutar una bÃºsqueda
    }

    // A partir de aquÃ­, maneja el caso en que hay una bÃºsqueda vÃ¡lida con 3 o mÃ¡s caracteres
    $w('#loading').expand()
    wixData.query("COMERCIAL")
        .contains("primerNombre", query)
        .find()
        .then((results) => {
            if (results.items.length > 0) {
                const filialesPromises = results.items.map(item =>
                    wixData.get("FILIALES", item.filial)
                    .then(filial => ({ ...item, filialNombre: filial.filial })) // Asigna el nombre de la filial directamente al item
                    .catch(err => ({ ...item, filialNombre: "Sin filial" }))
                );

                Promise.all(filialesPromises)
                    .then(itemsConFiliales => {
                        $w('#resultadoBusqueda').expand(); // Muestra el repetidor con los resultados
                        $w('#loading').collapse(); // Esconde el indicador de carga
                        $w("#resultadoBusqueda").data = itemsConFiliales;
                        $w("#resultadoBusqueda").forEachItem(($item, itemData, index) => {
                            $item("#resultados").text = `${capitalizeFirstLetter(itemData.primerNombre)} ${capitalizeFirstLetter(itemData.primerApellido)}, ${itemData.rol} - ${itemData.filialNombre}`;
                            $item('#fotoBuscador').src = itemData.foto

                            $w("#resultadoBusqueda").onItemReady(($item, itemData, index) => {
                                $item("#resultados").onClick(() => {
                                    idUsuario = itemData._id
                                    redirectUserProfile(itemData._id, itemData.numeroId);
                                });
                            });
                        });

                    })

                    .catch(err => {
                        console.error("Error al procesar filiales", err);
                    });

            } else {
                $w('#loading').collapse();
                $w('#noExiste').show();
                $w("#resultadoBusqueda").data = [];
                $w('#resultadoBusqueda').collapse(); // Si no hay resultados, tambiÃ©n esconde el repetidor
                console.log("No se encontraron resultados");
            }
        })
        .catch((err) => {
            console.error("Error al realizar la bÃºsqueda", err);
        });
}

// -- 2.2 Repeater porAsignar

function porAsignar() {

    gestionarPorAsignar();
}

function gestionarPorAsignar() {

    wixData.query('PROSPECTOS')
        .eq("bulkAsignado", idUsuario)
        .isEmpty("agenteAsignado")
        .limit(7)
        .find()
        .then(res => {
            if (res.items.length > 0) {
                $w('#repeaterAsignar').data = res.items;
                $w("#repeaterAsignar").forEachItem(($item, itemData, index) => {
                    setupItemPorAsignar($item, itemData);
                });
                $w('#tituloRepeaters').text = ("Prospectos sin atender (" + res.items.length + ")");

            } else {
                $w('#tituloRepeaters').text = "No hay registros para asignar hoy"
                $w('#repeaterAsignar').hide()
                console.log("No se encontraron datos.");
            }
        })
        .catch(err => {
            console.error('Error al cargar los datos', err);
        });
}

function setupItemPorAsignar($item, itemData) {
    const fullName = capitalizeFirstLetter(itemData.primerNombre) + " " + capitalizeFirstLetter(itemData.primerApellido);
    $item("#fechaCreacionPorAsignar").text = new Date(itemData._createdDate).toLocaleDateString();
    $item("#paisPorAsignar").text = itemData.pais;
    $item("#nombrePorAsignar").text = fullName;
    $item("#telefono").text = itemData.celular;
    $item('#asesorAsignadoDrop').value = itemData.agenteAsignado
    $item('#fechaAsignada').value = itemData.fechaProximaGestion

    // Configuración del dropdown de fechas
    cargarFechasDropdown($item);

    // Variables para guardar selecciones temporales
    let asesorSeleccionado = null;
    let fechaSeleccionada = null;

    // Evento onChange para el dropdown de asesores asignados
    $item('#asesorAsignadoDrop').onChange(event => {
        asesorSeleccionado = event.target.value;
        if (fechaSeleccionada) {
            actualizarRegistro(itemData, asesorSeleccionado, fechaSeleccionada);
        }
    });

    // Evento onChange para el dropdown de fechas asignadas
    $item('#fechaAsignada').onChange(event => {
        fechaSeleccionada = event.target.value;
        if (asesorSeleccionado) {
            actualizarRegistro(itemData, asesorSeleccionado, fechaSeleccionada);
        }
    });
}


function cargarFechasDropdown($item, itemData) {
    const today = new Date();
    const opciones = [];
    for (let i = 0; i < 7; i++) { // Genera los próximos 7 días
        const futureDate = new Date(today);
        futureDate.setDate(futureDate.getDate() + i);
        const dayName = futureDate.toLocaleDateString('es', { weekday: 'long' });
        const dayNumber = futureDate.getDate();
        const optionValue = futureDate.toISOString(); // Guardar la fecha como string ISO para facilidad de manejo
        opciones.push({
            label: `${capitalizeFirstLetter(dayName)} ${dayNumber}`,
            value: optionValue
        });
        console.log(`Opción agregada: ${capitalizeFirstLetter(dayName)} ${dayNumber} - ${optionValue}`);
    }
    $item('#fechaAsignada').options = opciones;
    $item('#fechaReasignada').options = opciones;
    $item('#fechaPorInsistir').options = opciones;

    // Establecer el valor inicial del dropdown fechaReasignada
    if (itemData.fechaProximaGestion) {
        const fechaProximaGestionISO = new Date(itemData.fechaProximaGestion).toISOString();
        console.log(`Configurando fechaReasignada con: ${fechaProximaGestionISO}`);
        setTimeout(() => {
            $item('#fechaReasignada').value = fechaProximaGestionISO;
            console.log(`Fecha reasignada después de establecer: ${$item('#fechaReasignada').value}`);
        }, 100); // Pequeño retraso para asegurarse de que las opciones se hayan establecido
    }
}






function actualizarRegistro(itemData, asesorSeleccionado, fechaSeleccionada) {
    wixData.get('PROSPECTOS', itemData._id)
        .then((result) => {
            result.agenteAsignado = asesorSeleccionado;
            result.fechaProximaGestion = new Date(fechaSeleccionada); // Asegúrate de que la fecha está en el formato adecuado
            return wixData.update('PROSPECTOS', result);
        })
        .then((updatedItem) => {
            console.log('Prospecto actualizado correctamente:', updatedItem);
            // Aquí se puede agregar la lógica para actualizar la vista o informar al usuario
        })
        .catch((err) => {
            console.error('Error al actualizar el prospecto:', err);
            // Aquí se puede agregar la lógica para manejar errores o informar al usuario
        });
}

// -- 2.3 repeater PorContactar
function porContactar() {
    $w('#porAsignar').show()
    $w("#repeaterPorContactar").show(); // Mostrar repeaterPorContactar
    $w('#tituloRepeaters').text = "Prospectos por Gestionar"

    const today = new Date();
    const tomorrow = new Date();
    today.setHours(0, 0, 0, 0); // Establece la hora al inicio del día
    tomorrow.setDate(today.getDate() + 1); // Establece 'tomorrow' como el día siguiente a 'today'
    tomorrow.setHours(0, 0, 0, 0); // Inicio del día siguiente

    wixData.query("PROSPECTOS")
        .ge("fechaProximaGestion", today)
        .lt("fechaProximaGestion", tomorrow)
        .find()
        .then(res => {
            if (res.items.length > 0) {
                $w('#tituloRepeaters').text = ("Prospectos sin atender (" + res.items.length + ")");
                setupRepeater(res.items, '#repeaterPorContactar', setupPorContactar);
            } else {

                $w('#tituloRepeaters').text = "No hay registros para gestionar hoy";
            }
        })
        .catch(err => {
            console.error('Error al cargar los datos', err);
            $w('#tituloRepeaters').text = "Error al cargar los datos";
        });
}

function setupPorContactar($item, itemData) {
    const fullName = [capitalizeFirstLetter(itemData.primerNombre), capitalizeFirstLetter(itemData.primerApellido)].filter(Boolean).join(" ");

    $item('#FechacreacionPorContactar').text = itemData._createdDate.toLocaleDateString();
    $item('#paisPorContactar').text = itemData.numeroId;
    $item('#nombrePorContactar').text = fullName;
    $item('#celularPorContactar').text = itemData.celular;
    $item('#asesorReAsignadoDrop').value = itemData.agenteAsignado;
    console.log(itemData._createdDate.toLocaleDateString())

    cargarFechasDropdown($item, itemData); // Pasar itemData para ajustar correctamente el dropdown de fechas

    let asesorSeleccionado = itemData.agenteAsignado;
    let fechaSeleccionada = itemData.fechaProximaGestion;

    $item('#asesorReAsignadoDrop').onChange(event => {
        asesorSeleccionado = event.target.value;
        if (fechaSeleccionada) {
            actualizarRegistro(itemData, asesorSeleccionado, fechaSeleccionada);
        }
    });

$item('#fechaReasignada').onChange(async event => {
    const fechaSeleccionada = event.target.value;
    if (asesorSeleccionado) {
        try {
            // Esperar a que se complete la actualización del registro
            await actualizarRegistro(itemData, asesorSeleccionado, fechaSeleccionada);

            // ----------------------------------------------------------
            // Enviar mensaje PARA ACTUALIZAR CANAL en este caso el repeater porContactar del Dash Comercial 
            const response = await sendmessage("gestionProspectos", { type: "updateComplete" });
            console.log("Mensaje enviado con éxito:", response);
            // ----------------------------------------------------------
        } catch (error) {
            console.error("Error en el proceso de actualización o envío de mensaje:", error);
        }
    }
});


}


// -- 2.4 Funciones de setUp y querys de los repeaters
function setupRepeater(items, repeaterId, setupFunction, additionalFunction = null) {
    $w(repeaterId).data = items;
    $w(repeaterId).forEachItem(($item, itemData) => {
        setupFunction($item, itemData);
        if (additionalFunction) additionalFunction($item);
    });
}

// 2.4 Repater porInsistir

function porInsistir() {
    // Definir los motivos por los que los prospectos han desistido
    const motivosDesistidos = [
        "No cuenta con dinero",
        "No cuenta con tiempo",
        "Indeciso",
        "No me interesa",
        "No contestó"
    ];

    // Realizar la consulta con el filtro apropiado
    wixData.query("PROSPECTOS")
        .hasSome("desistioMotivo", motivosDesistidos)
        .find()
        .then(res => {
            if (res.items.length > 0) {
                $w('#porInsistirRepeater').data = res.items;
                $w('#porInsistirRepeater').forEachItem(($item, itemData, index) => {
                    $w('#tituloRepeaters').text = ("Prospectos sin atender (" + res.items.length + ")")
                    setupItemPorInsistir($item, itemData);
                    console.log("PorInsistir", res.items)
                });
            } else {
                console.log("No se encontraron datos para insistir.");
                $w('#tituloRepeaters').text = "No hay registros para insistir";
                $w('#porInsistirRepeater').collapse();
            }
        })
        .catch(err => {
            console.error("Error al cargar los datos para insistir:", err);
        });
}

function setupItemPorInsistir($item, itemData) {

    const fullName = [capitalizeFirstLetter(itemData.primerNombre), capitalizeFirstLetter(itemData.primerApellido)].filter(Boolean).join(" ");

    $item('#fechaCreacionPorInsistir').text = new Date(itemData._createdDate).toLocaleDateString();
    $item('#paisPorInsistir').text = itemData.pais;
    $item('#nombrePorInsistir').text = fullName;
    $item('#celularPorInsistir').text = itemData.celular;
    $item('#asesorAsignadoInsistir').value = itemData.agenteAsignado;

    let asesorSeleccionado = itemData.agenteAsignado;
    let fechaSeleccionada = itemData.fechaProximaGestion;

    $item('#asesorPorInsistir').onChange(event => {
        asesorSeleccionado = event.target.value;
        if (fechaSeleccionada) {
            guardarPorInsistir(itemData, asesorSeleccionado, fechaSeleccionada);
        }
    });

    $item('#fechaPorInsistir').onChange(event => {
        fechaSeleccionada = event.target.value;
        if (asesorSeleccionado) {
            guardarPorInsistir(itemData, asesorSeleccionado, fechaSeleccionada);
        }
    });
}

function guardarPorInsistir(itemData, asesorSeleccionado, fechaSeleccionada) {
    $w('#tituloRepeaters').text = "Prospectos por Insistir"
    wixData.get('PROSPECTOS', itemData._id)
        .then((result) => {
            result.agenteAsignado = asesorSeleccionado;
            result.fechaProximaGestion = new Date(fechaSeleccionada); // Asegúrate de que la fecha está en el formato adecuado
            return wixData.update('PROSPECTOS', result);
        })
        .then((updatedItem) => {
            console.log('Prospecto actualizado correctamente:', updatedItem);
            // Aquí se puede agregar la lógica para actualizar la vista o informar al usuario
        })
        .catch((err) => {
            console.error('Error al actualizar el prospecto:', err);
            // Aquí se puede agregar la lógica para manejar errores o informar al usuario
        });
}

// 2.5 Función Cerrados con Éxito

function cerradosConExito() {
    $w('#boxCerradosconExito').show() // Mostrar repeaterPorContactar
console.log("exitosísimo")
    // Realizar la consulta con el filtro apropiado
    wixData.query("PEOPLE")
        .eq("tipoUsuario", "TITULAR")
        .find()
        .then(res => {
            if (res.items.length > 0) {
                $w('#repeaterCerradosConExitoRepeater').data = res.items;
                $w('#repeaterCerradosConExitoRepeater').forEachItem(($item, itemData, index) => {
                    $w('#tituloCerrado').text = ("Gestión Exitosa  (" + res.items.length + ")");
                    setupCerradoConExito($item, itemData);
                    // Obtener el _id del item de PEOPLE
                    const idUsuario = itemData._id;
                    // Consultar la base de datos FINANCIERA para obtener el totalPlan
                    wixData.query("FINANCIERA")
                        .eq("titularId", idUsuario)
                        .find()
                        .then(finRes => {
                            if (finRes.items.length > 0) {
                                const totalPlan = finRes.items[0].totalPlan;
                                // Establecer el valor de totalPlan en el objeto de texto del repeater
                                $item('#valorCerrado').text = separarNumeros(totalPlan.toString());
                            }
                        })
                        .catch(err => {
                            console.error("Error al obtener el totalPlan:", err);
                        });

                    // Consultar la base de datos COMERCIAL para obtener el nombre del agente asignado
                    wixData.query("COMERCIAL")
                        .eq("_id", itemData.agenteAsignado)
                        .find()
                        .then(comRes => {
                            if (comRes.items.length > 0) {
                                const agenteAsignado = comRes.items[0];
                                const fullNameAgente = [capitalizeFirstLetter(agenteAsignado.primerNombre), capitalizeFirstLetter(agenteAsignado.primerApellido)].filter(Boolean).join(" ");
                                console.log(fullNameAgente, "agente")
                                $item('#asesorCerrado').text = fullNameAgente;

                            }
                        })
                        .catch(err => {
                            console.error("Error al obtener el agente asignado:", err);
                        });
                });
            } else {
                console.log("No se encontraron datos para insistir.");
                $w('#tituloRepeaters').text = "No hay registros para insistir";
                $w('#repeaterCerradosConExitoRepeater').collapse();
            }
        })
        .catch(err => {
            console.error("Error al cargar los datos para insistir:", err);
        });
}

function setupCerradoConExito($item, itemData) {
    const fullName = [capitalizeFirstLetter(itemData.primerNombre), capitalizeFirstLetter(itemData.primerApellido)].filter(Boolean).join(" ");
    $item('#fechaCerrado').text = new Date(itemData._createdDate).toLocaleDateString();
    $item('#paisCerrado').text = itemData.plataforma;
    $item('#nombreCerrado').text = fullName;
    $item('#valorCerrado').text = itemData.celular;
}

function separarNumeros(numero) {
    const separador = ".";
    const numeroString = numero.toString();
    const partes = numeroString.split(".");
    let parteEntera = partes[0];
    let parteDecimal = partes.length > 1 ? "." + partes[1] : "";

    // Separar parte entera
    let resultado = "";
    while (parteEntera.length > 3) {
        resultado = separador + parteEntera.slice(-3) + resultado;
        parteEntera = parteEntera.slice(0, -3);
    }
    resultado = parteEntera + resultado + parteDecimal;

    return resultado;
}

// ASIGNAR BULK A AGENTES

let totalProspectos = 0;
let totalAsignado = 0;
let itemsEnRepeater = [];

async function bulk() {
    try {
        let count = await wixData.query('PROSPECTOS').eq('bulkAsignado', idUsuario).count();
        totalProspectos = count;
        $w('#tituloRepeaterBulk').text = `Total de prospectos: ${totalProspectos}`;
        calcularTotalAsignado();
    } catch (err) {
        console.error('Error al contar prospectos:', err);
    }
}

$w('#repeaterBulk').forEachItem(($item, itemData, index) => {
    $item('#cantProspectosAsignados').onChange((event) => {
        let valorNuevo = parseInt(event.target.value, 10) || 0;
        let valorAnterior = itemData.asignados || 0;

        if (puedeAsignarCantidad(valorNuevo, valorAnterior)) {
            totalAsignado = totalAsignado - valorAnterior + valorNuevo; // Actualizar total asignado globalmente
            itemData.asignados = valorNuevo; // Actualizar valor asignado localmente
            calcularTotalAsignado(); // Recalcular y actualizar la interfaz
        } else {
            $item('#cantProspectosAsignados').value = valorAnterior; // Restablece al valor anterior si no es posible asignar
        }
    });
});

function calcularTotalAsignado() {
    totalAsignado = 0;
    itemsEnRepeater.forEach(item => {
        totalAsignado += item.asignados;
    });
    $w('#tituloRepeaterBulk').text = `Total de prospectos: ${totalProspectos - totalAsignado}`;
}

function verificarSaldoDisponible() {
    // Calcular el saldo disponible restando el total asignado del total de prospectos
    let saldoDisponible = totalProspectos - totalAsignado;

    // Si el saldo disponible es menor o igual a 0, no permitir añadir nuevos ítems y mostrar error
    if (saldoDisponible <= 0) {
        console.error(`No se pueden añadir más ítems, no hay saldo suficiente. Saldo disponible: ${saldoDisponible}`);
        return false;
    }
    return true;
}

function puedeAsignarCantidad(nuevaCantidad, cantidadActual = 0) {
    let impactoNeto = nuevaCantidad - cantidadActual;
    let nuevoTotalAsignado = totalAsignado + impactoNeto;
    if (nuevoTotalAsignado > totalProspectos) {
        console.error(`No se pueden asignar más prospectos de los disponibles. Saldo máximo disponible: ${totalProspectos - totalAsignado}`);
        return false;
    }
    return true;
}

function refrescarRepeater() {
    $w('#repeaterBulk').data = itemsEnRepeater;
    $w('#repeaterBulk').forEachItem(($item, itemData, index) => {
        $item('#cantProspectosAsignados').value = itemData.asignados || 0;
        $item('#cantProspectosAsignados').onChange((event) => {
            let valorNuevo = parseInt(event.target.value, 10) || 0;
            let valorAnterior = itemData.asignados || 0;
            if (!puedeAsignarCantidad(valorNuevo, valorAnterior)) {
                $item('#cantProspectosAsignados').value = valorAnterior;
                return;
            }
            itemData.asignados = valorNuevo;
            calcularTotalAsignado();
        });
    });
}

$w('#agregarAgenteRepeaterBulk').onClick(() => {
    if (verificarSaldoDisponible()) { // Solo añadir un nuevo ítem si hay saldo
        itemsEnRepeater.push({
            _id: "nuevo" + new Date().getTime(),
            asignados: 0
        });
        refrescarRepeater();
    }
});

async function distribuirBulk() {
    try {
        // Recorrer cada ítem en el repeater para obtener los datos necesarios
        $w('#repeaterBulk').forEachItem(async ($item, itemData, index) => {
            let cantidad = parseInt($item('#cantProspectosAsignados').value, 10);
            let agenteId = $item('#agenteRepeaterBulk').value;

            // Asignar este agente a la cantidad especificada de prospectos
            let prospectosParaActualizar = await wixData.query('PROSPECTOS')
                .limit(cantidad) // Asegúrate de ajustar esto según necesites filtrar los prospectos que ya están asignados o no
                .find();

            for (let prospecto of prospectosParaActualizar.items) {
                // Actualizar el campo 'agenteAsignado' con el ID del asesor
                prospecto.agenteAsignado = agenteId;
                await wixData.update('PROSPECTOS', prospecto);
            }
        });

        console.log('Todos los prospectos han sido distribuidos correctamente.');
    } catch (error) {
        console.error('Error al distribuir prospectos:', error);
    }
}

$w('#distribuirBulk').onClick(() => {
    distribuirBulk();
});

$w('#distribuirBulk').onClick(() => {
    distribuirBulk();
});