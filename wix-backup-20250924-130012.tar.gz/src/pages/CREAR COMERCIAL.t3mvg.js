import wixData from 'wix-data';
import wixLocation from 'wix-location';
import wixWindow from 'wix-window';


// Se ejecuta cuando el documento estÃ¡ listo
$w.onReady(function () {
   initializePage();

});


let savedPersonId = null;
let fotoUrl; // ID de la persona guardada, se usa globalmente


// Prepara la pÃ¡gina para su uso
function initializePage() {
    hideAllGroupsExceptFirst();
    setupEventHandlers();
    loadLeaderOptions();
    loadFilialOptions();
}


// Oculta todos los grupos excepto el primero
function hideAllGroupsExceptFirst() {
   ['2', '3', '4', '5' ].forEach(group => hideElement(`#group${group}`));
}


function setupEventHandlers() {
   // Configura el evento de entrada para validar la fecha en tiempo real
   $w("#fechaNacimiento").onInput(validateDateRealTime);

 
   // BotÃ³n de acciÃ³n para pasar al siguiente grupo de formulario
   $w('#siguiente').onClick(handleNextButtonClick);

   // Manejadores de cambio para validar el formulario dinÃ¡micamente
   setupFieldChangeHandlers();

}


// Maneja el evento de clic en el botÃ³n "Siguiente"
// Maneja el evento de clic en el botÃ³n "Siguiente"
async function handleNextButtonClick() {
    wixWindow.scrollTo(0, 0);
  let currentGroup = getCurrentGroup();
  if (currentGroup < 5) {
      let validation = validateCurrentGroupFields(currentGroup);
      if (validation.isValid) {
          if (currentGroup === 4) {
              $w('#loading').show()
              // Verifica si el visitante del sitio eligiÃ³ un archivo
              if ($w("#uploadButton1").value.length > 0) {
                  // Espera a que la carga del archivo se complete
                  await $w("#uploadButton1").uploadFiles().then((uploadedFiles) => {
                      uploadedFiles.forEach(uploadedFile => {
                          fotoUrl = uploadedFile.fileUrl; // Asigna la URL de la foto cargada a fotoUrl
                          console.log("Foto url:" + uploadedFile.fileUrl);
                      });
                      console.log("Upload successful.");
                      $w('#textoNuevoComercial').text = "Registro Creado"
                      $w('#loading').hide()
                  });
              } else { // Si el visitante del sitio hizo clic en el botÃ³n pero no eligiÃ³ un archivo
                  console.log("Please choose a file to upload.");
              }
              // Espera a que la informaciÃ³n del titular se guarde despuÃ©s de la carga de archivos
              await saveTitular();
          }
          // Procesos posteriores despuÃ©s de guardar/cargar
          toggleGroupVisibility(currentGroup, false); // Oculta el grupo actual
          currentGroup++; // Avanza al siguiente grupo
          toggleGroupVisibility(currentGroup, true); // Muestra el nuevo grupo
          if (currentGroup === 5) hideElement("#siguiente"); // Oculta el botÃ³n si es el Ãºltimo grupo
      } else {
          // Muestra advertencia si la validaciÃ³n falla
          showElementWithText("#aviso", `Por favor complete los siguientes campos: ${validation.missingFields.join(", ")}`);
      }
  }
}





// Guarda informaciÃ³n del titular
async function saveTitular() {
   const person = createPersonObject("COMERCIAL");
   try {
       const result = await wixData.insert("COMERCIAL", person);
       savedPersonId = result._id; // Guarda el ID para uso futuro
       console.log("Titular guardado con Ã©xito:", result);
   } catch (err) {
       handleError(err);
   }
}


async function loadLeaderOptions() {
    console.log("ejecutando Load Leader")
    try {
        const results = await wixData.query("COMERCIAL")
        .limit(300)
            .find();
console.log("Resultados obtenidos:", results.items.length);
        const options = results.items.map(item => {
            return {
                "label": item.primerNombre + " " + item.primerApellido,
                "value": item._id  // Almacenamos el ID como valor para uso posterior
            };
        });
        console.log(options)
        $w("#lider").options = options;
    } catch (err) {
        console.error("Error al cargar líderes:", err);
        showElementWithText("#aviso", "Error al cargar opciones de líder. Por favor, intente de nuevo.");
    }
}

async function loadFilialOptions() {
    try {
        const results = await wixData.query("FILIALES")
            .find();

        const options = results.items.map(item => {
            return {
                "label": item.filial,  // Asumiendo que el campo se llama 'nombreFilial'
                "value": item._id  // Guardamos el ID como valor para uso posterior
            };
        });

        $w("#filial").options = options;
    } catch (err) {
        console.error("Error al cargar filiales:", err);
        showElementWithText("#aviso", "Error al cargar opciones de filial. Por favor, intente de nuevo.");
    }
}


function setupFieldChangeHandlers() {
    const allFields = [
        "#primerNombre", "#segundoNombre", "#primerApellido", "#segundoApellido", "#numeroId",
        "#fechaNacimiento", "#pais", "#domicilio", "#ciudad", "#celular", "#telefono",
        "#email","#genero", "#lider"  // Asegúrate de que todos los selectores son correctos y tienen el prefijo '#'
    ];
    allFields.forEach(fieldId => {
        try {
            $w(fieldId).onChange(() => {
                let currentGroup = getCurrentGroup();
                let validation = validateCurrentGroupFields(currentGroup);
                if (validation.isValid) {
                    hideElement("#aviso");
                }
            });
        } catch (err) {
            console.error(`Error setting up change handler for ${fieldId}:`, err);
        }
    });
}



// Crea el objeto de la persona con todos los campos necesarios
function createPersonObject(tipoUsuario) {
    let partes = $w("#fechaNacimiento").value.split("/");
let fechaISO = `${partes[2]}-${partes[1].padStart(2,"0")}-${partes[0].padStart(2,"0")}`;
    let rawNumeroId = $w("#numeroId").value;
    let numeroIdLimpio = rawNumeroId.replace(/\D/g, ""); // Elimina todo menos números
    let clave = numeroIdLimpio.slice(-4);

    return {
        primerNombre: $w("#primerNombre").value,
        segundoNombre: $w("#segundoNombre").value,
        primerApellido: $w("#primerApellido").value,
        segundoApellido: $w("#segundoApellido").value,
        numeroId: rawNumeroId,
        clave: clave,
        fechaNacimiento: fechaISO,
        pais: $w("#pais").value,
        domicilio: $w("#domicilio").value,
        filial: $w("#filial").value,
        celular: $w("#celular").value,
        email: $w("#email").value,
        genero: $w("#genero").value,
        tipoUsuario: tipoUsuario,
        estado: "ACTIVO",
        foto: fotoUrl,
        rol: $w('#cargo').value,
        lider: $w('#lider').value
    };
}





// Muestra un elemento
function showElement(selector) {
   $w(selector).show();
}


// Oculta un elemento
function hideElement(selector) {
   $w(selector).hide();
}


// Muestra un elemento con texto especÃ­fico
function showElementWithText(selector, text) {
   const element = $w(selector);
   element.text = text;
   element.show();
}


// Maneja errores generales
function handleError(err) {
   console.error("Error: ", err);
   showElementWithText("#aviso", "Error al guardar la informaciÃ³n. Por favor, intente de nuevo.");
}


// Valida la fecha de nacimiento en tiempo real
function validateDateRealTime(event) {
   const inputId = "#" + event.target.id;
   let inputDate = $w(inputId).value;
   const regexSimple = /^[0-9/]*$/;


   if (!regexSimple.test(inputDate)) {
       $w(inputId).value = inputDate.slice(0, -1);
       return;
   }


   let parts = inputDate.split('/').filter(Boolean);
   if (parts.length === 1 && parts[0].length === 2 && inputDate.endsWith('/') === false && inputDate.length < 6) {
       $w(inputId).value += '/';
   } else if (parts.length === 2 && parts[1].length === 2 && inputDate.endsWith('/') === false && inputDate.length === 5) {
       $w(inputId).value += '/';
   } else if (inputDate.length > 10) {
       $w(inputId).value = inputDate.slice(0, 10);
   }
}


function validateCurrentGroupFields(groupNumber) {
  const groupFields = {
      1: ["#primerNombre", "#primerApellido", "#numeroId"],
      2: ["#fechaNacimiento", "#pais", "#filial"],
      3: ["#genero", "#email", "#celular", "#cargo", "#domicilio"],
      4: ["#lider"]
  };
  
  let isValid = true;
  let missingFields = [];

  groupFields[groupNumber].forEach(fieldId => {
      let fieldValue = $w(fieldId).value;

      // Verifica si el campo es un checkbox de múltiples selecciones
      if (Array.isArray(fieldValue)) {
          if (fieldValue.length === 0) {  // Chequea si el array está vacío, lo que significa que no se seleccionó ninguna opción
              missingFields.push($w(fieldId).placeholder || fieldId);
              isValid = false;
          }
      } else {
          // Para campos de texto normales, sigue usando trim para verificar campos vacíos
          if (fieldValue.trim() === "") {
              missingFields.push($w(fieldId).placeholder || fieldId);
              isValid = false;
          }
      }
  });

  return { isValid, missingFields };
}



// Cambia la visibilidad de un grupo de campos
function toggleGroupVisibility(groupNumber, show) {
   const groupId = `#group${groupNumber}`;
   if (show) {
       showElement(groupId);
   } else {
       hideElement(groupId);
   }
}


// Obtiene el grupo actual basado en la visibilidad de los grupos
function getCurrentGroup() {
   for (let i = 1; i <= 4; i++) {
       if (!$w(`#group${i}`).hidden) {
           return i;
       }
   }
   return 1; // Por defecto retorna el primer grupo si no se encuentra el actual
}
