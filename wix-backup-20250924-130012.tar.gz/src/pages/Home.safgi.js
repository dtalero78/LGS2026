import { testSendMessage } from 'backend/jobs';
import { queryAllContacts, deleteContactById, queryContactById } from 'backend/queryContacts';
import { triggeredEmails } from 'wix-crm';
    import { contacts } from "wix-crm-frontend";



function mostrarContactos(event) {
  queryAllContacts()
    .then((contactos) => {
      if (contactos) {
        console.log('Contactos obtenidos:', contactos);
      } else {
        console.log('No se encontraron contactos');
      }
    })
    .catch((error) => {
      console.error('Error al obtener los contactos:', error);
    });
}

export function query_click(event) {
	mostrarContactos()
}




$w.onReady(() => {
  $w('#crearContacto').onClick(() => {
    const contactInfo = {
      name: {
        first: $w('#primerNombre').value,
        last: $w('#primerApellido').value,
      },
      emails: [
        {
          email: $w('#email').value,
        }
      ]
    };

    contacts
      .appendOrCreateContact(contactInfo)
      .then((resolvedContact) => {
        console.log("Contacto creado:", resolvedContact);
        // Acceder al _id del contacto creado
        const contactId = resolvedContact.contactId;
        console.log("ID del contacto creado:", contactId);
        // Aquí puedes usar el contactId según tus necesidades
      })
      .catch((error) => {
        console.error("Error al crear el contacto:", error);
      });
  });
});



//BORRAR

export function borrarContactos_click_1(event) {


deleteContactById("a835ba2e-01a7-4255-b38f-b8c1c551853d")
    .then((result) => {
      if (result.success) {
        console.log('Contacto eliminado exitosamente.');
      } else {
        console.error('Error al eliminar el contacto:', result.error);
      }
    })
    .catch((error) => {
      console.error('Error al eliminar el contacto:', error);
    });
  
}


export function queryId_click(event) {
queryContactById("9bb1112b-f4fd-4269-a242-80c06f6e9f14")
    .then((contacto) => {
      if (contacto) {
        console.log('Contacto obtenido:', contacto);
      } else {
        console.log('No se encontró el contacto');
      }
    })
    .catch((error) => {
      console.error('Error al obtener el contacto:', error);
    });
}

export function enviarMail_click(event) {
    let contactId = $w('#contactId').value;
    triggeredEmails.emailContact('pruebaLGS', contactId)
        .then(() => {
            console.log(`Correo electrónico enviado al contacto con ID: ${contactId}`);
        })
        .catch(err => {
            console.error(`Error al enviar el correo electrónico al contacto con ID: ${contactId}`, err);
        });
}