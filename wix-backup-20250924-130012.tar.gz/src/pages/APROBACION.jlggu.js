import wixData from 'wix-data';
import { sendTextMessage, sendTextMessageServicioUsuario } from 'backend/WHP';
import wixWindow from 'wix-window';
import wixLocation from 'wix-location';

$w.onReady(function () {

    /*
        // -----  BLOQUE DE RECONOCIMIENTO DE TOKEN LOGIN
        const tokenData = JSON.parse(session.getItem('accessToken'));
        if (tokenData) {
            const currentTime = new Date().getTime();
            // Convertir el tiempo de expiración a una fecha legible
            const expirationDate = new Date(tokenData.expiresAt);
            console.log(`El token expira el: ${expirationDate.toLocaleString()}`);
            if (currentTime > tokenData.expiresAt) {
                // Token ha expirado
                session.removeItem('accessToken');
                console.log("Token Acabado") // Eliminar el token expirado
                wixLocation.to(`/login`); // Redirigir a una página de error o login
            } else {
                // Token es válido
                // Aquí puedes continuar cargando el contenido de la página
            }
        } else {
            console.log("Token Expirado") // Eliminar el token expirado
            wixLocation.to(`/login`); // Redirigir a una página de error o login
        }
        //
        */

    $w('#createStepButton').target = "_blank"

    mostrarUsuarioSeleccionado(); // Cargar todos los datos inicialmente

});

// Variables de paginación
let paginaActual = 0;
const registrosPorPagina = 10;
let totalPaginas = 0;
let allUsersData = []; // Guardará todos los datos obtenidos de la consulta
let filteredData = []; // Datos filtrados por la búsqueda

function mostrarUsuarioSeleccionado() {
    wixData.query("PEOPLE")
        .isEmpty("estado")
        .descending("_createdDate")
        .limit(1000)
        .find()
        .then((result) => {
            if (result.items.length > 0) {
                // Guardar todos los registros en memoria
                allUsersData = result.items.map((peopleData) => ({
                    _id: peopleData._id,
                    primerNombre: peopleData.primerNombre || "",
                    segundoNombre: peopleData.segundoNombre || "",
                    primerApellido: peopleData.primerApellido || "",
                    segundoApellido: peopleData.segundoApellido || "",
                    contrato: peopleData.contrato || "",
                    numeroId: peopleData.numeroId || "",
                    tipoUsuario: peopleData.tipoUsuario || "",
                    plataforma: peopleData.plataforma || "",
                    documentacion: peopleData.documentacion || []
                }));

                // Inicialmente mostramos todos los datos
                filteredData = allUsersData;
                totalPaginas = Math.ceil(filteredData.length / registrosPorPagina);
                actualizarRepetidorFiltrado(""); // Mostrar sin filtros
                $w("#allUsers").expand();
            } else {
                console.log("No se encontraron datos en ACADEMICA.");
                $w("#allUsers").collapse();
            }
        })
        .catch((err) => {
            console.error("Error en la consulta a ACADEMICA:", err);
            $w("#allUsers").collapse();
        });
}

// Función para actualizar el repetidor según el filtro
function actualizarRepetidorFiltrado(query) {
    filteredData = allUsersData.filter(item => {
        return (
            item.primerNombre.toLowerCase().includes(query.toLowerCase()) ||
            item.segundoNombre.toLowerCase().includes(query.toLowerCase()) ||
            item.primerApellido.toLowerCase().includes(query.toLowerCase()) ||
            item.segundoApellido.toLowerCase().includes(query.toLowerCase()) ||
            item.contrato.toLowerCase().includes(query.toLowerCase()) ||
            item.numeroId.toLowerCase().includes(query.toLowerCase()) ||
            item.nivel.toLowerCase().includes(query.toLowerCase()) ||
            item.plataforma.toLowerCase().includes(query.toLowerCase())
        );
    });

    paginaActual = 0;
    totalPaginas = Math.ceil(filteredData.length / registrosPorPagina);
    actualizarRepetidor();
}

// Función para actualizar el repetidor con la página actual
function actualizarRepetidor() {
    console.log("iniciando")
    const inicio = paginaActual * registrosPorPagina;
    const fin = inicio + registrosPorPagina;
    const datosPagina = filteredData.slice(inicio, fin);

    $w("#allUsers").data = datosPagina;

    // Configurar los elementos del repetidor
    $w("#allUsers").forEachItem(($item, itemData, index) => {

        $item("#primerNombre").value = itemData.primerNombre;
        $item("#segundoNombre").value = itemData.segundoNombre;
        $item("#primerApellido").value = itemData.primerApellido;
        $item("#segundoApellido").value = itemData.segundoApellido;
        $item("#contrato").value = itemData.contrato;
        $item("#numeroId").value = itemData.numeroId;
        $item('#plataforma').value = itemData.plataforma;
        $item('#tipoUsuario').value = itemData.tipoUsuario;

        $item("#aprobarButton").onClick(async () => {
            if (!$item("#aprobarButton").label.includes("✔")) {
                await crearRegistroAcademico(itemData._id, $item);
                $item("#aprobarButton").label = "✅ Listo";
                $item("#aprobarButton").disable();
            }

        });

        $item("#documentosButton").onClick(() => {
    const documentos = itemData.documentacion;

    if (!documentos || documentos.length === 0) {
        console.log("Este beneficiario no tiene documentos guardados.");
        return;
    }

    // Descargar cada documento (abre en nueva pestaña una por una)
   documentos.forEach((url) => {
    wixLocation.to(url);
});

});

    });

    if (paginaActual > 0) {
        $w("#backButton").enable();
    } else {
        $w("#backButton").disable();
    }

    if (paginaActual < totalPaginas - 1) {
        $w("#nextButton").enable();
    } else {
        $w("#nextButton").disable();
    }

}

// Eventos de paginación
$w("#backButton").onClick(() => {
    if (paginaActual > 0) {
        paginaActual--;
        actualizarRepetidor();
    }
});

$w("#nextButton").onClick(() => {
    if (paginaActual < totalPaginas - 1) {
        paginaActual++;
        actualizarRepetidor();
    }
});

async function crearRegistroAcademico(idPersona, $item) {
    try {
        // Obtener todos los datos del estudiante en PEOPLE
        const personaData = await wixData.get("PEOPLE", idPersona);
        if (!personaData) {
            console.error("No se encontró la persona en PEOPLE con ID:", idPersona);
            return;
        }

        // Obtener valores del repetidor en el contexto del ítem (o usar valores originales si están vacíos)
        const primerNombre = $item("#primerNombre").value || personaData.primerNombre;
        const segundoNombre = $item("#segundoNombre").value || personaData.segundoNombre;
        const primerApellido = $item("#primerApellido").value || personaData.primerApellido;
        const segundoApellido = $item("#segundoApellido").value || personaData.segundoApellido;
        const plataforma = $item("#plataforma").value || personaData.plataforma;
        const numeroId = $item("#numeroId").value || personaData.numeroId;
        //const nivel = $item("#nivel").value || personaData.nivel;
        const contrato = $item("#contrato").value || personaData.contrato;
        const step = personaData.ultimoStep || "";

        const idEstudiante = personaData._id;
        const usuarioId = personaData._id;
        const email = personaData.email;
        const celular = personaData.celular;

        // Crear el nuevo objeto para insertar en ACADEMICA
        const nuevoRegistroAcademico = {
            primerNombre,
            primerApellido,
            contrato,
            plataforma,
            //nivel,
            numeroId,
            idEstudiante,
            usuarioId,
            celular,
            email,
            step,
            clave: numeroId.substring(0, 4),
            aprobacion: "Aprobado" // 👈 AÑADIR AQUÍ
        };

        // Insertar en la colección ACADEMICA
        const result = await wixData.insert("ACADEMICA", nuevoRegistroAcademico);
        $item('#creadoText').show(); // Mostrar texto de creado

        const idAcademico = result._id; // Capturar el _id del registro creado en ACADEMICA

        // Actualizar cambios en PEOPLE
        const cambios = {};
        if (personaData.primerNombre !== primerNombre) cambios.primerNombre = primerNombre;
        if (personaData.segundoNombre !== segundoNombre) cambios.segundoNombre = segundoNombre;
        if (personaData.primerApellido !== primerApellido) cambios.primerApellido = primerApellido;
        if (personaData.segundoApellido !== segundoApellido) cambios.segundoApellido = segundoApellido;
        if (personaData.plataforma !== plataforma) cambios.plataforma = plataforma;
        if (personaData.numeroId !== numeroId) cambios.numeroId = numeroId;
        //if (personaData.nivel !== nivel) cambios.nivel = nivel;
        if (personaData.contrato !== contrato) cambios.contrato = contrato;
        if (personaData.ultimoStep !== step) cambios.ultimoStep = step;
        cambios.estado = "ACTIVA"; // Siempre se activa
        cambios.aprobacion = "Aprobado"; // 👈 AÑADIR AQUÍ

        if (Object.keys(cambios).length > 0) {
            const registroActualizado = { ...personaData, ...cambios };
            await wixData.update("PEOPLE", registroActualizado);
            console.log("Registro en PEOPLE actualizado correctamente:", step);
        } else {
            console.log("No hubo cambios en PEOPLE.");
        }

        // Preparar y enviar mensaje de WhatsApp
        const message = `Hola 👋:\n\n*¡Eres parte de Lets Go Speak!* 🎉 \n\nPara terminar tu registro y crear tu usuario sigue este enlace:\n\nhttps://www.lgsplataforma.com/nuevo-usuario/${idAcademico}`;
        await enviarFormularioCreacionUsuario(celular, message);

        return idAcademico;

    } catch (err) {
        console.error("Error al crear el registro académico y actualizar PEOPLE:", err);
    }
}

//-----------

$w('#search').onInput(() => {
    actualizarRepetidorFiltrado($w("#search").value);
});

function enviarFormularioCreacionUsuario(celular, message) {
    return sendTextMessageServicioUsuario(celular, message)
        .then(response => {
            console.log("Actividad enviada", response);
            $w('#loading').hide();
        })
        .catch(err => {
            console.error("Error al enviar actividad", err);
        });
}