import wixData from 'wix-data';
import wixStorage from 'wix-storage';
import wixWindow from 'wix-window';
import wixRealtimeFrontend from 'wix-realtime-frontend';
import wixLocation from 'wix-location';
import { session } from 'wix-storage';

let debounceTimer;
const debounceDelay = 500; // Tiempo en milisegundos
let idUsuario;
let lastButtonClicked = ''; // 'gestionNueva' o 'pendientesHoy'
let isOpen = false; // Variable para controlar el estado de la tabla suscriptoresTable
const ITEMS_PER_PAGE = 7; // Número de elementos por página
let totalItems = 0; // Total de elementos para la paginación
let currentPage = 1; // Página actual

const suscribeToUpdates = () => {
    const channel = { "name": "calificacionUsuario" };
    wixRealtimeFrontend.subscribe(channel, (message, channel) => {
            let payload = message.payload;
            console.log("Mensaje recibido:", message, channel); // Verifica que el mensaje se recibe correctamente
            if (payload.type === "updateComplete") {
                console.log("Ejecutando cargarNuevosProspectos...");
                filtrarProspectos();
            } else {
                console.log("Tipo de mensaje no coincide: ", payload.type);
            }
        })
        .then((id) => {
            console.log("Suscripción a updates exitosa con ID:", id);
        })
        .catch(err => {
            console.error("Error en la suscripción a updates:", err);
        });
}

$w.onReady(async function () {

    // -----  BLOQUE DE RECONOCIMIENTO DE TOKEN LOGIN

    const tokenData = JSON.parse(session.getItem('accessToken'));
    if (tokenData) {
        const currentTime = new Date().getTime();
        // Convertir el tiempo de expiración a una fecha legible
        const expirationDate = new Date(tokenData.expiresAt);
        console.log(`El token expira el: ${expirationDate.toLocaleString()}`);
        if (currentTime > tokenData.expiresAt) {
            // Token ha expirado
            session.removeItem('accessToken');
            console.log("Token Acabado") // Eliminar el token expirado
            wixLocation.to(`/login`); // Redirigir a una página de error o login
        } else {
            // Token es válido
            // Aquí puedes continuar cargando el contenido de la página
        }
    } else {
        console.log("Token Expirado") // Eliminar el token expirado
        wixLocation.to(`/login`); // Redirigir a una página de error o login
    }
    //

    suscribeToUpdates();

    lastButtonClicked = 'gestionNueva'; // Asignar el valor automáticamente

    const query = wixLocation.query;
    const usuarioEmail = decodeURIComponent(query.email); // Obtiene el email de los parámetros de la URL
    console.log(usuarioEmail)
    if (usuarioEmail) {
        try {
            const results = await wixData.query("ADVISORS")
                .eq("email", usuarioEmail)
                .find();
            $w('#nombreAdvisor').text = "¡Hola " + results.items[0].primerNombre + "!"
            if (results.items.length > 0) {
                idUsuario = results.items[0]._id;
                await filtrarProspectos();
            }
        } catch (error) {
            console.error("Error en la búsqueda del usuario", error);
        }
    }

    // INICIO BUSCADOR
    $w("#search").onKeyPress((event) => {
        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(() => {
            realizarBusqueda($w("#search").value);
        }, debounceDelay);
    });
    // FIN BUSCADOR

    $w('#eventosPendientesButton').onClick(async () => {
        lastButtonClicked = 'eventosPendientes';
        await cargaEventosPendientes(true); // true para eventos pendientes
    });

    $w('#eventosCerradosButton').onClick(async () => {
        lastButtonClicked = 'eventosCerrados';
        await cargaEventosPendientes(false); // false para eventos cerrados
    });
});

function capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1).toLowerCase();
}

// BUSCADOR
function realizarBusqueda(query) {
    $w('#todosLosRepeaters').collapse();
    $w('#noExiste').hide();

    console.log("ID en motor:", idUsuario); // Verifica que el idUsuario actual se imprime correctamente

    // Si el input está vacío o contiene menos de 3 caracteres, resetea el estado sin buscar
    if (query.length < 3) {
        $w("#resultadoBusqueda").data = []; // Limpia los datos del repetidor
        $w('#resultadoBusqueda').collapse(); // Esconde el repetidor
        return; // Sale de la función para no ejecutar una búsqueda
    }

    // Muestra el indicador de carga
    $w('#loading').expand();

    // Realizar búsquedas simultáneamente en ambas colecciones
    const academicaQuery = wixData.query("ACADEMICA")
        .eq("advisor", idUsuario)
        .contains("numeroId", query)
        .or(wixData.query("ACADEMICA").eq("advisor", idUsuario).contains("primerNombre", query))
        .or(wixData.query("ACADEMICA").eq("advisor", idUsuario).contains("primerApellido", query))
        .find();

    const advisorsQuery = wixData.query("ADVISORS")
        .contains("numeroId", query)
        .or(wixData.query("ADVISORS").contains("primerNombre", query))
        .or(wixData.query("ADVISORS").contains("primerApellido", query))
        .find();

    // Ejecutar ambas promesas en paralelo
    Promise.all([academicaQuery, advisorsQuery])
        .then(([academicaResults, advisorsResults]) => {
            const combinedResults = [];

            // Procesar resultados de ACADEMICA
            academicaResults.items.forEach(item => {
                combinedResults.push({
                    _id: item._id,
                    primerNombre: item.primerNombre,
                    primerApellido: item.primerApellido,
                    segundoApellido: item.segundoApellido || "",
                    fuente: "ACADEMICA", // Aquí se asigna
                    numeroId: item.numeroId || "N/A"
                });
            });

            // Procesar resultados de ADVISORS
            advisorsResults.items.forEach(item => {
                combinedResults.push({
                    _id: item._id,
                    primerNombre: item.primerNombre,
                    primerApellido: item.primerApellido,
                    segundoApellido: "", // ADVISORS no tiene campo segundoApellido
                    fuente: "ADVISORS", // Aquí se asigna
                    numeroId: item.numeroId || "N/A"
                });
            });

            if (combinedResults.length > 0) {
                // Mostrar los resultados combinados
                procesarResultados(combinedResults);
            } else {
                // Si no hay resultados en ninguna colección
                $w('#noExiste').show();
                $w('#resultadoBusqueda').collapse();
            }
        })
        .catch(err => {
            console.error("Error al realizar las búsquedas", err);
            $w('#noExiste').show();
            $w('#resultadoBusqueda').collapse();
        })
        .finally(() => {
            $w('#loading').collapse(); // Esconde el indicador de carga al final
        });
}

function procesarResultados(resultados) {
    $w("#resultadoBusqueda").data = resultados;
    $w('#resultadoBusqueda').expand(); // Muestra el repetidor con los resultados

    $w('#resultadoBusqueda').forEachItem(($item, itemData, index) => {
        const fuenteTexto = itemData.fuente === "ACADEMICA" ? "(ACADEMICA)" : "(ADVISORS)";

        $item("#resultados").text = `ID: ${itemData.numeroId}, ${capitalizeFirstLetter(itemData.primerNombre)} ${capitalizeFirstLetter(itemData.primerApellido)} ${itemData.segundoApellido ? capitalizeFirstLetter(itemData.segundoApellido) : ''} ${fuenteTexto}`;

        // Configuración del evento onClick para realizar la redirección
        $item("#resultados").onClick(() => {
            console.log("Datos del item seleccionado:", itemData); // Verifica que itemData.fuente esté presente
            redirectUserProfile(itemData.numeroId, null, false, true, itemData.fuente);
            console.log("ESTES 1", itemData.numeroId)
        });
    });
}

async function filtrarProspectos() {
    await cargaEventosPendientes(true); // true para eventos futuros por defecto
}

async function cargaEventosPendientes(pendientes = true, page = 1) {
    if (!idUsuario) {
        console.log("idUsuario no está definido");
        return;
    }

    try {
        const now = new Date();
        let oneHourAgo = new Date(now.getTime() - (60 * 60 * 1000)); // Restar 1 hora
        console.log("Hora actual:", now);
        console.log("Hace una hora:", oneHourAgo);

        let query = wixData.query("CALENDARIO")
            .eq("advisor", idUsuario);

        if (pendientes) {
            // Para eventos pendientes, incluimos los que están en curso
            query = query.ge("dia", now).or(query.between("dia", oneHourAgo, now)); // Considera eventos en curso
        } else {
            // Para eventos cerrados, buscamos eventos que hayan pasado más de una hora
            query = query.lt("dia", oneHourAgo);
        }

        // Obtener el número total de eventos para paginar
        totalItems = await query.count();

        // Agregar paginación
        query = query.limit(ITEMS_PER_PAGE).skip((page - 1) * ITEMS_PER_PAGE);

        const results = await query.find();

        const eventosPendientes = [];
        const eventosCerrados = [];

        // Para cada evento, obtener los estudiantes inscritos y su estado de calificación
        for (let item of results.items) {
            const idEvento = item._id;

            // Obtener los estudiantes inscritos en la clase desde la colección CLASSES
            const estudiantesInscritos = await wixData.query("CLASSES")
                .eq("idEvento", idEvento)
                .find();

            // Filtrar aquellos estudiantes que no han sido calificados
            const noCalificados = estudiantesInscritos.items.filter(estudiante => !estudiante.calificacion);
            const estudiantesInscritosCount = estudiantesInscritos.items.length; // Cantidad de inscritos
            const estudiantesNoCalificados = noCalificados.length; // Cantidad de estudiantes no calificados

            // Agregar los datos relevantes al evento actual
            item.estudiantesInscritosCount = estudiantesInscritosCount;
            item.estudiantesNoCalificados = estudiantesNoCalificados;

            if (pendientes) {
                eventosPendientes.push(item);
            } else {
                eventosCerrados.push(item);
            }
        }

        // Asignar los eventos al repetidor
        if (pendientes) {
            $w('#eventosPendientes').data = eventosPendientes;
        } else {
            $w('#eventosPendientes').data = eventosCerrados;
        }

        // Configuración del repetidor
        $w('#eventosPendientes').onItemReady(($item, itemData, index) => {

            const estudiantesNoCalificados = itemData.estudiantesNoCalificados || 0;
            const estudiantesInscritosCount = itemData.estudiantesInscritosCount || 0;

            // Mostrar inscritos o por calificar
            if (new Date(itemData.dia) >= now) {
                $item('#suscripcionesRepeaterEventosPendientes').text = `${estudiantesInscritosCount} inscritos`;
            } else {
                $item('#suscripcionesRepeaterEventosPendientes').text = estudiantesNoCalificados > 0 ?
                    `${estudiantesNoCalificados} por calificar` :
                    "Todos calificados";
            }

            $item('#tipoEventoRepeater').text = itemData.evento;

            // Formatear la fecha y hora
            const fecha = new Date(itemData.dia);

            const diasSemana = ["Domingo", "Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado"];
            const mesesCortos = ["Ene", "Feb", "Mar", "Abr", "May", "Jun", "Jul", "Ago", "Sep", "Oct", "Nov", "Dic"];

            const nombreDia = diasSemana[fecha.getDay()];
            const nombreMes = mesesCortos[fecha.getMonth()];
            const numeroDia = fecha.getDate();
            const hora = fecha.getHours();
            const minutos = fecha.getMinutes();

            const fechaFormateada = `${nombreDia} ${numeroDia} ${nombreMes}, ${hora}:${minutos < 10 ? '0' : ''}${minutos}`;
            $item('#fechaRepeaterClasesPendientes').text = fechaFormateada;

            $item('#tituloRepeaterClasesPendientes').text = itemData.nombreEvento;

            // Aquí va el bloque que maneja la tabla de suscriptores
            $item('#suscripcionesRepeaterEventosPendientes').onClick(async () => {
                if (isOpen) {
                    $item('#suscriptoresTable').collapse();
                    isOpen = false;
                } else {
                    try {
                        // Obtener los suscriptores del evento desde BOOKING
                        const suscriptores = await wixData.query("BOOKING")
                            .eq("idEvento", itemData._id)
                            .isEmpty("cancelo") // Filtrar donde el campo cancelo esté vacío
                            .find();

                        // Extraer los IDs de los estudiantes
                        const estudianteIds = [...new Set(suscriptores.items.map(suscriptor => suscriptor.idEstudiante))];
                        console.log("IDs de los estudiantes:", estudianteIds);

                        // Hacer un query a la base de datos ACADEMICA para obtener los datos de los estudiantes
                        const estudiantes = await wixData.query("ACADEMICA")
                            .hasSome("_id", estudianteIds)
                            .find();

                        console.log("Datos de los estudiantes obtenidos:", estudiantes.items);

                        // Formatear los datos para la tabla
                        const formattedData = estudiantes.items.map(estudiante => ({
                            nombreCompleto: `${estudiante.primerNombre} ${estudiante.primerApellido}`,
                            pais: estudiante.plataforma,
                            edad: estudiante.edad
                        }));

                        $item('#suscriptoresTable').columns = [
                            { id: 'nombreCompleto', label: 'Nombre Completo', dataPath: 'nombreCompleto', type: 'string' },
                            { id: 'pais', label: 'País', dataPath: 'pais', type: 'string' },
                            { id: 'edad', label: 'Edad', dataPath: 'edad', type: 'number' }
                        ];

                        // Asignar los datos formateados a la tabla
                        $item('#suscriptoresTable').rows = formattedData;

                        // Mostrar la tabla con los suscriptores
                        $item('#suscriptoresTable').expand();
                        isOpen = true;
                    } catch (err) {
                        console.error("Error al obtener los suscriptores", err);
                    }
                }
            });

            const idEvento = itemData._id; // Definir idEvento en el scope adecuado
            $item('#irAlEventoButton').link = (`/sesion/${idEvento}`);
            $item('#irAlEventoButton').target = "_blank";

            // Añadir el evento de clic a la tabla de suscriptores
            $item('#suscriptoresTable').onRowSelect(event => {
                const selectedRowData = event.rowData;
                redirectUserProfile(selectedRowData.numeroId, itemData._id, false, true);
            });
        });

        // Mostrar el título del repetidor con el conteo correcto
        if (pendientes) {
            $w('#tituloRepeaters').text = "Eventos pendientes (" + eventosPendientes.length + ")";
        } else {
            $w('#tituloRepeaters').text = "Eventos cerrados (" + eventosCerrados.length + ")";
        }

        // Configuración de la paginación
        configurarPaginacion();
    } catch (error) {
        console.error("Error al cargar los datos:", error);
    }
}

function configurarPaginacion() {
    const totalPages = Math.ceil(totalItems / ITEMS_PER_PAGE);

    $w('#paginacion').currentPage = currentPage; // Configura la página actual
    $w('#paginacion').totalPages = totalPages; // Total de páginas

    // Al cambiar de página, recargar los datos
    $w('#paginacion').onChange(async (event, $w) => {
        const pageIndex = $w("#paginacion").currentPage; // Obtener el número de página actual
        currentPage = pageIndex; // Actualiza la página actual
        await cargaEventosPendientes(lastButtonClicked === 'eventosPendientes', currentPage); // Recargar con la nueva página
    });
}

function redirectUserProfile(userId, eventId, showPrimerContactoBox, showSegundoContactoBox, fuente) {
    console.log("Redirigiendo con los siguientes datos:");
    console.log("userId:", userId, "eventId:", eventId, "fuente:", fuente);

    wixStorage.local.setItem('userId', userId);
    wixStorage.local.setItem('showPrimerContactoBox', showPrimerContactoBox.toString());
    wixStorage.local.setItem('showSegundoContactoBox', showSegundoContactoBox.toString());
    console.log("Enviado a Lightbox:", userId);

    if (fuente === "ACADEMICA") {
        wixWindow.openLightbox("FICHA CLASE USER", { userId });
    } else if (fuente === "ADVISORS") {
        console.log("Abriendo FICHA ADVISOR");
        wixWindow.openLightbox("FICHA ADVISOR", { userId });
    } else {
        console.error("Fuente desconocida:", fuente);
    }
}

$w('#buttonLibrosLGS').onClick((event) => {
    $w('#librosLGS').show()
})

$w('#closeButtLibros').onClick((event) => {
    $w('#librosLGS').hide()
})